#![no_main]
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    let _ = verdant_iso8583_switch::run_interchange_advice_pipeline(data);
});
