#![no_main]
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    if data.len() < 40 {
        return;
    }
    let span = data.len().saturating_sub(4);
    let mut at = ((u16::from_le_bytes([data[0], data[1]]) as usize) % span) + 2;
    at = at.max(16).min(data.len().saturating_sub(12));
    let (first, second) = data.split_at(at);
    let _ = verdant_iso8583_switch::route_auth_message_stream(first);
    let _ = verdant_iso8583_switch::route_auth_message_stream(second);
});
