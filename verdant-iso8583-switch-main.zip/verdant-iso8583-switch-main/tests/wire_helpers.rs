//! Inline VIS wire samples for integration tests.

pub fn sample_settle_batch_wire() -> Vec<u8> {
    let payload: [u8; 9] = [0x9F, 0x02, 0x06, 0x00, 0x00, 0x00, 0x00, 0x50, 0x00];
    let mut out = Vec::new();
    out.extend_from_slice(b"VISB");
    out.extend_from_slice(&2u16.to_le_bytes());
    out.extend_from_slice(&1u32.to_le_bytes());
    out.extend_from_slice(&0u32.to_le_bytes());
    out.extend_from_slice(&7u16.to_le_bytes());
    out.extend_from_slice(&0x0001u16.to_le_bytes());
    out.extend_from_slice(&100_001u32.to_le_bytes());
    out.extend_from_slice(&0u32.to_le_bytes());
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&((1 << 16) | 5411u32).to_le_bytes());
    out.extend_from_slice(&payload);
    out
}

pub fn sample_auth_capsule_wire() -> Vec<u8> {
    let payload = b"AUTHROUTECHANNELPAYLOAD!!";
    let mut out = Vec::new();
    out.extend_from_slice(b"VISA");
    out.extend_from_slice(&2u16.to_le_bytes());
    out.extend_from_slice(&1u16.to_le_bytes());
    out.extend_from_slice(&9u16.to_le_bytes());
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(&0u16.to_le_bytes());
    out.extend_from_slice(payload);
    out
}
