mod wire_helpers;

use verdant_iso8583_switch::merchant::auth_hold_registry::AuthHoldRegistry;
use verdant_iso8583_switch::merchant::capture_reconciliation::CaptureReconciler;
use verdant_iso8583_switch::merchant::interchange_tier_matrix::compute_interchange_minor;
use verdant_iso8583_switch::protocol::iso8583_builder::build_auth_request;
use verdant_iso8583_switch::protocol::iso8583_parser::parse_iso8583_message;
use verdant_iso8583_switch::run_settle_batch_pipeline;
use verdant_iso8583_switch::route_auth_message_stream;

#[test]
fn interchange_fee_for_grocery_mcc() {
    let fee = compute_interchange_minor(10_000, 1, 5411);
    assert!(fee > 0);
    assert!(fee < 10_000);
}

#[test]
fn auth_hold_capture_reconcile() {
    let mut holds = AuthHoldRegistry::new();
    holds.place_hold(42, 25_000);
    let mut rec = CaptureReconciler::new();
    rec.reconcile(&holds, &[(42, "RRN42".into(), 25_000)]);
    assert_eq!(rec.matches.len(), 1);
    assert_eq!(rec.orphan_captures, 0);
}

#[test]
fn parse_auth_request_wire() {
    let wire = build_auth_request("4111111111111111", "000000005000", "999001", "TERM0001", "MERCH0000000001");
    let msg = parse_iso8583_message(&wire).expect("parse");
    assert_eq!(msg.mti, 200);
    assert_eq!(msg.stan(), Some(999001));
}

#[test]
fn route_capsule_nonzero_on_valid_magic() {
    let wire = wire_helpers::sample_auth_capsule_wire();
    let crc = route_auth_message_stream(&wire);
    assert_ne!(crc, 0);
}

#[test]
fn settle_batch_pipeline_runs() {
    let wire = wire_helpers::sample_settle_batch_wire();
    let crc = run_settle_batch_pipeline(&wire).expect("pipeline");
    assert_ne!(crc, 0);
}
