# VIS wire formats — Verdant ISO8583 Switch

Internal binary formats used between the acquiring switch, issuer host, and settlement batch exporter. ISO8583 field layouts follow `iso8583_field_registry`.

## VISB — settlement batch

| Offset | Field |
|--------|-------|
| 0 | Magic `VISB` |
| 4 | Version u16 LE |
| 6 | Record count u32 LE |
| 10 | Flags u32 LE (bit0 compact, bit1 shrink) |
| 14 | Acquirer id u16 LE |
| 16+ | Records (18 bytes each) |
| end | Payload arena |

Record (18 bytes): `mti_class u16`, `stan u32`, `payload_offset u32`, `payload_len u32`, `merchant_tag u32`.

## VISA — auth route capsule

Magic `VISA`, version u16, root count u16, recursive nodes:

`channel u16`, `depth u16`, `payload_len u32`, `child_count u16`, `flags u16`, payload, children.

## VIST — terminal session frame

Magic `VIST`, version u16, batch_id u32, leg_count u32, graft_flags u32, repeated legs.

Each leg: `leg_id u32`, `terminal_id u32`, `amount_minor i64`, `track_len u32`, track bytes.

## ISO8583

Standard 4-digit MTI + 8-byte primary bitmap (+ optional secondary). Fields encoded per `iso8583_field_registry`.

## FIX gateway subset

SOH-delimited tag=value frames for host connectivity (`fix_gateway`). Desk custom tags 5500–5509 carry merchant id, terminal id, MCC, and batch reference.

## SWIFT settlement advice

Text MT n96-style blocks with `:20:` reference, `:32A:` value date / currency / amount (`swift_advice`).
