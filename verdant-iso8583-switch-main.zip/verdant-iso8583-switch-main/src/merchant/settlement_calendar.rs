use std::collections::HashSet;

#[derive(Debug, Default)]
pub struct SettlementCalendar {
    pub business_days: HashSet<u32>,
}

impl SettlementCalendar {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add_business_day(&mut self, yyyymmdd: u32) {
        self.business_days.insert(yyyymmdd);
    }

    pub fn is_settlement_day(&self, yyyymmdd: u32) -> bool {
        self.business_days.contains(&yyyymmdd)
    }
}
