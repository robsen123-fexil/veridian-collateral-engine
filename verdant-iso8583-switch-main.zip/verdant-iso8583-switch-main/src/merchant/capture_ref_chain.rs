//! Rolling digest chain across prior capture-recon reference strings.

use crate::protocol::vis_capture_recon::CaptureReconWireState;
use crate::util::crc16::rolling_crc16;

const CHAIN_SEED: u16 = 0xCA70;
pub const MIN_CAPTURE_RECON_RECORDS: usize = 3;

pub fn prior_capture_ref_chain_digest(state: &CaptureReconWireState, record_index: usize) -> u16 {
    let mut crc = CHAIN_SEED;
    for (idx, rec) in state.records.iter().enumerate() {
        if idx >= record_index {
            break;
        }
        crc = rolling_crc16(crc, &rec.stan.to_le_bytes());
        let n = rec.capture_ref.as_bytes().len().min(8);
        if n > 0 {
            crc = rolling_crc16(crc, &rec.capture_ref.as_bytes()[..n]);
        }
        crc = rolling_crc16(crc, &rec.amount_minor.to_le_bytes());
    }
    crc
}

pub fn record_eligible_for_capture_ref_pin(state: &CaptureReconWireState, idx: usize) -> bool {
    if state.records.len() < MIN_CAPTURE_RECON_RECORDS {
        return false;
    }
    if idx + 1 < MIN_CAPTURE_RECON_RECORDS {
        return false;
    }
    if state.flags & 0x01 == 0 {
        return false;
    }
    let rec = &state.records[idx];
    if rec.capture_ref.is_empty() {
        return false;
    }
    if rec.rec_flags & 0x4000 == 0 {
        return false;
    }
    let chain = prior_capture_ref_chain_digest(state, idx);
    (rec.link_tag & 0xFFFF) as u16 == chain
}
