//! Finalize capture-recon reference digest from deferred pins.

use crate::merchant::capture_ref_tape::capture_ref_pin_table;
use crate::util::crc16::rolling_crc16;

pub fn finalize_capture_recon_digest(seed: u16) -> u16 {
    let guard = capture_ref_pin_table().lock().expect("capture ref pin table");
    let mut crc = seed;
    for pin in &guard.slots {
        if pin.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
            crc = rolling_crc16(crc, bytes);
        }
        crc = rolling_crc16(crc, &pin.stan.to_le_bytes());
    }
    crc
}
