//! Deferred RRN byte pins for capture-hold reconciliation.

use crate::merchant::auth_hold_registry::AuthHoldRegistry;
use crate::merchant::hold_wire_flags::HOLD_FLAG_RESET_PIN_EPOCH;
use crate::protocol::vis_capture_hold::CaptureHoldWireState;
use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
pub struct HoldRrnPin {
    pub stan: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct HoldRrnPinBoard {
    pub slots: Vec<HoldRrnPin>,
    pub capture_epoch: u32,
}

unsafe impl Send for HoldRrnPinBoard {}
unsafe impl Sync for HoldRrnPinBoard {}

static HOLD_RRN_PIN_TABLE: Mutex<HoldRrnPinBoard> = Mutex::new(HoldRrnPinBoard {
    slots: Vec::new(),
    capture_epoch: 0,
});

pub fn hold_rrn_pin_table() -> &'static Mutex<HoldRrnPinBoard> {
    &HOLD_RRN_PIN_TABLE
}

pub fn capture_hold_rrn_pins(state: &CaptureHoldWireState, registry: &AuthHoldRegistry) {
    let table = hold_rrn_pin_table();
    let mut guard = table.lock().expect("hold pin table");
    if state.flags & HOLD_FLAG_RESET_PIN_EPOCH != 0 {
        guard.slots.clear();
    }
    guard.capture_epoch = guard.capture_epoch.wrapping_add(1);
    for (idx, rec) in state.records.iter().enumerate() {
        if !crate::merchant::hold_rrn_chain::record_eligible_for_rrn_pin(state, idx) {
            continue;
        }
        if let Some(hold) = registry.lookup_by_stan(rec.stan) {
            let bytes = hold.rrn.as_bytes();
            if bytes.is_empty() {
                continue;
            }
            unsafe {
                guard.slots.push(HoldRrnPin {
                    stan: rec.stan,
                    ptr: bytes.as_ptr(),
                    len: bytes.len(),
                });
            }
        }
    }
}
