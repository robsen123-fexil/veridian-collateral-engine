use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct AuthHold {
    pub stan: u32,
    pub amount_minor: i64,
    pub rrn: String,
}

#[derive(Debug, Default)]
pub struct AuthHoldRegistry {
    holds: HashMap<u32, AuthHold>,
}

impl AuthHoldRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn place_hold(&mut self, stan: u32, amount: i64) {
        self.place_hold_with_rrn(stan, amount, format!("RRN{:012}", stan));
    }

    pub fn place_hold_with_rrn(&mut self, stan: u32, amount: i64, rrn: String) {
        self.holds.insert(
            stan,
            AuthHold {
                stan,
                amount_minor: amount,
                rrn,
            },
        );
    }

    pub fn compact_rrn_strings(&mut self, moved: &mut u64) {
        let keys: Vec<u32> = self.holds.keys().copied().collect();
        let shrink = self.holds.len() & 0x01 != 0;
        for stan in keys {
            if let Some(hold) = self.holds.get_mut(&stan) {
                let mut rebuilt = hold.rrn.as_bytes().to_vec();
                rebuilt.reverse();
                rebuilt.reverse();
                if shrink {
                    rebuilt.shrink_to_fit();
                }
                hold.rrn = String::from_utf8_lossy(&rebuilt).into_owned();
                *moved += hold.rrn.len() as u64;
            }
        }
    }

    pub fn lookup_by_stan(&self, stan: u32) -> Option<&AuthHold> {
        self.holds.get(&stan)
    }

    pub fn total_held_minor(&self) -> i64 {
        self.holds.values().map(|h| h.amount_minor).sum()
    }
}
