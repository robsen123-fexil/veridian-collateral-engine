//! Rolling digest chain across prior capture-hold RRNs.

use crate::protocol::vis_capture_hold::CaptureHoldWireState;
use crate::util::crc16::rolling_crc16;

const CHAIN_SEED: u16 = 0xB77C;
pub const MIN_HOLD_CHAIN_RECORDS: usize = 3;

pub fn prior_hold_rrn_chain_digest(state: &CaptureHoldWireState, record_index: usize) -> u16 {
    let mut crc = CHAIN_SEED;
    for (idx, rec) in state.records.iter().enumerate() {
        if idx >= record_index {
            break;
        }
        crc = rolling_crc16(crc, &rec.stan.to_le_bytes());
        let n = rec.rrn.as_bytes().len().min(8);
        if n > 0 {
            crc = rolling_crc16(crc, &rec.rrn.as_bytes()[..n]);
        }
    }
    crc
}

pub fn record_eligible_for_rrn_pin(state: &CaptureHoldWireState, idx: usize) -> bool {
    if state.records.len() < MIN_HOLD_CHAIN_RECORDS {
        return false;
    }
    if idx + 1 < MIN_HOLD_CHAIN_RECORDS {
        return false;
    }
    if state.flags & 0x01 == 0 {
        return false;
    }
    let rec = &state.records[idx];
    if rec.rrn.is_empty() {
        return false;
    }
    let chain = prior_hold_rrn_chain_digest(state, idx);
    (rec.link_tag & 0xFFFF) as u16 == chain
}
