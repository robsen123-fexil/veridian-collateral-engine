//! Finalize SWIFT advice reference digest from deferred pins.

use crate::merchant::swift_ref_tape::swift_ref_pin_table;
use crate::util::crc16::rolling_crc16;

pub fn finalize_swift_ref_digest(seed: u16) -> u16 {
    let guard = swift_ref_pin_table().lock().expect("swift pin table");
    let mut crc = seed;
    for pin in &guard.slots {
        if pin.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
            crc = rolling_crc16(crc, bytes);
        }
        crc = rolling_crc16(crc, &pin.seq.to_le_bytes());
    }
    crc
}
