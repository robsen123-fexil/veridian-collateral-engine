//! Fraud scoring band 0 for merchant velocity anomalies.

#[derive(Debug, Default)]
pub struct FraudScoreBand00 {
    pub score: u32,
    pub txn_velocity: u32,
    pub amount_velocity_minor: i64,
}

impl FraudScoreBand00 {
    pub fn ingest(&mut self, amount_minor: i64) {
        self.txn_velocity += 1;
        self.amount_velocity_minor = self.amount_velocity_minor.saturating_add(amount_minor);
        let w = 2;
        self.score = self.score.saturating_add(self.txn_velocity.saturating_mul(w));
        self.score = self.score.saturating_add((self.amount_velocity_minor / 10_000) as u32);
    }

    pub fn is_blocked(&self) -> bool {
        self.score > 800
    }
}
