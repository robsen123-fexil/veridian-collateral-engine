#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ChargebackReason {
    Fraud,
    Service,
    Duplicate,
    ProcessingError,
}

pub fn classify_chargeback_narrative(text: &str) -> ChargebackReason {
    let lower = text.to_ascii_lowercase();
    if lower.contains("fraud") || lower.contains("stolen") {
        ChargebackReason::Fraud
    } else if lower.contains("duplicate") {
        ChargebackReason::Duplicate
    } else if lower.contains("service") || lower.contains("goods") {
        ChargebackReason::Service
    } else {
        ChargebackReason::ProcessingError
    }
}
