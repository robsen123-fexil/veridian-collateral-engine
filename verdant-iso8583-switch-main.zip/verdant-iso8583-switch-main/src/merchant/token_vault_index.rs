use std::collections::HashMap;

#[derive(Debug, Default)]
pub struct TokenVaultIndex {
    pub pan_token: HashMap<String, String>,
}

impl TokenVaultIndex {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn tokenize(&mut self, pan: &str) -> String {
        let token = format!("TOK{:016x}", crc32fast(pan.as_bytes()));
        self.pan_token.insert(pan.to_string(), token.clone());
        token
    }

    pub fn detokenize(&self, token: &str) -> Option<&str> {
        self.pan_token.iter().find(|(_, t)| t.as_str() == token).map(|(p, _)| p.as_str())
    }
}

fn crc32fast(data: &[u8]) -> u32 {
    let mut crc = 0xFFFF_FFFFu32;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 {
            crc = if crc & 1 != 0 {
                (crc >> 1) ^ 0xEDB8_8320
            } else {
                crc >> 1
            };
        }
    }
    !crc
}
