//! Interchange fee tier matrix by card product and MCC band.

#[derive(Debug, Clone, Copy)]
pub struct InterchangeTier { pub product: u8, pub mcc_lo: u16, pub mcc_hi: u16, pub bps: u32, pub cap_minor: i64 }

pub const TIERS: &[InterchangeTier] = &[
    InterchangeTier { product: 1, mcc_lo: 1000, mcc_hi: 1199, bps: 150, cap_minor: 50000 },
    InterchangeTier { product: 2, mcc_lo: 1200, mcc_hi: 1399, bps: 157, cap_minor: 51000 },
    InterchangeTier { product: 3, mcc_lo: 1400, mcc_hi: 1599, bps: 164, cap_minor: 52000 },
    InterchangeTier { product: 4, mcc_lo: 1600, mcc_hi: 1799, bps: 171, cap_minor: 53000 },
    InterchangeTier { product: 5, mcc_lo: 1800, mcc_hi: 1999, bps: 178, cap_minor: 54000 },
    InterchangeTier { product: 6, mcc_lo: 2000, mcc_hi: 2199, bps: 185, cap_minor: 55000 },
    InterchangeTier { product: 7, mcc_lo: 2200, mcc_hi: 2399, bps: 192, cap_minor: 56000 },
    InterchangeTier { product: 8, mcc_lo: 2400, mcc_hi: 2599, bps: 199, cap_minor: 57000 },
    InterchangeTier { product: 9, mcc_lo: 2600, mcc_hi: 2799, bps: 206, cap_minor: 58000 },
    InterchangeTier { product: 10, mcc_lo: 2800, mcc_hi: 2999, bps: 213, cap_minor: 59000 },
    InterchangeTier { product: 11, mcc_lo: 3000, mcc_hi: 3199, bps: 220, cap_minor: 60000 },
    InterchangeTier { product: 12, mcc_lo: 3200, mcc_hi: 3399, bps: 227, cap_minor: 61000 },
    InterchangeTier { product: 13, mcc_lo: 3400, mcc_hi: 3599, bps: 234, cap_minor: 62000 },
    InterchangeTier { product: 14, mcc_lo: 3600, mcc_hi: 3799, bps: 241, cap_minor: 63000 },
    InterchangeTier { product: 15, mcc_lo: 3800, mcc_hi: 3999, bps: 248, cap_minor: 64000 },
    InterchangeTier { product: 16, mcc_lo: 4000, mcc_hi: 4199, bps: 255, cap_minor: 65000 },
    InterchangeTier { product: 17, mcc_lo: 4200, mcc_hi: 4399, bps: 262, cap_minor: 66000 },
    InterchangeTier { product: 18, mcc_lo: 4400, mcc_hi: 4599, bps: 269, cap_minor: 67000 },
    InterchangeTier { product: 19, mcc_lo: 4600, mcc_hi: 4799, bps: 276, cap_minor: 68000 },
    InterchangeTier { product: 20, mcc_lo: 4800, mcc_hi: 4999, bps: 283, cap_minor: 69000 },
    InterchangeTier { product: 21, mcc_lo: 5000, mcc_hi: 5199, bps: 290, cap_minor: 70000 },
    InterchangeTier { product: 22, mcc_lo: 5200, mcc_hi: 5399, bps: 297, cap_minor: 71000 },
    InterchangeTier { product: 23, mcc_lo: 5400, mcc_hi: 5599, bps: 304, cap_minor: 72000 },
    InterchangeTier { product: 24, mcc_lo: 5600, mcc_hi: 5799, bps: 311, cap_minor: 73000 },
    InterchangeTier { product: 25, mcc_lo: 5800, mcc_hi: 5999, bps: 318, cap_minor: 74000 },
    InterchangeTier { product: 26, mcc_lo: 6000, mcc_hi: 6199, bps: 325, cap_minor: 75000 },
    InterchangeTier { product: 27, mcc_lo: 6200, mcc_hi: 6399, bps: 332, cap_minor: 76000 },
    InterchangeTier { product: 28, mcc_lo: 6400, mcc_hi: 6599, bps: 339, cap_minor: 77000 },
    InterchangeTier { product: 29, mcc_lo: 6600, mcc_hi: 6799, bps: 346, cap_minor: 78000 },
    InterchangeTier { product: 30, mcc_lo: 6800, mcc_hi: 6999, bps: 153, cap_minor: 79000 },
    InterchangeTier { product: 31, mcc_lo: 7000, mcc_hi: 7199, bps: 160, cap_minor: 80000 },
    InterchangeTier { product: 32, mcc_lo: 7200, mcc_hi: 7399, bps: 167, cap_minor: 81000 },
    InterchangeTier { product: 33, mcc_lo: 7400, mcc_hi: 7599, bps: 174, cap_minor: 82000 },
    InterchangeTier { product: 34, mcc_lo: 7600, mcc_hi: 7799, bps: 181, cap_minor: 83000 },
    InterchangeTier { product: 35, mcc_lo: 7800, mcc_hi: 7999, bps: 188, cap_minor: 84000 },
    InterchangeTier { product: 36, mcc_lo: 8000, mcc_hi: 8199, bps: 195, cap_minor: 85000 },
    InterchangeTier { product: 37, mcc_lo: 8200, mcc_hi: 8399, bps: 202, cap_minor: 86000 },
    InterchangeTier { product: 38, mcc_lo: 8400, mcc_hi: 8599, bps: 209, cap_minor: 87000 },
    InterchangeTier { product: 39, mcc_lo: 8600, mcc_hi: 8799, bps: 216, cap_minor: 88000 },
];

pub fn lookup_tier(product: u8, mcc: u16) -> Option<&'static InterchangeTier> {
    TIERS.iter().find(|t| t.product == product && mcc >= t.mcc_lo && mcc <= t.mcc_hi)
}

pub fn compute_interchange_minor(amount: i64, product: u8, mcc: u16) -> i64 {
    let Some(t) = lookup_tier(product, mcc) else { return amount * 150 / 10_000 };
    let fee = amount.saturating_mul(t.bps as i64) / 10_000;
    fee.min(t.cap_minor)
}
