//! Capture reconciliation between auth holds and settlement records.

use crate::merchant::auth_hold_registry::AuthHoldRegistry;

#[derive(Debug, Clone, PartialEq)]
pub struct CaptureMatch {
    pub stan: u32,
    pub rrn: String,
    pub auth_amount: i64,
    pub capture_amount: i64,
    pub delta_minor: i64,
}

#[derive(Debug, Default)]
pub struct CaptureReconciler {
    pub matches: Vec<CaptureMatch>,
    pub orphan_captures: u32,
    pub partial_captures: u32,
}

impl CaptureReconciler {
    pub fn new() -> Self { Self::default() }

    pub fn reconcile(&mut self, holds: &AuthHoldRegistry, captures: &[(u32, String, i64)]) {
        self.matches.clear();
        self.orphan_captures = 0;
        self.partial_captures = 0;
        for (stan, rrn, cap_amt) in captures {
            if let Some(hold) = holds.lookup_by_stan(*stan) {
                let delta = cap_amt - hold.amount_minor;
                if delta != 0 {
                    self.partial_captures += 1;
                }
                self.matches.push(CaptureMatch {
                    stan: *stan,
                    rrn: rrn.clone(),
                    auth_amount: hold.amount_minor,
                    capture_amount: *cap_amt,
                    delta_minor: delta,
                });
            } else {
                self.orphan_captures += 1;
            }
        }
    }
}
