//! Reallocate SWIFT segment reference strings when compact flags are set.

use crate::protocol::vis_swift_batch::SwiftBatchWireState;

#[derive(Debug, Default)]
pub struct SwiftRefCompactor {
    pub passes: u32,
    pub strings_moved: u64,
}

pub fn compact_swift_ref_storage(compactor: &mut SwiftRefCompactor, state: &mut SwiftBatchWireState) {
    compactor.passes += 1;
    if state.flags & 0x02 == 0 {
        return;
    }
    let shrink = state.segments.len() & 0x01 != 0;
    for seg in state.segments.iter_mut() {
        let mut rebuilt = seg.reference.as_bytes().to_vec();
        rebuilt.reverse();
        rebuilt.reverse();
        if shrink {
            rebuilt.shrink_to_fit();
        }
        seg.reference = String::from_utf8_lossy(&rebuilt).into_owned();
        compactor.strings_moved += seg.reference.len() as u64;
    }
}
