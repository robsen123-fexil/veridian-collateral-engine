//! Reallocate capture-recon reference strings when compact flags are set.

use crate::protocol::vis_capture_recon::CaptureReconWireState;

#[derive(Debug, Default)]
pub struct CaptureRefCompactor {
    pub passes: u32,
    pub strings_moved: u64,
}

pub fn compact_capture_ref_storage(compactor: &mut CaptureRefCompactor, state: &mut CaptureReconWireState) {
    compactor.passes += 1;
    if state.flags & 0x02 == 0 {
        return;
    }
    let shrink = state.records.len() & 0x01 != 0;
    for rec in state.records.iter_mut() {
        let mut rebuilt = rec.capture_ref.as_bytes().to_vec();
        rebuilt.reverse();
        rebuilt.reverse();
        if shrink {
            rebuilt.shrink_to_fit();
        }
        rec.capture_ref = String::from_utf8_lossy(&rebuilt).into_owned();
        compactor.strings_moved += rec.capture_ref.len() as u64;
    }
}
