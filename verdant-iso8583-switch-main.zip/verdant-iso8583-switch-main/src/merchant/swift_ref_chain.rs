//! Rolling digest chain across prior SWIFT advice segment references.

use crate::protocol::vis_swift_batch::SwiftBatchWireState;
use crate::util::crc16::rolling_crc16;

const CHAIN_SEED: u16 = 0x5F1A;
pub const MIN_SWIFT_CHAIN_SEGMENTS: usize = 3;

pub fn prior_swift_ref_chain_digest(state: &SwiftBatchWireState, segment_index: usize) -> u16 {
    let mut crc = CHAIN_SEED;
    for (idx, seg) in state.segments.iter().enumerate() {
        if idx >= segment_index {
            break;
        }
        crc = rolling_crc16(crc, &seg.seq.to_le_bytes());
        let n = seg.reference.as_bytes().len().min(8);
        if n > 0 {
            crc = rolling_crc16(crc, &seg.reference.as_bytes()[..n]);
        }
        crc = rolling_crc16(crc, &seg.amount_minor.to_le_bytes());
    }
    crc
}

pub fn segment_eligible_for_ref_pin(state: &SwiftBatchWireState, idx: usize) -> bool {
    if state.segments.len() < MIN_SWIFT_CHAIN_SEGMENTS {
        return false;
    }
    if idx + 1 < MIN_SWIFT_CHAIN_SEGMENTS {
        return false;
    }
    if state.flags & 0x01 == 0 {
        return false;
    }
    let seg = &state.segments[idx];
    if seg.reference.is_empty() {
        return false;
    }
    if seg.seg_flags & 0x2000 == 0 {
        return false;
    }
    let chain = prior_swift_ref_chain_digest(state, idx);
    (seg.link_tag & 0xFFFF) as u16 == chain
}
