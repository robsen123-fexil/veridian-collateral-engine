use std::collections::HashMap;

#[derive(Debug, Default)]
pub struct MidDirectory {
    pub by_mid: HashMap<String, u16>,
}

impl MidDirectory {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, mid: &str, mcc: u16) {
        self.by_mid.insert(mid.to_string(), mcc);
    }

    pub fn lookup_mcc(&self, mid: &str) -> Option<u16> {
        self.by_mid.get(mid).copied()
    }
}
