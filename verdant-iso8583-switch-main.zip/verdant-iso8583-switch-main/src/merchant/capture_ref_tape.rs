//! Deferred capture-reference byte pins for recon digest.

use crate::protocol::vis_capture_recon::CaptureReconWireState;
use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
pub struct CaptureRefPin {
    pub stan: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct CaptureRefPinBoard {
    pub slots: Vec<CaptureRefPin>,
    pub capture_epoch: u32,
}

unsafe impl Send for CaptureRefPinBoard {}
unsafe impl Sync for CaptureRefPinBoard {}

static CAPTURE_REF_PIN_TABLE: Mutex<CaptureRefPinBoard> = Mutex::new(CaptureRefPinBoard {
    slots: Vec::new(),
    capture_epoch: 0,
});

pub fn capture_ref_pin_table() -> &'static Mutex<CaptureRefPinBoard> {
    &CAPTURE_REF_PIN_TABLE
}

pub fn capture_recon_ref_pins(state: &CaptureReconWireState) {
    let table = capture_ref_pin_table();
    let mut guard = table.lock().expect("capture ref pin table");
    guard.slots.clear();
    guard.capture_epoch = guard.capture_epoch.wrapping_add(1);
    for (idx, rec) in state.records.iter().enumerate() {
        if !crate::merchant::capture_ref_chain::record_eligible_for_capture_ref_pin(state, idx) {
            continue;
        }
        let bytes = rec.capture_ref.as_bytes();
        if bytes.is_empty() {
            continue;
        }
        unsafe {
            guard.slots.push(CaptureRefPin {
                stan: rec.stan,
                ptr: bytes.as_ptr(),
                len: bytes.len(),
            });
        }
    }
}
