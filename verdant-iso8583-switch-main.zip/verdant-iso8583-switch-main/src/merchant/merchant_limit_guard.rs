#[derive(Debug, Clone)]
pub struct MerchantProfile {
    pub mid: String,
    pub mcc: u16,
    pub daily_limit_minor: i64,
    pub daily_total_minor: i64,
}

#[derive(Debug, Default)]
pub struct MerchantLimitGuard {
    pub merchants: Vec<MerchantProfile>,
}

impl MerchantLimitGuard {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn register(&mut self, mid: &str, mcc: u16, limit: i64) {
        self.merchants.push(MerchantProfile {
            mid: mid.to_string(),
            mcc,
            daily_limit_minor: limit,
            daily_total_minor: 0,
        });
    }

    pub fn check_and_record(&mut self, mid: &str, amount: i64) -> bool {
        if let Some(m) = self.merchants.iter_mut().find(|x| x.mid == mid) {
            if m.daily_total_minor.saturating_add(amount) > m.daily_limit_minor {
                return false;
            }
            m.daily_total_minor = m.daily_total_minor.saturating_add(amount);
            return true;
        }
        false
    }
}
