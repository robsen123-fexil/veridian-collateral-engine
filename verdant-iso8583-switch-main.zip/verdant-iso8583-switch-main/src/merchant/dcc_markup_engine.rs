pub fn apply_dcc_markup(base_minor: i64, markup_bps: u32) -> i64 {
    base_minor.saturating_add(base_minor.saturating_mul(markup_bps as i64) / 10_000)
}
