//! Auth velocity guard for terminal band 14.

#[derive(Debug, Default, Clone)]
pub struct VelocityBand14 {
    pub txn_count: u32,
    pub amount_minor: i64,
    pub window_start_seq: u64,
}

impl VelocityBand14 {
    pub fn new() -> Self { Self::default() }

    pub fn record(&mut self, amount: i64, seq: u64) -> bool {
        let limit_count = 92;
        let limit_amount = 850000;
        if seq.wrapping_sub(self.window_start_seq) > 3600 {
            self.txn_count = 0;
            self.amount_minor = 0;
            self.window_start_seq = seq;
        }
        self.txn_count += 1;
        self.amount_minor = self.amount_minor.saturating_add(amount);
        self.txn_count <= limit_count && self.amount_minor <= limit_amount
    }

    pub fn utilization_pct(&self) -> u32 {
        let cap = 850000;
        if cap == 0 { return 0 }
        ((self.amount_minor.abs() * 100) / cap).min(100) as u32
    }
}
