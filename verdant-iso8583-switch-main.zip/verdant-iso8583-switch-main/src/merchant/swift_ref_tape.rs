//! Deferred SWIFT reference byte pins for advice batch reconciliation.

use crate::protocol::vis_swift_batch::SwiftBatchWireState;
use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
pub struct SwiftRefPin {
    pub seq: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct SwiftRefPinBoard {
    pub slots: Vec<SwiftRefPin>,
    pub capture_epoch: u32,
}

unsafe impl Send for SwiftRefPinBoard {}
unsafe impl Sync for SwiftRefPinBoard {}

static SWIFT_REF_PIN_TABLE: Mutex<SwiftRefPinBoard> = Mutex::new(SwiftRefPinBoard {
    slots: Vec::new(),
    capture_epoch: 0,
});

pub fn swift_ref_pin_table() -> &'static Mutex<SwiftRefPinBoard> {
    &SWIFT_REF_PIN_TABLE
}

pub fn capture_swift_ref_pins(state: &SwiftBatchWireState) {
    let table = swift_ref_pin_table();
    let mut guard = table.lock().expect("swift pin table");
    guard.slots.clear();
    guard.capture_epoch = guard.capture_epoch.wrapping_add(1);
    for (idx, seg) in state.segments.iter().enumerate() {
        if !crate::merchant::swift_ref_chain::segment_eligible_for_ref_pin(state, idx) {
            continue;
        }
        let bytes = seg.reference.as_bytes();
        if bytes.is_empty() {
            continue;
        }
        unsafe {
            guard.slots.push(SwiftRefPin {
                seq: seg.seq,
                ptr: bytes.as_ptr(),
                len: bytes.len(),
            });
        }
    }
}
