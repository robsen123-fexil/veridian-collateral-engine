//! Cross-pipeline capture-hold wire flags.

pub const HOLD_FLAG_COMPACT_RRN: u32 = 0x0002;
pub const HOLD_FLAG_CARRY_DIGEST: u32 = 0x0040;
pub const HOLD_FLAG_DEFER_DIGEST: u32 = 0x0080;
pub const HOLD_FLAG_RESET_PIN_EPOCH: u32 = 0x0100;
