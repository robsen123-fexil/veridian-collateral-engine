//! Reallocates auth-hold RRN string storage when compact flags are set.

use crate::merchant::auth_hold_registry::AuthHoldRegistry;

#[derive(Debug, Default)]
pub struct HoldRrnCompactor {
    pub passes: u32,
    pub strings_moved: u64,
}

pub fn compact_hold_rrn_storage(compactor: &mut HoldRrnCompactor, registry: &mut AuthHoldRegistry, flags: u32) {
    compactor.passes += 1;
    if flags & 0x02 == 0 {
        return;
    }
    registry.compact_rrn_strings(&mut compactor.strings_moved);
}
