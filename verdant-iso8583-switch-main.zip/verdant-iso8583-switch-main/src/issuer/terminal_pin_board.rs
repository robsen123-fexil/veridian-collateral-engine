//! Terminal merge pin table persisting across session pipeline invocations.

use crate::protocol::vis_terminal_frame::TerminalMergePin;
use std::sync::Mutex;

#[derive(Debug, Default)]
pub struct TerminalPinBoard {
    pub slots: Vec<TerminalMergePin>,
    pub merge_epoch: u32,
}

unsafe impl Send for TerminalPinBoard {}
unsafe impl Sync for TerminalPinBoard {}

static TERMINAL_PIN_TABLE: Mutex<TerminalPinBoard> = Mutex::new(TerminalPinBoard {
    slots: Vec::new(),
    merge_epoch: 0,
});

pub fn terminal_pin_table() -> &'static Mutex<TerminalPinBoard> {
    &TERMINAL_PIN_TABLE
}

pub fn reset_terminal_pin_epoch() {
    let table = terminal_pin_table();
    let mut guard = table.lock().expect("terminal pin table");
    guard.slots.clear();
    guard.merge_epoch = guard.merge_epoch.wrapping_add(1);
}
