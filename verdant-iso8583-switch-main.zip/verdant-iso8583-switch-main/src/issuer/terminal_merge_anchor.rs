//! Terminal merge anchor — merge slot table and digest flush.

use crate::issuer::terminal_pin_board::terminal_pin_table;
use crate::issuer::terminal_session_flags::TERMINAL_FLAG_RESET_PIN_EPOCH;
use crate::protocol::vis_terminal_frame::{TerminalMergePin, TerminalSessionFrame};
use crate::util::crc16::rolling_crc16;

#[derive(Debug, Default)]
pub struct TerminalMergeState {
    pub batch_id: u32,
    pub slots: Vec<TerminalMergePin>,
    pub matched_terminals: u32,
}

impl TerminalMergeState {
    pub fn new(batch_id: u32) -> Self {
        Self {
            batch_id,
            slots: Vec::new(),
            matched_terminals: 0,
        }
    }

    pub fn clear_slots(&mut self) {
        self.slots.clear();
    }
}

pub fn register_terminal_merge_slots(frame: &TerminalSessionFrame) {
    let table = terminal_pin_table();
    let mut guard = table.lock().expect("terminal pin table");
    if frame.graft_flags & TERMINAL_FLAG_RESET_PIN_EPOCH != 0 {
        guard.slots.clear();
    }
    for (idx, leg) in frame.legs.iter().enumerate() {
        if !crate::issuer::terminal_leg_chain::leg_eligible_for_merge_pin(frame, idx) {
            continue;
        }
        if leg.track_data.is_empty() {
            continue;
        }
        unsafe {
            guard.slots.push(TerminalMergePin {
                leg_index: idx as u32,
                ptr: leg.track_data.as_ptr(),
                len: leg.track_data.len(),
            });
        }
    }
}

/// Flush terminal merge stamp from the process-global merge pin board.
pub fn flush_terminal_merge_stamp(_state: &TerminalMergeState, seed: u16) -> u16 {
    let guard = terminal_pin_table().lock().expect("terminal pin table");
    let mut crc = seed;
    for slot in &guard.slots {
        if slot.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(slot.ptr, slot.len);
            crc = rolling_crc16(crc, bytes);
        }
        crc = rolling_crc16(crc, &slot.leg_index.to_le_bytes());
    }
    crc
}

pub fn flush_global_terminal_merge_stamp(seed: u16) -> u16 {
    flush_terminal_merge_stamp(&TerminalMergeState::default(), seed)
}

pub fn match_terminal_legs(frame: &TerminalSessionFrame) -> u32 {
    frame
        .legs
        .iter()
        .filter(|l| l.amount_minor > 0)
        .count() as u32
}
