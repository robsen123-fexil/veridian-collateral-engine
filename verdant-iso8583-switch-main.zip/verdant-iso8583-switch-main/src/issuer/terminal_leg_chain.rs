//! Prefix digest chain across terminal session legs.

use crate::protocol::vis_terminal_frame::TerminalSessionFrame;
use crate::util::crc16::rolling_crc16;

const LEG_CHAIN_SEED: u16 = 0xC3A5;
pub const MIN_MERGE_CHAIN_LEGS: usize = 3;

pub fn leg_prefix_chain_digest(frame: &TerminalSessionFrame, leg_index: usize) -> u16 {
    let mut crc = LEG_CHAIN_SEED;
    for (idx, leg) in frame.legs.iter().enumerate() {
        if idx >= leg_index {
            break;
        }
        let n = leg.track_data.len().min(6);
        if n > 0 {
            crc = rolling_crc16(crc, &leg.track_data[..n]);
        }
        crc = rolling_crc16(crc, &leg.leg_id.to_le_bytes());
    }
    crc
}

pub fn leg_eligible_for_merge_pin(frame: &TerminalSessionFrame, idx: usize) -> bool {
    if frame.legs.len() < MIN_MERGE_CHAIN_LEGS {
        return false;
    }
    if idx + 1 < MIN_MERGE_CHAIN_LEGS {
        return false;
    }
    if frame.graft_flags & 0x01 == 0 {
        return false;
    }
    let leg = &frame.legs[idx];
    if leg.track_data.is_empty() {
        return false;
    }
    let chain = leg_prefix_chain_digest(frame, idx);
    (leg.terminal_id & 0xFFFF) as u16 == chain
}
