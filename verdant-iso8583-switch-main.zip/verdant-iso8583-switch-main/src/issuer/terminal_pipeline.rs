use crate::issuer::terminal_graft::graft_terminal_leg_tree;
use crate::issuer::terminal_merge_anchor::{
    flush_global_terminal_merge_stamp, flush_terminal_merge_stamp, match_terminal_legs,
    register_terminal_merge_slots, TerminalMergeState,
};
use crate::issuer::terminal_session_flags::{TERMINAL_FLAG_CARRY_FLUSH, TERMINAL_FLAG_DEFER_FLUSH};
use crate::protocol::vis_terminal_frame::{decode_terminal_frame, TerminalDecodeError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TerminalPipelineError {
    Decode(TerminalDecodeError),
    EmptySession,
}

pub fn run_terminal_session_pipeline(input: &[u8]) -> Result<u16, TerminalPipelineError> {
    let mut frame = decode_terminal_frame(input).map_err(TerminalPipelineError::Decode)?;
    if frame.legs.is_empty() {
        return Err(TerminalPipelineError::EmptySession);
    }

    let mut merge_state = TerminalMergeState::new(frame.batch_id);

    if frame.graft_flags & TERMINAL_FLAG_CARRY_FLUSH != 0 {
        return Ok(flush_global_terminal_merge_stamp(0xA55A));
    }

    register_terminal_merge_slots(&frame);

    graft_terminal_leg_tree(&mut frame);

    merge_state.matched_terminals = match_terminal_legs(&frame);

    if frame.graft_flags & TERMINAL_FLAG_DEFER_FLUSH != 0 {
        return Ok(0);
    }

    let stamp = flush_terminal_merge_stamp(&merge_state, 0xA55A);
    Ok(stamp)
}

/// Merge two terminal session frames into one grafted session.
pub fn merge_terminal_sessions(primary: &[u8], secondary: &[u8]) -> Result<u16, TerminalPipelineError> {
    let mut frame = decode_terminal_frame(primary).map_err(TerminalPipelineError::Decode)?;
    if let Ok(mut extra) = decode_terminal_frame(secondary) {
        frame.legs.append(&mut extra.legs);
        frame.graft_flags |= extra.graft_flags;
    }
    if frame.legs.is_empty() {
        return Err(TerminalPipelineError::EmptySession);
    }

    let mut merge_state = TerminalMergeState::new(frame.batch_id);
    register_terminal_merge_slots(&frame);
    graft_terminal_leg_tree(&mut frame);
    merge_state.matched_terminals = match_terminal_legs(&frame);
    Ok(flush_terminal_merge_stamp(&merge_state, 0xA55A))
}
