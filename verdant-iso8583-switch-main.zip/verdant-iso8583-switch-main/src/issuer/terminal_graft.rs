//! Terminal leg graft — reallocates track buffers when graft flags are set.

use crate::protocol::vis_terminal_frame::TerminalSessionFrame;

pub fn graft_terminal_leg_tree(frame: &mut TerminalSessionFrame) {
    if frame.graft_flags & 0x0F == 0 {
        return;
    }
    for leg in frame.legs.iter_mut() {
        if frame.graft_flags & 0x01 != 0 {
            let mut expanded = leg.track_data.clone();
            expanded.extend_from_slice(&leg.leg_id.to_le_bytes());
            expanded.extend_from_slice(&leg.terminal_id.to_le_bytes());
            leg.track_data = expanded;
        }
        if frame.graft_flags & 0x02 != 0 {
            leg.track_data.shrink_to_fit();
        }
        if frame.graft_flags & 0x04 != 0 {
            leg.track_data.sort_unstable();
        }
        if frame.graft_flags & 0x08 != 0 {
            let cap = leg.track_data.capacity();
            let mut replacement = Vec::with_capacity(cap.saturating_add(64));
            replacement.extend_from_slice(&leg.track_data);
            leg.track_data = replacement;
        }
    }
}
