//! Terminal end-of-day policy pack 7 for batch close rules.

#[derive(Debug, Clone)]
pub struct TerminalPolicy07 {
    pub max_auth_count: u32,
    pub max_capture_minor: i64,
    pub offline_floor_minor: i64,
}

impl TerminalPolicy07 {
    pub fn evaluate_close(&self, auth_count: u32, capture_minor: i64, offline_minor: i64) -> bool {
        auth_count <= self.max_auth_count
            && capture_minor <= self.max_capture_minor
            && offline_minor <= self.offline_floor_minor
    }

    pub fn penalty_score(&self, auth_count: u32, capture_minor: i64) -> u32 {
        let over_auth = auth_count.saturating_sub(self.max_auth_count / 2);
        let over_cap = (capture_minor.saturating_sub(self.max_capture_minor / 2) / 1000) as u32;
        over_auth.saturating_mul(5).saturating_add(over_cap)
    }
}

pub fn default_policy_07() -> TerminalPolicy07 {
    TerminalPolicy07 {
        max_auth_count: 640,
        max_capture_minor: 5700000,
        offline_floor_minor: 85000,
    }
}
