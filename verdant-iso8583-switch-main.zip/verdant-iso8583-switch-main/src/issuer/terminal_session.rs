//! Terminal session bookkeeping for end-of-day batch close.

#[derive(Debug, Clone)]
pub struct TerminalSessionRecord {
    pub terminal_id: String,
    pub batch_id: u32,
    pub auth_count: u32,
    pub capture_total_minor: i64,
}

#[derive(Debug, Default)]
pub struct TerminalSessionBook {
    pub sessions: Vec<TerminalSessionRecord>,
}

impl TerminalSessionBook {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn open_session(&mut self, terminal_id: &str, batch_id: u32) {
        self.sessions.push(TerminalSessionRecord {
            terminal_id: terminal_id.to_string(),
            batch_id,
            auth_count: 0,
            capture_total_minor: 0,
        });
    }

    pub fn record_auth(&mut self, terminal_id: &str, amount: i64) {
        if let Some(s) = self.sessions.iter_mut().find(|s| s.terminal_id == terminal_id) {
            s.auth_count += 1;
            s.capture_total_minor = s.capture_total_minor.saturating_add(amount);
        }
    }
}
