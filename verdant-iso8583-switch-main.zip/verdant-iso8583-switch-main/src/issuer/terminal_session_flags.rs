//! Cross-session terminal merge staging flags.

pub const TERMINAL_FLAG_DEFER_FLUSH: u32 = 0x0001_0000;
pub const TERMINAL_FLAG_CARRY_FLUSH: u32 = 0x0002_0000;
pub const TERMINAL_FLAG_RESET_PIN_EPOCH: u32 = 0x0004_0000;
