//! Acquirer network routing policy slice 17 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy17 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_17: &[RoutePolicy17] = &[
    RoutePolicy17 { bin_lo: 417000, bin_hi: 417099, priority: 3, failover_host: 1170 },
    RoutePolicy17 { bin_lo: 417100, bin_hi: 417199, priority: 4, failover_host: 1171 },
    RoutePolicy17 { bin_lo: 417200, bin_hi: 417299, priority: 5, failover_host: 1172 },
    RoutePolicy17 { bin_lo: 417300, bin_hi: 417399, priority: 6, failover_host: 1173 },
    RoutePolicy17 { bin_lo: 417400, bin_hi: 417499, priority: 0, failover_host: 1174 },
    RoutePolicy17 { bin_lo: 417500, bin_hi: 417599, priority: 1, failover_host: 1175 },
    RoutePolicy17 { bin_lo: 417600, bin_hi: 417699, priority: 2, failover_host: 1176 },
    RoutePolicy17 { bin_lo: 417700, bin_hi: 417799, priority: 3, failover_host: 1177 },
];

pub fn route_bin_17(pan_prefix: u32) -> Option<u16> {
    ROUTES_17.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_17(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (17 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_17(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
