//! Acquirer network routing policy slice 4 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy04 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_04: &[RoutePolicy04] = &[
    RoutePolicy04 { bin_lo: 404000, bin_hi: 404099, priority: 4, failover_host: 1040 },
    RoutePolicy04 { bin_lo: 404100, bin_hi: 404199, priority: 5, failover_host: 1041 },
    RoutePolicy04 { bin_lo: 404200, bin_hi: 404299, priority: 6, failover_host: 1042 },
    RoutePolicy04 { bin_lo: 404300, bin_hi: 404399, priority: 0, failover_host: 1043 },
    RoutePolicy04 { bin_lo: 404400, bin_hi: 404499, priority: 1, failover_host: 1044 },
    RoutePolicy04 { bin_lo: 404500, bin_hi: 404599, priority: 2, failover_host: 1045 },
    RoutePolicy04 { bin_lo: 404600, bin_hi: 404699, priority: 3, failover_host: 1046 },
    RoutePolicy04 { bin_lo: 404700, bin_hi: 404799, priority: 4, failover_host: 1047 },
];

pub fn route_bin_04(pan_prefix: u32) -> Option<u16> {
    ROUTES_04.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_04(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (4 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_04(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
