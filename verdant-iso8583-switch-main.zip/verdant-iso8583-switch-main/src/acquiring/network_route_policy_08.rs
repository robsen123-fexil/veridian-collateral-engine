//! Acquirer network routing policy slice 8 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy08 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_08: &[RoutePolicy08] = &[
    RoutePolicy08 { bin_lo: 408000, bin_hi: 408099, priority: 1, failover_host: 1080 },
    RoutePolicy08 { bin_lo: 408100, bin_hi: 408199, priority: 2, failover_host: 1081 },
    RoutePolicy08 { bin_lo: 408200, bin_hi: 408299, priority: 3, failover_host: 1082 },
    RoutePolicy08 { bin_lo: 408300, bin_hi: 408399, priority: 4, failover_host: 1083 },
    RoutePolicy08 { bin_lo: 408400, bin_hi: 408499, priority: 5, failover_host: 1084 },
    RoutePolicy08 { bin_lo: 408500, bin_hi: 408599, priority: 6, failover_host: 1085 },
    RoutePolicy08 { bin_lo: 408600, bin_hi: 408699, priority: 0, failover_host: 1086 },
    RoutePolicy08 { bin_lo: 408700, bin_hi: 408799, priority: 1, failover_host: 1087 },
];

pub fn route_bin_08(pan_prefix: u32) -> Option<u16> {
    ROUTES_08.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_08(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (8 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_08(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
