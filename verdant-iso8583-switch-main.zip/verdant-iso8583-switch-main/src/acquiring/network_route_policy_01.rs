//! Acquirer network routing policy slice 1 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy01 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_01: &[RoutePolicy01] = &[
    RoutePolicy01 { bin_lo: 401000, bin_hi: 401099, priority: 1, failover_host: 1010 },
    RoutePolicy01 { bin_lo: 401100, bin_hi: 401199, priority: 2, failover_host: 1011 },
    RoutePolicy01 { bin_lo: 401200, bin_hi: 401299, priority: 3, failover_host: 1012 },
    RoutePolicy01 { bin_lo: 401300, bin_hi: 401399, priority: 4, failover_host: 1013 },
    RoutePolicy01 { bin_lo: 401400, bin_hi: 401499, priority: 5, failover_host: 1014 },
    RoutePolicy01 { bin_lo: 401500, bin_hi: 401599, priority: 6, failover_host: 1015 },
    RoutePolicy01 { bin_lo: 401600, bin_hi: 401699, priority: 0, failover_host: 1016 },
    RoutePolicy01 { bin_lo: 401700, bin_hi: 401799, priority: 1, failover_host: 1017 },
];

pub fn route_bin_01(pan_prefix: u32) -> Option<u16> {
    ROUTES_01.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_01(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (1 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_01(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
