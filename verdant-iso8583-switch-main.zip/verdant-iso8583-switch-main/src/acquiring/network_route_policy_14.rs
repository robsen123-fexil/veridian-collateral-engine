//! Acquirer network routing policy slice 14 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy14 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_14: &[RoutePolicy14] = &[
    RoutePolicy14 { bin_lo: 414000, bin_hi: 414099, priority: 0, failover_host: 1140 },
    RoutePolicy14 { bin_lo: 414100, bin_hi: 414199, priority: 1, failover_host: 1141 },
    RoutePolicy14 { bin_lo: 414200, bin_hi: 414299, priority: 2, failover_host: 1142 },
    RoutePolicy14 { bin_lo: 414300, bin_hi: 414399, priority: 3, failover_host: 1143 },
    RoutePolicy14 { bin_lo: 414400, bin_hi: 414499, priority: 4, failover_host: 1144 },
    RoutePolicy14 { bin_lo: 414500, bin_hi: 414599, priority: 5, failover_host: 1145 },
    RoutePolicy14 { bin_lo: 414600, bin_hi: 414699, priority: 6, failover_host: 1146 },
    RoutePolicy14 { bin_lo: 414700, bin_hi: 414799, priority: 0, failover_host: 1147 },
];

pub fn route_bin_14(pan_prefix: u32) -> Option<u16> {
    ROUTES_14.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_14(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (14 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_14(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
