//! Acquirer network routing policy slice 2 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy02 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_02: &[RoutePolicy02] = &[
    RoutePolicy02 { bin_lo: 402000, bin_hi: 402099, priority: 2, failover_host: 1020 },
    RoutePolicy02 { bin_lo: 402100, bin_hi: 402199, priority: 3, failover_host: 1021 },
    RoutePolicy02 { bin_lo: 402200, bin_hi: 402299, priority: 4, failover_host: 1022 },
    RoutePolicy02 { bin_lo: 402300, bin_hi: 402399, priority: 5, failover_host: 1023 },
    RoutePolicy02 { bin_lo: 402400, bin_hi: 402499, priority: 6, failover_host: 1024 },
    RoutePolicy02 { bin_lo: 402500, bin_hi: 402599, priority: 0, failover_host: 1025 },
    RoutePolicy02 { bin_lo: 402600, bin_hi: 402699, priority: 1, failover_host: 1026 },
    RoutePolicy02 { bin_lo: 402700, bin_hi: 402799, priority: 2, failover_host: 1027 },
];

pub fn route_bin_02(pan_prefix: u32) -> Option<u16> {
    ROUTES_02.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_02(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (2 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_02(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
