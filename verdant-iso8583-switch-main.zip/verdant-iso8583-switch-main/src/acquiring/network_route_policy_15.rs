//! Acquirer network routing policy slice 15 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy15 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_15: &[RoutePolicy15] = &[
    RoutePolicy15 { bin_lo: 415000, bin_hi: 415099, priority: 1, failover_host: 1150 },
    RoutePolicy15 { bin_lo: 415100, bin_hi: 415199, priority: 2, failover_host: 1151 },
    RoutePolicy15 { bin_lo: 415200, bin_hi: 415299, priority: 3, failover_host: 1152 },
    RoutePolicy15 { bin_lo: 415300, bin_hi: 415399, priority: 4, failover_host: 1153 },
    RoutePolicy15 { bin_lo: 415400, bin_hi: 415499, priority: 5, failover_host: 1154 },
    RoutePolicy15 { bin_lo: 415500, bin_hi: 415599, priority: 6, failover_host: 1155 },
    RoutePolicy15 { bin_lo: 415600, bin_hi: 415699, priority: 0, failover_host: 1156 },
    RoutePolicy15 { bin_lo: 415700, bin_hi: 415799, priority: 1, failover_host: 1157 },
];

pub fn route_bin_15(pan_prefix: u32) -> Option<u16> {
    ROUTES_15.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_15(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (15 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_15(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
