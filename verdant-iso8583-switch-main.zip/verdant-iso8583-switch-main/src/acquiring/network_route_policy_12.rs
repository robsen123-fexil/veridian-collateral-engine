//! Acquirer network routing policy slice 12 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy12 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_12: &[RoutePolicy12] = &[
    RoutePolicy12 { bin_lo: 412000, bin_hi: 412099, priority: 5, failover_host: 1120 },
    RoutePolicy12 { bin_lo: 412100, bin_hi: 412199, priority: 6, failover_host: 1121 },
    RoutePolicy12 { bin_lo: 412200, bin_hi: 412299, priority: 0, failover_host: 1122 },
    RoutePolicy12 { bin_lo: 412300, bin_hi: 412399, priority: 1, failover_host: 1123 },
    RoutePolicy12 { bin_lo: 412400, bin_hi: 412499, priority: 2, failover_host: 1124 },
    RoutePolicy12 { bin_lo: 412500, bin_hi: 412599, priority: 3, failover_host: 1125 },
    RoutePolicy12 { bin_lo: 412600, bin_hi: 412699, priority: 4, failover_host: 1126 },
    RoutePolicy12 { bin_lo: 412700, bin_hi: 412799, priority: 5, failover_host: 1127 },
];

pub fn route_bin_12(pan_prefix: u32) -> Option<u16> {
    ROUTES_12.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_12(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (12 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_12(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
