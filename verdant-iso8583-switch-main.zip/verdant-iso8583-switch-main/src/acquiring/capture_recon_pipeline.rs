use crate::merchant::capture_recon_digest::finalize_capture_recon_digest;
use crate::merchant::capture_ref_compactor::{compact_capture_ref_storage, CaptureRefCompactor};
use crate::merchant::capture_ref_tape::capture_recon_ref_pins;
use crate::protocol::vis_capture_recon::{decode_capture_recon_wire, CaptureReconDecodeError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CaptureReconPipelineError {
    Decode(CaptureReconDecodeError),
    EmptyBatch,
}

pub fn run_capture_recon_pipeline(input: &[u8]) -> Result<u16, CaptureReconPipelineError> {
    let mut state = decode_capture_recon_wire(input).map_err(CaptureReconPipelineError::Decode)?;
    if state.records.is_empty() {
        return Err(CaptureReconPipelineError::EmptyBatch);
    }

    capture_recon_ref_pins(&state);

    let mut compactor = CaptureRefCompactor::default();
    compact_capture_ref_storage(&mut compactor, &mut state);

    Ok(finalize_capture_recon_digest(0xCA9E))
}
