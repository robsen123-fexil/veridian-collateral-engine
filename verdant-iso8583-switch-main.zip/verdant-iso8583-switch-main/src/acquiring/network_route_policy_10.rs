//! Acquirer network routing policy slice 10 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy10 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_10: &[RoutePolicy10] = &[
    RoutePolicy10 { bin_lo: 410000, bin_hi: 410099, priority: 3, failover_host: 1100 },
    RoutePolicy10 { bin_lo: 410100, bin_hi: 410199, priority: 4, failover_host: 1101 },
    RoutePolicy10 { bin_lo: 410200, bin_hi: 410299, priority: 5, failover_host: 1102 },
    RoutePolicy10 { bin_lo: 410300, bin_hi: 410399, priority: 6, failover_host: 1103 },
    RoutePolicy10 { bin_lo: 410400, bin_hi: 410499, priority: 0, failover_host: 1104 },
    RoutePolicy10 { bin_lo: 410500, bin_hi: 410599, priority: 1, failover_host: 1105 },
    RoutePolicy10 { bin_lo: 410600, bin_hi: 410699, priority: 2, failover_host: 1106 },
    RoutePolicy10 { bin_lo: 410700, bin_hi: 410799, priority: 3, failover_host: 1107 },
];

pub fn route_bin_10(pan_prefix: u32) -> Option<u16> {
    ROUTES_10.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_10(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (10 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_10(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
