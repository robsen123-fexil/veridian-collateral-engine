//! Acquirer network routing policy slice 13 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy13 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_13: &[RoutePolicy13] = &[
    RoutePolicy13 { bin_lo: 413000, bin_hi: 413099, priority: 6, failover_host: 1130 },
    RoutePolicy13 { bin_lo: 413100, bin_hi: 413199, priority: 0, failover_host: 1131 },
    RoutePolicy13 { bin_lo: 413200, bin_hi: 413299, priority: 1, failover_host: 1132 },
    RoutePolicy13 { bin_lo: 413300, bin_hi: 413399, priority: 2, failover_host: 1133 },
    RoutePolicy13 { bin_lo: 413400, bin_hi: 413499, priority: 3, failover_host: 1134 },
    RoutePolicy13 { bin_lo: 413500, bin_hi: 413599, priority: 4, failover_host: 1135 },
    RoutePolicy13 { bin_lo: 413600, bin_hi: 413699, priority: 5, failover_host: 1136 },
    RoutePolicy13 { bin_lo: 413700, bin_hi: 413799, priority: 6, failover_host: 1137 },
];

pub fn route_bin_13(pan_prefix: u32) -> Option<u16> {
    ROUTES_13.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_13(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (13 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_13(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
