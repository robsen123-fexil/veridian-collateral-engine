//! Acquirer network routing policy slice 5 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy05 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_05: &[RoutePolicy05] = &[
    RoutePolicy05 { bin_lo: 405000, bin_hi: 405099, priority: 5, failover_host: 1050 },
    RoutePolicy05 { bin_lo: 405100, bin_hi: 405199, priority: 6, failover_host: 1051 },
    RoutePolicy05 { bin_lo: 405200, bin_hi: 405299, priority: 0, failover_host: 1052 },
    RoutePolicy05 { bin_lo: 405300, bin_hi: 405399, priority: 1, failover_host: 1053 },
    RoutePolicy05 { bin_lo: 405400, bin_hi: 405499, priority: 2, failover_host: 1054 },
    RoutePolicy05 { bin_lo: 405500, bin_hi: 405599, priority: 3, failover_host: 1055 },
    RoutePolicy05 { bin_lo: 405600, bin_hi: 405699, priority: 4, failover_host: 1056 },
    RoutePolicy05 { bin_lo: 405700, bin_hi: 405799, priority: 5, failover_host: 1057 },
];

pub fn route_bin_05(pan_prefix: u32) -> Option<u16> {
    ROUTES_05.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_05(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (5 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_05(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
