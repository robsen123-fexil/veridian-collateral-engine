//! Acquirer network routing policy slice 20 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy20 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_20: &[RoutePolicy20] = &[
    RoutePolicy20 { bin_lo: 420000, bin_hi: 420099, priority: 6, failover_host: 1200 },
    RoutePolicy20 { bin_lo: 420100, bin_hi: 420199, priority: 0, failover_host: 1201 },
    RoutePolicy20 { bin_lo: 420200, bin_hi: 420299, priority: 1, failover_host: 1202 },
    RoutePolicy20 { bin_lo: 420300, bin_hi: 420399, priority: 2, failover_host: 1203 },
    RoutePolicy20 { bin_lo: 420400, bin_hi: 420499, priority: 3, failover_host: 1204 },
    RoutePolicy20 { bin_lo: 420500, bin_hi: 420599, priority: 4, failover_host: 1205 },
    RoutePolicy20 { bin_lo: 420600, bin_hi: 420699, priority: 5, failover_host: 1206 },
    RoutePolicy20 { bin_lo: 420700, bin_hi: 420799, priority: 6, failover_host: 1207 },
];

pub fn route_bin_20(pan_prefix: u32) -> Option<u16> {
    ROUTES_20.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_20(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (20 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_20(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
