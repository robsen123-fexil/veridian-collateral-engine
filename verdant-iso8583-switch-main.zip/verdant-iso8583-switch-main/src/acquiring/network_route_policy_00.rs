//! Acquirer network routing policy slice 0 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy00 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_00: &[RoutePolicy00] = &[
    RoutePolicy00 { bin_lo: 400000, bin_hi: 400099, priority: 0, failover_host: 1000 },
    RoutePolicy00 { bin_lo: 400100, bin_hi: 400199, priority: 1, failover_host: 1001 },
    RoutePolicy00 { bin_lo: 400200, bin_hi: 400299, priority: 2, failover_host: 1002 },
    RoutePolicy00 { bin_lo: 400300, bin_hi: 400399, priority: 3, failover_host: 1003 },
    RoutePolicy00 { bin_lo: 400400, bin_hi: 400499, priority: 4, failover_host: 1004 },
    RoutePolicy00 { bin_lo: 400500, bin_hi: 400599, priority: 5, failover_host: 1005 },
    RoutePolicy00 { bin_lo: 400600, bin_hi: 400699, priority: 6, failover_host: 1006 },
    RoutePolicy00 { bin_lo: 400700, bin_hi: 400799, priority: 0, failover_host: 1007 },
];

pub fn route_bin_00(pan_prefix: u32) -> Option<u16> {
    ROUTES_00.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_00(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (0 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_00(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
