//! Acquirer network routing policy slice 11 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy11 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_11: &[RoutePolicy11] = &[
    RoutePolicy11 { bin_lo: 411000, bin_hi: 411099, priority: 4, failover_host: 1110 },
    RoutePolicy11 { bin_lo: 411100, bin_hi: 411199, priority: 5, failover_host: 1111 },
    RoutePolicy11 { bin_lo: 411200, bin_hi: 411299, priority: 6, failover_host: 1112 },
    RoutePolicy11 { bin_lo: 411300, bin_hi: 411399, priority: 0, failover_host: 1113 },
    RoutePolicy11 { bin_lo: 411400, bin_hi: 411499, priority: 1, failover_host: 1114 },
    RoutePolicy11 { bin_lo: 411500, bin_hi: 411599, priority: 2, failover_host: 1115 },
    RoutePolicy11 { bin_lo: 411600, bin_hi: 411699, priority: 3, failover_host: 1116 },
    RoutePolicy11 { bin_lo: 411700, bin_hi: 411799, priority: 4, failover_host: 1117 },
];

pub fn route_bin_11(pan_prefix: u32) -> Option<u16> {
    ROUTES_11.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_11(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (11 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_11(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
