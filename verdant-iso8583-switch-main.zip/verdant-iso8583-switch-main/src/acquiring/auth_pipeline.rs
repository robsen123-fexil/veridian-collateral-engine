use crate::protocol::iso8583_message_catalog::handle_inbound_mti;
use crate::merchant::auth_hold_registry::AuthHoldRegistry;

#[derive(Debug, Default)]
pub struct AuthPipeline {
    pub holds: AuthHoldRegistry,
    pub approved_count: u32,
    pub declined_count: u32,
}

impl AuthPipeline {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn process_auth(&mut self, input: &[u8]) -> bool {
        match handle_inbound_mti(input) {
            Ok(msg) => {
                let stan = msg.stan().unwrap_or(0);
                let amt = msg.amount_minor().unwrap_or(0);
                self.holds.place_hold(stan, amt);
                self.approved_count += 1;
                true
            }
            Err(_) => {
                self.declined_count += 1;
                false
            }
        }
    }
}
