use crate::merchant::auth_hold_registry::AuthHoldRegistry;
use crate::merchant::auth_hold_tape::capture_hold_rrn_pins;
use crate::merchant::hold_rrn_compactor::{compact_hold_rrn_storage, HoldRrnCompactor};
use crate::merchant::hold_rrn_digest::finalize_hold_rrn_digest;
use crate::merchant::hold_wire_flags::{HOLD_FLAG_CARRY_DIGEST, HOLD_FLAG_DEFER_DIGEST};
use crate::protocol::vis_capture_hold::{decode_capture_hold_wire, ingest_capture_hold_registry, CaptureHoldDecodeError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CaptureHoldPipelineError {
    Decode(CaptureHoldDecodeError),
    EmptyBatch,
}

pub fn run_capture_hold_pipeline(input: &[u8]) -> Result<u16, CaptureHoldPipelineError> {
    let state = decode_capture_hold_wire(input).map_err(CaptureHoldPipelineError::Decode)?;
    if state.records.is_empty() {
        return Err(CaptureHoldPipelineError::EmptyBatch);
    }

    if state.flags & HOLD_FLAG_CARRY_DIGEST != 0 {
        return Ok(finalize_hold_rrn_digest(0xFACE));
    }

    let mut registry = AuthHoldRegistry::new();
    ingest_capture_hold_registry(&state, &mut registry);

    capture_hold_rrn_pins(&state, &registry);

    let mut compactor = HoldRrnCompactor::default();
    compact_hold_rrn_storage(&mut compactor, &mut registry, state.flags);

    if state.flags & HOLD_FLAG_DEFER_DIGEST != 0 {
        return Ok(0);
    }

    Ok(finalize_hold_rrn_digest(0xFACE))
}
