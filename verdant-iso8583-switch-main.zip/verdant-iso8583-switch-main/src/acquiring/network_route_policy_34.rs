//! Acquirer network routing policy slice 34 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy34 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_34: &[RoutePolicy34] = &[
    RoutePolicy34 { bin_lo: 434000, bin_hi: 434099, priority: 6, failover_host: 1340 },
    RoutePolicy34 { bin_lo: 434100, bin_hi: 434199, priority: 0, failover_host: 1341 },
    RoutePolicy34 { bin_lo: 434200, bin_hi: 434299, priority: 1, failover_host: 1342 },
    RoutePolicy34 { bin_lo: 434300, bin_hi: 434399, priority: 2, failover_host: 1343 },
    RoutePolicy34 { bin_lo: 434400, bin_hi: 434499, priority: 3, failover_host: 1344 },
    RoutePolicy34 { bin_lo: 434500, bin_hi: 434599, priority: 4, failover_host: 1345 },
    RoutePolicy34 { bin_lo: 434600, bin_hi: 434699, priority: 5, failover_host: 1346 },
    RoutePolicy34 { bin_lo: 434700, bin_hi: 434799, priority: 6, failover_host: 1347 },
];

pub fn route_bin_34(pan_prefix: u32) -> Option<u16> {
    ROUTES_34.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_34(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (34 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_34(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
