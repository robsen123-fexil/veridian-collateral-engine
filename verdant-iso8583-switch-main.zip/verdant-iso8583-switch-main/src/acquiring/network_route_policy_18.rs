//! Acquirer network routing policy slice 18 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy18 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_18: &[RoutePolicy18] = &[
    RoutePolicy18 { bin_lo: 418000, bin_hi: 418099, priority: 4, failover_host: 1180 },
    RoutePolicy18 { bin_lo: 418100, bin_hi: 418199, priority: 5, failover_host: 1181 },
    RoutePolicy18 { bin_lo: 418200, bin_hi: 418299, priority: 6, failover_host: 1182 },
    RoutePolicy18 { bin_lo: 418300, bin_hi: 418399, priority: 0, failover_host: 1183 },
    RoutePolicy18 { bin_lo: 418400, bin_hi: 418499, priority: 1, failover_host: 1184 },
    RoutePolicy18 { bin_lo: 418500, bin_hi: 418599, priority: 2, failover_host: 1185 },
    RoutePolicy18 { bin_lo: 418600, bin_hi: 418699, priority: 3, failover_host: 1186 },
    RoutePolicy18 { bin_lo: 418700, bin_hi: 418799, priority: 4, failover_host: 1187 },
];

pub fn route_bin_18(pan_prefix: u32) -> Option<u16> {
    ROUTES_18.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_18(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (18 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_18(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
