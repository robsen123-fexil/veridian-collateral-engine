//! Acquirer network routing policy slice 25 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy25 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_25: &[RoutePolicy25] = &[
    RoutePolicy25 { bin_lo: 425000, bin_hi: 425099, priority: 4, failover_host: 1250 },
    RoutePolicy25 { bin_lo: 425100, bin_hi: 425199, priority: 5, failover_host: 1251 },
    RoutePolicy25 { bin_lo: 425200, bin_hi: 425299, priority: 6, failover_host: 1252 },
    RoutePolicy25 { bin_lo: 425300, bin_hi: 425399, priority: 0, failover_host: 1253 },
    RoutePolicy25 { bin_lo: 425400, bin_hi: 425499, priority: 1, failover_host: 1254 },
    RoutePolicy25 { bin_lo: 425500, bin_hi: 425599, priority: 2, failover_host: 1255 },
    RoutePolicy25 { bin_lo: 425600, bin_hi: 425699, priority: 3, failover_host: 1256 },
    RoutePolicy25 { bin_lo: 425700, bin_hi: 425799, priority: 4, failover_host: 1257 },
];

pub fn route_bin_25(pan_prefix: u32) -> Option<u16> {
    ROUTES_25.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_25(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (25 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_25(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
