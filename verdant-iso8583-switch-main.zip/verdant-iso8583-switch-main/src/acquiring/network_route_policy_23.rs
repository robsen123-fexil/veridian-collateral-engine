//! Acquirer network routing policy slice 23 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy23 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_23: &[RoutePolicy23] = &[
    RoutePolicy23 { bin_lo: 423000, bin_hi: 423099, priority: 2, failover_host: 1230 },
    RoutePolicy23 { bin_lo: 423100, bin_hi: 423199, priority: 3, failover_host: 1231 },
    RoutePolicy23 { bin_lo: 423200, bin_hi: 423299, priority: 4, failover_host: 1232 },
    RoutePolicy23 { bin_lo: 423300, bin_hi: 423399, priority: 5, failover_host: 1233 },
    RoutePolicy23 { bin_lo: 423400, bin_hi: 423499, priority: 6, failover_host: 1234 },
    RoutePolicy23 { bin_lo: 423500, bin_hi: 423599, priority: 0, failover_host: 1235 },
    RoutePolicy23 { bin_lo: 423600, bin_hi: 423699, priority: 1, failover_host: 1236 },
    RoutePolicy23 { bin_lo: 423700, bin_hi: 423799, priority: 2, failover_host: 1237 },
];

pub fn route_bin_23(pan_prefix: u32) -> Option<u16> {
    ROUTES_23.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_23(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (23 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_23(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
