//! Acquirer network routing policy slice 9 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy09 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_09: &[RoutePolicy09] = &[
    RoutePolicy09 { bin_lo: 409000, bin_hi: 409099, priority: 2, failover_host: 1090 },
    RoutePolicy09 { bin_lo: 409100, bin_hi: 409199, priority: 3, failover_host: 1091 },
    RoutePolicy09 { bin_lo: 409200, bin_hi: 409299, priority: 4, failover_host: 1092 },
    RoutePolicy09 { bin_lo: 409300, bin_hi: 409399, priority: 5, failover_host: 1093 },
    RoutePolicy09 { bin_lo: 409400, bin_hi: 409499, priority: 6, failover_host: 1094 },
    RoutePolicy09 { bin_lo: 409500, bin_hi: 409599, priority: 0, failover_host: 1095 },
    RoutePolicy09 { bin_lo: 409600, bin_hi: 409699, priority: 1, failover_host: 1096 },
    RoutePolicy09 { bin_lo: 409700, bin_hi: 409799, priority: 2, failover_host: 1097 },
];

pub fn route_bin_09(pan_prefix: u32) -> Option<u16> {
    ROUTES_09.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_09(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (9 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_09(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
