//! Acquirer network routing policy slice 7 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy07 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_07: &[RoutePolicy07] = &[
    RoutePolicy07 { bin_lo: 407000, bin_hi: 407099, priority: 0, failover_host: 1070 },
    RoutePolicy07 { bin_lo: 407100, bin_hi: 407199, priority: 1, failover_host: 1071 },
    RoutePolicy07 { bin_lo: 407200, bin_hi: 407299, priority: 2, failover_host: 1072 },
    RoutePolicy07 { bin_lo: 407300, bin_hi: 407399, priority: 3, failover_host: 1073 },
    RoutePolicy07 { bin_lo: 407400, bin_hi: 407499, priority: 4, failover_host: 1074 },
    RoutePolicy07 { bin_lo: 407500, bin_hi: 407599, priority: 5, failover_host: 1075 },
    RoutePolicy07 { bin_lo: 407600, bin_hi: 407699, priority: 6, failover_host: 1076 },
    RoutePolicy07 { bin_lo: 407700, bin_hi: 407799, priority: 0, failover_host: 1077 },
];

pub fn route_bin_07(pan_prefix: u32) -> Option<u16> {
    ROUTES_07.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_07(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (7 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_07(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
