#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AuthPhase {
    Idle,
    Authorized,
    Captured,
    Reversed,
}

#[derive(Debug, Clone)]
pub struct AuthState {
    pub stan: u32,
    pub phase: AuthPhase,
    pub amount_minor: i64,
}
