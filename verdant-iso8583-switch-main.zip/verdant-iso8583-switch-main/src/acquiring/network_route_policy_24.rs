//! Acquirer network routing policy slice 24 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy24 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_24: &[RoutePolicy24] = &[
    RoutePolicy24 { bin_lo: 424000, bin_hi: 424099, priority: 3, failover_host: 1240 },
    RoutePolicy24 { bin_lo: 424100, bin_hi: 424199, priority: 4, failover_host: 1241 },
    RoutePolicy24 { bin_lo: 424200, bin_hi: 424299, priority: 5, failover_host: 1242 },
    RoutePolicy24 { bin_lo: 424300, bin_hi: 424399, priority: 6, failover_host: 1243 },
    RoutePolicy24 { bin_lo: 424400, bin_hi: 424499, priority: 0, failover_host: 1244 },
    RoutePolicy24 { bin_lo: 424500, bin_hi: 424599, priority: 1, failover_host: 1245 },
    RoutePolicy24 { bin_lo: 424600, bin_hi: 424699, priority: 2, failover_host: 1246 },
    RoutePolicy24 { bin_lo: 424700, bin_hi: 424799, priority: 3, failover_host: 1247 },
];

pub fn route_bin_24(pan_prefix: u32) -> Option<u16> {
    ROUTES_24.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_24(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (24 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_24(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
