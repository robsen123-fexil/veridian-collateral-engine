//! Acquirer network routing policy slice 31 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy31 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_31: &[RoutePolicy31] = &[
    RoutePolicy31 { bin_lo: 431000, bin_hi: 431099, priority: 3, failover_host: 1310 },
    RoutePolicy31 { bin_lo: 431100, bin_hi: 431199, priority: 4, failover_host: 1311 },
    RoutePolicy31 { bin_lo: 431200, bin_hi: 431299, priority: 5, failover_host: 1312 },
    RoutePolicy31 { bin_lo: 431300, bin_hi: 431399, priority: 6, failover_host: 1313 },
    RoutePolicy31 { bin_lo: 431400, bin_hi: 431499, priority: 0, failover_host: 1314 },
    RoutePolicy31 { bin_lo: 431500, bin_hi: 431599, priority: 1, failover_host: 1315 },
    RoutePolicy31 { bin_lo: 431600, bin_hi: 431699, priority: 2, failover_host: 1316 },
    RoutePolicy31 { bin_lo: 431700, bin_hi: 431799, priority: 3, failover_host: 1317 },
];

pub fn route_bin_31(pan_prefix: u32) -> Option<u16> {
    ROUTES_31.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_31(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (31 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_31(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
