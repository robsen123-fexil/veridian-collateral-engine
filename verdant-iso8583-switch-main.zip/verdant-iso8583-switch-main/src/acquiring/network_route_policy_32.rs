//! Acquirer network routing policy slice 32 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy32 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_32: &[RoutePolicy32] = &[
    RoutePolicy32 { bin_lo: 432000, bin_hi: 432099, priority: 4, failover_host: 1320 },
    RoutePolicy32 { bin_lo: 432100, bin_hi: 432199, priority: 5, failover_host: 1321 },
    RoutePolicy32 { bin_lo: 432200, bin_hi: 432299, priority: 6, failover_host: 1322 },
    RoutePolicy32 { bin_lo: 432300, bin_hi: 432399, priority: 0, failover_host: 1323 },
    RoutePolicy32 { bin_lo: 432400, bin_hi: 432499, priority: 1, failover_host: 1324 },
    RoutePolicy32 { bin_lo: 432500, bin_hi: 432599, priority: 2, failover_host: 1325 },
    RoutePolicy32 { bin_lo: 432600, bin_hi: 432699, priority: 3, failover_host: 1326 },
    RoutePolicy32 { bin_lo: 432700, bin_hi: 432799, priority: 4, failover_host: 1327 },
];

pub fn route_bin_32(pan_prefix: u32) -> Option<u16> {
    ROUTES_32.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_32(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (32 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_32(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
