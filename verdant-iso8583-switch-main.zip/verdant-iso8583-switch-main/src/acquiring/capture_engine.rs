use crate::merchant::capture_reconciliation::CaptureReconciler;
use crate::merchant::auth_hold_registry::AuthHoldRegistry;

#[derive(Debug, Default)]
pub struct CaptureEngine {
    pub reconciler: CaptureReconciler,
}

impl CaptureEngine {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn run_capture_batch(&mut self, holds: &AuthHoldRegistry, captures: &[(u32, String, i64)]) -> u32 {
        self.reconciler.reconcile(holds, captures);
        self.reconciler.matches.len() as u32
    }
}
