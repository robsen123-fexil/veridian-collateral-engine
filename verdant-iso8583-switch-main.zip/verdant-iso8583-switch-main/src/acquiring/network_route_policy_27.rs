//! Acquirer network routing policy slice 27 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy27 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_27: &[RoutePolicy27] = &[
    RoutePolicy27 { bin_lo: 427000, bin_hi: 427099, priority: 6, failover_host: 1270 },
    RoutePolicy27 { bin_lo: 427100, bin_hi: 427199, priority: 0, failover_host: 1271 },
    RoutePolicy27 { bin_lo: 427200, bin_hi: 427299, priority: 1, failover_host: 1272 },
    RoutePolicy27 { bin_lo: 427300, bin_hi: 427399, priority: 2, failover_host: 1273 },
    RoutePolicy27 { bin_lo: 427400, bin_hi: 427499, priority: 3, failover_host: 1274 },
    RoutePolicy27 { bin_lo: 427500, bin_hi: 427599, priority: 4, failover_host: 1275 },
    RoutePolicy27 { bin_lo: 427600, bin_hi: 427699, priority: 5, failover_host: 1276 },
    RoutePolicy27 { bin_lo: 427700, bin_hi: 427799, priority: 6, failover_host: 1277 },
];

pub fn route_bin_27(pan_prefix: u32) -> Option<u16> {
    ROUTES_27.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_27(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (27 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_27(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
