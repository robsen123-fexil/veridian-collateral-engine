//! Acquirer network routing policy slice 19 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy19 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_19: &[RoutePolicy19] = &[
    RoutePolicy19 { bin_lo: 419000, bin_hi: 419099, priority: 5, failover_host: 1190 },
    RoutePolicy19 { bin_lo: 419100, bin_hi: 419199, priority: 6, failover_host: 1191 },
    RoutePolicy19 { bin_lo: 419200, bin_hi: 419299, priority: 0, failover_host: 1192 },
    RoutePolicy19 { bin_lo: 419300, bin_hi: 419399, priority: 1, failover_host: 1193 },
    RoutePolicy19 { bin_lo: 419400, bin_hi: 419499, priority: 2, failover_host: 1194 },
    RoutePolicy19 { bin_lo: 419500, bin_hi: 419599, priority: 3, failover_host: 1195 },
    RoutePolicy19 { bin_lo: 419600, bin_hi: 419699, priority: 4, failover_host: 1196 },
    RoutePolicy19 { bin_lo: 419700, bin_hi: 419799, priority: 5, failover_host: 1197 },
];

pub fn route_bin_19(pan_prefix: u32) -> Option<u16> {
    ROUTES_19.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_19(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (19 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_19(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
