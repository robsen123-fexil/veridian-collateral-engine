//! Acquirer network routing policy slice 26 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy26 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_26: &[RoutePolicy26] = &[
    RoutePolicy26 { bin_lo: 426000, bin_hi: 426099, priority: 5, failover_host: 1260 },
    RoutePolicy26 { bin_lo: 426100, bin_hi: 426199, priority: 6, failover_host: 1261 },
    RoutePolicy26 { bin_lo: 426200, bin_hi: 426299, priority: 0, failover_host: 1262 },
    RoutePolicy26 { bin_lo: 426300, bin_hi: 426399, priority: 1, failover_host: 1263 },
    RoutePolicy26 { bin_lo: 426400, bin_hi: 426499, priority: 2, failover_host: 1264 },
    RoutePolicy26 { bin_lo: 426500, bin_hi: 426599, priority: 3, failover_host: 1265 },
    RoutePolicy26 { bin_lo: 426600, bin_hi: 426699, priority: 4, failover_host: 1266 },
    RoutePolicy26 { bin_lo: 426700, bin_hi: 426799, priority: 5, failover_host: 1267 },
];

pub fn route_bin_26(pan_prefix: u32) -> Option<u16> {
    ROUTES_26.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_26(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (26 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_26(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
