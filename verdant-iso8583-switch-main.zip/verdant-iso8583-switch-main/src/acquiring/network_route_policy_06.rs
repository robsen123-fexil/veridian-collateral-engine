//! Acquirer network routing policy slice 6 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy06 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_06: &[RoutePolicy06] = &[
    RoutePolicy06 { bin_lo: 406000, bin_hi: 406099, priority: 6, failover_host: 1060 },
    RoutePolicy06 { bin_lo: 406100, bin_hi: 406199, priority: 0, failover_host: 1061 },
    RoutePolicy06 { bin_lo: 406200, bin_hi: 406299, priority: 1, failover_host: 1062 },
    RoutePolicy06 { bin_lo: 406300, bin_hi: 406399, priority: 2, failover_host: 1063 },
    RoutePolicy06 { bin_lo: 406400, bin_hi: 406499, priority: 3, failover_host: 1064 },
    RoutePolicy06 { bin_lo: 406500, bin_hi: 406599, priority: 4, failover_host: 1065 },
    RoutePolicy06 { bin_lo: 406600, bin_hi: 406699, priority: 5, failover_host: 1066 },
    RoutePolicy06 { bin_lo: 406700, bin_hi: 406799, priority: 6, failover_host: 1067 },
];

pub fn route_bin_06(pan_prefix: u32) -> Option<u16> {
    ROUTES_06.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_06(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (6 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_06(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
