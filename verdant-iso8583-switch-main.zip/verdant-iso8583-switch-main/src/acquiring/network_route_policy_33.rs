//! Acquirer network routing policy slice 33 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy33 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_33: &[RoutePolicy33] = &[
    RoutePolicy33 { bin_lo: 433000, bin_hi: 433099, priority: 5, failover_host: 1330 },
    RoutePolicy33 { bin_lo: 433100, bin_hi: 433199, priority: 6, failover_host: 1331 },
    RoutePolicy33 { bin_lo: 433200, bin_hi: 433299, priority: 0, failover_host: 1332 },
    RoutePolicy33 { bin_lo: 433300, bin_hi: 433399, priority: 1, failover_host: 1333 },
    RoutePolicy33 { bin_lo: 433400, bin_hi: 433499, priority: 2, failover_host: 1334 },
    RoutePolicy33 { bin_lo: 433500, bin_hi: 433599, priority: 3, failover_host: 1335 },
    RoutePolicy33 { bin_lo: 433600, bin_hi: 433699, priority: 4, failover_host: 1336 },
    RoutePolicy33 { bin_lo: 433700, bin_hi: 433799, priority: 5, failover_host: 1337 },
];

pub fn route_bin_33(pan_prefix: u32) -> Option<u16> {
    ROUTES_33.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_33(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (33 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_33(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
