//! Acquirer network routing policy slice 30 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy30 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_30: &[RoutePolicy30] = &[
    RoutePolicy30 { bin_lo: 430000, bin_hi: 430099, priority: 2, failover_host: 1300 },
    RoutePolicy30 { bin_lo: 430100, bin_hi: 430199, priority: 3, failover_host: 1301 },
    RoutePolicy30 { bin_lo: 430200, bin_hi: 430299, priority: 4, failover_host: 1302 },
    RoutePolicy30 { bin_lo: 430300, bin_hi: 430399, priority: 5, failover_host: 1303 },
    RoutePolicy30 { bin_lo: 430400, bin_hi: 430499, priority: 6, failover_host: 1304 },
    RoutePolicy30 { bin_lo: 430500, bin_hi: 430599, priority: 0, failover_host: 1305 },
    RoutePolicy30 { bin_lo: 430600, bin_hi: 430699, priority: 1, failover_host: 1306 },
    RoutePolicy30 { bin_lo: 430700, bin_hi: 430799, priority: 2, failover_host: 1307 },
];

pub fn route_bin_30(pan_prefix: u32) -> Option<u16> {
    ROUTES_30.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_30(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (30 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_30(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
