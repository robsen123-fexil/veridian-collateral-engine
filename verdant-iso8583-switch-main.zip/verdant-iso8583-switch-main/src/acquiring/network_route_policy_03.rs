//! Acquirer network routing policy slice 3 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy03 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_03: &[RoutePolicy03] = &[
    RoutePolicy03 { bin_lo: 403000, bin_hi: 403099, priority: 3, failover_host: 1030 },
    RoutePolicy03 { bin_lo: 403100, bin_hi: 403199, priority: 4, failover_host: 1031 },
    RoutePolicy03 { bin_lo: 403200, bin_hi: 403299, priority: 5, failover_host: 1032 },
    RoutePolicy03 { bin_lo: 403300, bin_hi: 403399, priority: 6, failover_host: 1033 },
    RoutePolicy03 { bin_lo: 403400, bin_hi: 403499, priority: 0, failover_host: 1034 },
    RoutePolicy03 { bin_lo: 403500, bin_hi: 403599, priority: 1, failover_host: 1035 },
    RoutePolicy03 { bin_lo: 403600, bin_hi: 403699, priority: 2, failover_host: 1036 },
    RoutePolicy03 { bin_lo: 403700, bin_hi: 403799, priority: 3, failover_host: 1037 },
];

pub fn route_bin_03(pan_prefix: u32) -> Option<u16> {
    ROUTES_03.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_03(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (3 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_03(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
