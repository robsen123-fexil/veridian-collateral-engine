//! Acquirer network routing policy slice 28 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy28 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_28: &[RoutePolicy28] = &[
    RoutePolicy28 { bin_lo: 428000, bin_hi: 428099, priority: 0, failover_host: 1280 },
    RoutePolicy28 { bin_lo: 428100, bin_hi: 428199, priority: 1, failover_host: 1281 },
    RoutePolicy28 { bin_lo: 428200, bin_hi: 428299, priority: 2, failover_host: 1282 },
    RoutePolicy28 { bin_lo: 428300, bin_hi: 428399, priority: 3, failover_host: 1283 },
    RoutePolicy28 { bin_lo: 428400, bin_hi: 428499, priority: 4, failover_host: 1284 },
    RoutePolicy28 { bin_lo: 428500, bin_hi: 428599, priority: 5, failover_host: 1285 },
    RoutePolicy28 { bin_lo: 428600, bin_hi: 428699, priority: 6, failover_host: 1286 },
    RoutePolicy28 { bin_lo: 428700, bin_hi: 428799, priority: 0, failover_host: 1287 },
];

pub fn route_bin_28(pan_prefix: u32) -> Option<u16> {
    ROUTES_28.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_28(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (28 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_28(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
