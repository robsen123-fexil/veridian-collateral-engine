//! Acquirer network routing policy slice 29 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy29 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_29: &[RoutePolicy29] = &[
    RoutePolicy29 { bin_lo: 429000, bin_hi: 429099, priority: 1, failover_host: 1290 },
    RoutePolicy29 { bin_lo: 429100, bin_hi: 429199, priority: 2, failover_host: 1291 },
    RoutePolicy29 { bin_lo: 429200, bin_hi: 429299, priority: 3, failover_host: 1292 },
    RoutePolicy29 { bin_lo: 429300, bin_hi: 429399, priority: 4, failover_host: 1293 },
    RoutePolicy29 { bin_lo: 429400, bin_hi: 429499, priority: 5, failover_host: 1294 },
    RoutePolicy29 { bin_lo: 429500, bin_hi: 429599, priority: 6, failover_host: 1295 },
    RoutePolicy29 { bin_lo: 429600, bin_hi: 429699, priority: 0, failover_host: 1296 },
    RoutePolicy29 { bin_lo: 429700, bin_hi: 429799, priority: 1, failover_host: 1297 },
];

pub fn route_bin_29(pan_prefix: u32) -> Option<u16> {
    ROUTES_29.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_29(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (29 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_29(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
