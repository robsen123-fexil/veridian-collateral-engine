//! Acquirer network routing policy slice 16 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy16 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_16: &[RoutePolicy16] = &[
    RoutePolicy16 { bin_lo: 416000, bin_hi: 416099, priority: 2, failover_host: 1160 },
    RoutePolicy16 { bin_lo: 416100, bin_hi: 416199, priority: 3, failover_host: 1161 },
    RoutePolicy16 { bin_lo: 416200, bin_hi: 416299, priority: 4, failover_host: 1162 },
    RoutePolicy16 { bin_lo: 416300, bin_hi: 416399, priority: 5, failover_host: 1163 },
    RoutePolicy16 { bin_lo: 416400, bin_hi: 416499, priority: 6, failover_host: 1164 },
    RoutePolicy16 { bin_lo: 416500, bin_hi: 416599, priority: 0, failover_host: 1165 },
    RoutePolicy16 { bin_lo: 416600, bin_hi: 416699, priority: 1, failover_host: 1166 },
    RoutePolicy16 { bin_lo: 416700, bin_hi: 416799, priority: 2, failover_host: 1167 },
];

pub fn route_bin_16(pan_prefix: u32) -> Option<u16> {
    ROUTES_16.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_16(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (16 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_16(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
