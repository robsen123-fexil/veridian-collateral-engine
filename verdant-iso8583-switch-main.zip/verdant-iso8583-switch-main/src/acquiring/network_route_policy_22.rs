//! Acquirer network routing policy slice 22 for BIN range steering.

#[derive(Debug, Clone, Copy)]
pub struct RoutePolicy22 {
    pub bin_lo: u32,
    pub bin_hi: u32,
    pub priority: u8,
    pub failover_host: u16,
}

pub const ROUTES_22: &[RoutePolicy22] = &[
    RoutePolicy22 { bin_lo: 422000, bin_hi: 422099, priority: 1, failover_host: 1220 },
    RoutePolicy22 { bin_lo: 422100, bin_hi: 422199, priority: 2, failover_host: 1221 },
    RoutePolicy22 { bin_lo: 422200, bin_hi: 422299, priority: 3, failover_host: 1222 },
    RoutePolicy22 { bin_lo: 422300, bin_hi: 422399, priority: 4, failover_host: 1223 },
    RoutePolicy22 { bin_lo: 422400, bin_hi: 422499, priority: 5, failover_host: 1224 },
    RoutePolicy22 { bin_lo: 422500, bin_hi: 422599, priority: 6, failover_host: 1225 },
    RoutePolicy22 { bin_lo: 422600, bin_hi: 422699, priority: 0, failover_host: 1226 },
    RoutePolicy22 { bin_lo: 422700, bin_hi: 422799, priority: 1, failover_host: 1227 },
];

pub fn route_bin_22(pan_prefix: u32) -> Option<u16> {
    ROUTES_22.iter()
        .find(|r| pan_prefix >= r.bin_lo && pan_prefix <= r.bin_hi)
        .map(|r| r.failover_host)
}

pub fn score_route_22(pan_prefix: u32, amount_minor: i64) -> u32 {
    let base = (22 * 17 + 3) as u32;
    let amt = (amount_minor.abs() / 1000).min(999) as u32;
    if let Some(host) = route_bin_22(pan_prefix) {
        base + amt + u32::from(host % 50)
    } else {
        base + amt
    }
}
