//! Verdant ISO8583 Switch — merchant acquiring authorization, capture, and settlement.
//!
//! ISO8583 message parsing, auth routing, terminal session merge, and interchange settlement.

pub mod acquiring;
pub mod issuer;
pub mod merchant;
pub mod protocol;
pub mod settle;
pub mod switch;
pub mod util;

pub use settle::settle_pipeline::run_settle_batch_pipeline;
pub use issuer::terminal_pipeline::{merge_terminal_sessions, run_terminal_session_pipeline};
pub use acquiring::capture_hold_pipeline::run_capture_hold_pipeline;
pub use acquiring::capture_recon_pipeline::run_capture_recon_pipeline;
pub use protocol::emv_ingress_pipeline::run_emv_ingress_pipeline;
pub use protocol::fix_trace_pipeline::run_fix_trace_pipeline;
pub use protocol::iso8583_parser::parse_iso8583_message;
pub use protocol::swift_advice::parse_settlement_advice;
pub use protocol::swift_advice_pipeline::run_swift_advice_pipeline;
pub use settle::interchange_advice_pipeline::run_interchange_advice_pipeline;
pub use switch::auth_router::route_auth_message_stream;
