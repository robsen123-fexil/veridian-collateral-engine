use crate::protocol::vis_magics::{SWIFT_BATCH_MAGIC, SWIFT_BATCH_VERSION};
use crate::util::limits::MAX_SETTLE_RECORDS;

#[derive(Debug, Clone)]
pub struct SwiftAdviceSegment {
    pub seq: u32,
    pub seg_flags: u16,
    pub link_tag: u32,
    pub reference: String,
    pub amount_minor: i64,
}

#[derive(Debug, Default)]
pub struct SwiftBatchWireState {
    pub version: u16,
    pub flags: u32,
    pub segments: Vec<SwiftAdviceSegment>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SwiftBatchDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    SegmentOverflow,
    RefOob,
}

pub fn decode_swift_batch_wire(input: &[u8]) -> Result<SwiftBatchWireState, SwiftBatchDecodeError> {
    if input.len() < 14 || &input[..4] != SWIFT_BATCH_MAGIC {
        return Err(SwiftBatchDecodeError::TooShort);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != SWIFT_BATCH_VERSION {
        return Err(SwiftBatchDecodeError::BadVersion);
    }
    let segment_count = u32::from_le_bytes([input[6], input[7], input[8], input[9]]) as usize;
    if segment_count > MAX_SETTLE_RECORDS {
        return Err(SwiftBatchDecodeError::SegmentOverflow);
    }
    let flags = u32::from_le_bytes([input[10], input[11], input[12], input[13]]);
    let mut off = 14;
    let mut segments = Vec::with_capacity(segment_count);
    for _ in 0..segment_count {
        if off + 20 > input.len() {
            return Err(SwiftBatchDecodeError::TooShort);
        }
        let seq = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]);
        let seg_flags = u16::from_le_bytes([input[off + 4], input[off + 5]]);
        let link_tag = u32::from_le_bytes([input[off + 6], input[off + 7], input[off + 8], input[off + 9]]);
        let amount_minor = i64::from_le_bytes([
            input[off + 10],
            input[off + 11],
            input[off + 12],
            input[off + 13],
            input[off + 14],
            input[off + 15],
            input[off + 16],
            input[off + 17],
        ]);
        let ref_len = u16::from_le_bytes([input[off + 18], input[off + 19]]) as usize;
        off += 20;
        if off + ref_len > input.len() {
            return Err(SwiftBatchDecodeError::RefOob);
        }
        let reference = String::from_utf8_lossy(&input[off..off + ref_len]).into_owned();
        off += ref_len;
        segments.push(SwiftAdviceSegment {
            seq,
            seg_flags,
            link_tag,
            reference,
            amount_minor,
        });
    }
    Ok(SwiftBatchWireState {
        version,
        flags,
        segments,
    })
}
