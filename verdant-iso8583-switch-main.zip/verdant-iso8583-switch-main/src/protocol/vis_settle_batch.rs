use crate::protocol::vis_magics::{SETTLE_BATCH_MAGIC, SETTLE_VERSION};
use crate::util::limits::{slice_at, MAX_SETTLE_RECORDS, MAX_ISO_FRAME};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SettleRecordHeader {
    pub mti_class: u16,
    pub stan: u32,
    pub payload_offset: u32,
    pub payload_len: u32,
    pub merchant_tag: u32,
}

#[derive(Debug, Clone, Copy)]
pub struct SettleReconPin {
    pub record_index: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct SettleBatchWireState {
    pub version: u16,
    pub acquirer_id: u16,
    pub flags: u32,
    pub headers: Vec<SettleRecordHeader>,
    pub payload_arena: Vec<u8>,
    pub recon_pins: Vec<SettleReconPin>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SettleDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    RecordOverflow,
    PayloadOob,
}

pub fn decode_settle_batch_wire(input: &[u8]) -> Result<SettleBatchWireState, SettleDecodeError> {
    if input.len() < 16 {
        return Err(SettleDecodeError::TooShort);
    }
    if &input[..4] != SETTLE_BATCH_MAGIC {
        return Err(SettleDecodeError::BadMagic);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != SETTLE_VERSION {
        return Err(SettleDecodeError::BadVersion);
    }
    let record_count = u32::from_le_bytes([input[6], input[7], input[8], input[9]]) as usize;
    if record_count > MAX_SETTLE_RECORDS {
        return Err(SettleDecodeError::RecordOverflow);
    }
    let flags = u32::from_le_bytes([input[10], input[11], input[12], input[13]]);
    let acquirer_id = u16::from_le_bytes([input[14], input[15]]);
    let mut off = 16;
    let mut headers = Vec::with_capacity(record_count);
    for _ in 0..record_count {
        if off + 18 > input.len() {
            return Err(SettleDecodeError::TooShort);
        }
        let mti_class = u16::from_le_bytes([input[off], input[off + 1]]);
        let stan = u32::from_le_bytes([input[off + 2], input[off + 3], input[off + 4], input[off + 5]]);
        let payload_offset = u32::from_le_bytes([input[off + 6], input[off + 7], input[off + 8], input[off + 9]]);
        let payload_len = u32::from_le_bytes([input[off + 10], input[off + 11], input[off + 12], input[off + 13]]);
        let merchant_tag = u32::from_le_bytes([input[off + 14], input[off + 15], input[off + 16], input[off + 17]]);
        headers.push(SettleRecordHeader {
            mti_class,
            stan,
            payload_offset,
            payload_len,
            merchant_tag,
        });
        off += 18;
    }
    let payload_arena = input.get(off..).unwrap_or(&[]).to_vec();
    if payload_arena.len() > MAX_ISO_FRAME {
        return Err(SettleDecodeError::PayloadOob);
    }
    Ok(SettleBatchWireState {
        version,
        acquirer_id,
        flags,
        headers,
        payload_arena,
        recon_pins: Vec::new(),
    })
}

pub fn record_payload<'a>(state: &'a SettleBatchWireState, idx: usize) -> Option<&'a [u8]> {
    let hdr = state.headers.get(idx)?;
    let off = hdr.payload_offset as usize;
    let len = hdr.payload_len as usize;
    slice_at(&state.payload_arena, off, len)
}

pub fn capture_settle_recon_pins(state: &SettleBatchWireState) {
    let table = crate::settle::batch_pin_board::batch_pin_table();
    let mut guard = table.lock().expect("pin table");
    if state.flags & crate::settle::batch_wire_flags::BATCH_FLAG_RESET_PIN_EPOCH != 0 {
        guard.slots.clear();
        guard.pinned_records = 0;
    }
    guard.capture_epoch = guard.capture_epoch.wrapping_add(1);
    for (idx, _hdr) in state.headers.iter().enumerate() {
        if !crate::settle::batch_chain_digest::record_eligible_for_recon_pin(state, idx) {
            continue;
        }
        if let Some(payload) = record_payload(state, idx) {
            if payload.is_empty() {
                continue;
            }
            unsafe {
                guard.slots.push(SettleReconPin {
                    record_index: idx as u32,
                    ptr: payload.as_ptr(),
                    len: payload.len(),
                });
            }
            guard.pinned_records += 1;
        }
    }
}

pub fn encode_settle_batch_wire(state: &SettleBatchWireState) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&SETTLE_BATCH_MAGIC);
    out.extend_from_slice(&state.version.to_le_bytes());
    out.extend_from_slice(&(state.headers.len() as u32).to_le_bytes());
    out.extend_from_slice(&state.flags.to_le_bytes());
    out.extend_from_slice(&state.acquirer_id.to_le_bytes());
    for hdr in &state.headers {
        out.extend_from_slice(&hdr.mti_class.to_le_bytes());
        out.extend_from_slice(&hdr.stan.to_le_bytes());
        out.extend_from_slice(&hdr.payload_offset.to_le_bytes());
        out.extend_from_slice(&hdr.payload_len.to_le_bytes());
        out.extend_from_slice(&hdr.merchant_tag.to_le_bytes());
    }
    out.extend_from_slice(&state.payload_arena);
    out
}
