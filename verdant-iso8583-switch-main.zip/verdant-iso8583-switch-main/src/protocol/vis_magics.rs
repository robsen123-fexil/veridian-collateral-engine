pub const SETTLE_BATCH_MAGIC: [u8; 4] = *b"VISB";
pub const AUTH_CAPSULE_MAGIC: [u8; 4] = *b"VISA";
pub const TERMINAL_FRAME_MAGIC: [u8; 4] = *b"VIST";
pub const CAPTURE_HOLD_MAGIC: [u8; 4] = *b"VISC";
pub const EMV_INGRESS_MAGIC: [u8; 4] = *b"VISE";
pub const SWIFT_BATCH_MAGIC: [u8; 4] = *b"VISW";
pub const FIX_TRACE_MAGIC: [u8; 4] = *b"VISF";
pub const CAPTURE_RECON_MAGIC: [u8; 4] = *b"VISR";
pub const INTERCHANGE_ADVICE_MAGIC: [u8; 4] = *b"VISI";

pub const SETTLE_VERSION: u16 = 2;
pub const AUTH_VERSION: u16 = 2;
pub const TERMINAL_VERSION: u16 = 1;
pub const CAPTURE_HOLD_VERSION: u16 = 1;
pub const EMV_INGRESS_VERSION: u16 = 1;
pub const SWIFT_BATCH_VERSION: u16 = 1;
pub const FIX_TRACE_VERSION: u16 = 1;
pub const CAPTURE_RECON_VERSION: u16 = 1;
pub const INTERCHANGE_ADVICE_VERSION: u16 = 1;

pub fn matches_magic(input: &[u8], magic: &[u8; 4]) -> bool {
    input.len() >= 4 && &input[..4] == magic
}
