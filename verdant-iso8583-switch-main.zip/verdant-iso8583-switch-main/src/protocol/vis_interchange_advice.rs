use crate::protocol::vis_magics::{INTERCHANGE_ADVICE_MAGIC, INTERCHANGE_ADVICE_VERSION};
use crate::util::limits::{slice_at, MAX_ISO_FRAME, MAX_SETTLE_RECORDS};

#[derive(Debug, Clone, Copy)]
pub struct InterchangeSlotHeader {
    pub mcc: u16,
    pub slot_flags: u16,
    pub tier_offset: u32,
    pub tier_len: u32,
    pub merchant_slot: u32,
}

#[derive(Debug, Default)]
pub struct InterchangeAdviceState {
    pub version: u16,
    pub flags: u32,
    pub headers: Vec<InterchangeSlotHeader>,
    pub tier_arena: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InterchangeAdviceDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    SlotOverflow,
    TierOob,
}

pub fn decode_interchange_advice_wire(input: &[u8]) -> Result<InterchangeAdviceState, InterchangeAdviceDecodeError> {
    if input.len() < 14 {
        return Err(InterchangeAdviceDecodeError::TooShort);
    }
    if &input[..4] != INTERCHANGE_ADVICE_MAGIC {
        return Err(InterchangeAdviceDecodeError::BadMagic);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != INTERCHANGE_ADVICE_VERSION {
        return Err(InterchangeAdviceDecodeError::BadVersion);
    }
    let slot_count = u32::from_le_bytes([input[6], input[7], input[8], input[9]]) as usize;
    if slot_count > MAX_SETTLE_RECORDS {
        return Err(InterchangeAdviceDecodeError::SlotOverflow);
    }
    let flags = u32::from_le_bytes([input[10], input[11], input[12], input[13]]);
    let mut off = 14;
    let mut headers = Vec::with_capacity(slot_count);
    for _ in 0..slot_count {
        if off + 16 > input.len() {
            return Err(InterchangeAdviceDecodeError::TooShort);
        }
        let mcc = u16::from_le_bytes([input[off], input[off + 1]]);
        let slot_flags = u16::from_le_bytes([input[off + 2], input[off + 3]]);
        let tier_offset = u32::from_le_bytes([input[off + 4], input[off + 5], input[off + 6], input[off + 7]]);
        let tier_len = u32::from_le_bytes([input[off + 8], input[off + 9], input[off + 10], input[off + 11]]);
        let merchant_slot = u32::from_le_bytes([input[off + 12], input[off + 13], input[off + 14], input[off + 15]]);
        headers.push(InterchangeSlotHeader {
            mcc,
            slot_flags,
            tier_offset,
            tier_len,
            merchant_slot,
        });
        off += 16;
    }
    let tier_arena = input.get(off..).unwrap_or(&[]).to_vec();
    if tier_arena.len() > MAX_ISO_FRAME {
        return Err(InterchangeAdviceDecodeError::TierOob);
    }
    Ok(InterchangeAdviceState {
        version,
        flags,
        headers,
        tier_arena,
    })
}

pub fn tier_payload<'a>(state: &'a InterchangeAdviceState, idx: usize) -> Option<&'a [u8]> {
    let hdr = state.headers.get(idx)?;
    let off = hdr.tier_offset as usize;
    let len = hdr.tier_len as usize;
    slice_at(&state.tier_arena, off, len)
}
