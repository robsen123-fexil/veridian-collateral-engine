//! Minimal FIX gateway bridge for host connectivity.

#[derive(Debug, Default, Clone)]
pub struct FixGatewayFrame {
    pub tags: Vec<(u32, String)>,
}

pub fn parse_fix_gateway_frame(input: &[u8]) -> Result<FixGatewayFrame, ()> {
    let s = std::str::from_utf8(input).map_err(|_| ())?;
    let mut tags = Vec::new();
    for part in s.split('\x01') {
        if part.is_empty() {
            continue;
        }
        if let Some((k, v)) = part.split_once('=') {
            if let Ok(tag) = k.parse::<u32>() {
                tags.push((tag, v.to_string()));
            }
        }
    }
    Ok(FixGatewayFrame { tags })
}

pub fn fix_tag_string(frame: &FixGatewayFrame, tag: u32) -> Option<&str> {
    frame.tags.iter().find(|(t, _)| *t == tag).map(|(_, v)| v.as_str())
}
