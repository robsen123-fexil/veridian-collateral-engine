use crate::protocol::vis_magics::{AUTH_CAPSULE_MAGIC, AUTH_VERSION};
use crate::util::limits::{MAX_ISO_FRAME, MAX_TLV_DEPTH};

#[derive(Debug, Clone)]
pub struct AuthCapsuleNode {
    pub channel: u16,
    pub depth: u16,
    pub flags: u16,
    pub payload: Vec<u8>,
    pub children: Vec<AuthCapsuleNode>,
}

#[derive(Debug, Default)]
pub struct AuthCapsuleTree {
    pub roots: Vec<AuthCapsuleNode>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CapsuleDecodeError {
    TooShort,
    BadMagic,
    DepthExceeded,
}

pub fn decode_auth_capsule_tree(input: &[u8]) -> Result<AuthCapsuleTree, CapsuleDecodeError> {
    if input.len() < 8 || &input[..4] != AUTH_CAPSULE_MAGIC {
        return Err(if input.len() < 8 {
            CapsuleDecodeError::TooShort
        } else {
            CapsuleDecodeError::BadMagic
        });
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != AUTH_VERSION {
        return Err(CapsuleDecodeError::BadMagic);
    }
    let root_count = u16::from_le_bytes([input[6], input[7]]) as usize;
    let mut off = 8;
    let mut roots = Vec::with_capacity(root_count);
    for _ in 0..root_count {
        let (node, consumed) = parse_node(input, off, 0)?;
        off += consumed;
        roots.push(node);
    }
    Ok(AuthCapsuleTree { roots })
}

fn parse_node(input: &[u8], mut off: usize, depth: u16) -> Result<(AuthCapsuleNode, usize), CapsuleDecodeError> {
    if depth as usize > MAX_TLV_DEPTH {
        return Err(CapsuleDecodeError::DepthExceeded);
    }
    if off + 10 > input.len() {
        return Err(CapsuleDecodeError::TooShort);
    }
    let start = off;
    let channel = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    let node_depth = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    let payload_len = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]) as usize;
    off += 4;
    let child_count = u16::from_le_bytes([input[off], input[off + 1]]) as usize;
    off += 2;
    let flags = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    if off + payload_len > input.len() {
        return Err(CapsuleDecodeError::TooShort);
    }
    let payload = input[off..off + payload_len].to_vec();
    off += payload_len;
    let mut children = Vec::with_capacity(child_count);
    for _ in 0..child_count {
        let (child, consumed) = parse_node(input, off, depth.saturating_add(1))?;
        off += consumed;
        children.push(child);
    }
    Ok((
        AuthCapsuleNode {
            channel,
            depth: node_depth,
            flags,
            payload,
            children,
        },
        off - start,
    ))
}

pub fn encode_auth_capsule_tree(tree: &AuthCapsuleTree) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&AUTH_CAPSULE_MAGIC);
    out.extend_from_slice(&AUTH_VERSION.to_le_bytes());
    out.extend_from_slice(&(tree.roots.len() as u16).to_le_bytes());
    for root in &tree.roots {
        encode_node(&mut out, root);
    }
    if out.len() > MAX_ISO_FRAME {
        out.truncate(MAX_ISO_FRAME);
    }
    out
}

fn encode_node(out: &mut Vec<u8>, node: &AuthCapsuleNode) {
    out.extend_from_slice(&node.channel.to_le_bytes());
    out.extend_from_slice(&node.depth.to_le_bytes());
    out.extend_from_slice(&(node.payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&(node.children.len() as u16).to_le_bytes());
    out.extend_from_slice(&node.flags.to_le_bytes());
    out.extend_from_slice(&node.payload);
    for child in &node.children {
        encode_node(out, child);
    }
}
