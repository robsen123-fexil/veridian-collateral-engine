//! MTI-specific validation and response shaping for acquiring switch.

use crate::protocol::iso8583_parser::{parse_iso8583_message, Iso8583Message, IsoParseError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MtiHandlerError {
    Parse(IsoParseError),
    UnsupportedMti(u16),
    Declined(&'static str),
}

pub fn handle_inbound_mti(input: &[u8]) -> Result<Iso8583Message, MtiHandlerError> {
    let msg = parse_iso8583_message(input).map_err(MtiHandlerError::Parse)?;
    match msg.mti {
        200 => validate_auth_request(&msg)?,
        220 => validate_capture_advice(&msg)?,
        400 => validate_reversal(&msg)?,
        800 => return Ok(msg),
        _ => return Err(MtiHandlerError::UnsupportedMti(msg.mti)),
    }
    Ok(msg)
}

fn validate_auth_request(msg: &Iso8583Message) -> Result<(), MtiHandlerError> {
    if msg.fields.get(&4).is_none() {
        return Err(MtiHandlerError::Declined("missing amount"));
    }
    if msg.fields.get(&11).is_none() {
        return Err(MtiHandlerError::Declined("missing stan"));
    }
    Ok(())
}

fn validate_capture_advice(msg: &Iso8583Message) -> Result<(), MtiHandlerError> {
    if msg.fields.get(&38).is_none() {
        return Err(MtiHandlerError::Declined("missing auth code"));
    }
    Ok(())
}

fn validate_reversal(msg: &Iso8583Message) -> Result<(), MtiHandlerError> {
    if msg.fields.get(&37).is_none() {
        return Err(MtiHandlerError::Declined("missing rrn"));
    }
    Ok(())
}

/// Response code mapping for issuer host simulation.
pub fn map_decline_to_response(code: &str) -> &'static str {
    match code {
        "insufficient" => "51",
        "stolen" => "43",
        "expired" => "54",
        "limit" => "61",
        _ => "05",
    }
}
