//! SWIFT MT n96 settlement advice scanner.

#[derive(Debug, Default, Clone)]
pub struct SettlementAdvice {
    pub reference: String,
    pub value_date: String,
    pub amount_minor: i64,
    pub currency: String,
}

pub fn parse_settlement_advice(input: &[u8]) -> Result<SettlementAdvice, ()> {
    let text = std::str::from_utf8(input).map_err(|_| ())?;
    let mut advice = SettlementAdvice::default();
    for line in text.lines() {
        if let Some(rest) = line.strip_prefix(":20:") {
            advice.reference = rest.trim().to_string();
        } else if let Some(rest) = line.strip_prefix(":32A:") {
            parse_32a(rest, &mut advice);
        }
    }
    if advice.reference.is_empty() {
        return Err(());
    }
    Ok(advice)
}

fn parse_32a(s: &str, advice: &mut SettlementAdvice) {
    let parts: Vec<&str> = s.trim().splitn(2, ',').collect();
    if parts.len() == 2 {
        advice.value_date = parts[0].to_string();
        if parts[1].len() >= 4 {
            advice.currency = parts[1][..3].to_string();
            if let Ok(amt) = parts[1][3..].replace(',', "").parse::<i64>() {
                advice.amount_minor = amt;
            }
        }
    }
}
