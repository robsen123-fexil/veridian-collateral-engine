//! Acquiring switch product constants.

pub const DEFAULT_CURRENCY: &str = "840";
pub const MAX_STAN: u32 = 999_999;
pub const CAPTURE_MTI: u16 = 220;
pub const AUTH_MTI: u16 = 200;
pub const REVERSAL_MTI: u16 = 400;

pub fn mti_class(mti: u16) -> u8 {
    ((mti / 100) % 10) as u8
}

pub fn is_financial(mti: u16) -> bool {
    mti_class(mti) == 2
}

pub fn is_reversal(mti: u16) -> bool {
    mti_class(mti) == 4
}

pub fn is_network(mti: u16) -> bool {
    mti_class(mti) == 8
}
