//! Ancestor FIX tag-path digest for nested trace capsules.

use crate::util::crc16::rolling_crc16;

pub const MIN_FIX_PIN_DEPTH: u16 = 2;
pub const FIX_PIN_FLAG_MASK: u16 = 0x0006;

pub fn fix_path_seed() -> u16 {
    0xF1C0
}

pub fn extend_fix_path_digest(ancestor_crc: u16, tag: u16) -> u16 {
    rolling_crc16(ancestor_crc, &tag.to_le_bytes())
}

pub fn fix_pin_tag_matches(ancestor_crc: u16, tag: u16) -> bool {
    (tag & 0xFF) as u16 == ancestor_crc
}
