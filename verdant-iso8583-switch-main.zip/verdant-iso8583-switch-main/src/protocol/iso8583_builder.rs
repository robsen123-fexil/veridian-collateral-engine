use crate::protocol::iso8583_parser::Iso8583Message;
use crate::util::bitmap::FieldBitmap;

pub fn build_auth_request(
    pan: &str,
    amount: &str,
    stan: &str,
    terminal_id: &str,
    merchant_id: &str,
) -> Vec<u8> {
    let mut msg = Iso8583Message {
        mti: 200,
        bitmap: FieldBitmap::default(),
        fields: std::collections::HashMap::new(),
    };
    msg.bitmap.set(2);
    msg.bitmap.set(3);
    msg.bitmap.set(4);
    msg.bitmap.set(11);
    msg.bitmap.set(41);
    msg.bitmap.set(42);
    msg.fields.insert(2, pan.as_bytes().to_vec());
    msg.fields.insert(3, b"000000".to_vec());
    msg.fields.insert(4, amount.as_bytes().to_vec());
    msg.fields.insert(11, stan.as_bytes().to_vec());
    msg.fields.insert(41, terminal_id.as_bytes().to_vec());
    msg.fields.insert(42, merchant_id.as_bytes().to_vec());
    encode_message(&msg)
}

pub fn build_capture_advice(stan: &str, amount: &str, auth_code: &str) -> Vec<u8> {
    let mut msg = Iso8583Message {
        mti: 220,
        bitmap: FieldBitmap::default(),
        fields: std::collections::HashMap::new(),
    };
    msg.bitmap.set(3);
    msg.bitmap.set(4);
    msg.bitmap.set(11);
    msg.bitmap.set(38);
    msg.fields.insert(3, b"000000".to_vec());
    msg.fields.insert(4, amount.as_bytes().to_vec());
    msg.fields.insert(11, stan.as_bytes().to_vec());
    msg.fields.insert(38, auth_code.as_bytes().to_vec());
    encode_message(&msg)
}

fn encode_message(msg: &Iso8583Message) -> Vec<u8> {
    use crate::protocol::iso8583_field_registry::{lookup_field, IsoFieldFormat};
    let mut out = format!("{:04}", msg.mti).into_bytes();
    out.extend_from_slice(&msg.bitmap.bits[0].to_be_bytes());
    if msg.bitmap.bits[1] != 0 {
        out.extend_from_slice(&msg.bitmap.bits[1].to_be_bytes());
    }
    for de in msg.bitmap.field_list() {
        let Some(val) = msg.fields.get(&(de as u16)) else {
            continue;
        };
        let Some(spec) = lookup_field(de as u16) else {
            continue;
        };
        match spec.format {
            IsoFieldFormat::Fixed(w) => {
                let mut padded = val.clone();
                if padded.len() < w {
                    padded.resize(w, b'0');
                }
                out.extend_from_slice(&padded[..w]);
            }
            IsoFieldFormat::LlVar(_) => {
                out.push(b'0' + (val.len() / 10) as u8);
                out.push(b'0' + (val.len() % 10) as u8);
                out.extend_from_slice(val);
            }
            IsoFieldFormat::LllVar(_) => {
                out.push(b'0' + (val.len() / 100) as u8);
                out.push(b'0' + ((val.len() / 10) % 10) as u8);
                out.push(b'0' + (val.len() % 10) as u8);
                out.extend_from_slice(val);
            }
            IsoFieldFormat::Binary(w) => {
                out.extend_from_slice(&val[..w.min(val.len())]);
            }
        }
    }
    out
}
