//! Prefix tag-path digest across nested EMV ingress nodes.

use crate::protocol::vis_emv_ingress::EmvIngressNode;
use crate::util::crc16::rolling_crc16;

const TAG_CHAIN_SEED: u16 = 0xE8A1;
pub const MIN_EMV_PIN_DEPTH: u16 = 2;
pub const EMV_PIN_FLAG_MASK: u16 = 0x000C;

pub fn tag_path_seed() -> u16 {
    TAG_CHAIN_SEED
}

pub fn extend_tag_path_digest(ancestor_crc: u16, tag: u16) -> u16 {
    rolling_crc16(ancestor_crc, &tag.to_le_bytes())
}

pub fn emv_pin_tag_matches(ancestor_crc: u16, tag: u16) -> bool {
    (tag & 0xFF) as u16 == ancestor_crc
}

pub fn prior_sibling_tag_digest(nodes: &[EmvIngressNode], node_index: usize) -> u16 {
    let mut crc = TAG_CHAIN_SEED;
    for (idx, node) in nodes.iter().enumerate() {
        if idx >= node_index {
            break;
        }
        crc = extend_tag_path_digest(crc, node.tag);
        let n = node.value.len().min(6);
        if n > 0 {
            crc = rolling_crc16(crc, &node.value[..n]);
        }
    }
    crc
}
