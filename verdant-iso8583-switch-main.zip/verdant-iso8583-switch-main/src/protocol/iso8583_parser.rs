use crate::util::bitmap::FieldBitmap;
use crate::util::limits::MAX_ISO_FRAME;
use std::collections::HashMap;

#[derive(Debug, Clone, Default)]
pub struct Iso8583Message {
    pub mti: u16,
    pub bitmap: FieldBitmap,
    pub fields: HashMap<u16, Vec<u8>>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IsoParseError {
    TooShort,
    BadMti,
    BitmapTruncated,
    FieldTruncated(u16),
}

pub fn parse_iso8583_message(input: &[u8]) -> Result<Iso8583Message, IsoParseError> {
    if input.len() < 4 {
        return Err(IsoParseError::TooShort);
    }
    let mti = parse_mti(&input[..4])?;
    let mut off = 4;
    if off + 8 > input.len() {
        return Err(IsoParseError::BitmapTruncated);
    }
    let primary = u64::from_be_bytes([
        input[off],
        input[off + 1],
        input[off + 2],
        input[off + 3],
        input[off + 4],
        input[off + 5],
        input[off + 6],
        input[off + 7],
    ]);
    off += 8;
    let secondary = if primary & (1 << 63) != 0 {
        if off + 8 > input.len() {
            return Err(IsoParseError::BitmapTruncated);
        }
        let sec = u64::from_be_bytes([
            input[off],
            input[off + 1],
            input[off + 2],
            input[off + 3],
            input[off + 4],
            input[off + 5],
            input[off + 6],
            input[off + 7],
        ]);
        off += 8;
        Some(sec)
    } else {
        None
    };
    let bitmap = FieldBitmap::from_primary_secondary(primary, secondary);
    let mut fields = HashMap::new();
    for de in bitmap.field_list() {
        let (value, consumed) = parse_field(input, off, de)?;
        off += consumed;
        fields.insert(de as u16, value);
        if off > MAX_ISO_FRAME {
            break;
        }
    }
    Ok(Iso8583Message {
        mti,
        bitmap,
        fields,
    })
}

fn parse_mti(s: &[u8]) -> Result<u16, IsoParseError> {
    if s.len() < 4 || !s.iter().all(|b| b.is_ascii_digit()) {
        return Err(IsoParseError::BadMti);
    }
    let mti = s
        .iter()
        .fold(0u16, |acc, &b| acc * 10 + (b - b'0') as u16);
    Ok(mti)
}

fn parse_field(input: &[u8], off: usize, de: u8) -> Result<(Vec<u8>, usize), IsoParseError> {
    use crate::protocol::iso8583_field_registry::{lookup_field, IsoFieldFormat};
    let spec = lookup_field(de as u16).ok_or(IsoParseError::FieldTruncated(de as u16))?;
    match spec.format {
        IsoFieldFormat::Fixed(w) => {
            if off + w > input.len() {
                return Err(IsoParseError::FieldTruncated(de as u16));
            }
            Ok((input[off..off + w].to_vec(), w))
        }
        IsoFieldFormat::LlVar(max) => {
            if off + 2 > input.len() {
                return Err(IsoParseError::FieldTruncated(de as u16));
            }
            let len = ((input[off] - b'0') as usize) * 10 + (input[off + 1] - b'0') as usize;
            if len > max || off + 2 + len > input.len() {
                return Err(IsoParseError::FieldTruncated(de as u16));
            }
            Ok((input[off + 2..off + 2 + len].to_vec(), 2 + len))
        }
        IsoFieldFormat::LllVar(max) => {
            if off + 3 > input.len() {
                return Err(IsoParseError::FieldTruncated(de as u16));
            }
            let len = ((input[off] - b'0') as usize) * 100
                + ((input[off + 1] - b'0') as usize) * 10
                + (input[off + 2] - b'0') as usize;
            if len > max || off + 3 + len > input.len() {
                return Err(IsoParseError::FieldTruncated(de as u16));
            }
            Ok((input[off + 3..off + 3 + len].to_vec(), 3 + len))
        }
        IsoFieldFormat::Binary(w) => {
            if off + w > input.len() {
                return Err(IsoParseError::FieldTruncated(de as u16));
            }
            Ok((input[off..off + w].to_vec(), w))
        }
    }
}

impl Iso8583Message {
    pub fn stan(&self) -> Option<u32> {
        self.fields.get(&11).map(|f| {
            f.iter()
                .fold(0u32, |acc, &b| acc * 10 + (b - b'0') as u32)
        })
    }

    pub fn amount_minor(&self) -> Option<i64> {
        self.fields.get(&4).map(|f| {
            f.iter()
                .fold(0i64, |acc, &b| acc * 10 + (b - b'0') as i64)
        })
    }

    pub fn response_code(&self) -> Option<String> {
        self.fields.get(&39).map(|f| String::from_utf8_lossy(f).into_owned())
    }
}
