use crate::merchant::swift_ref_compactor::{compact_swift_ref_storage, SwiftRefCompactor};
use crate::merchant::swift_ref_digest::finalize_swift_ref_digest;
use crate::merchant::swift_ref_tape::capture_swift_ref_pins;
use crate::protocol::vis_swift_batch::{decode_swift_batch_wire, SwiftBatchDecodeError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SwiftAdvicePipelineError {
    Decode(SwiftBatchDecodeError),
    EmptyBatch,
}

pub fn run_swift_advice_pipeline(input: &[u8]) -> Result<u16, SwiftAdvicePipelineError> {
    let mut state = decode_swift_batch_wire(input).map_err(SwiftAdvicePipelineError::Decode)?;
    if state.segments.is_empty() {
        return Err(SwiftAdvicePipelineError::EmptyBatch);
    }

    capture_swift_ref_pins(&state);

    let mut compactor = SwiftRefCompactor::default();
    compact_swift_ref_storage(&mut compactor, &mut state);

    Ok(finalize_swift_ref_digest(0x5F1F))
}
