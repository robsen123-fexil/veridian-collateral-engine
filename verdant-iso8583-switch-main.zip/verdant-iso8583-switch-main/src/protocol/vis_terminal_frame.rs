use crate::protocol::vis_magics::{TERMINAL_FRAME_MAGIC, TERMINAL_VERSION};
use crate::util::limits::MAX_TERMINAL_LEGS;

#[derive(Debug, Clone)]
pub struct TerminalLeg {
    pub leg_id: u32,
    pub terminal_id: u32,
    pub amount_minor: i64,
    pub track_data: Vec<u8>,
}

#[derive(Debug, Default)]
pub struct TerminalSessionFrame {
    pub version: u16,
    pub batch_id: u32,
    pub graft_flags: u32,
    pub legs: Vec<TerminalLeg>,
}

#[derive(Debug, Clone, Copy)]
pub struct TerminalMergePin {
    pub leg_index: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TerminalDecodeError {
    TooShort,
    BadMagic,
    TooManyLegs,
}

pub fn decode_terminal_frame(input: &[u8]) -> Result<TerminalSessionFrame, TerminalDecodeError> {
    if input.len() < 14 || &input[..4] != TERMINAL_FRAME_MAGIC {
        return Err(TerminalDecodeError::TooShort);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != TERMINAL_VERSION {
        return Err(TerminalDecodeError::BadMagic);
    }
    let batch_id = u32::from_le_bytes([input[6], input[7], input[8], input[9]]);
    let leg_count = u32::from_le_bytes([input[10], input[11], input[12], input[13]]) as usize;
    if leg_count > MAX_TERMINAL_LEGS {
        return Err(TerminalDecodeError::TooManyLegs);
    }
    let mut off = 14;
    let graft_flags = if input.len() >= off + 4 {
        let f = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]);
        off += 4;
        f
    } else {
        0
    };
    let mut legs = Vec::with_capacity(leg_count);
    for _ in 0..leg_count {
        if off + 24 > input.len() {
            return Err(TerminalDecodeError::TooShort);
        }
        let leg_id = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]);
        let terminal_id = u32::from_le_bytes([input[off + 4], input[off + 5], input[off + 6], input[off + 7]]);
        let amount_minor = i64::from_le_bytes([
            input[off + 8],
            input[off + 9],
            input[off + 10],
            input[off + 11],
            input[off + 12],
            input[off + 13],
            input[off + 14],
            input[off + 15],
        ]);
        let track_len = u32::from_le_bytes([input[off + 16], input[off + 17], input[off + 18], input[off + 19]]) as usize;
        off += 20;
        if off + track_len > input.len() {
            return Err(TerminalDecodeError::TooShort);
        }
        let track_data = input[off..off + track_len].to_vec();
        off += track_len;
        legs.push(TerminalLeg {
            leg_id,
            terminal_id,
            amount_minor,
            track_data,
        });
    }
    Ok(TerminalSessionFrame {
        version,
        batch_id,
        graft_flags,
        legs,
    })
}

pub fn encode_terminal_frame(frame: &TerminalSessionFrame) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&TERMINAL_FRAME_MAGIC);
    out.extend_from_slice(&frame.version.to_le_bytes());
    out.extend_from_slice(&frame.batch_id.to_le_bytes());
    out.extend_from_slice(&(frame.legs.len() as u32).to_le_bytes());
    out.extend_from_slice(&frame.graft_flags.to_le_bytes());
    for leg in &frame.legs {
        out.extend_from_slice(&leg.leg_id.to_le_bytes());
        out.extend_from_slice(&leg.terminal_id.to_le_bytes());
        out.extend_from_slice(&leg.amount_minor.to_le_bytes());
        out.extend_from_slice(&(leg.track_data.len() as u32).to_le_bytes());
        out.extend_from_slice(&leg.track_data);
    }
    out
}
