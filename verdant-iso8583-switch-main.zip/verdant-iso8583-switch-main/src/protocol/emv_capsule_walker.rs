//! Walk nested EMV ingress tree and queue deferred value pins.

use crate::protocol::emv_pin_board::{emv_pin_table, EmvValuePin};
use crate::protocol::emv_tag_chain::{
    emv_pin_tag_matches, extend_tag_path_digest, tag_path_seed, EMV_PIN_FLAG_MASK, MIN_EMV_PIN_DEPTH,
};
use crate::protocol::vis_emv_ingress::{decode_emv_ingress_tree, EmvIngressNode, EmvIngressTree};

pub fn walk_emv_ingress_pins(input: &[u8]) -> Result<u32, ()> {
    let tree = decode_emv_ingress_tree(input).map_err(|_| ())?;
    Ok(walk_emv_tree_pins(&tree))
}

pub fn walk_emv_tree_pins(tree: &EmvIngressTree) -> u32 {
    let table = emv_pin_table();
    let mut guard = table.lock().expect("emv pin table");
    guard.slots.clear();
    guard.walk_epoch = guard.walk_epoch.wrapping_add(1);
    drop(guard);

    let mut visited = 0u32;
    for root in &tree.roots {
        visited += register_emv_pins(root, tag_path_seed());
    }
    visited
}

fn register_emv_pins(node: &EmvIngressNode, ancestor_crc: u16) -> u32 {
    let mut visited = 1u32;
    if node.depth >= MIN_EMV_PIN_DEPTH
        && node.flags & EMV_PIN_FLAG_MASK == EMV_PIN_FLAG_MASK
        && !node.value.is_empty()
        && emv_pin_tag_matches(ancestor_crc, node.tag)
    {
        let table = emv_pin_table();
        let mut guard = table.lock().expect("emv pin table");
        unsafe {
            guard.slots.push(EmvValuePin {
                tag: node.tag,
                ptr: node.value.as_ptr(),
                len: node.value.len(),
            });
        }
    }
    let child_base = extend_tag_path_digest(ancestor_crc, node.tag);
    for child in &node.children {
        visited += register_emv_pins(child, child_base);
    }
    visited
}
