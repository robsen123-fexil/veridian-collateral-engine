//! Finalize EMV ingress fingerprint from deferred TLV pins.

use crate::protocol::emv_pin_board::emv_pin_table;
use crate::util::crc16::rolling_crc16;

pub fn seal_emv_ingress_fingerprint(seed: u16) -> u16 {
    let guard = emv_pin_table().lock().expect("emv pin table");
    let mut crc = seed;
    for pin in &guard.slots {
        if pin.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
            crc = rolling_crc16(crc, bytes);
        }
        crc = rolling_crc16(crc, &pin.tag.to_le_bytes());
    }
    crc
}
