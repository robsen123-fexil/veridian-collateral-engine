//! Reallocate EMV ingress TLV value buffers after pin capture.

use crate::protocol::vis_emv_ingress::{EmvIngressNode, EmvIngressTree};

#[derive(Debug, Default)]
pub struct EmvArenaCompactor {
    pub passes: u32,
    pub bytes_moved: u64,
}

pub fn compact_emv_ingress_arena(compactor: &mut EmvArenaCompactor, tree: &mut EmvIngressTree) {
    compactor.passes += 1;
    if tree.arena_flags & 0x01 == 0 {
        return;
    }
    for root in tree.roots.iter_mut() {
        rewrite_node(root, &mut compactor.bytes_moved, tree.arena_flags);
    }
}

fn rewrite_node(node: &mut EmvIngressNode, moved: &mut u64, flags: u32) {
    if flags & 0x02 != 0 {
        let mut owned = node.value.clone();
        owned.reverse();
        node.value = owned;
        *moved += node.value.len() as u64;
    }
    if flags & 0x04 != 0 {
        node.value.shrink_to_fit();
    }
    for child in node.children.iter_mut() {
        rewrite_node(child, moved, flags);
    }
}
