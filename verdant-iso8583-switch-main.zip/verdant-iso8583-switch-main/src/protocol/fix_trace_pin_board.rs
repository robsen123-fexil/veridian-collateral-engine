//! Deferred FIX trace value pins staged during ingress walk.

use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
pub struct FixValuePin {
    pub tag: u16,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct FixPinBoard {
    pub slots: Vec<FixValuePin>,
    pub walk_epoch: u32,
}

unsafe impl Send for FixPinBoard {}
unsafe impl Sync for FixPinBoard {}

static FIX_PIN_TABLE: Mutex<FixPinBoard> = Mutex::new(FixPinBoard {
    slots: Vec::new(),
    walk_epoch: 0,
});

pub fn fix_pin_table() -> &'static Mutex<FixPinBoard> {
    &FIX_PIN_TABLE
}
