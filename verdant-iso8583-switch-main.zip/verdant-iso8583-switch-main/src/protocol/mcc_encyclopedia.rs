//! Merchant category code encyclopedia and risk overlays.

pub fn mcc_1000_descriptor() -> &'static str {
    "1000 acquiring segment"
}
pub fn mcc_1000_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_1120_descriptor() -> &'static str {
    "1120 acquiring segment"
}
pub fn mcc_1120_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_1240_descriptor() -> &'static str {
    "1240 acquiring segment"
}
pub fn mcc_1240_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_1360_descriptor() -> &'static str {
    "1360 acquiring segment"
}
pub fn mcc_1360_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_1480_descriptor() -> &'static str {
    "1480 acquiring segment"
}
pub fn mcc_1480_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_1600_descriptor() -> &'static str {
    "1600 acquiring segment"
}
pub fn mcc_1600_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_1720_descriptor() -> &'static str {
    "1720 acquiring segment"
}
pub fn mcc_1720_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_1840_descriptor() -> &'static str {
    "1840 acquiring segment"
}
pub fn mcc_1840_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_1960_descriptor() -> &'static str {
    "1960 acquiring segment"
}
pub fn mcc_1960_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_2080_descriptor() -> &'static str {
    "2080 acquiring segment"
}
pub fn mcc_2080_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_2200_descriptor() -> &'static str {
    "2200 acquiring segment"
}
pub fn mcc_2200_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_2320_descriptor() -> &'static str {
    "2320 acquiring segment"
}
pub fn mcc_2320_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_2440_descriptor() -> &'static str {
    "2440 acquiring segment"
}
pub fn mcc_2440_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_2560_descriptor() -> &'static str {
    "2560 acquiring segment"
}
pub fn mcc_2560_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_2680_descriptor() -> &'static str {
    "2680 acquiring segment"
}
pub fn mcc_2680_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_2800_descriptor() -> &'static str {
    "2800 acquiring segment"
}
pub fn mcc_2800_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_2920_descriptor() -> &'static str {
    "2920 acquiring segment"
}
pub fn mcc_2920_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_3040_descriptor() -> &'static str {
    "3040 acquiring segment"
}
pub fn mcc_3040_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_3160_descriptor() -> &'static str {
    "3160 acquiring segment"
}
pub fn mcc_3160_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_3280_descriptor() -> &'static str {
    "3280 acquiring segment"
}
pub fn mcc_3280_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_3400_descriptor() -> &'static str {
    "3400 acquiring segment"
}
pub fn mcc_3400_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_3520_descriptor() -> &'static str {
    "3520 acquiring segment"
}
pub fn mcc_3520_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_3640_descriptor() -> &'static str {
    "3640 acquiring segment"
}
pub fn mcc_3640_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_3760_descriptor() -> &'static str {
    "3760 acquiring segment"
}
pub fn mcc_3760_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_3880_descriptor() -> &'static str {
    "3880 acquiring segment"
}
pub fn mcc_3880_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_4000_descriptor() -> &'static str {
    "4000 acquiring segment"
}
pub fn mcc_4000_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_4120_descriptor() -> &'static str {
    "4120 acquiring segment"
}
pub fn mcc_4120_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_4240_descriptor() -> &'static str {
    "4240 acquiring segment"
}
pub fn mcc_4240_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_4360_descriptor() -> &'static str {
    "4360 acquiring segment"
}
pub fn mcc_4360_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_4480_descriptor() -> &'static str {
    "4480 acquiring segment"
}
pub fn mcc_4480_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_4600_descriptor() -> &'static str {
    "4600 acquiring segment"
}
pub fn mcc_4600_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_4720_descriptor() -> &'static str {
    "4720 acquiring segment"
}
pub fn mcc_4720_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_4840_descriptor() -> &'static str {
    "4840 acquiring segment"
}
pub fn mcc_4840_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_4960_descriptor() -> &'static str {
    "4960 acquiring segment"
}
pub fn mcc_4960_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_5080_descriptor() -> &'static str {
    "5080 acquiring segment"
}
pub fn mcc_5080_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_5200_descriptor() -> &'static str {
    "5200 acquiring segment"
}
pub fn mcc_5200_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_5320_descriptor() -> &'static str {
    "5320 acquiring segment"
}
pub fn mcc_5320_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_5440_descriptor() -> &'static str {
    "5440 acquiring segment"
}
pub fn mcc_5440_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_5560_descriptor() -> &'static str {
    "5560 acquiring segment"
}
pub fn mcc_5560_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_5680_descriptor() -> &'static str {
    "5680 acquiring segment"
}
pub fn mcc_5680_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_5800_descriptor() -> &'static str {
    "5800 acquiring segment"
}
pub fn mcc_5800_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_5920_descriptor() -> &'static str {
    "5920 acquiring segment"
}
pub fn mcc_5920_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_6040_descriptor() -> &'static str {
    "6040 acquiring segment"
}
pub fn mcc_6040_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_6160_descriptor() -> &'static str {
    "6160 acquiring segment"
}
pub fn mcc_6160_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_6280_descriptor() -> &'static str {
    "6280 acquiring segment"
}
pub fn mcc_6280_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_6400_descriptor() -> &'static str {
    "6400 acquiring segment"
}
pub fn mcc_6400_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_6520_descriptor() -> &'static str {
    "6520 acquiring segment"
}
pub fn mcc_6520_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_6640_descriptor() -> &'static str {
    "6640 acquiring segment"
}
pub fn mcc_6640_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_6760_descriptor() -> &'static str {
    "6760 acquiring segment"
}
pub fn mcc_6760_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_6880_descriptor() -> &'static str {
    "6880 acquiring segment"
}
pub fn mcc_6880_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_7000_descriptor() -> &'static str {
    "7000 acquiring segment"
}
pub fn mcc_7000_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_7120_descriptor() -> &'static str {
    "7120 acquiring segment"
}
pub fn mcc_7120_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_7240_descriptor() -> &'static str {
    "7240 acquiring segment"
}
pub fn mcc_7240_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_7360_descriptor() -> &'static str {
    "7360 acquiring segment"
}
pub fn mcc_7360_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_7480_descriptor() -> &'static str {
    "7480 acquiring segment"
}
pub fn mcc_7480_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_7600_descriptor() -> &'static str {
    "7600 acquiring segment"
}
pub fn mcc_7600_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_7720_descriptor() -> &'static str {
    "7720 acquiring segment"
}
pub fn mcc_7720_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_7840_descriptor() -> &'static str {
    "7840 acquiring segment"
}
pub fn mcc_7840_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_7960_descriptor() -> &'static str {
    "7960 acquiring segment"
}
pub fn mcc_7960_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_8080_descriptor() -> &'static str {
    "8080 acquiring segment"
}
pub fn mcc_8080_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_8200_descriptor() -> &'static str {
    "8200 acquiring segment"
}
pub fn mcc_8200_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_8320_descriptor() -> &'static str {
    "8320 acquiring segment"
}
pub fn mcc_8320_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_8440_descriptor() -> &'static str {
    "8440 acquiring segment"
}
pub fn mcc_8440_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_8560_descriptor() -> &'static str {
    "8560 acquiring segment"
}
pub fn mcc_8560_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_8680_descriptor() -> &'static str {
    "8680 acquiring segment"
}
pub fn mcc_8680_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_8800_descriptor() -> &'static str {
    "8800 acquiring segment"
}
pub fn mcc_8800_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_8920_descriptor() -> &'static str {
    "8920 acquiring segment"
}
pub fn mcc_8920_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_9040_descriptor() -> &'static str {
    "9040 acquiring segment"
}
pub fn mcc_9040_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_9160_descriptor() -> &'static str {
    "9160 acquiring segment"
}
pub fn mcc_9160_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_9280_descriptor() -> &'static str {
    "9280 acquiring segment"
}
pub fn mcc_9280_interchange_cap_bps() -> u32 {
    400
}
pub fn mcc_9400_descriptor() -> &'static str {
    "9400 acquiring segment"
}
pub fn mcc_9400_interchange_cap_bps() -> u32 {
    220
}
pub fn mcc_9520_descriptor() -> &'static str {
    "9520 acquiring segment"
}
pub fn mcc_9520_interchange_cap_bps() -> u32 {
    340
}
pub fn mcc_9640_descriptor() -> &'static str {
    "9640 acquiring segment"
}
pub fn mcc_9640_interchange_cap_bps() -> u32 {
    160
}
pub fn mcc_9760_descriptor() -> &'static str {
    "9760 acquiring segment"
}
pub fn mcc_9760_interchange_cap_bps() -> u32 {
    280
}
pub fn mcc_9880_descriptor() -> &'static str {
    "9880 acquiring segment"
}
pub fn mcc_9880_interchange_cap_bps() -> u32 {
    400
}
