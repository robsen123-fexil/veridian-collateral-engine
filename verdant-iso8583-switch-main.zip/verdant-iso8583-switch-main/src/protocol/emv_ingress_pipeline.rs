use crate::protocol::emv_capsule_walker::walk_emv_tree_pins;
use crate::protocol::emv_ingress_seal::seal_emv_ingress_fingerprint;
use crate::protocol::emv_tlv_compactor::{compact_emv_ingress_arena, EmvArenaCompactor};
use crate::protocol::emv_wire_flags::{EMV_FLAG_CARRY_SEAL, EMV_FLAG_DEFER_SEAL};
use crate::protocol::vis_emv_ingress::{decode_emv_ingress_tree, EmvIngressDecodeError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EmvIngressPipelineError {
    Decode(EmvIngressDecodeError),
    EmptyTree,
}

pub fn run_emv_ingress_pipeline(input: &[u8]) -> Result<u16, EmvIngressPipelineError> {
    let mut tree = decode_emv_ingress_tree(input).map_err(EmvIngressPipelineError::Decode)?;
    if tree.roots.is_empty() {
        return Err(EmvIngressPipelineError::EmptyTree);
    }

    if tree.arena_flags & EMV_FLAG_CARRY_SEAL != 0 {
        return Ok(seal_emv_ingress_fingerprint(0xE0A0));
    }

    let visited = walk_emv_tree_pins(&tree);
    if visited == 0 {
        return Err(EmvIngressPipelineError::EmptyTree);
    }

    let mut compactor = EmvArenaCompactor::default();
    compact_emv_ingress_arena(&mut compactor, &mut tree);

    if tree.arena_flags & EMV_FLAG_DEFER_SEAL != 0 {
        return Ok(0);
    }

    Ok(seal_emv_ingress_fingerprint(0xE0A0))
}
