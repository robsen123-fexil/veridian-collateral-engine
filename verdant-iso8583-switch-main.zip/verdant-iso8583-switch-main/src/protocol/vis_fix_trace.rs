use crate::protocol::vis_magics::{FIX_TRACE_MAGIC, FIX_TRACE_VERSION};
use crate::util::limits::{MAX_ISO_FRAME, MAX_TLV_DEPTH};

#[derive(Debug, Clone)]
pub struct FixTraceNode {
    pub tag: u16,
    pub depth: u16,
    pub flags: u16,
    pub value: Vec<u8>,
    pub children: Vec<FixTraceNode>,
}

#[derive(Debug, Default)]
pub struct FixTraceTree {
    pub roots: Vec<FixTraceNode>,
    pub arena_flags: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FixTraceDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    DepthExceeded,
}

pub fn decode_fix_trace_tree(input: &[u8]) -> Result<FixTraceTree, FixTraceDecodeError> {
    if input.len() < 12 || &input[..4] != FIX_TRACE_MAGIC {
        return Err(FixTraceDecodeError::TooShort);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != FIX_TRACE_VERSION {
        return Err(FixTraceDecodeError::BadVersion);
    }
    let arena_flags = u32::from_le_bytes([input[6], input[7], input[8], input[9]]);
    let root_count = u16::from_le_bytes([input[10], input[11]]) as usize;
    let mut off = 12;
    let mut roots = Vec::with_capacity(root_count);
    for _ in 0..root_count {
        let (node, consumed) = parse_fix_node(input, off, 0)?;
        off += consumed;
        roots.push(node);
    }
    Ok(FixTraceTree {
        roots,
        arena_flags,
    })
}

fn parse_fix_node(input: &[u8], mut off: usize, depth: u16) -> Result<(FixTraceNode, usize), FixTraceDecodeError> {
    if depth as usize > MAX_TLV_DEPTH {
        return Err(FixTraceDecodeError::DepthExceeded);
    }
    if off + 10 > input.len() {
        return Err(FixTraceDecodeError::TooShort);
    }
    let start = off;
    let tag = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    let node_depth = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    let value_len = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]) as usize;
    off += 4;
    let child_count = u16::from_le_bytes([input[off], input[off + 1]]) as usize;
    off += 2;
    let flags = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    if off + value_len > input.len() {
        return Err(FixTraceDecodeError::TooShort);
    }
    let value = input[off..off + value_len].to_vec();
    off += value_len;
    let mut children = Vec::with_capacity(child_count);
    for _ in 0..child_count {
        let (child, consumed) = parse_fix_node(input, off, depth.saturating_add(1))?;
        off += consumed;
        children.push(child);
    }
    Ok((
        FixTraceNode {
            tag,
            depth: node_depth,
            flags,
            value,
            children,
        },
        off - start,
    ))
}

pub fn encode_fix_trace_tree(tree: &FixTraceTree) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&FIX_TRACE_MAGIC);
    out.extend_from_slice(&FIX_TRACE_VERSION.to_le_bytes());
    out.extend_from_slice(&tree.arena_flags.to_le_bytes());
    out.extend_from_slice(&(tree.roots.len() as u16).to_le_bytes());
    for root in &tree.roots {
        encode_fix_node(&mut out, root);
    }
    if out.len() > MAX_ISO_FRAME {
        out.truncate(MAX_ISO_FRAME);
    }
    out
}

fn encode_fix_node(out: &mut Vec<u8>, node: &FixTraceNode) {
    out.extend_from_slice(&node.tag.to_le_bytes());
    out.extend_from_slice(&node.depth.to_le_bytes());
    out.extend_from_slice(&(node.value.len() as u32).to_le_bytes());
    out.extend_from_slice(&(node.children.len() as u16).to_le_bytes());
    out.extend_from_slice(&node.flags.to_le_bytes());
    out.extend_from_slice(&node.value);
    for child in &node.children {
        encode_fix_node(out, child);
    }
}
