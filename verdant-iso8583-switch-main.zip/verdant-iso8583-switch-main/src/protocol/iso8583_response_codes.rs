//! ISO8583 response code catalog and decline reason mapping.

#[derive(Debug, Clone, Copy)]
pub struct ResponseCodeEntry {
    pub code: &'static str,
    pub description: &'static str,
    pub retryable: bool,
    pub chargeback_risk_bps: u16,
}

pub const RESPONSE_TABLE: &[ResponseCodeEntry] = &[
    ResponseCodeEntry { code: "00", description: "Approved", retryable: false, chargeback_risk_bps: 0 },
    ResponseCodeEntry { code: "05", description: "Do not honor", retryable: false, chargeback_risk_bps: 50 },
    ResponseCodeEntry { code: "12", description: "Invalid transaction", retryable: true, chargeback_risk_bps: 10 },
    ResponseCodeEntry { code: "14", description: "Invalid card number", retryable: false, chargeback_risk_bps: 200 },
    ResponseCodeEntry { code: "30", description: "Format error", retryable: true, chargeback_risk_bps: 5 },
    ResponseCodeEntry { code: "41", description: "Lost card", retryable: false, chargeback_risk_bps: 500 },
    ResponseCodeEntry { code: "43", description: "Stolen card", retryable: false, chargeback_risk_bps: 800 },
    ResponseCodeEntry { code: "51", description: "Insufficient funds", retryable: true, chargeback_risk_bps: 20 },
    ResponseCodeEntry { code: "54", description: "Expired card", retryable: false, chargeback_risk_bps: 100 },
    ResponseCodeEntry { code: "55", description: "Incorrect PIN", retryable: true, chargeback_risk_bps: 15 },
    ResponseCodeEntry { code: "57", description: "Transaction not permitted", retryable: false, chargeback_risk_bps: 30 },
    ResponseCodeEntry { code: "58", description: "Transaction not permitted to terminal", retryable: false, chargeback_risk_bps: 25 },
    ResponseCodeEntry { code: "61", description: "Exceeds withdrawal limit", retryable: true, chargeback_risk_bps: 40 },
    ResponseCodeEntry { code: "62", description: "Restricted card", retryable: false, chargeback_risk_bps: 120 },
    ResponseCodeEntry { code: "65", description: "Exceeds frequency limit", retryable: true, chargeback_risk_bps: 35 },
    ResponseCodeEntry { code: "91", description: "Issuer unavailable", retryable: true, chargeback_risk_bps: 0 },
    ResponseCodeEntry { code: "96", description: "System malfunction", retryable: true, chargeback_risk_bps: 0 },
];

pub fn lookup_response(code: &str) -> Option<&'static ResponseCodeEntry> {
    RESPONSE_TABLE.iter().find(|e| e.code == code)
}

/// Regional decline overlay bucket 0.
pub fn regional_decline_weight_0(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 1.
pub fn regional_decline_weight_1(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 2.
pub fn regional_decline_weight_2(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 3.
pub fn regional_decline_weight_3(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 4.
pub fn regional_decline_weight_4(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 5.
pub fn regional_decline_weight_5(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 6.
pub fn regional_decline_weight_6(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 7.
pub fn regional_decline_weight_7(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 8.
pub fn regional_decline_weight_8(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 9.
pub fn regional_decline_weight_9(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 10.
pub fn regional_decline_weight_10(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 11.
pub fn regional_decline_weight_11(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 12.
pub fn regional_decline_weight_12(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 13.
pub fn regional_decline_weight_13(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 14.
pub fn regional_decline_weight_14(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 15.
pub fn regional_decline_weight_15(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 16.
pub fn regional_decline_weight_16(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 17.
pub fn regional_decline_weight_17(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 18.
pub fn regional_decline_weight_18(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 19.
pub fn regional_decline_weight_19(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 20.
pub fn regional_decline_weight_20(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 21.
pub fn regional_decline_weight_21(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 22.
pub fn regional_decline_weight_22(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 23.
pub fn regional_decline_weight_23(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 24.
pub fn regional_decline_weight_24(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 25.
pub fn regional_decline_weight_25(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 26.
pub fn regional_decline_weight_26(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 27.
pub fn regional_decline_weight_27(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 28.
pub fn regional_decline_weight_28(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 29.
pub fn regional_decline_weight_29(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 30.
pub fn regional_decline_weight_30(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 31.
pub fn regional_decline_weight_31(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 32.
pub fn regional_decline_weight_32(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 33.
pub fn regional_decline_weight_33(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 34.
pub fn regional_decline_weight_34(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 35.
pub fn regional_decline_weight_35(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 36.
pub fn regional_decline_weight_36(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 37.
pub fn regional_decline_weight_37(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 38.
pub fn regional_decline_weight_38(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 39.
pub fn regional_decline_weight_39(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 40.
pub fn regional_decline_weight_40(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 41.
pub fn regional_decline_weight_41(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 42.
pub fn regional_decline_weight_42(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 43.
pub fn regional_decline_weight_43(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 44.
pub fn regional_decline_weight_44(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 45.
pub fn regional_decline_weight_45(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 46.
pub fn regional_decline_weight_46(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 47.
pub fn regional_decline_weight_47(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 48.
pub fn regional_decline_weight_48(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 49.
pub fn regional_decline_weight_49(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 50.
pub fn regional_decline_weight_50(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 51.
pub fn regional_decline_weight_51(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 52.
pub fn regional_decline_weight_52(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 53.
pub fn regional_decline_weight_53(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 54.
pub fn regional_decline_weight_54(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 55.
pub fn regional_decline_weight_55(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 56.
pub fn regional_decline_weight_56(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 57.
pub fn regional_decline_weight_57(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 58.
pub fn regional_decline_weight_58(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 59.
pub fn regional_decline_weight_59(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 60.
pub fn regional_decline_weight_60(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 61.
pub fn regional_decline_weight_61(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 62.
pub fn regional_decline_weight_62(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 63.
pub fn regional_decline_weight_63(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 64.
pub fn regional_decline_weight_64(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 65.
pub fn regional_decline_weight_65(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 66.
pub fn regional_decline_weight_66(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 67.
pub fn regional_decline_weight_67(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 68.
pub fn regional_decline_weight_68(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 69.
pub fn regional_decline_weight_69(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 70.
pub fn regional_decline_weight_70(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 71.
pub fn regional_decline_weight_71(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 72.
pub fn regional_decline_weight_72(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 73.
pub fn regional_decline_weight_73(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 74.
pub fn regional_decline_weight_74(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 75.
pub fn regional_decline_weight_75(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 76.
pub fn regional_decline_weight_76(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 77.
pub fn regional_decline_weight_77(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 78.
pub fn regional_decline_weight_78(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 79.
pub fn regional_decline_weight_79(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 80.
pub fn regional_decline_weight_80(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 81.
pub fn regional_decline_weight_81(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 82.
pub fn regional_decline_weight_82(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 83.
pub fn regional_decline_weight_83(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 84.
pub fn regional_decline_weight_84(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 85.
pub fn regional_decline_weight_85(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 86.
pub fn regional_decline_weight_86(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 87.
pub fn regional_decline_weight_87(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 88.
pub fn regional_decline_weight_88(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 89.
pub fn regional_decline_weight_89(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 90.
pub fn regional_decline_weight_90(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 91.
pub fn regional_decline_weight_91(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 92.
pub fn regional_decline_weight_92(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 93.
pub fn regional_decline_weight_93(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 94.
pub fn regional_decline_weight_94(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 95.
pub fn regional_decline_weight_95(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 96.
pub fn regional_decline_weight_96(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 97.
pub fn regional_decline_weight_97(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 98.
pub fn regional_decline_weight_98(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 99.
pub fn regional_decline_weight_99(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 100.
pub fn regional_decline_weight_100(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 101.
pub fn regional_decline_weight_101(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 102.
pub fn regional_decline_weight_102(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 103.
pub fn regional_decline_weight_103(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 104.
pub fn regional_decline_weight_104(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 105.
pub fn regional_decline_weight_105(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 106.
pub fn regional_decline_weight_106(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 107.
pub fn regional_decline_weight_107(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 108.
pub fn regional_decline_weight_108(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 109.
pub fn regional_decline_weight_109(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 110.
pub fn regional_decline_weight_110(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 111.
pub fn regional_decline_weight_111(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 112.
pub fn regional_decline_weight_112(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 113.
pub fn regional_decline_weight_113(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 114.
pub fn regional_decline_weight_114(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 115.
pub fn regional_decline_weight_115(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 116.
pub fn regional_decline_weight_116(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 117.
pub fn regional_decline_weight_117(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 118.
pub fn regional_decline_weight_118(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 119.
pub fn regional_decline_weight_119(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 120.
pub fn regional_decline_weight_120(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 121.
pub fn regional_decline_weight_121(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 122.
pub fn regional_decline_weight_122(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 123.
pub fn regional_decline_weight_123(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 124.
pub fn regional_decline_weight_124(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 125.
pub fn regional_decline_weight_125(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 126.
pub fn regional_decline_weight_126(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 127.
pub fn regional_decline_weight_127(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 128.
pub fn regional_decline_weight_128(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 129.
pub fn regional_decline_weight_129(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 130.
pub fn regional_decline_weight_130(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 131.
pub fn regional_decline_weight_131(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 132.
pub fn regional_decline_weight_132(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 133.
pub fn regional_decline_weight_133(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 134.
pub fn regional_decline_weight_134(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 135.
pub fn regional_decline_weight_135(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 136.
pub fn regional_decline_weight_136(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 137.
pub fn regional_decline_weight_137(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 138.
pub fn regional_decline_weight_138(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 139.
pub fn regional_decline_weight_139(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 140.
pub fn regional_decline_weight_140(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 141.
pub fn regional_decline_weight_141(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 142.
pub fn regional_decline_weight_142(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 143.
pub fn regional_decline_weight_143(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 144.
pub fn regional_decline_weight_144(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 145.
pub fn regional_decline_weight_145(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 146.
pub fn regional_decline_weight_146(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 147.
pub fn regional_decline_weight_147(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 148.
pub fn regional_decline_weight_148(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 149.
pub fn regional_decline_weight_149(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 150.
pub fn regional_decline_weight_150(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 151.
pub fn regional_decline_weight_151(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 152.
pub fn regional_decline_weight_152(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 153.
pub fn regional_decline_weight_153(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 154.
pub fn regional_decline_weight_154(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 155.
pub fn regional_decline_weight_155(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 156.
pub fn regional_decline_weight_156(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 157.
pub fn regional_decline_weight_157(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 158.
pub fn regional_decline_weight_158(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 159.
pub fn regional_decline_weight_159(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 160.
pub fn regional_decline_weight_160(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 161.
pub fn regional_decline_weight_161(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 162.
pub fn regional_decline_weight_162(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 163.
pub fn regional_decline_weight_163(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 164.
pub fn regional_decline_weight_164(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 165.
pub fn regional_decline_weight_165(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 166.
pub fn regional_decline_weight_166(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 167.
pub fn regional_decline_weight_167(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 168.
pub fn regional_decline_weight_168(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 169.
pub fn regional_decline_weight_169(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 170.
pub fn regional_decline_weight_170(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 171.
pub fn regional_decline_weight_171(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 172.
pub fn regional_decline_weight_172(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 173.
pub fn regional_decline_weight_173(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 174.
pub fn regional_decline_weight_174(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 175.
pub fn regional_decline_weight_175(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 176.
pub fn regional_decline_weight_176(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 177.
pub fn regional_decline_weight_177(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 178.
pub fn regional_decline_weight_178(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 179.
pub fn regional_decline_weight_179(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 180.
pub fn regional_decline_weight_180(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 181.
pub fn regional_decline_weight_181(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 182.
pub fn regional_decline_weight_182(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 183.
pub fn regional_decline_weight_183(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 184.
pub fn regional_decline_weight_184(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 185.
pub fn regional_decline_weight_185(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 186.
pub fn regional_decline_weight_186(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 187.
pub fn regional_decline_weight_187(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 188.
pub fn regional_decline_weight_188(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 189.
pub fn regional_decline_weight_189(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 2;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 190.
pub fn regional_decline_weight_190(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 3;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 191.
pub fn regional_decline_weight_191(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 4;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 192.
pub fn regional_decline_weight_192(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 5;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 193.
pub fn regional_decline_weight_193(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 6;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 194.
pub fn regional_decline_weight_194(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 7;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 195.
pub fn regional_decline_weight_195(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 8;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 196.
pub fn regional_decline_weight_196(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 9;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 197.
pub fn regional_decline_weight_197(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 10;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 198.
pub fn regional_decline_weight_198(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 0;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}

/// Regional decline overlay bucket 199.
pub fn regional_decline_weight_199(mcc: u16, amount_minor: i64) -> u32 {
    let mcc_factor = (mcc as u32 % 97) + 1;
    let amt = (amount_minor.abs() / 500).min(2000) as u32;
    mcc_factor.saturating_mul(3).saturating_add(amt / 10)
}
