use crate::protocol::vis_magics::{CAPTURE_RECON_MAGIC, CAPTURE_RECON_VERSION};
use crate::util::limits::MAX_SETTLE_RECORDS;

#[derive(Debug, Clone)]
pub struct CaptureReconRecord {
    pub stan: u32,
    pub rec_flags: u16,
    pub link_tag: u32,
    pub capture_ref: String,
    pub amount_minor: i64,
}

#[derive(Debug, Default)]
pub struct CaptureReconWireState {
    pub version: u16,
    pub flags: u32,
    pub records: Vec<CaptureReconRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CaptureReconDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    RecordOverflow,
    RefOob,
}

pub fn decode_capture_recon_wire(input: &[u8]) -> Result<CaptureReconWireState, CaptureReconDecodeError> {
    if input.len() < 14 || &input[..4] != CAPTURE_RECON_MAGIC {
        return Err(CaptureReconDecodeError::TooShort);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != CAPTURE_RECON_VERSION {
        return Err(CaptureReconDecodeError::BadVersion);
    }
    let record_count = u32::from_le_bytes([input[6], input[7], input[8], input[9]]) as usize;
    if record_count > MAX_SETTLE_RECORDS {
        return Err(CaptureReconDecodeError::RecordOverflow);
    }
    let flags = u32::from_le_bytes([input[10], input[11], input[12], input[13]]);
    let mut off = 14;
    let mut records = Vec::with_capacity(record_count);
    for _ in 0..record_count {
        if off + 20 > input.len() {
            return Err(CaptureReconDecodeError::TooShort);
        }
        let stan = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]);
        let rec_flags = u16::from_le_bytes([input[off + 4], input[off + 5]]);
        let link_tag = u32::from_le_bytes([input[off + 6], input[off + 7], input[off + 8], input[off + 9]]);
        let amount_minor = i64::from_le_bytes([
            input[off + 10],
            input[off + 11],
            input[off + 12],
            input[off + 13],
            input[off + 14],
            input[off + 15],
            input[off + 16],
            input[off + 17],
        ]);
        let ref_len = u16::from_le_bytes([input[off + 18], input[off + 19]]) as usize;
        off += 20;
        if off + ref_len > input.len() {
            return Err(CaptureReconDecodeError::RefOob);
        }
        let capture_ref = String::from_utf8_lossy(&input[off..off + ref_len]).into_owned();
        off += ref_len;
        records.push(CaptureReconRecord {
            stan,
            rec_flags,
            link_tag,
            capture_ref,
            amount_minor,
        });
    }
    Ok(CaptureReconWireState {
        version,
        flags,
        records,
    })
}
