use crate::protocol::fix_trace_compactor::{compact_fix_trace_arena, FixArenaCompactor};
use crate::protocol::fix_trace_seal::seal_fix_trace_fingerprint;
use crate::protocol::fix_trace_walker::walk_fix_tree_pins;
use crate::protocol::vis_fix_trace::{decode_fix_trace_tree, FixTraceDecodeError};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FixTracePipelineError {
    Decode(FixTraceDecodeError),
    EmptyTree,
}

pub fn run_fix_trace_pipeline(input: &[u8]) -> Result<u16, FixTracePipelineError> {
    let mut tree = decode_fix_trace_tree(input).map_err(FixTracePipelineError::Decode)?;
    if tree.roots.is_empty() {
        return Err(FixTracePipelineError::EmptyTree);
    }

    let visited = walk_fix_tree_pins(&tree);
    if visited == 0 {
        return Err(FixTracePipelineError::EmptyTree);
    }

    let mut compactor = FixArenaCompactor::default();
    compact_fix_trace_arena(&mut compactor, &mut tree);

    Ok(seal_fix_trace_fingerprint(0xF1CE))
}
