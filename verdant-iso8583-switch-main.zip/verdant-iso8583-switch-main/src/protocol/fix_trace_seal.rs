//! Finalize FIX trace fingerprint from deferred value pins.

use crate::protocol::fix_trace_pin_board::fix_pin_table;
use crate::util::crc16::rolling_crc16;

pub fn seal_fix_trace_fingerprint(seed: u16) -> u16 {
    let guard = fix_pin_table().lock().expect("fix pin table");
    let mut crc = seed;
    for pin in &guard.slots {
        if pin.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
            crc = rolling_crc16(crc, bytes);
        }
        crc = rolling_crc16(crc, &pin.tag.to_le_bytes());
    }
    crc
}
