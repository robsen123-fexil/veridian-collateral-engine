use crate::protocol::vis_magics::{EMV_INGRESS_MAGIC, EMV_INGRESS_VERSION};
use crate::util::limits::{MAX_ISO_FRAME, MAX_TLV_DEPTH};

#[derive(Debug, Clone)]
pub struct EmvIngressNode {
    pub tag: u16,
    pub depth: u16,
    pub flags: u16,
    pub value: Vec<u8>,
    pub children: Vec<EmvIngressNode>,
}

#[derive(Debug, Default)]
pub struct EmvIngressTree {
    pub roots: Vec<EmvIngressNode>,
    pub arena_flags: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EmvIngressDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    DepthExceeded,
}

pub fn decode_emv_ingress_tree(input: &[u8]) -> Result<EmvIngressTree, EmvIngressDecodeError> {
    if input.len() < 12 || &input[..4] != EMV_INGRESS_MAGIC {
        return Err(EmvIngressDecodeError::TooShort);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != EMV_INGRESS_VERSION {
        return Err(EmvIngressDecodeError::BadVersion);
    }
    let arena_flags = u32::from_le_bytes([input[6], input[7], input[8], input[9]]);
    let root_count = u16::from_le_bytes([input[10], input[11]]) as usize;
    let mut off = 12;
    let mut roots = Vec::with_capacity(root_count);
    for _ in 0..root_count {
        let (node, consumed) = parse_emv_node(input, off, 0)?;
        off += consumed;
        roots.push(node);
    }
    Ok(EmvIngressTree {
        roots,
        arena_flags,
    })
}

fn parse_emv_node(input: &[u8], mut off: usize, depth: u16) -> Result<(EmvIngressNode, usize), EmvIngressDecodeError> {
    if depth as usize > MAX_TLV_DEPTH {
        return Err(EmvIngressDecodeError::DepthExceeded);
    }
    if off + 10 > input.len() {
        return Err(EmvIngressDecodeError::TooShort);
    }
    let start = off;
    let tag = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    let node_depth = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    let value_len = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]) as usize;
    off += 4;
    let child_count = u16::from_le_bytes([input[off], input[off + 1]]) as usize;
    off += 2;
    let flags = u16::from_le_bytes([input[off], input[off + 1]]);
    off += 2;
    if off + value_len > input.len() {
        return Err(EmvIngressDecodeError::TooShort);
    }
    let value = input[off..off + value_len].to_vec();
    off += value_len;
    let mut children = Vec::with_capacity(child_count);
    for _ in 0..child_count {
        let (child, consumed) = parse_emv_node(input, off, depth.saturating_add(1))?;
        off += consumed;
        children.push(child);
    }
    Ok((
        EmvIngressNode {
            tag,
            depth: node_depth,
            flags,
            value,
            children,
        },
        off - start,
    ))
}

pub fn encode_emv_ingress_tree(tree: &EmvIngressTree) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&EMV_INGRESS_MAGIC);
    out.extend_from_slice(&EMV_INGRESS_VERSION.to_le_bytes());
    out.extend_from_slice(&tree.arena_flags.to_le_bytes());
    out.extend_from_slice(&(tree.roots.len() as u16).to_le_bytes());
    for root in &tree.roots {
        encode_emv_node(&mut out, root);
    }
    if out.len() > MAX_ISO_FRAME {
        out.truncate(MAX_ISO_FRAME);
    }
    out
}

fn encode_emv_node(out: &mut Vec<u8>, node: &EmvIngressNode) {
    out.extend_from_slice(&node.tag.to_le_bytes());
    out.extend_from_slice(&node.depth.to_le_bytes());
    out.extend_from_slice(&(node.value.len() as u32).to_le_bytes());
    out.extend_from_slice(&(node.children.len() as u16).to_le_bytes());
    out.extend_from_slice(&node.flags.to_le_bytes());
    out.extend_from_slice(&node.value);
    for child in &node.children {
        encode_emv_node(out, child);
    }
}
