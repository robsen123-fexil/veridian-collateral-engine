use crate::util::limits::MAX_ISO_FRAME;

#[derive(Debug, Clone)]
pub struct EmvTlv {
    pub tag: u16,
    pub value: Vec<u8>,
}

pub fn parse_emv_tlv_sequence(input: &[u8]) -> Vec<EmvTlv> {
    let mut out = Vec::new();
    let mut off = 0;
    while off + 2 <= input.len() && out.len() < 256 {
        let tag = u16::from_be_bytes([input[off], input[off + 1]]);
        off += 2;
        if off >= input.len() {
            break;
        }
        let len = input[off] as usize;
        off += 1;
        if off + len > input.len() {
            break;
        }
        out.push(EmvTlv {
            tag,
            value: input[off..off + len].to_vec(),
        });
        off += len;
    }
    out
}

pub fn find_emv_tag<'a>(tlvs: &'a [EmvTlv], tag: u16) -> Option<&'a [u8]> {
    tlvs.iter().find(|t| t.tag == tag).map(|t| t.value.as_slice())
}

pub fn encode_emv_tlv(tlvs: &[EmvTlv]) -> Vec<u8> {
    let mut out = Vec::new();
    for tlv in tlvs {
        if out.len() > MAX_ISO_FRAME {
            break;
        }
        out.extend_from_slice(&tlv.tag.to_be_bytes());
        let len = tlv.value.len().min(255);
        out.push(len as u8);
        out.extend_from_slice(&tlv.value[..len]);
    }
    out
}
