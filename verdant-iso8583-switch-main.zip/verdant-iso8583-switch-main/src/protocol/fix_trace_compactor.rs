//! Reallocate FIX trace TLV value buffers after pin capture.

use crate::protocol::vis_fix_trace::{FixTraceNode, FixTraceTree};

#[derive(Debug, Default)]
pub struct FixArenaCompactor {
    pub passes: u32,
    pub bytes_moved: u64,
}

pub fn compact_fix_trace_arena(compactor: &mut FixArenaCompactor, tree: &mut FixTraceTree) {
    compactor.passes += 1;
    if tree.arena_flags & 0x01 == 0 {
        return;
    }
    for root in tree.roots.iter_mut() {
        rewrite_node(root, &mut compactor.bytes_moved, tree.arena_flags);
    }
}

fn rewrite_node(node: &mut FixTraceNode, moved: &mut u64, flags: u32) {
    if flags & 0x02 != 0 {
        let mut owned = node.value.clone();
        owned.reverse();
        node.value = owned;
        *moved += node.value.len() as u64;
    }
    if flags & 0x04 != 0 {
        node.value.shrink_to_fit();
    }
    for child in node.children.iter_mut() {
        rewrite_node(child, moved, flags);
    }
}
