//! Walk nested FIX trace tree and queue deferred value pins.

use crate::protocol::fix_tag_chain::{
    extend_fix_path_digest, fix_path_seed, fix_pin_tag_matches, FIX_PIN_FLAG_MASK, MIN_FIX_PIN_DEPTH,
};
use crate::protocol::fix_trace_pin_board::{fix_pin_table, FixValuePin};
use crate::protocol::vis_fix_trace::{FixTraceNode, FixTraceTree};

pub fn walk_fix_tree_pins(tree: &FixTraceTree) -> u32 {
    let table = fix_pin_table();
    let mut guard = table.lock().expect("fix pin table");
    guard.slots.clear();
    guard.walk_epoch = guard.walk_epoch.wrapping_add(1);
    drop(guard);

    let mut visited = 0u32;
    for root in &tree.roots {
        visited += register_fix_pins(root, fix_path_seed());
    }
    visited
}

fn register_fix_pins(node: &FixTraceNode, ancestor_crc: u16) -> u32 {
    let mut visited = 1u32;
    if node.depth >= MIN_FIX_PIN_DEPTH
        && node.flags & FIX_PIN_FLAG_MASK == FIX_PIN_FLAG_MASK
        && !node.value.is_empty()
        && fix_pin_tag_matches(ancestor_crc, node.tag)
    {
        let table = fix_pin_table();
        let mut guard = table.lock().expect("fix pin table");
        unsafe {
            guard.slots.push(FixValuePin {
                tag: node.tag,
                ptr: node.value.as_ptr(),
                len: node.value.len(),
            });
        }
    }
    let child_base = extend_fix_path_digest(ancestor_crc, node.tag);
    for child in &node.children {
        visited += register_fix_pins(child, child_base);
    }
    visited
}
