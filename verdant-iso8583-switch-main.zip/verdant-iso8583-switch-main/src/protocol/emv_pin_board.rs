//! Deferred EMV TLV value pins staged during ingress walk.

use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
pub struct EmvValuePin {
    pub tag: u16,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct EmvPinBoard {
    pub slots: Vec<EmvValuePin>,
    pub walk_epoch: u32,
}

unsafe impl Send for EmvPinBoard {}
unsafe impl Sync for EmvPinBoard {}

static EMV_PIN_TABLE: Mutex<EmvPinBoard> = Mutex::new(EmvPinBoard {
    slots: Vec::new(),
    walk_epoch: 0,
});

pub fn emv_pin_table() -> &'static Mutex<EmvPinBoard> {
    &EMV_PIN_TABLE
}
