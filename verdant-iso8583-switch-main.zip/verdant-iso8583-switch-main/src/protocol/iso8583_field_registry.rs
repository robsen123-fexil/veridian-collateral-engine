//! ISO8583:1987 / 1993 field registry for acquiring switch.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IsoFieldFormat {
    Fixed(usize),
    LlVar(usize),
    LllVar(usize),
    Binary(usize),
}

#[derive(Debug, Clone, Copy)]
pub struct IsoFieldSpec {
    pub de: u16,
    pub name: &'static str,
    pub format: IsoFieldFormat,
    pub required_auth: bool,
    pub required_capture: bool,
}

pub const ISO_FIELD_TABLE: &[IsoFieldSpec] = &[
    IsoFieldSpec { de: 2, name: "Primary Account Number", format: IsoFieldFormat::LlVar(19), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 3, name: "Processing Code", format: IsoFieldFormat::Fixed(6), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 4, name: "Amount Transaction", format: IsoFieldFormat::Fixed(12), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 7, name: "Transmission Date and Time", format: IsoFieldFormat::Fixed(10), required_auth: true, required_capture: false },
    IsoFieldSpec { de: 11, name: "Systems Trace Audit Number", format: IsoFieldFormat::Fixed(6), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 12, name: "Time Local Transaction", format: IsoFieldFormat::Fixed(6), required_auth: true, required_capture: false },
    IsoFieldSpec { de: 13, name: "Date Local Transaction", format: IsoFieldFormat::Fixed(4), required_auth: true, required_capture: false },
    IsoFieldSpec { de: 14, name: "Date Expiration", format: IsoFieldFormat::Fixed(4), required_auth: true, required_capture: false },
    IsoFieldSpec { de: 18, name: "Merchant Type", format: IsoFieldFormat::Fixed(4), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 22, name: "POS Entry Mode", format: IsoFieldFormat::Fixed(3), required_auth: true, required_capture: false },
    IsoFieldSpec { de: 25, name: "POS Condition Code", format: IsoFieldFormat::Fixed(2), required_auth: true, required_capture: false },
    IsoFieldSpec { de: 32, name: "Acquiring Institution ID", format: IsoFieldFormat::LlVar(11), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 35, name: "Track 2 Data", format: IsoFieldFormat::LlVar(37), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 37, name: "Retrieval Reference Number", format: IsoFieldFormat::Fixed(12), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 38, name: "Authorization ID Response", format: IsoFieldFormat::Fixed(6), required_auth: false, required_capture: true },
    IsoFieldSpec { de: 39, name: "Response Code", format: IsoFieldFormat::Fixed(2), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 41, name: "Card Acceptor Terminal ID", format: IsoFieldFormat::Fixed(8), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 42, name: "Card Acceptor ID Code", format: IsoFieldFormat::Fixed(15), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 43, name: "Card Acceptor Name/Location", format: IsoFieldFormat::Fixed(40), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 49, name: "Currency Code Transaction", format: IsoFieldFormat::Fixed(3), required_auth: true, required_capture: true },
    IsoFieldSpec { de: 52, name: "PIN Data", format: IsoFieldFormat::Binary(8), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 54, name: "Additional Amounts", format: IsoFieldFormat::LllVar(120), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 55, name: "ICC Data", format: IsoFieldFormat::LllVar(255), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 60, name: "Reserved Private", format: IsoFieldFormat::LllVar(999), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 61, name: "Reserved Private", format: IsoFieldFormat::LllVar(999), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 62, name: "Reserved Private", format: IsoFieldFormat::LllVar(999), required_auth: false, required_capture: false },
    IsoFieldSpec { de: 63, name: "Reserved Private", format: IsoFieldFormat::LllVar(999), required_auth: false, required_capture: false },
];

pub fn lookup_field(de: u16) -> Option<&'static IsoFieldSpec> {
    ISO_FIELD_TABLE.iter().find(|s| s.de == de)
}

pub fn validate_field_width(de: u16, len: usize) -> bool {
    let Some(spec) = lookup_field(de) else { return len <= 999 };
    match spec.format {
        IsoFieldFormat::Fixed(w) => len == w,
        IsoFieldFormat::LlVar(max) | IsoFieldFormat::LllVar(max) | IsoFieldFormat::Binary(max) => len <= max,
    }
}

/// MCC-specific field requirement overlay.
pub fn mcc_requires_field(mcc: u16, de: u16) -> bool {
    match mcc {
        5411..=5499 => matches!(de, 4 | 11 | 37 | 39 | 41 | 42),
        5812..=5814 => matches!(de, 4 | 11 | 22 | 37 | 39 | 41 | 42 | 55),
        6010..=6012 => matches!(de, 4 | 11 | 32 | 37 | 39),
        _ => lookup_field(de).map(|s| s.required_auth).unwrap_or(false),
    }
}

/// Risk weight for MCC band starting 1000.
pub fn mcc_band_risk_1000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (1000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 1250.
pub fn mcc_band_risk_1250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (1250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 1500.
pub fn mcc_band_risk_1500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (1500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 1750.
pub fn mcc_band_risk_1750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (1750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 2000.
pub fn mcc_band_risk_2000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (2000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 2250.
pub fn mcc_band_risk_2250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (2250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 2500.
pub fn mcc_band_risk_2500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (2500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 2750.
pub fn mcc_band_risk_2750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (2750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 3000.
pub fn mcc_band_risk_3000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (3000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 3250.
pub fn mcc_band_risk_3250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (3250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 3500.
pub fn mcc_band_risk_3500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (3500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 3750.
pub fn mcc_band_risk_3750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (3750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 4000.
pub fn mcc_band_risk_4000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (4000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 4250.
pub fn mcc_band_risk_4250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (4250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 4500.
pub fn mcc_band_risk_4500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (4500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 4750.
pub fn mcc_band_risk_4750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (4750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 5000.
pub fn mcc_band_risk_5000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (5000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 5250.
pub fn mcc_band_risk_5250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (5250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 5500.
pub fn mcc_band_risk_5500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (5500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 5750.
pub fn mcc_band_risk_5750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (5750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 6000.
pub fn mcc_band_risk_6000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (6000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 6250.
pub fn mcc_band_risk_6250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (6250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 6500.
pub fn mcc_band_risk_6500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (6500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 6750.
pub fn mcc_band_risk_6750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (6750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 7000.
pub fn mcc_band_risk_7000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (7000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 7250.
pub fn mcc_band_risk_7250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (7250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 7500.
pub fn mcc_band_risk_7500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (7500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 7750.
pub fn mcc_band_risk_7750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (7750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 8000.
pub fn mcc_band_risk_8000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (8000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 8250.
pub fn mcc_band_risk_8250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (8250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 8500.
pub fn mcc_band_risk_8500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (8500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 8750.
pub fn mcc_band_risk_8750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (8750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 9000.
pub fn mcc_band_risk_9000(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (9000 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 9250.
pub fn mcc_band_risk_9250(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (9250 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 9500.
pub fn mcc_band_risk_9500(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (9500 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}

/// Risk weight for MCC band starting 9750.
pub fn mcc_band_risk_9750(volume_minor: i64, chargeback_rate_bps: u32) -> u32 {
    let base = (9750 % 97) + 10;
    let vol_factor = (volume_minor.abs() / 10_000).min(50) as u32;
    base + vol_factor + chargeback_rate_bps / 4
}
