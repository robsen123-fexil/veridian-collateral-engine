//! Cross-run EMV ingress wire flags.

pub const EMV_FLAG_COMPACT_ARENA: u32 = 0x0001;
pub const EMV_FLAG_CARRY_SEAL: u32 = 0x0040;
pub const EMV_FLAG_DEFER_SEAL: u32 = 0x0080;
