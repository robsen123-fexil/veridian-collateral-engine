use crate::merchant::auth_hold_registry::AuthHoldRegistry;
use crate::protocol::vis_magics::{CAPTURE_HOLD_MAGIC, CAPTURE_HOLD_VERSION};
use crate::util::limits::MAX_SETTLE_RECORDS;

#[derive(Debug, Clone)]
pub struct CaptureHoldRecord {
    pub stan: u32,
    pub amount_minor: i64,
    pub link_tag: u32,
    pub rrn: String,
}

#[derive(Debug, Default)]
pub struct CaptureHoldWireState {
    pub version: u16,
    pub flags: u32,
    pub records: Vec<CaptureHoldRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CaptureHoldDecodeError {
    TooShort,
    BadMagic,
    BadVersion,
    RecordOverflow,
    RrnOob,
}

pub fn decode_capture_hold_wire(input: &[u8]) -> Result<CaptureHoldWireState, CaptureHoldDecodeError> {
    if input.len() < 14 {
        return Err(CaptureHoldDecodeError::TooShort);
    }
    if &input[..4] != CAPTURE_HOLD_MAGIC {
        return Err(CaptureHoldDecodeError::BadMagic);
    }
    let version = u16::from_le_bytes([input[4], input[5]]);
    if version != CAPTURE_HOLD_VERSION {
        return Err(CaptureHoldDecodeError::BadVersion);
    }
    let record_count = u32::from_le_bytes([input[6], input[7], input[8], input[9]]) as usize;
    if record_count > MAX_SETTLE_RECORDS {
        return Err(CaptureHoldDecodeError::RecordOverflow);
    }
    let flags = u32::from_le_bytes([input[10], input[11], input[12], input[13]]);
    let mut off = 14;
    let mut records = Vec::with_capacity(record_count);
    for _ in 0..record_count {
        if off + 18 > input.len() {
            return Err(CaptureHoldDecodeError::TooShort);
        }
        let stan = u32::from_le_bytes([input[off], input[off + 1], input[off + 2], input[off + 3]]);
        let amount_minor = i64::from_le_bytes([
            input[off + 4],
            input[off + 5],
            input[off + 6],
            input[off + 7],
            input[off + 8],
            input[off + 9],
            input[off + 10],
            input[off + 11],
        ]);
        let link_tag = u32::from_le_bytes([input[off + 12], input[off + 13], input[off + 14], input[off + 15]]);
        let rrn_len = u16::from_le_bytes([input[off + 16], input[off + 17]]) as usize;
        off += 18;
        if off + rrn_len > input.len() {
            return Err(CaptureHoldDecodeError::RrnOob);
        }
        let rrn = String::from_utf8_lossy(&input[off..off + rrn_len]).into_owned();
        off += rrn_len;
        records.push(CaptureHoldRecord {
            stan,
            amount_minor,
            link_tag,
            rrn,
        });
    }
    Ok(CaptureHoldWireState {
        version,
        flags,
        records,
    })
}

pub fn ingest_capture_hold_registry(state: &CaptureHoldWireState, registry: &mut AuthHoldRegistry) {
    for rec in &state.records {
        registry.place_hold_with_rrn(rec.stan, rec.amount_minor, rec.rrn.clone());
    }
}
