pub const MAX_ISO_FRAME: usize = 65_536;
pub const MAX_TLV_DEPTH: usize = 16;
pub const MAX_BITMAP_FIELDS: usize = 128;
pub const MAX_SETTLE_RECORDS: usize = 4_096;
pub const MAX_TERMINAL_LEGS: usize = 512;
pub const MAX_MERCHANT_ID_LEN: usize = 15;
pub const MAX_PAN_LEN: usize = 19;

pub fn slice_at<'a>(buf: &'a [u8], off: usize, len: usize) -> Option<&'a [u8]> {
    if len == 0 {
        return Some(&[]);
    }
    buf.get(off..off.checked_add(len)?)
}

pub fn read_u16_be(buf: &[u8], off: usize) -> Option<u16> {
    let s = slice_at(buf, off, 2)?;
    Some(u16::from_be_bytes([s[0], s[1]]))
}

pub fn read_u32_be(buf: &[u8], off: usize) -> Option<u32> {
    let s = slice_at(buf, off, 4)?;
    Some(u32::from_be_bytes([s[0], s[1], s[2], s[3]]))
}

pub fn read_u32_le(buf: &[u8], off: usize) -> Option<u32> {
    let s = slice_at(buf, off, 4)?;
    Some(u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
}
