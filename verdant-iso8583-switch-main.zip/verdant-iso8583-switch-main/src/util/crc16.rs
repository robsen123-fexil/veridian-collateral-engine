/// ISO8583-style CRC-16/CCITT-FALSE for settlement batch trailers.
pub fn crc16_ccitt(data: &[u8], seed: u16) -> u16 {
    let mut crc = seed;
    for &b in data {
        crc ^= (b as u16) << 8;
        for _ in 0..8 {
            if crc & 0x8000 != 0 {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc <<= 1;
            }
        }
    }
    crc
}

pub fn rolling_crc16(prev: u16, chunk: &[u8]) -> u16 {
    crc16_ccitt(chunk, prev)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_seed() {
        assert_eq!(crc16_ccitt(b"", 0xFFFF), 0xFFFF);
    }
}
