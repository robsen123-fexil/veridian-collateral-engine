use crate::util::limits::MAX_BITMAP_FIELDS;

#[derive(Debug, Clone, Default)]
pub struct FieldBitmap {
    pub bits: [u64; 2],
}

impl FieldBitmap {
    pub fn from_primary_secondary(primary: u64, secondary: Option<u64>) -> Self {
        let mut bits = [primary, secondary.unwrap_or(0)];
        if primary & (1 << 63) != 0 {
            // secondary present
        } else {
            bits[1] = 0;
        }
        Self { bits }
    }

    pub fn is_set(&self, field: u8) -> bool {
        if field == 0 || field as usize > MAX_BITMAP_FIELDS {
            return false;
        }
        let idx = (field - 1) as usize;
        let word = idx / 64;
        let bit = idx % 64;
        self.bits.get(word).map(|w| w & (1u64 << bit) != 0).unwrap_or(false)
    }

    pub fn set(&mut self, field: u8) {
        if field == 0 {
            return;
        }
        let idx = (field - 1) as usize;
        let word = idx / 64;
        let bit = idx % 64;
        if word < self.bits.len() {
            self.bits[word] |= 1u64 << bit;
        }
    }

    pub fn field_list(&self) -> Vec<u8> {
        let mut out = Vec::new();
        for f in 1..=MAX_BITMAP_FIELDS as u8 {
            if self.is_set(f) {
                out.push(f);
            }
        }
        out
    }
}
