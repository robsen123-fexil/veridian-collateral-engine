//! Compact interchange tier arena when advice compact flags are set.

use crate::protocol::vis_interchange_advice::InterchangeAdviceState;

#[derive(Debug, Default)]
pub struct InterchangeArenaCompactor {
    pub passes: u32,
    pub bytes_moved: u64,
}

pub fn compact_interchange_tier_arena(compactor: &mut InterchangeArenaCompactor, state: &mut InterchangeAdviceState) {
    compactor.passes += 1;
    if state.headers.is_empty() {
        return;
    }
    if state.flags & 0x01 == 0 {
        return;
    }

    state.headers.sort_by_key(|h| h.merchant_slot);

    let mut new_arena: Vec<u8> = Vec::with_capacity(state.tier_arena.len());
    for hdr in state.headers.iter_mut() {
        let off = hdr.tier_offset as usize;
        let len = hdr.tier_len as usize;
        if let Some(slice) = state.tier_arena.get(off..off.saturating_add(len)) {
            let new_off = new_arena.len() as u32;
            if hdr.slot_flags & 0x4000 != 0 {
                let mut owned = slice.to_vec();
                owned.reverse();
                new_arena.extend_from_slice(&owned);
            } else {
                new_arena.extend_from_slice(slice);
            }
            hdr.tier_offset = new_off;
            compactor.bytes_moved += len as u64;
        }
    }
    state.tier_arena = new_arena;
    if state.flags & 0x02 != 0 {
        state.tier_arena.shrink_to_fit();
    }
}
