//! Deferred interchange tier byte pins for advice digest.

use crate::protocol::vis_interchange_advice::InterchangeAdviceState;
use std::sync::Mutex;

#[derive(Debug, Clone, Copy)]
pub struct InterchangeTierPin {
    pub slot_index: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct InterchangePinBoard {
    pub slots: Vec<InterchangeTierPin>,
    pub capture_epoch: u32,
}

unsafe impl Send for InterchangePinBoard {}
unsafe impl Sync for InterchangePinBoard {}

static INTERCHANGE_PIN_TABLE: Mutex<InterchangePinBoard> = Mutex::new(InterchangePinBoard {
    slots: Vec::new(),
    capture_epoch: 0,
});

pub fn interchange_pin_table() -> &'static Mutex<InterchangePinBoard> {
    &INTERCHANGE_PIN_TABLE
}

pub fn capture_interchange_tier_pins(state: &InterchangeAdviceState) {
    let table = interchange_pin_table();
    let mut guard = table.lock().expect("interchange pin table");
    guard.slots.clear();
    guard.capture_epoch = guard.capture_epoch.wrapping_add(1);
    for (idx, _hdr) in state.headers.iter().enumerate() {
        if !crate::settle::interchange_slot_chain::slot_eligible_for_tier_pin(state, idx) {
            continue;
        }
        if let Some(payload) = crate::protocol::vis_interchange_advice::tier_payload(state, idx) {
            if payload.is_empty() {
                continue;
            }
            unsafe {
                guard.slots.push(InterchangeTierPin {
                    slot_index: idx as u32,
                    ptr: payload.as_ptr(),
                    len: payload.len(),
                });
            }
        }
    }
}
