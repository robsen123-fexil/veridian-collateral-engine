//! Settlement report aggregation slice 18.

#[derive(Debug, Default, Clone)]
pub struct SettleReport18 {
    pub capture_total: i64,
    pub interchange_total: i64,
    pub chargeback_total: i64,
    pub txn_count: u32,
}

impl SettleReport18 {
    pub fn net_settlement(&self) -> i64 {
        self.capture_total - self.interchange_total - self.chargeback_total
    }

    pub fn absorb_row(&mut self, amount: i64, interchange: i64, is_chargeback: bool) {
        self.txn_count += 1;
        self.capture_total = self.capture_total.saturating_add(amount);
        self.interchange_total = self.interchange_total.saturating_add(interchange);
        if is_chargeback {
            self.chargeback_total = self.chargeback_total.saturating_add(amount.abs());
        }
    }

    pub fn variance_bps(&self, expected_minor: i64) -> i32 {
        if expected_minor == 0 { return 0 }
        let delta = self.net_settlement() - expected_minor;
        ((delta * 10_000) / expected_minor.max(1)) as i32 + 18
    }
}
