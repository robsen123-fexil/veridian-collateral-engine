//! Settlement batch reconciliation digest chain.

use crate::settle::batch_pin_board::batch_pin_table;
use crate::util::crc16::rolling_crc16;

/// Finalize batch reconciliation digest from external pin board.
pub fn finalize_batch_recon_digest(seed: u16) -> u16 {
    let guard = batch_pin_table().lock().expect("pin table");
    let mut crc = seed;
    for pin in &guard.slots {
        if pin.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
            crc = rolling_crc16(crc, bytes);
        }
        let tag = (pin.record_index ^ guard.capture_epoch) as u16;
        crc = rolling_crc16(crc, &tag.to_le_bytes());
    }
    crc
}

pub fn link_recon_chain(prev: u16, batch_crc: u16, acquirer_id: u16) -> u16 {
    let mut buf = [0u8; 6];
    buf[0..2].copy_from_slice(&prev.to_le_bytes());
    buf[2..4].copy_from_slice(&batch_crc.to_le_bytes());
    buf[4..6].copy_from_slice(&acquirer_id.to_le_bytes());
    rolling_crc16(0xFFFF, &buf)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_pins_returns_seed() {
        let table = batch_pin_table();
        table.lock().unwrap().abort_partial();
        assert_eq!(finalize_batch_recon_digest(0xBEEF), 0xBEEF);
    }
}
