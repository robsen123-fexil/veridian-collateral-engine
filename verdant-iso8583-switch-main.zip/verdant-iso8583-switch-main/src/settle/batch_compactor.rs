//! Compacts settlement payload arena when batch compact flags are set.

use crate::protocol::vis_settle_batch::SettleBatchWireState;

#[derive(Debug)]
pub struct BatchCompactor {
    pub passes: u32,
    pub bytes_moved: u64,
}

impl BatchCompactor {
    pub fn new() -> Self {
        Self {
            passes: 0,
            bytes_moved: 0,
        }
    }
}

impl Default for BatchCompactor {
    fn default() -> Self {
        Self::new()
    }
}

pub fn compact_settle_arena(compactor: &mut BatchCompactor, state: &mut SettleBatchWireState) {
    compactor.passes += 1;
    if state.headers.is_empty() {
        return;
    }
    if state.flags & 0x01 == 0 {
        return;
    }

    state.headers.sort_by_key(|h| h.merchant_tag);

    let mut new_arena: Vec<u8> = Vec::with_capacity(state.payload_arena.len());
    for hdr in state.headers.iter_mut() {
        let off = hdr.payload_offset as usize;
        let len = hdr.payload_len as usize;
        if let Some(slice) = state.payload_arena.get(off..off.saturating_add(len)) {
            let new_off = new_arena.len() as u32;
            if hdr.mti_class & 0x4000 != 0 {
                let mut owned = slice.to_vec();
                owned.reverse();
                new_arena.extend_from_slice(&owned);
            } else {
                new_arena.extend_from_slice(slice);
            }
            hdr.payload_offset = new_off;
            compactor.bytes_moved += len as u64;
        }
    }
    state.payload_arena = new_arena;
    if state.flags & 0x02 != 0 {
        state.payload_arena.shrink_to_fit();
    }
}
