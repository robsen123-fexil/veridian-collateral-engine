use crate::merchant::interchange_tier_matrix::compute_interchange_minor;
use crate::protocol::vis_settle_batch::{
    capture_settle_recon_pins, decode_settle_batch_wire, SettleDecodeError,
};
use crate::settle::batch_compactor::{compact_settle_arena, BatchCompactor};
use crate::settle::batch_wire_flags::{BATCH_FLAG_CARRY_FINALIZE, BATCH_FLAG_DEFER_FINALIZE};
use crate::settle::reconciliation_chain::{finalize_batch_recon_digest, link_recon_chain};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SettlePipelineError {
    Decode(SettleDecodeError),
    EmptyBatch,
}

/// Run settlement batch decode, compaction, interchange totals, and recon digest.
pub fn run_settle_batch_pipeline(input: &[u8]) -> Result<u16, SettlePipelineError> {
    let mut state = decode_settle_batch_wire(input).map_err(SettlePipelineError::Decode)?;
    if state.headers.is_empty() {
        return Err(SettlePipelineError::EmptyBatch);
    }

    if state.flags & BATCH_FLAG_CARRY_FINALIZE != 0 {
        let batch_crc = finalize_batch_recon_digest(0xFFFF);
        return Ok(link_recon_chain(0, batch_crc, state.acquirer_id));
    }

    capture_settle_recon_pins(&state);

    let mut compactor = BatchCompactor::new();
    compact_settle_arena(&mut compactor, &mut state);

    if state.flags & BATCH_FLAG_DEFER_FINALIZE != 0 {
        return Ok(link_recon_chain(0, 0, state.acquirer_id));
    }

    let mut interchange_total: i64 = 0;
    for (idx, hdr) in state.headers.iter().enumerate() {
        let mcc = (hdr.merchant_tag & 0xFFFF) as u16;
        let product = ((hdr.merchant_tag >> 16) & 0xFF) as u8;
        if let Some(payload) = crate::protocol::vis_settle_batch::record_payload(&state, idx) {
            let amt = parse_amount_from_tlv(payload);
            interchange_total += compute_interchange_minor(amt, product, mcc);
        }
    }

    let batch_crc = finalize_batch_recon_digest(0xFFFF);
    let chain = link_recon_chain(0, batch_crc, state.acquirer_id);
    let _ = interchange_total;
    Ok(chain)
}

fn parse_amount_from_tlv(payload: &[u8]) -> i64 {
    if payload.len() < 6 {
        return 0;
    }
    let tag = u16::from_be_bytes([payload[0], payload[1]]);
    if tag != 0x9F02 {
        return 0;
    }
    let len = payload[2] as usize;
    if payload.len() < 3 + len {
        return 0;
    }
    let mut amt: i64 = 0;
    for &b in &payload[3..3 + len] {
        amt = amt.saturating_mul(10).saturating_add((b >> 4) as i64);
        amt = amt.saturating_mul(10).saturating_add((b & 0x0F) as i64);
    }
    amt
}
