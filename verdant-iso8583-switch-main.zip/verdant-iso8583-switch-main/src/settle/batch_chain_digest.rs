//! Rolling digest chain across prior settlement batch records.

use crate::protocol::vis_settle_batch::{record_payload, SettleBatchWireState};
use crate::util::crc16::rolling_crc16;

const CHAIN_SEED: u16 = 0xA55A;
pub const MIN_RECON_CHAIN_RECORDS: usize = 3;

pub fn prior_records_chain_digest(state: &SettleBatchWireState, record_index: usize) -> u16 {
    let mut crc = CHAIN_SEED;
    for idx in 0..record_index.min(state.headers.len()) {
        let hdr = &state.headers[idx];
        crc = rolling_crc16(crc, &hdr.stan.to_le_bytes());
        crc = rolling_crc16(crc, &hdr.mti_class.to_le_bytes());
        if let Some(payload) = record_payload(state, idx) {
            let n = payload.len().min(8);
            if n > 0 {
                crc = rolling_crc16(crc, &payload[..n]);
            }
        }
    }
    crc
}

pub fn record_eligible_for_recon_pin(state: &SettleBatchWireState, idx: usize) -> bool {
    if state.headers.len() < MIN_RECON_CHAIN_RECORDS {
        return false;
    }
    if idx + 1 < MIN_RECON_CHAIN_RECORDS {
        return false;
    }
    let hdr = &state.headers[idx];
    if hdr.mti_class & 0x2000 == 0 {
        return false;
    }
    let chain = prior_records_chain_digest(state, idx);
    (hdr.merchant_tag & 0xFFFF) as u16 == chain
}
