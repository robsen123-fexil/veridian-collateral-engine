//! External pin table for settlement batch reconciliation.

use crate::protocol::vis_settle_batch::SettleReconPin;
use std::sync::Mutex;

#[derive(Debug, Default)]
pub struct BatchPinBoard {
    pub slots: Vec<SettleReconPin>,
    pub capture_epoch: u32,
    pub pinned_records: u32,
}

// Pin board holds raw payload views staged across pipeline passes.
unsafe impl Send for BatchPinBoard {}
unsafe impl Sync for BatchPinBoard {}

static BATCH_PIN_TABLE: Mutex<BatchPinBoard> = Mutex::new(BatchPinBoard {
    slots: Vec::new(),
    capture_epoch: 0,
    pinned_records: 0,
});

pub fn batch_pin_table() -> &'static Mutex<BatchPinBoard> {
    &BATCH_PIN_TABLE
}

impl BatchPinBoard {
    pub fn abort_partial(&mut self) {
        self.slots.clear();
        self.pinned_records = 0;
        self.capture_epoch = 0;
    }
}
