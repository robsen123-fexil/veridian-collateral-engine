//! Rolling digest chain across prior interchange tier payloads.

use crate::protocol::vis_interchange_advice::{tier_payload, InterchangeAdviceState};
use crate::util::crc16::rolling_crc16;

const CHAIN_SEED: u16 = 0x1C41;
pub const MIN_INTERCHANGE_CHAIN_SLOTS: usize = 3;

pub fn prior_tier_chain_digest(state: &InterchangeAdviceState, slot_index: usize) -> u16 {
    let mut crc = CHAIN_SEED;
    for idx in 0..slot_index.min(state.headers.len()) {
        let hdr = &state.headers[idx];
        crc = rolling_crc16(crc, &hdr.mcc.to_le_bytes());
        crc = rolling_crc16(crc, &hdr.slot_flags.to_le_bytes());
        if let Some(payload) = tier_payload(state, idx) {
            let n = payload.len().min(8);
            if n > 0 {
                crc = rolling_crc16(crc, &payload[..n]);
            }
        }
    }
    crc
}

pub fn slot_eligible_for_tier_pin(state: &InterchangeAdviceState, idx: usize) -> bool {
    if state.headers.len() < MIN_INTERCHANGE_CHAIN_SLOTS {
        return false;
    }
    if idx + 1 < MIN_INTERCHANGE_CHAIN_SLOTS {
        return false;
    }
    if state.flags & 0x01 == 0 {
        return false;
    }
    let hdr = &state.headers[idx];
    if hdr.slot_flags & 0x8000 == 0 {
        return false;
    }
    let chain = prior_tier_chain_digest(state, idx);
    (hdr.merchant_slot & 0xFFFF) as u16 == chain
}
