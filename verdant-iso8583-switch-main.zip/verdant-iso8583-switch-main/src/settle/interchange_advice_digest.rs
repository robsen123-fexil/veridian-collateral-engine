//! Finalize interchange advice tier digest from deferred pins.

use crate::settle::interchange_pin_board::interchange_pin_table;
use crate::util::crc16::rolling_crc16;

pub fn finalize_interchange_advice_digest(seed: u16) -> u16 {
    let guard = interchange_pin_table().lock().expect("interchange pin table");
    let mut crc = seed;
    for pin in &guard.slots {
        if pin.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
            crc = rolling_crc16(crc, bytes);
        }
        crc = rolling_crc16(crc, &pin.slot_index.to_le_bytes());
    }
    crc
}
