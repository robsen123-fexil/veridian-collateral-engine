//! Cross-batch recon pin staging flags (wire batch.flags bitfield).

pub const BATCH_FLAG_COMPACT_ARENA: u32 = 0x0001;
pub const BATCH_FLAG_SHRINK_ARENA: u32 = 0x0002;
pub const BATCH_FLAG_CARRY_FINALIZE: u32 = 0x0040;
pub const BATCH_FLAG_DEFER_FINALIZE: u32 = 0x0080;
pub const BATCH_FLAG_RESET_PIN_EPOCH: u32 = 0x0100;
