use crate::protocol::vis_interchange_advice::{decode_interchange_advice_wire, InterchangeAdviceDecodeError};
use crate::settle::interchange_advice_digest::finalize_interchange_advice_digest;
use crate::settle::interchange_arena_compactor::{compact_interchange_tier_arena, InterchangeArenaCompactor};
use crate::settle::interchange_pin_board::capture_interchange_tier_pins;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InterchangeAdvicePipelineError {
    Decode(InterchangeAdviceDecodeError),
    EmptyAdvice,
}

pub fn run_interchange_advice_pipeline(input: &[u8]) -> Result<u16, InterchangeAdvicePipelineError> {
    let mut state = decode_interchange_advice_wire(input).map_err(InterchangeAdvicePipelineError::Decode)?;
    if state.headers.is_empty() {
        return Err(InterchangeAdvicePipelineError::EmptyAdvice);
    }

    capture_interchange_tier_pins(&state);

    let mut compactor = InterchangeArenaCompactor::default();
    compact_interchange_tier_arena(&mut compactor, &mut state);

    Ok(finalize_interchange_advice_digest(0x1CCE))
}
