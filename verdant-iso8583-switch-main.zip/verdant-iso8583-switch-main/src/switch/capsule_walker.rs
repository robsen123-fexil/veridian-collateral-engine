//! Walk nested VISA auth capsules and queue route pins.

use crate::protocol::vis_auth_capsule::{decode_auth_capsule_tree, AuthCapsuleNode};
use crate::switch::route_path_digest::{
    extend_route_path_digest, route_pin_channel_matches, RoutePathSeed, MIN_ROUTE_PIN_DEPTH,
    ROUTE_PIN_FLAG_MASK,
};
use crate::switch::route_staging::RouteStagingBoard;

pub fn walk_auth_capsules(input: &[u8], board: &mut RouteStagingBoard) -> u32 {
    board.capsules_visited = 0;
    let tree = match decode_auth_capsule_tree(input) {
        Ok(t) => t,
        Err(_) => {
            board.abort_route();
            return 0;
        }
    };
    for root in &tree.roots {
        register_capsule_pins(board, root, RoutePathSeed::SEED);
    }
    board.walk_generation = board.walk_generation.wrapping_add(1);
    board.capsules_visited
}

fn register_capsule_pins(board: &mut RouteStagingBoard, node: &AuthCapsuleNode, ancestor_crc: u16) {
    board.capsules_visited += 1;
    if node.depth >= MIN_ROUTE_PIN_DEPTH
        && node.flags & ROUTE_PIN_FLAG_MASK == ROUTE_PIN_FLAG_MASK
        && !node.payload.is_empty()
        && route_pin_channel_matches(ancestor_crc, node.channel)
    {
        unsafe {
            crate::switch::route_pin_board::stage_route_pin(
                node.channel,
                node.payload.as_ptr(),
                node.payload.len(),
                node.depth,
            );
        }
    }
    let child_base = extend_route_path_digest(ancestor_crc, node.channel);
    for child in &node.children {
        register_capsule_pins(board, child, child_base);
    }
}
