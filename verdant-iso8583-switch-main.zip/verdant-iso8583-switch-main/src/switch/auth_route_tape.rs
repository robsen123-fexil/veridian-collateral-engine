//! Auth route tape — seals deferred pins after capsule walk.

use crate::switch::route_pin_board::route_pin_table;
use crate::switch::route_staging::RouteStagingBoard;
use crate::util::crc16::rolling_crc16;

#[derive(Debug, Default)]
pub struct AuthRouteTape {
    pub board: RouteStagingBoard,
    pub last_seal_crc: u16,
    pub routes_sealed: u32,
}

impl AuthRouteTape {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn ingest_capsule_stream(&mut self, input: &[u8]) {
        self.board.abort_route();
        crate::switch::capsule_walker::walk_auth_capsules(input, &mut self.board);
    }

    /// Seal auth route fingerprint from the process-global route pin board.
    pub fn seal_auth_route_fingerprint(&mut self, seed: u16) -> u16 {
        let guard = route_pin_table().lock().expect("route pin table");
        let mut crc = seed;
        for pin in &guard.slots {
            if pin.len == 0 {
                continue;
            }
            unsafe {
                let bytes = std::slice::from_raw_parts(pin.ptr, pin.len);
                crc = rolling_crc16(crc, bytes);
            }
            let ch = pin.channel ^ pin.depth;
            crc = rolling_crc16(crc, &ch.to_le_bytes());
        }
        self.last_seal_crc = crc;
        self.routes_sealed += 1;
        crc
    }
}

pub fn seal_global_route_fingerprint(seed: u16) -> u16 {
    let mut tape = AuthRouteTape::new();
    tape.seal_auth_route_fingerprint(seed)
}
