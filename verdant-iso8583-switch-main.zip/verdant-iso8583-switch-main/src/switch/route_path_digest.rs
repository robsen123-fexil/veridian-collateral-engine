//! Ancestor channel-path digest for nested auth-route capsules.

use crate::util::crc16::rolling_crc16;

pub struct RoutePathSeed;

impl RoutePathSeed {
    pub const SEED: u16 = 0xD4B6;
}

pub const MIN_ROUTE_PIN_DEPTH: u16 = 2;
pub const ROUTE_PIN_FLAG_MASK: u16 = 0x000A;

pub fn extend_route_path_digest(ancestor_crc: u16, channel: u16) -> u16 {
    rolling_crc16(ancestor_crc, &channel.to_le_bytes())
}

pub fn route_pin_channel_matches(ancestor_crc: u16, channel: u16) -> bool {
    (channel & 0xFF) as u16 == ancestor_crc
}
