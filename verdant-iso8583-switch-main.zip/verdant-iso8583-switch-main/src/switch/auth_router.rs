use crate::protocol::vis_magics::{matches_magic, AUTH_CAPSULE_MAGIC, SETTLE_BATCH_MAGIC, TERMINAL_FRAME_MAGIC};
use crate::switch::auth_route_tape::{seal_global_route_fingerprint, AuthRouteTape};
use crate::switch::route_session_flags::{route_capsule_root_flags, ROUTE_ROOT_CARRY_SEAL, ROUTE_ROOT_DEFER_SEAL};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AuthIngressClass {
    Empty,
    SettleBatch,
    AuthCapsule,
    TerminalFrame,
    RawIso8583,
    Opaque,
}

pub fn classify_auth_ingress(input: &[u8]) -> AuthIngressClass {
    if input.is_empty() {
        return AuthIngressClass::Empty;
    }
    if matches_magic(input, &SETTLE_BATCH_MAGIC) {
        return AuthIngressClass::SettleBatch;
    }
    if matches_magic(input, &AUTH_CAPSULE_MAGIC) {
        return AuthIngressClass::AuthCapsule;
    }
    if matches_magic(input, &TERMINAL_FRAME_MAGIC) {
        return AuthIngressClass::TerminalFrame;
    }
    if input.len() >= 4 && input[0].is_ascii_digit() && input[1].is_ascii_digit() && input[2].is_ascii_digit() && input[3].is_ascii_digit() {
        return AuthIngressClass::RawIso8583;
    }
    AuthIngressClass::Opaque
}

/// Classify ingress bytes and route auth capsules or ISO8583 messages.
pub fn route_auth_message_stream(input: &[u8]) -> u16 {
    let class = classify_auth_ingress(input);
    match class {
        AuthIngressClass::AuthCapsule => {
            let root_flags = route_capsule_root_flags(input);
            if root_flags & ROUTE_ROOT_CARRY_SEAL != 0 {
                return seal_global_route_fingerprint(0xC0DE);
            }
            let mut tape = AuthRouteTape::new();
            tape.ingest_capsule_stream(input);
            if root_flags & ROUTE_ROOT_DEFER_SEAL != 0 {
                return 0;
            }
            tape.seal_auth_route_fingerprint(0xC0DE)
        }
        AuthIngressClass::RawIso8583 => {
            if let Ok(msg) = crate::protocol::iso8583_parser::parse_iso8583_message(input) {
                msg.stan().map(|s| (s & 0xFFFF) as u16).unwrap_or(0)
            } else {
                0
            }
        }
        _ => 0,
    }
}
