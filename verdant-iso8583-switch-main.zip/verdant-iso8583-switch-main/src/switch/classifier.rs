pub use super::auth_router::AuthIngressClass;
