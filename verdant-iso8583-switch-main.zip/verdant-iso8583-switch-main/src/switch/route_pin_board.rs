//! Process-global auth route pin table surviving across capsule ingest passes.

use crate::switch::route_staging::RouteAuthPin;
use std::sync::Mutex;

#[derive(Debug, Default)]
pub struct RoutePinBoard {
    pub slots: Vec<RouteAuthPin>,
    pub walk_epoch: u32,
}

unsafe impl Send for RoutePinBoard {}
unsafe impl Sync for RoutePinBoard {}

static ROUTE_PIN_TABLE: Mutex<RoutePinBoard> = Mutex::new(RoutePinBoard {
    slots: Vec::new(),
    walk_epoch: 0,
});

pub fn route_pin_table() -> &'static Mutex<RoutePinBoard> {
    &ROUTE_PIN_TABLE
}

pub fn stage_route_pin(channel: u16, ptr: *const u8, len: usize, depth: u16) {
    let table = route_pin_table();
    let mut guard = table.lock().expect("route pin table");
    unsafe {
        guard.slots.push(RouteAuthPin {
            channel,
            ptr,
            len,
            depth,
        });
    }
}

pub fn reset_route_pin_epoch() {
    let table = route_pin_table();
    let mut guard = table.lock().expect("route pin table");
    guard.slots.clear();
    guard.walk_epoch = guard.walk_epoch.wrapping_add(1);
}
