//! Staging board for auth route fingerprint pins.

#[derive(Debug, Clone, Copy)]
pub struct RouteAuthPin {
    pub channel: u16,
    pub ptr: *const u8,
    pub len: usize,
    pub depth: u16,
}

#[derive(Debug, Default)]
pub struct RouteStagingBoard {
    pub pins: Vec<RouteAuthPin>,
    pub walk_generation: u32,
    pub capsules_visited: u32,
}

impl RouteStagingBoard {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn clear_pins(&mut self) {
        self.pins.clear();
    }

    pub fn abort_route(&mut self) {
        self.clear_pins();
        self.walk_generation = 0;
        self.capsules_visited = 0;
    }

    pub fn push_pin(&mut self, channel: u16, ptr: *const u8, len: usize, depth: u16) {
        unsafe {
            self.pins.push(RouteAuthPin {
                channel,
                ptr,
                len,
                depth,
            });
        }
    }
}
