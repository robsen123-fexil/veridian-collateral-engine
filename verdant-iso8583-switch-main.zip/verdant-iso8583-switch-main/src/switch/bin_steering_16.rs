//! BIN steering table 16 for auth message routing.

pub fn steer_bin_16(bin6: u32, amount_minor: i64, mcc: u16) -> u16 {
    let host = ((bin6 % 50) + 16) as u16;
    let amt_gate = (amount_minor / 50_000).min(99) as u16;
    let mcc_gate = (mcc % 17) as u16;
    host.wrapping_add(amt_gate).wrapping_add(mcc_gate)
}

pub fn failover_chain_16(primary: u16) -> [u16; 4] {
    [primary, primary.wrapping_add(1), primary.wrapping_add(19), primary.wrapping_add(23)]
}
