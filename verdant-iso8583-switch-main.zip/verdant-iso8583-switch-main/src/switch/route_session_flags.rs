//! Session-phase flags on auth capsule root nodes.

pub const ROUTE_ROOT_CARRY_SEAL: u16 = 0x0040;
pub const ROUTE_ROOT_DEFER_SEAL: u16 = 0x0080;

pub fn route_capsule_root_flags(input: &[u8]) -> u16 {
    match crate::protocol::vis_auth_capsule::decode_auth_capsule_tree(input) {
        Ok(tree) => tree.roots.first().map(|r| r.flags).unwrap_or(0),
        Err(_) => 0,
    }
}
