# Verdant ISO8583 Switch

**Author:** misgana tsegaye  
**Crate:** `verdant-iso8583-switch` (`vis` types)  
**Domain:** Merchant card acquiring switch (authorization, capture, settlement batching)

Rust library and CLI for ISO8583 acquiring: VISB settlement batches, VISA auth-route capsules, VIST terminal session merge, interchange fee tiers, and capture reconciliation.

## Build

```bash
cargo build --release
cargo test
```

## CLI

```bash
cargo run --bin visctl -- auth --pan 4111111111111111 --amount 000000001000 --stan 123456 --terminal TERM0001 --merchant MERCH0000000001
cargo run --bin visctl -- capture --stan 123456 --amount 000000001000 --auth AUTH01
cargo run --bin visctl -- settle-batch fuzz/corpus/batch_fuzzer/seed_settle.bin
cargo run --bin visctl -- route fuzz/corpus/router_fuzzer/seed_capsule.bin
cargo run --bin visctl -- limit-check MERCH0000000001 50000
```

## Fuzzing

```bash
cargo install cargo-fuzz
cargo fuzz build batch_fuzzer --release --sanitizer address
cargo fuzz run batch_fuzzer fuzz/corpus/batch_fuzzer --release --sanitizer address
```

ClusterFuzzLite:

```bash
export SRC="$PWD" OUT=/tmp/vis_out && mkdir -p "$OUT"
bash .clusterfuzzlite/build.sh
```

| Harness | Exercises |
|---------|-----------|
| `batch_fuzzer` | VISB settlement batch decode and pipeline |
| `router_fuzzer` | VISA capsule ingress and auth routing |
| `session_fuzzer` | VIST terminal session merge |
| `fix_fuzzer` | FIX gateway frame parse |
| `swift_fuzzer` | SWIFT settlement advice parse |

## Module map

| Path | Responsibility |
|------|----------------|
| `src/protocol/iso8583_parser.rs` | ISO8583 MTI, bitmap, field parse |
| `src/protocol/iso8583_builder.rs` | Auth/capture message builder |
| `src/protocol/iso8583_field_registry.rs` | DE field specs and MCC overlays |
| `src/protocol/iso8583_message_catalog.rs` | MTI 0200/0220/0400 validation |
| `src/protocol/iso8583_response_codes.rs` | Response code catalog |
| `src/protocol/vis_settle_batch.rs` | VISB settlement batch wire |
| `src/protocol/vis_auth_capsule.rs` | VISA nested auth-route capsule |
| `src/protocol/vis_terminal_frame.rs` | VIST terminal session frame |
| `src/protocol/emv_tlv.rs` | EMV TLV parse for field 55 |
| `src/protocol/fix_gateway.rs` | FIX gateway frame parse |
| `src/protocol/swift_advice.rs` | SWIFT settlement advice parse |
| `src/switch/auth_router.rs` | Auth ingress classification and routing |
| `src/switch/auth_route_tape.rs` | Auth route fingerprint seal |
| `src/switch/capsule_walker.rs` | Nested capsule walk |
| `src/switch/route_staging.rs` | Auth-route staging board |
| `src/settle/settle_pipeline.rs` | Settlement batch pipeline |
| `src/settle/batch_pin_board.rs` | Settlement recon pin table |
| `src/settle/batch_compactor.rs` | Payload arena compaction |
| `src/settle/reconciliation_chain.rs` | Batch recon digest finalize |
| `src/issuer/terminal_pipeline.rs` | Terminal session merge pipeline |
| `src/issuer/terminal_merge_anchor.rs` | Terminal merge stamp flush |
| `src/issuer/terminal_graft.rs` | Leg track graft |
| `src/acquiring/auth_pipeline.rs` | Auth hold processing |
| `src/acquiring/capture_engine.rs` | Capture reconciliation driver |
| `src/merchant/interchange_tier_matrix.rs` | Interchange fee tiers |
| `src/merchant/auth_hold_registry.rs` | Auth hold book |
| `src/merchant/capture_reconciliation.rs` | Capture vs auth matcher |
| `src/merchant/merchant_limit_guard.rs` | Merchant daily limits |

## Wire formats

See [docs/FORMAT.md](docs/FORMAT.md) for VISB / VISA / VIST binary layouts and ISO8583 field notes.

## License

MIT
