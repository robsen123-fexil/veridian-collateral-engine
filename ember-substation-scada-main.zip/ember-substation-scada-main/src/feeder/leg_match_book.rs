//! Feeder leg voltage matching for checkpoint merge reconciliation.

use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Clone, Copy)]
pub struct EsFeederLeg {
    pub leg_id: u32,
    pub feeder_id: u32,
    pub voltage_kv: u16,
    pub current_amps: u16,
    pub lat_micro: i32,
    pub lon_micro: i32,
    pub substation_id: u32,
}

#[derive(Debug, Default)]
pub struct EsFeederMatchBook {
    pub legs: Vec<EsFeederLeg>,
    pub match_digest: u32,
}

impl EsFeederMatchBook {
    pub fn ingest(&mut self, leg: EsFeederLeg) {
        self.match_digest = fnv1a32(self.match_digest, &leg.leg_id.to_le_bytes());
        self.legs.push(leg);
    }

    pub fn match_voltage_pairs(&self) -> u32 {
        let mut pairs = 0u32;
        for i in 0..self.legs.len() {
            for j in (i + 1)..self.legs.len() {
                if self.legs[i].voltage_kv == self.legs[j].voltage_kv {
                    pairs = pairs.saturating_add(1);
                }
            }
        }
        self.match_digest ^ pairs
    }
}
