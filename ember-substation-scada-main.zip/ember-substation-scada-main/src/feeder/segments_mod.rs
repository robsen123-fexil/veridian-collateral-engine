// domain modules — electric utility SCADA surface area
pub mod seg_transmission;
pub mod seg_subtrans;
pub mod seg_distribution;
pub mod seg_industrial;
pub mod seg_residential;
pub mod seg_cap_feed;
pub mod seg_tie;
pub mod seg_gen_tie;
pub mod seg_svc;
pub mod seg_reactor_feed;
pub mod seg_underground;
pub mod seg_overhead;
