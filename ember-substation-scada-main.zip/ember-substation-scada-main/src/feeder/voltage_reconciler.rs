//! Feeder voltage reconciliation and merge stamp preparation.

use crate::feeder::leg_match_book::EsFeederMatchBook;
use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Default)]
pub struct FeederVoltageReconciler {
    pub nominal_kv: u16,
    pub measured_samples: Vec<u16>,
    pub recon_digest: u32,
}

impl FeederVoltageReconciler {
    pub fn new(nominal_kv: u16) -> Self {
        Self {
            nominal_kv,
            ..Default::default()
        }
    }

    pub fn sample_voltage(&mut self, kv: u16) {
        self.measured_samples.push(kv);
        self.recon_digest = fnv1a32(self.recon_digest, &kv.to_le_bytes());
    }

    pub fn deviation_ratio(&self) -> f64 {
        if self.measured_samples.is_empty() {
            return 0.0;
        }
        let avg: u32 = self.measured_samples.iter().map(|&v| v as u32).sum();
        let avg = avg as f64 / self.measured_samples.len() as f64;
        (avg - self.nominal_kv as f64).abs() / self.nominal_kv as f64
    }

    pub fn apply_match_book(&self, book: &EsFeederMatchBook) -> u32 {
        book.match_voltage_pairs() ^ self.recon_digest
    }
}
