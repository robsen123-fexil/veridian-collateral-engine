//! Underground Cable segment checkpoint merge and voltage reconciliation.

use crate::util::fnv_hash::fnv1a32;
use crate::feeder::leg_match_book::EsFeederLeg;

pub const NOMINAL_KV: u16 = 13;
pub const AMP_LIMIT: u16 = 120;
pub const SEGMENT_NAME: &str = "Underground Cable";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UndergroundCheckpoint {
    pub leg_id: u32,
    pub measured_kv: u16,
    pub measured_amps: u16,
    pub merge_epoch: u32,
}

#[derive(Debug, Default)]
pub struct UndergroundMergeBook {
    pub checkpoints: Vec<UndergroundCheckpoint>,
    pub merge_digest: u32,
    pub overload_count: u32,
}

impl UndergroundMergeBook {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn ingest_checkpoint(&mut self, cp: UndergroundCheckpoint) -> bool {
        if cp.measured_amps > AMP_LIMIT {
            self.overload_count += 1;
        }
        let kv_delta = (cp.measured_kv as i32 - NOMINAL_KV as i32).unsigned_abs();
        if kv_delta > (NOMINAL_KV as u32 / 10) {
            return false;
        }
        self.merge_digest = fnv1a32(self.merge_digest, &cp.leg_id.to_le_bytes());
        self.checkpoints.push(cp);
        true
    }

    pub fn to_feeder_legs(&self, substation_id: u32) -> Vec<EsFeederLeg> {
        self.checkpoints
            .iter()
            .map(|cp| EsFeederLeg {
                leg_id: cp.leg_id,
                feeder_id: cp.leg_id.wrapping_mul(17),
                voltage_kv: cp.measured_kv,
                current_amps: cp.measured_amps,
                lat_micro: 0,
                lon_micro: 0,
                substation_id,
            })
            .collect()
    }

    pub fn merge_stamp(&self) -> u32 {
        self.merge_digest
            .wrapping_add(self.overload_count)
            .wrapping_add(NOMINAL_KV as u32)
    }
}
