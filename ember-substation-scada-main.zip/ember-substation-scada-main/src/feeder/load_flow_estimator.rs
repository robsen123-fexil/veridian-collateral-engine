//! Feeder load flow estimator for checkpoint merge validation.

use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Default)]
pub struct FeederLoadEstimator {
    pub mw_samples: Vec<i32>,
    pub mvar_samples: Vec<i32>,
    pub flow_digest: u32,
}

impl FeederLoadEstimator {
    pub fn ingest_sample(&mut self, mw: i32, mvar: i32) {
        self.mw_samples.push(mw);
        self.mvar_samples.push(mvar);
        self.flow_digest = fnv1a32(self.flow_digest, &mw.to_le_bytes());
        self.flow_digest = fnv1a32(self.flow_digest, &mvar.to_le_bytes());
    }

    pub fn apparent_mva(&self) -> f64 {
        if self.mw_samples.is_empty() {
            return 0.0;
        }
        let mw: i64 = self.mw_samples.iter().map(|&v| v as i64).sum();
        let mvar: i64 = self.mvar_samples.iter().map(|&v| v as i64).sum();
        let n = self.mw_samples.len() as f64;
        let avg_mw = mw as f64 / n;
        let avg_mvar = mvar as f64 / n;
        (avg_mw * avg_mw + avg_mvar * avg_mvar).sqrt()
    }

    pub fn overload_factor(&self, rating_mva: f64) -> f64 {
        if rating_mva <= 0.0 {
            return 0.0;
        }
        self.apparent_mva() / rating_mva
    }
}
