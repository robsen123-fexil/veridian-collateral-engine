use crate::audit::feeder_epoch_ledger::{
    flush_feeder_merge_stamp, reset_feeder_checkpoint_epoch, seal_feeder_checkpoint_epoch,
};
use crate::audit::feeder_leg_spool::{
    compact_feeder_leg_spool, feeder_leg_spool, feeder_spool_has_deferred,
    intern_pinned_feeder_legs, remap_deferred_feeder_slots, FEEDER_CHECKPOINT_SPOOL_COMPACT,
    FEEDER_CHECKPOINT_SPOOL_FLUSH, FEEDER_CHECKPOINT_SPOOL_STAGE,
};
use crate::feeder::leg_match_book::EsFeederMatchBook;
use crate::protocol::feeder_checkpoint_codec::{
    decode_feeder_checkpoint, rebind_feeder_annexes, FeederCheckpointBundle,
};
use crate::protocol::frame_magics::FEEDER_CHECKPOINT_MAGIC;
use crate::util::safe_read::{read_u16_le, read_u32_le, slice_at, MAX_FRAME};

/// ESCL lifecycle stream magic — length-prefixed ESCK frame sequence.
pub const FEEDER_LIFECYCLE_MAGIC: [u8; 4] = *b"ESCL";
const FEEDER_LIFECYCLE_VERSION: u16 = 1;
const MAX_LIFECYCLE_FRAMES: usize = 16;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FeederCheckpointError {
    Decode(crate::protocol::feeder_checkpoint_codec::FeederCheckpointDecodeError),
    LifecycleTruncated,
    LifecycleVersion,
    LifecycleTooManyFrames,
    LifecycleFrameSize,
    LifecycleBadFrame,
    LifecycleTrailing,
    SpoolLock,
}

pub fn match_feeder_legs(bundle: &FeederCheckpointBundle) -> u32 {
    let mut book = EsFeederMatchBook::default();
    for leg in &bundle.legs {
        book.ingest(crate::feeder::leg_match_book::EsFeederLeg {
            leg_id: leg.entry.leg_id,
            feeder_id: leg.entry.feeder_id,
            voltage_kv: leg.entry.voltage_kv,
            current_amps: leg.entry.current_amps,
            lat_micro: leg.entry.lat_micro,
            lon_micro: leg.entry.lon_micro,
            substation_id: bundle.substation_id,
        });
    }
    book.match_voltage_pairs()
}

pub fn run_feeder_checkpoint_pipeline(input: &[u8]) -> Result<u32, FeederCheckpointError> {
    if input.len() >= 4 && &input[..4] == FEEDER_LIFECYCLE_MAGIC {
        return run_feeder_lifecycle(input);
    }
    run_single_feeder_checkpoint(input)
}

fn run_single_feeder_checkpoint(input: &[u8]) -> Result<u32, FeederCheckpointError> {
    let mut bundle =
        decode_feeder_checkpoint(input).map_err(|e| FeederCheckpointError::Decode(e))?;
    rebind_feeder_annexes(&mut bundle);
    let matched = match_feeder_legs(&bundle);
    Ok(matched ^ bundle.substation_id)
}

fn run_feeder_lifecycle(input: &[u8]) -> Result<u32, FeederCheckpointError> {
    if input.len() < 10 {
        return Err(FeederCheckpointError::LifecycleTruncated);
    }
    let version = read_u16_le(input, 4).ok_or(FeederCheckpointError::LifecycleTruncated)?;
    if version != FEEDER_LIFECYCLE_VERSION {
        return Err(FeederCheckpointError::LifecycleVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(FeederCheckpointError::LifecycleTruncated)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(FeederCheckpointError::LifecycleTooManyFrames);
    }

    let mut guard = feeder_leg_spool()
        .lock()
        .map_err(|_| FeederCheckpointError::SpoolLock)?;
    guard.reset();
    reset_feeder_checkpoint_epoch();

    let mut offset = 10usize;
    let mut rolling_digest = 0u32;

    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(FeederCheckpointError::LifecycleTruncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len == 0 || frame_len > MAX_FRAME {
            return Err(FeederCheckpointError::LifecycleFrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(FeederCheckpointError::LifecycleTruncated)?;
        offset = offset.saturating_add(frame_len);

        if frame.len() < 4 || frame[..4] != *FEEDER_CHECKPOINT_MAGIC {
            return Err(FeederCheckpointError::LifecycleBadFrame);
        }

        let frame_digest = process_feeder_lifecycle_frame(frame, &mut guard)?;
        rolling_digest = rolling_digest.rotate_left(9).wrapping_add(frame_digest);
    }

    if offset != input.len() {
        return Err(FeederCheckpointError::LifecycleTrailing);
    }

    Ok(rolling_digest ^ frame_count)
}

fn process_feeder_lifecycle_frame(
    frame: &[u8],
    spool: &mut crate::audit::feeder_leg_spool::FeederLegSpool,
) -> Result<u32, FeederCheckpointError> {
    let mut bundle =
        decode_feeder_checkpoint(frame).map_err(|e| FeederCheckpointError::Decode(e))?;

    rebind_feeder_annexes(&mut bundle);
    intern_pinned_feeder_legs(&bundle, spool);
    if bundle.merge_flags & FEEDER_CHECKPOINT_SPOOL_STAGE != 0 {
        seal_feeder_checkpoint_epoch(spool);
    }

    if bundle.merge_flags & FEEDER_CHECKPOINT_SPOOL_COMPACT != 0 {
        compact_feeder_leg_spool(spool);
        remap_deferred_feeder_slots(spool);
    }

    let mut digest = bundle.merge_flags;
    if bundle.merge_flags & FEEDER_CHECKPOINT_SPOOL_FLUSH != 0 && feeder_spool_has_deferred(spool) {
        digest = flush_feeder_merge_stamp();
    } else if bundle.merge_flags
        & (FEEDER_CHECKPOINT_SPOOL_STAGE
            | FEEDER_CHECKPOINT_SPOOL_COMPACT
            | FEEDER_CHECKPOINT_SPOOL_FLUSH)
        == 0
    {
        digest = match_feeder_legs(&bundle) ^ bundle.substation_id;
    }

    Ok(digest ^ bundle.substation_id)
}
