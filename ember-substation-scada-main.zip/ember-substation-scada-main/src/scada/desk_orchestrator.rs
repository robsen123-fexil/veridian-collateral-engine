//! SCADA desk orchestrator — coordinates multi-pipeline reconcile workflows.

use crate::desk::nerc_audit_trail::NercAuditTrail;
use crate::desk::reconcile_gate::DeskReconcileGate;
use crate::feeder::voltage_reconciler::FeederVoltageReconciler;
use crate::substation::rtu_health_monitor::RtuHealthBook;
use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Default)]
pub struct ScadaDeskOrchestrator {
    pub shift_id: u32,
    pub substation_ref: u32,
    pub pipelines_run: u32,
    pub desk_digest: u32,
}

impl ScadaDeskOrchestrator {
    pub fn new(shift_id: u32, substation_ref: u32) -> Self {
        Self {
            shift_id,
            substation_ref,
            ..Default::default()
        }
    }

    pub fn record_pipeline(&mut self, pipeline_id: u8, digest: u32) {
        self.pipelines_run += 1;
        self.desk_digest = fnv1a32(self.desk_digest, &[pipeline_id]);
        self.desk_digest = self.desk_digest.wrapping_add(digest);
    }

    pub fn reconcile_feeder_shift(
        &self,
        gate: &DeskReconcileGate,
        trail: &NercAuditTrail,
        reconciler: &FeederVoltageReconciler,
        health: &RtuHealthBook,
    ) -> u32 {
        let health_score = health.comm_loss_score();
        let voltage_score = reconciler.recon_digest;
        gate.reconcile_shift(trail)
            .wrapping_add(health_score)
            .wrapping_add(voltage_score)
            .wrapping_add(self.desk_digest)
            .wrapping_add(self.substation_ref)
    }

    pub fn nerc_spool_anchor(&self, epoch_digest: u32) -> u32 {
        self.desk_digest
            .rotate_left(11)
            .wrapping_add(epoch_digest)
            .wrapping_add(self.shift_id)
    }
}
