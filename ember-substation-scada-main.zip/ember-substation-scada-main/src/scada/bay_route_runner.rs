use crate::audit::bay_annex_spool::{
    bay_annex_spool, bay_spool_has_deferred, compact_bay_annex_spool, intern_pinned_bay_annexes,
    remap_deferred_bay_slots, BAY_ROUTE_SPOOL_COMPACT, BAY_ROUTE_SPOOL_FLUSH, BAY_ROUTE_SPOOL_STAGE,
};
use crate::audit::bay_route_epoch_ledger::{
    reset_bay_route_epoch, seal_bay_route_epoch, seal_bay_route_fingerprint,
};
use crate::protocol::bay_route_codec::decode_bay_route_chain;
use crate::protocol::frame_magics::BAY_ROUTE_MAGIC;
use crate::util::safe_read::{read_u16_le, read_u32_le, slice_at, MAX_FRAME};

/// ESLR lifecycle stream magic — length-prefixed ESRT frame sequence.
pub const BAY_LIFECYCLE_MAGIC: [u8; 4] = *b"ESLR";
const BAY_LIFECYCLE_VERSION: u16 = 1;
const MAX_LIFECYCLE_FRAMES: usize = 16;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BayRouteOutcome {
    pub bays_scanned: u32,
    pub bays_sealed: u32,
    pub seal_digest: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BayRouteError {
    Empty,
    Truncated,
    WrongWire,
    WalkFailed,
    LifecycleTruncated,
    LifecycleVersion,
    LifecycleTooManyFrames,
    LifecycleFrameSize,
    LifecycleBadFrame,
    LifecycleTrailing,
    SpoolLock,
}

pub fn route_bay_alarm_stream(input: &[u8]) -> Result<BayRouteOutcome, BayRouteError> {
    if input.is_empty() {
        return Err(BayRouteError::Empty);
    }
    if input.len() >= 4 && &input[..4] == BAY_LIFECYCLE_MAGIC {
        return run_bay_lifecycle(input);
    }
    run_single_bay_route(input)
}

fn run_single_bay_route(input: &[u8]) -> Result<BayRouteOutcome, BayRouteError> {
    if input.len() < 4 {
        return Err(BayRouteError::Truncated);
    }
    if &input[..4] != BAY_ROUTE_MAGIC {
        return Err(BayRouteError::WrongWire);
    }
    let chain = decode_bay_route_chain(input).map_err(|_| BayRouteError::WalkFailed)?;
    let digest = chain.chain_flags ^ chain.bay_count;
    Ok(BayRouteOutcome {
        bays_scanned: chain.nodes.len() as u32,
        bays_sealed: chain.bay_count,
        seal_digest: digest,
    })
}

fn run_bay_lifecycle(input: &[u8]) -> Result<BayRouteOutcome, BayRouteError> {
    if input.len() < 10 {
        return Err(BayRouteError::LifecycleTruncated);
    }
    let version = read_u16_le(input, 4).ok_or(BayRouteError::LifecycleTruncated)?;
    if version != BAY_LIFECYCLE_VERSION {
        return Err(BayRouteError::LifecycleVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(BayRouteError::LifecycleTruncated)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(BayRouteError::LifecycleTooManyFrames);
    }

    let mut guard = bay_annex_spool()
        .lock()
        .map_err(|_| BayRouteError::SpoolLock)?;
    guard.reset();
    reset_bay_route_epoch();

    let mut offset = 10usize;
    let mut rolling_digest = 0u32;
    let mut bays_scanned = 0u32;

    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(BayRouteError::LifecycleTruncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len == 0 || frame_len > MAX_FRAME {
            return Err(BayRouteError::LifecycleFrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(BayRouteError::LifecycleTruncated)?;
        offset = offset.saturating_add(frame_len);

        if frame.len() < 4 || frame[..4] != *BAY_ROUTE_MAGIC {
            return Err(BayRouteError::LifecycleBadFrame);
        }

        let (digest, scanned) = process_bay_lifecycle_frame(frame, &mut guard)?;
        rolling_digest = rolling_digest.rotate_left(3).wrapping_add(digest);
        bays_scanned = bays_scanned.saturating_add(scanned);
    }

    if offset != input.len() {
        return Err(BayRouteError::LifecycleTrailing);
    }

    Ok(BayRouteOutcome {
        bays_scanned,
        bays_sealed: frame_count,
        seal_digest: rolling_digest,
    })
}

fn process_bay_lifecycle_frame(
    frame: &[u8],
    spool: &mut crate::audit::bay_annex_spool::BayAnnexSpool,
) -> Result<(u32, u32), BayRouteError> {
    let chain = decode_bay_route_chain(frame).map_err(|_| BayRouteError::WalkFailed)?;
    let bays_scanned = chain.nodes.len() as u32;

    intern_pinned_bay_annexes(&chain, spool);
    if chain.chain_flags & BAY_ROUTE_SPOOL_STAGE != 0 {
        seal_bay_route_epoch(spool);
    }

    if chain.chain_flags & BAY_ROUTE_SPOOL_COMPACT != 0 {
        compact_bay_annex_spool(spool);
        remap_deferred_bay_slots(spool);
    }

    let mut digest = chain.chain_flags;
    if chain.chain_flags & BAY_ROUTE_SPOOL_FLUSH != 0 && bay_spool_has_deferred(spool) {
        digest = seal_bay_route_fingerprint();
    }

    Ok((digest, bays_scanned))
}
