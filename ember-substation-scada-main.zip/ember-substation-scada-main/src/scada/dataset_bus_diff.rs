//! Bus Differential GOOSE dataset node evaluation and TLV path digest.

use crate::util::fnv_hash::fnv1a32;
use crate::protocol::goose_event_codec::compute_path_crc;

pub const DATASET_NAME: &str = "Bus Differential";

const FIELD_TAGS: [&str; 3] = [
        "Idiff",
        "Slope",
        "Trip"
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BusDiffNodeValue {
    pub field_idx: u8,
    pub raw_value: i32,
    pub quality: u8,
}

#[derive(Debug, Default)]
pub struct BusDiffDatasetState {
    pub values: Vec<BusDiffNodeValue>,
    pub path_tags: Vec<u16>,
    pub dataset_digest: u32,
}

impl BusDiffDatasetState {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn build_path_tags(&mut self) {
        self.path_tags.clear();
        for (i, _) in FIELD_TAGS.iter().enumerate() {
            self.path_tags.push((0xE000 + i as u16) & 0xFFFF);
        }
    }

    pub fn ingest_value(&mut self, field: &str, raw: i32, quality: u8) {
        let idx = FIELD_TAGS
            .iter()
            .position(|f| *f == field)
            .unwrap_or(FIELD_TAGS.len()) as u8;
        self.values.push(BusDiffNodeValue {
            field_idx: idx,
            raw_value: raw,
            quality,
        });
        self.dataset_digest = fnv1a32(self.dataset_digest, field.as_bytes());
        self.dataset_digest = self.dataset_digest.wrapping_add(raw as u32);
    }

    pub fn nested_path_crc(&self, payload: &[u8]) -> u16 {
        if self.path_tags.len() < 2 {
            return 0;
        }
        compute_path_crc(&self.path_tags, payload)
    }

    pub fn evaluate_tree_depth(&self) -> u32 {
        let depth = self.path_tags.len() as u32;
        if depth >= 2 {
            self.dataset_digest.wrapping_add(depth.saturating_mul(100))
        } else {
            0
        }
    }

    pub fn substation_ref_score(&self, substation_ref: u32) -> u32 {
        self.evaluate_tree_depth() ^ substation_ref ^ self.dataset_digest
    }
}
