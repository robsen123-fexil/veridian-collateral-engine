use crate::audit::journal_epoch_ledger::{
    finalize_journal_alert_digest, reset_journal_alert_epoch, seal_journal_alert_epoch,
};
use crate::audit::journal_note_spool::{
    compact_journal_note_spool, intern_pinned_journal_notes, journal_note_spool,
    journal_spool_has_deferred, remap_deferred_journal_slots, JOURNAL_ALERT_SPOOL_COMPACT,
    JOURNAL_ALERT_SPOOL_FLUSH, JOURNAL_ALERT_SPOOL_STAGE,
};
use crate::protocol::frame_magics::JOURNAL_ALERT_MAGIC;
use crate::protocol::journal_alert_codec::parse_journal_alert_feed;
use crate::util::safe_read::{read_u16_le, read_u32_le, slice_at, MAX_FRAME};

/// ESJL lifecycle stream magic — length-prefixed ESJR frame sequence.
pub const JOURNAL_LIFECYCLE_MAGIC: [u8; 4] = *b"ESJL";
const JOURNAL_LIFECYCLE_VERSION: u16 = 1;
const MAX_LIFECYCLE_FRAMES: usize = 16;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JournalAlertError {
    Empty,
    BadMagic,
    ParseFailed,
    LifecycleTruncated,
    LifecycleVersion,
    LifecycleTooManyFrames,
    LifecycleFrameSize,
    LifecycleBadFrame,
    LifecycleTrailing,
    SpoolLock,
}

pub fn run_journal_alert_pipeline(input: &[u8]) -> Result<u32, JournalAlertError> {
    if input.is_empty() {
        return Err(JournalAlertError::Empty);
    }
    if input.len() >= 4 && &input[..4] == JOURNAL_LIFECYCLE_MAGIC {
        return run_journal_lifecycle(input);
    }
    run_single_journal_alert(input)
}

fn run_single_journal_alert(input: &[u8]) -> Result<u32, JournalAlertError> {
    if input.len() < 4 || &input[..4] != JOURNAL_ALERT_MAGIC {
        return Err(JournalAlertError::BadMagic);
    }
    let feed = parse_journal_alert_feed(input).map_err(|_| JournalAlertError::ParseFailed)?;
    Ok(feed.alert_count ^ feed.desk_ref)
}

fn run_journal_lifecycle(input: &[u8]) -> Result<u32, JournalAlertError> {
    if input.len() < 10 {
        return Err(JournalAlertError::LifecycleTruncated);
    }
    let version = read_u16_le(input, 4).ok_or(JournalAlertError::LifecycleTruncated)?;
    if version != JOURNAL_LIFECYCLE_VERSION {
        return Err(JournalAlertError::LifecycleVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(JournalAlertError::LifecycleTruncated)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(JournalAlertError::LifecycleTooManyFrames);
    }

    let mut guard = journal_note_spool()
        .lock()
        .map_err(|_| JournalAlertError::SpoolLock)?;
    guard.reset();
    reset_journal_alert_epoch();

    let mut offset = 10usize;
    let mut rolling_digest = 0u32;

    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(JournalAlertError::LifecycleTruncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len == 0 || frame_len > MAX_FRAME {
            return Err(JournalAlertError::LifecycleFrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(JournalAlertError::LifecycleTruncated)?;
        offset = offset.saturating_add(frame_len);

        if frame.len() < 4 || frame[..4] != *JOURNAL_ALERT_MAGIC {
            return Err(JournalAlertError::LifecycleBadFrame);
        }

        let frame_digest = process_journal_lifecycle_frame(frame, &mut guard)?;
        rolling_digest = rolling_digest.rotate_left(13).wrapping_add(frame_digest);
    }

    if offset != input.len() {
        return Err(JournalAlertError::LifecycleTrailing);
    }

    Ok(rolling_digest ^ frame_count)
}

fn process_journal_lifecycle_frame(
    frame: &[u8],
    spool: &mut crate::audit::journal_note_spool::JournalNoteSpool,
) -> Result<u32, JournalAlertError> {
    let feed = parse_journal_alert_feed(frame).map_err(|_| JournalAlertError::ParseFailed)?;

    intern_pinned_journal_notes(&feed, spool);
    if feed.epoch_secs & JOURNAL_ALERT_SPOOL_STAGE != 0 {
        seal_journal_alert_epoch(spool);
    }

    if feed.epoch_secs & JOURNAL_ALERT_SPOOL_COMPACT != 0 {
        compact_journal_note_spool(spool);
        remap_deferred_journal_slots(spool);
    }

    let mut digest = feed.desk_ref;
    if feed.epoch_secs & JOURNAL_ALERT_SPOOL_FLUSH != 0 && journal_spool_has_deferred(spool) {
        digest = finalize_journal_alert_digest();
    } else if feed.epoch_secs
        & (JOURNAL_ALERT_SPOOL_STAGE | JOURNAL_ALERT_SPOOL_COMPACT | JOURNAL_ALERT_SPOOL_FLUSH)
        == 0
    {
        digest = feed.alert_count ^ feed.desk_ref;
    }

    Ok(digest)
}
