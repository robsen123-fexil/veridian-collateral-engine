use crate::audit::goose_epoch_ledger::{
    reset_goose_event_epoch, seal_goose_event_epoch, seal_goose_event_fingerprint,
};
use crate::audit::goose_node_spool::{
    compact_goose_node_spool, goose_node_spool, goose_spool_has_deferred,
    intern_pinned_goose_nodes, remap_deferred_goose_slots, GOOSE_EVENT_SPOOL_COMPACT,
    GOOSE_EVENT_SPOOL_FLUSH, GOOSE_EVENT_SPOOL_STAGE,
};
use crate::protocol::frame_magics::GOOSE_EVENT_MAGIC;
use crate::protocol::goose_event_codec::{decode_goose_event_tree, walk_nested_goose_paths};
use crate::util::safe_read::{read_u16_le, read_u32_le, slice_at, MAX_FRAME};

/// ESGL lifecycle stream magic — length-prefixed ESGO frame sequence.
pub const GOOSE_LIFECYCLE_MAGIC: [u8; 4] = *b"ESGL";
const GOOSE_LIFECYCLE_VERSION: u16 = 1;
const MAX_LIFECYCLE_FRAMES: usize = 16;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GooseEventError {
    Decode(crate::protocol::goose_event_codec::GooseEventDecodeError),
    LifecycleTruncated,
    LifecycleVersion,
    LifecycleTooManyFrames,
    LifecycleFrameSize,
    LifecycleBadFrame,
    LifecycleTrailing,
    SpoolLock,
}

pub fn run_goose_event_pipeline(input: &[u8]) -> Result<u32, GooseEventError> {
    if input.len() >= 4 && &input[..4] == GOOSE_LIFECYCLE_MAGIC {
        return run_goose_lifecycle(input);
    }
    run_single_goose_event(input)
}

fn run_single_goose_event(input: &[u8]) -> Result<u32, GooseEventError> {
    let tree = decode_goose_event_tree(input).map_err(GooseEventError::Decode)?;
    let score = walk_nested_goose_paths(&tree);
    Ok(score ^ tree.substation_ref)
}

fn run_goose_lifecycle(input: &[u8]) -> Result<u32, GooseEventError> {
    if input.len() < 10 {
        return Err(GooseEventError::LifecycleTruncated);
    }
    let version = read_u16_le(input, 4).ok_or(GooseEventError::LifecycleTruncated)?;
    if version != GOOSE_LIFECYCLE_VERSION {
        return Err(GooseEventError::LifecycleVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(GooseEventError::LifecycleTruncated)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(GooseEventError::LifecycleTooManyFrames);
    }

    let mut guard = goose_node_spool()
        .lock()
        .map_err(|_| GooseEventError::SpoolLock)?;
    guard.reset();
    reset_goose_event_epoch();

    let mut offset = 10usize;
    let mut rolling_digest = 0u32;

    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(GooseEventError::LifecycleTruncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len == 0 || frame_len > MAX_FRAME {
            return Err(GooseEventError::LifecycleFrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(GooseEventError::LifecycleTruncated)?;
        offset = offset.saturating_add(frame_len);

        if frame.len() < 4 || frame[..4] != *GOOSE_EVENT_MAGIC {
            return Err(GooseEventError::LifecycleBadFrame);
        }

        let frame_digest = process_goose_lifecycle_frame(frame, &mut guard)?;
        rolling_digest = rolling_digest.rotate_left(11).wrapping_add(frame_digest);
    }

    if offset != input.len() {
        return Err(GooseEventError::LifecycleTrailing);
    }

    Ok(rolling_digest ^ frame_count)
}

fn process_goose_lifecycle_frame(
    frame: &[u8],
    spool: &mut crate::audit::goose_node_spool::GooseNodeSpool,
) -> Result<u32, GooseEventError> {
    let tree = decode_goose_event_tree(frame).map_err(GooseEventError::Decode)?;

    intern_pinned_goose_nodes(&tree, spool);
    if tree.tree_flags & GOOSE_EVENT_SPOOL_STAGE != 0 {
        seal_goose_event_epoch(spool);
    }

    if tree.tree_flags & GOOSE_EVENT_SPOOL_COMPACT != 0 {
        compact_goose_node_spool(spool);
        remap_deferred_goose_slots(spool);
    }

    let mut digest = tree.tree_flags;
    if tree.tree_flags & GOOSE_EVENT_SPOOL_FLUSH != 0 && goose_spool_has_deferred(spool) {
        digest = seal_goose_event_fingerprint();
    } else if tree.tree_flags
        & (GOOSE_EVENT_SPOOL_STAGE | GOOSE_EVENT_SPOOL_COMPACT | GOOSE_EVENT_SPOOL_FLUSH)
        == 0
    {
        digest = walk_nested_goose_paths(&tree);
    }

    Ok(digest ^ tree.substation_ref)
}
