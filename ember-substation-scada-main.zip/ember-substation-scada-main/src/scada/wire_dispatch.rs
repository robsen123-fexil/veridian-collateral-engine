//! SCADA wire dispatch — routes multiplexed ingress bytes to pipeline APIs.

use crate::protocol::streaming_frame_scanner::{classify_frame_magic, ScannedFrameKind};
use crate::scada::bay_route_runner::route_bay_alarm_stream;
use crate::scada::fault_spool_runner::run_fault_spool_pipeline;
use crate::scada::feeder_checkpoint_runner::run_feeder_checkpoint_pipeline;
use crate::scada::goose_event_runner::run_goose_event_pipeline;
use crate::scada::journal_alert_runner::run_journal_alert_pipeline;
use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DispatchError {
    Empty,
    UnknownMagic,
    PipelineFailed,
}

pub fn dispatch_scada_wire(input: &[u8]) -> Result<u32, DispatchError> {
    if input.is_empty() {
        return Err(DispatchError::Empty);
    }
    if input.len() < 4 {
        return Err(DispatchError::UnknownMagic);
    }
    let kind = classify_frame_magic(&input[..4]);
    match kind {
        ScannedFrameKind::FaultSpool => run_fault_spool_pipeline(input)
            .map_err(|_| DispatchError::PipelineFailed),
        ScannedFrameKind::BayRoute => route_bay_alarm_stream(input)
            .map(|o| o.seal_digest)
            .map_err(|_| DispatchError::PipelineFailed),
        ScannedFrameKind::FeederCheckpoint => run_feeder_checkpoint_pipeline(input)
            .map_err(|_| DispatchError::PipelineFailed),
        ScannedFrameKind::GooseEvent => run_goose_event_pipeline(input)
            .map_err(|_| DispatchError::PipelineFailed),
        ScannedFrameKind::JournalAlert => run_journal_alert_pipeline(input)
            .map_err(|_| DispatchError::PipelineFailed),
        ScannedFrameKind::Unknown => {
            if input.len() >= 4 {
                let lifecycle = &input[..4];
                if lifecycle == b"ESLF" || lifecycle == b"ESLR" || lifecycle == b"ESCL"
                    || lifecycle == b"ESGL" || lifecycle == b"ESJL"
                {
                    return dispatch_lifecycle_stream(input);
                }
            }
            Err(DispatchError::UnknownMagic)
        }
    }
}

fn dispatch_lifecycle_stream(input: &[u8]) -> Result<u32, DispatchError> {
    let magic = &input[..4];
    let digest = if magic == b"ESLF" {
        run_fault_spool_pipeline(input).map_err(|_| DispatchError::PipelineFailed)?
    } else if magic == b"ESLR" {
        route_bay_alarm_stream(input)
            .map(|o| o.seal_digest)
            .map_err(|_| DispatchError::PipelineFailed)?
    } else if magic == b"ESCL" {
        run_feeder_checkpoint_pipeline(input).map_err(|_| DispatchError::PipelineFailed)?
    } else if magic == b"ESGL" {
        run_goose_event_pipeline(input).map_err(|_| DispatchError::PipelineFailed)?
    } else {
        run_journal_alert_pipeline(input).map_err(|_| DispatchError::PipelineFailed)?
    };
    Ok(fnv1a32(0xDEAD_BEEF, &digest.to_le_bytes()))
}
