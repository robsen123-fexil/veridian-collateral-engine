use crate::audit::fault_epoch_ledger::{
    record_fault_chain_roll, reset_fault_desk_epoch, seal_fault_spool_epoch,
    try_finalize_fault_epoch_digest,
};
use crate::audit::fault_record_spool::{
    fault_record_spool, intern_verified_fault_chunks, spool_has_deferred,
};
use crate::protocol::fault_chunk_envelope::split_lifecycle_envelope;
use crate::protocol::fault_spool_codec::{
    decode_fault_spool, verify_fault_record_chain, FaultSpoolState,
};
use crate::protocol::frame_magics::FAULT_SPOOL_MAGIC;
use crate::substation::rtu_fault_classifier::apply_rtu_severity_shift;
use crate::util::safe_read::{read_u16_le, read_u32_le, slice_at, MAX_FRAME};

/// ESLF lifecycle stream magic — length-prefixed ESBF frame sequence.
pub const FAULT_LIFECYCLE_MAGIC: [u8; 4] = *b"ESLF";
const FAULT_LIFECYCLE_VERSION: u16 = 2;
const MAX_LIFECYCLE_FRAMES: usize = 32;

#[derive(Debug, Default)]
pub struct FaultSpoolOrchestrator {
    pub substation_lane: u16,
    pub records_normalized: u32,
    pub severity_shift: u32,
}

impl FaultSpoolOrchestrator {
    pub fn new(lane: u16) -> Self {
        Self {
            substation_lane: lane,
            records_normalized: 0,
            severity_shift: 100,
        }
    }

    pub fn load_batch(&mut self, state: &mut FaultSpoolState) {
        self.records_normalized = 0;
        if state.substation_lane != 0 {
            self.substation_lane = state.substation_lane;
        }
        self.severity_shift = 100 + (state.flags & 0xff) as u32;
    }
}

pub fn normalize_fault_records(orch: &mut FaultSpoolOrchestrator, state: &mut FaultSpoolState) {
    if state.flags & 0x0000_0002 == 0 {
        return;
    }
    for entry in state.entries.iter_mut() {
        if entry.severity & 0x04 != 0 {
            entry.severity = entry
                .severity
                .saturating_add((orch.severity_shift & 0xff) as u8);
        }
        orch.records_normalized += 1;
    }
}

pub fn sweep_rtu_faults(state: &FaultSpoolState) -> Result<i64, FaultSweepError> {
    let mut total = 0i64;
    for (idx, entry) in state.entries.iter().enumerate() {
        let payload = state
            .record_payload(idx)
            .ok_or(FaultSweepError::MissingPayload)?;
        let weight = payload.len() as i64 * 1000 + entry.rtu_id as i64;
        let adjusted = apply_rtu_severity_shift(weight, u32::from(entry.severity));
        total = total.saturating_add(adjusted);
    }
    Ok(total)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FaultSweepError {
    MissingPayload,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FaultSpoolError {
    Decode(crate::protocol::fault_spool_codec::FaultSpoolDecodeError),
    HeaderChain,
    Sweep(FaultSweepError),
    LifecycleTruncated,
    LifecycleVersion,
    LifecycleTooManyFrames,
    LifecycleFrameSize,
    LifecycleBadFrame,
    LifecycleTrailing,
    LifecycleEnvelope,
    SpoolLock,
}

pub fn run_fault_spool_pipeline(input: &[u8]) -> Result<u32, FaultSpoolError> {
    if input.len() >= 4 && &input[..4] == FAULT_LIFECYCLE_MAGIC {
        return run_fault_lifecycle(input);
    }
    run_single_fault_spool(input)
}

fn run_single_fault_spool(input: &[u8]) -> Result<u32, FaultSpoolError> {
    let mut state = decode_fault_spool(input).map_err(FaultSpoolError::Decode)?;
    if !verify_fault_record_chain(&state) {
        return Err(FaultSpoolError::HeaderChain);
    }
    let mut orch = FaultSpoolOrchestrator::new(state.substation_lane);
    orch.load_batch(&mut state);
    normalize_fault_records(&mut orch, &mut state);
    let sweep_total = sweep_rtu_faults(&state).map_err(FaultSpoolError::Sweep)?;
    Ok(sweep_total as u32 ^ state.epoch_secs)
}

fn run_fault_lifecycle(input: &[u8]) -> Result<u32, FaultSpoolError> {
    if input.len() < 10 {
        return Err(FaultSpoolError::LifecycleTruncated);
    }
    let version = read_u16_le(input, 4).ok_or(FaultSpoolError::LifecycleTruncated)?;
    if version != FAULT_LIFECYCLE_VERSION {
        return Err(FaultSpoolError::LifecycleVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(FaultSpoolError::LifecycleTruncated)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(FaultSpoolError::LifecycleTooManyFrames);
    }

    let mut guard = fault_record_spool()
        .lock()
        .map_err(|_| FaultSpoolError::SpoolLock)?;
    guard.reset();
    reset_fault_desk_epoch();

    let mut offset = 10usize;
    let mut rolling_digest = 0u32;
    let mut frames_processed = 0u32;

    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(FaultSpoolError::LifecycleTruncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len < 8 || frame_len > MAX_FRAME {
            return Err(FaultSpoolError::LifecycleFrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(FaultSpoolError::LifecycleTruncated)?;
        offset = offset.saturating_add(frame_len);

        let frame_digest = process_fault_lifecycle_frame(frame, &mut guard)?;
        rolling_digest = rolling_digest.rotate_left(5).wrapping_add(frame_digest);
        frames_processed = frames_processed.wrapping_add(1);
    }

    if offset != input.len() {
        return Err(FaultSpoolError::LifecycleTrailing);
    }

    let final_digest = if spool_has_deferred(&guard) {
        try_finalize_fault_epoch_digest(&guard)
    } else {
        0
    };

    Ok(rolling_digest ^ frames_processed ^ final_digest)
}

fn process_fault_lifecycle_frame(
    frame: &[u8],
    spool: &mut crate::audit::fault_record_spool::FaultRecordSpool,
) -> Result<u32, FaultSpoolError> {
    let (batch, esbf_frame) =
        split_lifecycle_envelope(frame).ok_or(FaultSpoolError::LifecycleEnvelope)?;

    if !batch.chunks.is_empty() {
        intern_verified_fault_chunks(&batch.chunks, spool);
        record_fault_chain_roll(batch.batch_roll);
        seal_fault_spool_epoch(spool);
    }

    if esbf_frame.len() < 4 || esbf_frame[..4] != *FAULT_SPOOL_MAGIC {
        return Err(FaultSpoolError::LifecycleBadFrame);
    }

    let mut state = decode_fault_spool(esbf_frame).map_err(FaultSpoolError::Decode)?;
    if !verify_fault_record_chain(&state) {
        return Err(FaultSpoolError::HeaderChain);
    }

    let mut orch = FaultSpoolOrchestrator::new(state.substation_lane);
    orch.load_batch(&mut state);
    normalize_fault_records(&mut orch, &mut state);

    let sweep_total = sweep_rtu_faults(&state).map_err(FaultSpoolError::Sweep)?;
    let mut digest = sweep_total as u32 ^ state.epoch_secs;

    if spool_has_deferred(spool) {
        let reconciled = try_finalize_fault_epoch_digest(spool);
        if reconciled != 0 {
            digest = reconciled;
        }
    }

    Ok(digest ^ batch.batch_roll)
}
