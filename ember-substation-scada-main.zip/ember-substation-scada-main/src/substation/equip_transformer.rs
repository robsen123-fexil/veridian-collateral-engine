//! Power Transformer telemetry routing and SOE tag evaluation.

use crate::util::fnv_hash::fnv1a32;
use crate::util::crc16::crc16_ccitt;

pub const EQUIP_MASK: u16 = 0x0002;
pub const EQUIP_NAME: &str = "Power Transformer";

const SOE_TAGS: [&str; 4] = [
        "TAP",
        "OIL",
        "GAS",
        "WIND"
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TransformerTelemetrySlot {
    pub tag_idx: u8,
    pub analog_value: i32,
    pub quality_flags: u8,
    pub timestamp_ms: u32,
}

#[derive(Debug, Default)]
pub struct TransformerEquipmentState {
    pub slots: Vec<TransformerTelemetrySlot>,
    pub equip_digest: u32,
    pub alarm_count: u32,
}

impl TransformerEquipmentState {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn ingest_telemetry(&mut self, tag: &str, value: i32, quality: u8, ts_ms: u32) {
        let idx = SOE_TAGS
            .iter()
            .position(|t| *t == tag)
            .unwrap_or(SOE_TAGS.len()) as u8;
        self.slots.push(TransformerTelemetrySlot {
            tag_idx: idx,
            analog_value: value,
            quality_flags: quality,
            timestamp_ms: ts_ms,
        });
        self.equip_digest = fnv1a32(self.equip_digest, tag.as_bytes());
        self.equip_digest = self.equip_digest.wrapping_add(value as u32);
        if quality & 0x80 != 0 {
            self.alarm_count += 1;
        }
    }

    pub fn evaluate_chain_crc(&self) -> u16 {
        let mut crc = 0xFFFFu16;
        for slot in &self.slots {
            crc = crc16_ccitt(crc, &slot.analog_value.to_le_bytes());
            crc = crc.wrapping_add(u16::from(slot.quality_flags));
        }
        crc
    }

    pub fn substation_lane_score(&self, lane: u16) -> u32 {
        let mut score = u32::from(EQUIP_MASK & 0xFF);
        score = score.saturating_add(u32::from(lane) * 7);
        score = score.saturating_add(self.alarm_count);
        score ^ self.equip_digest
    }

    pub fn is_critical(&self) -> bool {
        self.alarm_count > 0 && (EQUIP_MASK & 0x00F0) != 0
    }
}
