//! RTU communication health monitor and spool pressure estimator.

use crate::util::crc16::crc16_ccitt;
use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Clone, Copy)]
pub struct RtuCommHealth {
    pub rtu_id: u32,
    pub last_poll_ms: u32,
    pub missed_polls: u16,
    pub latency_ms: u16,
}

#[derive(Debug, Default)]
pub struct RtuHealthBook {
    pub rtus: Vec<RtuCommHealth>,
    pub health_digest: u32,
}

impl RtuHealthBook {
    pub fn ingest_poll(&mut self, rtu_id: u32, poll_ms: u32, latency: u16) {
        if let Some(entry) = self.rtus.iter_mut().find(|r| r.rtu_id == rtu_id) {
            if poll_ms > entry.last_poll_ms.saturating_add(5000) {
                entry.missed_polls = entry.missed_polls.saturating_add(1);
            }
            entry.last_poll_ms = poll_ms;
            entry.latency_ms = latency;
        } else {
            self.rtus.push(RtuCommHealth {
                rtu_id,
                last_poll_ms: poll_ms,
                missed_polls: 0,
                latency_ms: latency,
            });
        }
        self.health_digest = fnv1a32(self.health_digest, &rtu_id.to_le_bytes());
    }

    pub fn comm_loss_score(&self) -> u32 {
        let mut loss = 0u32;
        for rtu in &self.rtus {
            loss = loss.saturating_add(u32::from(rtu.missed_polls) * 10);
        }
        self.health_digest ^ loss
    }

    pub fn chain_crc_over_payloads(payloads: &[&[u8]]) -> u16 {
        let mut crc = 0xFFFFu16;
        for p in payloads {
            crc = crc16_ccitt(crc, p);
        }
        crc
    }
}
