//! IEC 61850 logical node reference table for GOOSE dataset binding.

use crate::util::fnv_hash::fnv1a32;

pub const LN_TYPES: [&str; 8] = ["XCBR", "XSWI", "MMXU", "PTRC", "PDIF", "GGIO", "CSWI", "LLN0"];

#[derive(Debug, Clone)]
pub struct LogicalNodeRef {
    pub ln_class: String,
    pub inst: u8,
    pub dataset: String,
}

#[derive(Debug, Default)]
pub struct LogicalNodeTable {
    pub nodes: Vec<LogicalNodeRef>,
    pub table_digest: u32,
}

impl LogicalNodeTable {
    pub fn bind_node(&mut self, ln_class: &str, inst: u8, dataset: &str) {
        self.nodes.push(LogicalNodeRef {
            ln_class: ln_class.to_string(),
            inst,
            dataset: dataset.to_string(),
        });
        self.table_digest = fnv1a32(self.table_digest, ln_class.as_bytes());
        self.table_digest = self.table_digest.wrapping_add(u32::from(inst));
    }

    pub fn lookup_dataset(&self, ln_class: &str, inst: u8) -> Option<&str> {
        self.nodes
            .iter()
            .find(|n| n.ln_class == ln_class && n.inst == inst)
            .map(|n| n.dataset.as_str())
    }

    pub fn goose_bind_score(&self) -> u32 {
        self.table_digest.wrapping_add(self.nodes.len() as u32 * 17)
    }
}
