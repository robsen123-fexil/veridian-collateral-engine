//! RTU fault severity shift for sweep weighting.

pub fn apply_rtu_severity_shift(weight: i64, severity: u32) -> i64 {
    let shift = (severity & 0x0F) as i64 * 17;
    weight.saturating_add(shift)
}
