//! Substation topology graph for IED connectivity and bay adjacency.

use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Clone, Copy)]
pub struct TopologyEdge {
    pub from_bay: u32,
    pub to_bay: u32,
    pub edge_type: u8,
}

#[derive(Debug, Default)]
pub struct SubstationTopologyGraph {
    pub edges: Vec<TopologyEdge>,
    pub graph_digest: u32,
}

impl SubstationTopologyGraph {
    pub fn add_edge(&mut self, from: u32, to: u32, edge_type: u8) {
        self.edges.push(TopologyEdge {
            from_bay: from,
            to_bay: to,
            edge_type,
        });
        self.graph_digest = fnv1a32(self.graph_digest, &from.to_le_bytes());
        self.graph_digest = fnv1a32(self.graph_digest, &to.to_le_bytes());
    }

    pub fn bay_degree(&self, bay_id: u32) -> u32 {
        self.edges
            .iter()
            .filter(|e| e.from_bay == bay_id || e.to_bay == bay_id)
            .count() as u32
    }

    pub fn route_hop_count(&self, start: u32, end: u32) -> u32 {
        if start == end {
            return 0;
        }
        for e in &self.edges {
            if e.from_bay == start && e.to_bay == end {
                return 1;
            }
        }
        0xFFFF
    }
}
