use crate::util::safe_read::{read_u16_le, read_u32_le, MAX_FRAME};
use crate::protocol::frame_magics::{JOURNAL_ALERT_MAGIC, JOURNAL_ALERT_VERSION};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct JournalAlertEntry {
    pub alert_id: u32,
    pub substation_id: u32,
    pub severity: u8,
    pub alert_class: u8,
    pub pickup_secs: u16,
    pub note_len: u16,
}

#[derive(Debug, Default)]
pub struct JournalAlertFeed {
    pub version: u16,
    pub desk_ref: u32,
    pub alert_count: u32,
    pub epoch_secs: u32,
    pub entries: Vec<JournalAlertEntry>,
    pub note_blob: Vec<u8>,
}

impl JournalAlertFeed {
    pub fn alert_note(&self, idx: usize) -> Option<&[u8]> {
        let e = self.entries.get(idx)?;
        let start = self.entries[..idx]
            .iter()
            .map(|x| x.note_len as usize)
            .sum::<usize>();
        let end = start.checked_add(e.note_len as usize)?;
        self.note_blob.get(start..end)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JournalAlertDecodeError {
    Truncated,
    BadMagic,
    BadVersion,
    FrameTooLarge,
}

pub fn parse_journal_alert_feed(input: &[u8]) -> Result<JournalAlertFeed, JournalAlertDecodeError> {
    if input.len() < 20 {
        return Err(JournalAlertDecodeError::Truncated);
    }
    if &input[..4] != JOURNAL_ALERT_MAGIC {
        return Err(JournalAlertDecodeError::BadMagic);
    }
    if input.len() > MAX_FRAME {
        return Err(JournalAlertDecodeError::FrameTooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(JournalAlertDecodeError::Truncated)?;
    if version != JOURNAL_ALERT_VERSION {
        return Err(JournalAlertDecodeError::BadVersion);
    }
    let desk_ref = read_u32_le(input, 6).ok_or(JournalAlertDecodeError::Truncated)?;
    let alert_count = read_u32_le(input, 10).ok_or(JournalAlertDecodeError::Truncated)?;
    let epoch_secs = read_u32_le(input, 14).ok_or(JournalAlertDecodeError::Truncated)?;

    let mut off = 18usize;
    let mut entries = Vec::with_capacity(alert_count as usize);
    let mut note_blob = Vec::new();
    for _ in 0..alert_count {
        if off + 16 > input.len() {
            return Err(JournalAlertDecodeError::Truncated);
        }
        let alert_id = read_u32_le(input, off).ok_or(JournalAlertDecodeError::Truncated)?;
        off += 4;
        let substation_id = read_u32_le(input, off).ok_or(JournalAlertDecodeError::Truncated)?;
        off += 4;
        let severity = input.get(off).copied().unwrap_or(0);
        off += 1;
        let alert_class = input.get(off).copied().unwrap_or(0);
        off += 1;
        let pickup_secs = read_u16_le(input, off).ok_or(JournalAlertDecodeError::Truncated)?;
        off += 2;
        let note_len = read_u16_le(input, off).ok_or(JournalAlertDecodeError::Truncated)?;
        off += 2;
        if off + note_len as usize > input.len() {
            return Err(JournalAlertDecodeError::Truncated);
        }
        note_blob.extend_from_slice(&input[off..off + note_len as usize]);
        off += note_len as usize;
        entries.push(JournalAlertEntry {
            alert_id,
            substation_id,
            severity,
            alert_class,
            pickup_secs,
            note_len,
        });
    }
    Ok(JournalAlertFeed {
        version,
        desk_ref,
        alert_count,
        epoch_secs,
        entries,
        note_blob,
    })
}

pub fn encode_journal_alert_feed(feed: &JournalAlertFeed) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(JOURNAL_ALERT_MAGIC);
    out.extend_from_slice(&feed.version.to_le_bytes());
    out.extend_from_slice(&feed.desk_ref.to_le_bytes());
    out.extend_from_slice(&feed.alert_count.to_le_bytes());
    out.extend_from_slice(&feed.epoch_secs.to_le_bytes());
    let mut note_off = 0usize;
    for entry in &feed.entries {
        out.extend_from_slice(&entry.alert_id.to_le_bytes());
        out.extend_from_slice(&entry.substation_id.to_le_bytes());
        out.push(entry.severity);
        out.push(entry.alert_class);
        out.extend_from_slice(&entry.pickup_secs.to_le_bytes());
        out.extend_from_slice(&entry.note_len.to_le_bytes());
        let end = note_off + entry.note_len as usize;
        out.extend_from_slice(&feed.note_blob[note_off..end]);
        note_off = end;
    }
    out
}
