//! Wire frame magic constants for SCADA event multiplexing.

pub const FAULT_SPOOL_MAGIC: &[u8; 4] = b"ESBF";
pub const FAULT_SPOOL_VERSION: u16 = 1;

pub const BAY_ROUTE_MAGIC: &[u8; 4] = b"ESRT";
pub const BAY_ROUTE_VERSION: u16 = 1;

pub const FEEDER_CHECKPOINT_MAGIC: &[u8; 4] = b"ESCK";
pub const FEEDER_CHECKPOINT_VERSION: u16 = 1;

pub const GOOSE_EVENT_MAGIC: &[u8; 4] = b"ESGO";
pub const GOOSE_EVENT_VERSION: u16 = 1;

pub const JOURNAL_ALERT_MAGIC: &[u8; 4] = b"ESJR";
pub const JOURNAL_ALERT_VERSION: u16 = 1;
