use crate::util::safe_read::{read_i32_le, read_u16_le, read_u32_le, MAX_FEEDER_LEGS, MAX_FRAME};
use crate::protocol::frame_magics::{FEEDER_CHECKPOINT_MAGIC, FEEDER_CHECKPOINT_VERSION};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FeederLegEntry {
    pub leg_id: u32,
    pub feeder_id: u32,
    pub voltage_kv: u16,
    pub current_amps: u16,
    pub lat_micro: i32,
    pub lon_micro: i32,
    pub annex_len: u32,
}

#[derive(Debug, Clone)]
pub struct FeederLeg {
    pub entry: FeederLegEntry,
    pub annex: Vec<u8>,
}

#[derive(Debug, Default)]
pub struct FeederCheckpointBundle {
    pub version: u16,
    pub substation_id: u32,
    pub leg_count: u32,
    pub merge_flags: u32,
    pub legs: Vec<FeederLeg>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FeederCheckpointDecodeError {
    Truncated,
    BadMagic,
    BadVersion,
    FrameTooLarge,
    TooManyLegs,
}

pub fn decode_feeder_checkpoint(input: &[u8]) -> Result<FeederCheckpointBundle, FeederCheckpointDecodeError> {
    if input.len() < 20 {
        return Err(FeederCheckpointDecodeError::Truncated);
    }
    if &input[..4] != FEEDER_CHECKPOINT_MAGIC {
        return Err(FeederCheckpointDecodeError::BadMagic);
    }
    if input.len() > MAX_FRAME {
        return Err(FeederCheckpointDecodeError::FrameTooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(FeederCheckpointDecodeError::Truncated)?;
    if version != FEEDER_CHECKPOINT_VERSION {
        return Err(FeederCheckpointDecodeError::BadVersion);
    }
    let substation_id = read_u32_le(input, 6).ok_or(FeederCheckpointDecodeError::Truncated)?;
    let leg_count = read_u32_le(input, 10).ok_or(FeederCheckpointDecodeError::Truncated)?;
    if leg_count as usize > MAX_FEEDER_LEGS {
        return Err(FeederCheckpointDecodeError::TooManyLegs);
    }
    let merge_flags = read_u32_le(input, 14).ok_or(FeederCheckpointDecodeError::Truncated)?;

    let mut off = 18usize;
    let mut bundle = FeederCheckpointBundle {
        version,
        substation_id,
        leg_count,
        merge_flags,
        ..Default::default()
    };
    for _ in 0..leg_count {
        if off + 28 > input.len() {
            return Err(FeederCheckpointDecodeError::Truncated);
        }
        let leg_id = read_u32_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 4;
        let feeder_id = read_u32_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 4;
        let voltage_kv = read_u16_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 2;
        let current_amps = read_u16_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 2;
        let lat_micro = read_i32_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 4;
        let lon_micro = read_i32_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 4;
        let annex_len = read_u32_le(input, off).ok_or(FeederCheckpointDecodeError::Truncated)?;
        off += 4;
        if off + annex_len as usize > input.len() {
            return Err(FeederCheckpointDecodeError::Truncated);
        }
        let annex = input[off..off + annex_len as usize].to_vec();
        off += annex_len as usize;
        bundle.legs.push(FeederLeg {
            entry: FeederLegEntry {
                leg_id,
                feeder_id,
                voltage_kv,
                current_amps,
                lat_micro,
                lon_micro,
                annex_len,
            },
            annex,
        });
    }
    Ok(bundle)
}

pub fn rebind_feeder_annexes(bundle: &mut FeederCheckpointBundle) {
    for leg in &mut bundle.legs {
        leg.entry.annex_len = leg.annex.len() as u32;
    }
}

pub fn encode_feeder_checkpoint(bundle: &FeederCheckpointBundle) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(FEEDER_CHECKPOINT_MAGIC);
    out.extend_from_slice(&bundle.version.to_le_bytes());
    out.extend_from_slice(&bundle.substation_id.to_le_bytes());
    out.extend_from_slice(&bundle.leg_count.to_le_bytes());
    out.extend_from_slice(&bundle.merge_flags.to_le_bytes());
    for leg in &bundle.legs {
        out.extend_from_slice(&leg.entry.leg_id.to_le_bytes());
        out.extend_from_slice(&leg.entry.feeder_id.to_le_bytes());
        out.extend_from_slice(&leg.entry.voltage_kv.to_le_bytes());
        out.extend_from_slice(&leg.entry.current_amps.to_le_bytes());
        out.extend_from_slice(&leg.entry.lat_micro.to_le_bytes());
        out.extend_from_slice(&leg.entry.lon_micro.to_le_bytes());
        out.extend_from_slice(&leg.entry.annex_len.to_le_bytes());
        out.extend_from_slice(&leg.annex);
    }
    out
}
