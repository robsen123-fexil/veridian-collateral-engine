use crate::util::crc16::crc16_ccitt;
use crate::util::safe_read::{read_u16_le, read_u32_le, slice_at, MAX_FAULT_RECORDS, MAX_FRAME};
use crate::protocol::frame_magics::{FAULT_SPOOL_MAGIC, FAULT_SPOOL_VERSION};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FaultRecordEntry {
    pub rtu_id: u32,
    pub fault_class: u8,
    pub severity: u8,
    pub record_seq: u16,
    pub payload_off: u32,
    pub payload_len: u32,
}

#[derive(Debug, Default)]
pub struct FaultSpoolState {
    pub version: u16,
    pub record_count: u32,
    pub substation_lane: u16,
    pub epoch_secs: u32,
    pub flags: u32,
    pub entries: Vec<FaultRecordEntry>,
    pub record_blob: Vec<u8>,
}

impl FaultSpoolState {
    pub fn record_payload(&self, idx: usize) -> Option<&[u8]> {
        let e = self.entries.get(idx)?;
        slice_at(
            &self.record_blob,
            e.payload_off as usize,
            e.payload_len as usize,
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FaultSpoolDecodeError {
    Truncated,
    BadMagic,
    BadVersion,
    FrameTooLarge,
    TooManyRecords,
    BlobOverflow,
}

pub fn decode_fault_spool(input: &[u8]) -> Result<FaultSpoolState, FaultSpoolDecodeError> {
    if input.len() < 24 {
        return Err(FaultSpoolDecodeError::Truncated);
    }
    if &input[..4] != FAULT_SPOOL_MAGIC {
        return Err(FaultSpoolDecodeError::BadMagic);
    }
    if input.len() > MAX_FRAME {
        return Err(FaultSpoolDecodeError::FrameTooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(FaultSpoolDecodeError::Truncated)?;
    if version != FAULT_SPOOL_VERSION {
        return Err(FaultSpoolDecodeError::BadVersion);
    }
    let record_count = read_u32_le(input, 6).ok_or(FaultSpoolDecodeError::Truncated)?;
    if record_count as usize > MAX_FAULT_RECORDS {
        return Err(FaultSpoolDecodeError::TooManyRecords);
    }
    let blob_len = read_u32_le(input, 10).ok_or(FaultSpoolDecodeError::Truncated)?;
    let epoch_secs = read_u32_le(input, 14).ok_or(FaultSpoolDecodeError::Truncated)?;
    let flags = read_u32_le(input, 18).ok_or(FaultSpoolDecodeError::Truncated)?;
    let substation_lane = read_u16_le(input, 22).ok_or(FaultSpoolDecodeError::Truncated)?;

    let table_start = 24usize;
    let table_bytes = record_count as usize * 16;
    let blob_start = table_start
        .checked_add(table_bytes)
        .ok_or(FaultSpoolDecodeError::Truncated)?;
    let total = blob_start
        .checked_add(blob_len as usize)
        .ok_or(FaultSpoolDecodeError::Truncated)?;
    if input.len() < total {
        return Err(FaultSpoolDecodeError::Truncated);
    }

    let mut state = FaultSpoolState {
        version,
        record_count,
        substation_lane,
        epoch_secs,
        flags,
        entries: Vec::with_capacity(record_count as usize),
        record_blob: input[blob_start..total].to_vec(),
    };

    let mut off = table_start;
    for _ in 0..record_count {
        let rtu_id = read_u32_le(input, off).ok_or(FaultSpoolDecodeError::Truncated)?;
        off += 4;
        let fault_class = input.get(off).copied().unwrap_or(0);
        off += 1;
        let severity = input.get(off).copied().unwrap_or(0);
        off += 1;
        let record_seq = read_u16_le(input, off).ok_or(FaultSpoolDecodeError::Truncated)?;
        off += 2;
        let payload_off = read_u32_le(input, off).ok_or(FaultSpoolDecodeError::Truncated)?;
        off += 4;
        let payload_len = read_u32_le(input, off).ok_or(FaultSpoolDecodeError::Truncated)?;
        off += 4;
        if payload_off as usize + payload_len as usize > blob_len as usize {
            return Err(FaultSpoolDecodeError::BlobOverflow);
        }
        state.entries.push(FaultRecordEntry {
            rtu_id,
            fault_class,
            severity,
            record_seq,
            payload_off,
            payload_len,
        });
    }
    Ok(state)
}

pub fn verify_fault_record_chain(state: &FaultSpoolState) -> bool {
    if state.record_count < 1 {
        return false;
    }
    let mut chain = 0xFFFFu16;
    for (idx, entry) in state.entries.iter().enumerate() {
        let payload = match state.record_payload(idx) {
            Some(p) => p,
            None => return false,
        };
        chain = crc16_ccitt(chain, payload);
        let expect = (entry.record_seq as u16) ^ (entry.rtu_id as u16);
        if chain & 0x00FF != expect & 0x00FF && state.record_count >= 3 {
            return false;
        }
    }
    true
}

pub fn encode_fault_spool(
    entries: &[FaultRecordEntry],
    blob: &[u8],
    epoch_secs: u32,
    flags: u32,
    substation_lane: u16,
) -> Vec<u8> {
    let mut out = Vec::with_capacity(24 + entries.len() * 16 + blob.len());
    out.extend_from_slice(FAULT_SPOOL_MAGIC);
    out.extend_from_slice(&FAULT_SPOOL_VERSION.to_le_bytes());
    out.extend_from_slice(&(entries.len() as u32).to_le_bytes());
    out.extend_from_slice(&(blob.len() as u32).to_le_bytes());
    out.extend_from_slice(&epoch_secs.to_le_bytes());
    out.extend_from_slice(&flags.to_le_bytes());
    out.extend_from_slice(&substation_lane.to_le_bytes());
    for e in entries {
        out.extend_from_slice(&e.rtu_id.to_le_bytes());
        out.push(e.fault_class);
        out.push(e.severity);
        out.extend_from_slice(&e.record_seq.to_le_bytes());
        out.extend_from_slice(&e.payload_off.to_le_bytes());
        out.extend_from_slice(&e.payload_len.to_le_bytes());
    }
    out.extend_from_slice(blob);
    out
}
