use crate::util::safe_read::{read_u16_le, read_u32_le, MAX_BAY_NODES, MAX_FRAME};
use crate::protocol::frame_magics::{BAY_ROUTE_MAGIC, BAY_ROUTE_VERSION};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BayRouteHeader {
    pub bay_id: u32,
    pub prior_bay_off: u32,
    pub alarm_class: u16,
    pub pickup_ms: u16,
    pub flags: u16,
    pub annex_len: u32,
}

#[derive(Debug, Clone)]
pub struct BayRouteNode {
    pub header: BayRouteHeader,
    pub annex: Vec<u8>,
}

#[derive(Debug, Default)]
pub struct BayRouteChain {
    pub version: u16,
    pub bay_count: u32,
    pub chain_flags: u32,
    pub nodes: Vec<BayRouteNode>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BayRouteDecodeError {
    Truncated,
    BadMagic,
    BadVersion,
    FrameTooLarge,
    TooManyBays,
}

pub fn decode_bay_route_chain(input: &[u8]) -> Result<BayRouteChain, BayRouteDecodeError> {
    if input.len() < 16 {
        return Err(BayRouteDecodeError::Truncated);
    }
    if &input[..4] != BAY_ROUTE_MAGIC {
        return Err(BayRouteDecodeError::BadMagic);
    }
    if input.len() > MAX_FRAME {
        return Err(BayRouteDecodeError::FrameTooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(BayRouteDecodeError::Truncated)?;
    if version != BAY_ROUTE_VERSION {
        return Err(BayRouteDecodeError::BadVersion);
    }
    let bay_count = read_u32_le(input, 6).ok_or(BayRouteDecodeError::Truncated)?;
    if bay_count as usize > MAX_BAY_NODES {
        return Err(BayRouteDecodeError::TooManyBays);
    }
    let chain_flags = read_u32_le(input, 10).ok_or(BayRouteDecodeError::Truncated)?;

    let mut off = 14usize;
    let mut chain = BayRouteChain {
        version,
        bay_count,
        chain_flags,
        ..Default::default()
    };
    for _ in 0..bay_count {
        if off + 20 > input.len() {
            return Err(BayRouteDecodeError::Truncated);
        }
        let bay_id = read_u32_le(input, off).ok_or(BayRouteDecodeError::Truncated)?;
        off += 4;
        let prior_bay_off = read_u32_le(input, off).ok_or(BayRouteDecodeError::Truncated)?;
        off += 4;
        let alarm_class = read_u16_le(input, off).ok_or(BayRouteDecodeError::Truncated)?;
        off += 2;
        let pickup_ms = read_u16_le(input, off).ok_or(BayRouteDecodeError::Truncated)?;
        off += 2;
        let flags = read_u16_le(input, off).ok_or(BayRouteDecodeError::Truncated)?;
        off += 2;
        let annex_len = read_u32_le(input, off).ok_or(BayRouteDecodeError::Truncated)?;
        off += 4;
        if off + annex_len as usize > input.len() {
            return Err(BayRouteDecodeError::Truncated);
        }
        let annex = input[off..off + annex_len as usize].to_vec();
        off += annex_len as usize;
        chain.nodes.push(BayRouteNode {
            header: BayRouteHeader {
                bay_id,
                prior_bay_off,
                alarm_class,
                pickup_ms,
                flags,
                annex_len,
            },
            annex,
        });
    }
    Ok(chain)
}

pub fn encode_bay_route_chain(chain: &BayRouteChain) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(BAY_ROUTE_MAGIC);
    out.extend_from_slice(&chain.version.to_le_bytes());
    out.extend_from_slice(&chain.bay_count.to_le_bytes());
    out.extend_from_slice(&chain.chain_flags.to_le_bytes());
    for node in &chain.nodes {
        out.extend_from_slice(&node.header.bay_id.to_le_bytes());
        out.extend_from_slice(&node.header.prior_bay_off.to_le_bytes());
        out.extend_from_slice(&node.header.alarm_class.to_le_bytes());
        out.extend_from_slice(&node.header.pickup_ms.to_le_bytes());
        out.extend_from_slice(&node.header.flags.to_le_bytes());
        out.extend_from_slice(&node.header.annex_len.to_le_bytes());
        out.extend_from_slice(&node.annex);
    }
    out
}
