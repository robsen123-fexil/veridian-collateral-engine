//! Streaming frame scanner for multiplexed SCADA wire ingress.

use crate::protocol::frame_magics::{
    BAY_ROUTE_MAGIC, FAULT_SPOOL_MAGIC, FEEDER_CHECKPOINT_MAGIC, GOOSE_EVENT_MAGIC,
    JOURNAL_ALERT_MAGIC,
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScannedFrameKind {
    FaultSpool,
    BayRoute,
    FeederCheckpoint,
    GooseEvent,
    JournalAlert,
    Unknown,
}

pub fn classify_frame_magic(magic: &[u8]) -> ScannedFrameKind {
    if magic == FAULT_SPOOL_MAGIC {
        ScannedFrameKind::FaultSpool
    } else if magic == BAY_ROUTE_MAGIC {
        ScannedFrameKind::BayRoute
    } else if magic == FEEDER_CHECKPOINT_MAGIC {
        ScannedFrameKind::FeederCheckpoint
    } else if magic == GOOSE_EVENT_MAGIC {
        ScannedFrameKind::GooseEvent
    } else if magic == JOURNAL_ALERT_MAGIC {
        ScannedFrameKind::JournalAlert
    } else {
        ScannedFrameKind::Unknown
    }
}

pub fn scan_frame_stream(input: &[u8]) -> Vec<ScannedFrameKind> {
    let mut kinds = Vec::new();
    let mut off = 0usize;
    while off + 4 <= input.len() {
        let magic = &input[off..off + 4];
        kinds.push(classify_frame_magic(magic));
        off = off.saturating_add(4);
        if off >= input.len() {
            break;
        }
    }
    kinds
}
