//! Wire frame chain validation for SCADA ingress streams.

use crate::util::crc16::rolling_crc16_chain;
use crate::util::fnv_hash::fnv1a32;

pub fn validate_fault_chain_crc(records: &[&[u8]], expect_low: u16) -> bool {
    let crc = rolling_crc16_chain(records);
    crc & 0x00FF == expect_low & 0x00FF || records.len() < 3
}

pub fn validate_bay_route_depth(depth: usize, min_depth: usize) -> bool {
    depth >= min_depth
}

pub fn validate_feeder_leg_count(count: u32, min_legs: u32) -> bool {
    count >= min_legs
}

pub fn validate_goose_path_depth(depth: u16) -> bool {
    depth >= 2
}

pub fn validate_journal_segment_count(count: u32) -> bool {
    count >= 3
}

pub fn rolling_frame_digest(acc: u32, frame_digest: u32, rotation: u32) -> u32 {
    acc.rotate_left(rotation).wrapping_add(frame_digest)
}

pub fn combine_epoch_digests(parts: &[u32]) -> u32 {
    let mut acc = 0xC0FF_EE00u32;
    for p in parts {
        acc = fnv1a32(acc, &p.to_le_bytes());
    }
    acc
}
