//! SCL-ish substation configuration scanner for IED topology hints.

use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SclIedEntry {
    pub name: String,
    pub substation: String,
    pub voltage_level: String,
    pub bay: String,
}

#[derive(Debug, Default)]
pub struct SclConfigScan {
    pub ieds: Vec<SclIedEntry>,
    pub scan_digest: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SclScanError {
    Empty,
    Malformed,
}

pub fn scan_scl_config(input: &[u8]) -> Result<SclConfigScan, SclScanError> {
    if input.is_empty() {
        return Err(SclScanError::Empty);
    }
    let text = std::str::from_utf8(input).map_err(|_| SclScanError::Malformed)?;
    let mut scan = SclConfigScan::default();
    let mut current_name = String::new();
    let mut current_sub = String::new();
    let mut current_vl = String::new();
    let mut current_bay = String::new();

    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with("<IED") {
            if let Some(name) = extract_attr(trimmed, "name") {
                current_name = name;
            }
        } else if trimmed.starts_with("<Substation") {
            if let Some(name) = extract_attr(trimmed, "name") {
                current_sub = name;
            }
        } else if trimmed.starts_with("<VoltageLevel") {
            if let Some(name) = extract_attr(trimmed, "name") {
                current_vl = name;
            }
        } else if trimmed.starts_with("<Bay") {
            if let Some(name) = extract_attr(trimmed, "name") {
                current_bay = name;
            }
        } else if trimmed.starts_with("</IED>") && !current_name.is_empty() {
            scan.ieds.push(SclIedEntry {
                name: current_name.clone(),
                substation: current_sub.clone(),
                voltage_level: current_vl.clone(),
                bay: current_bay.clone(),
            });
            scan.scan_digest = fnv1a32(scan.scan_digest, current_name.as_bytes());
            current_name.clear();
        }
    }
    Ok(scan)
}

fn extract_attr(line: &str, key: &str) -> Option<String> {
    let pattern = format!("{key}=\"");
    let start = line.find(&pattern)? + pattern.len();
    let rest = &line[start..];
    let end = rest.find('"')?;
    Some(rest[..end].to_string())
}

pub fn topology_digest(scan: &SclConfigScan) -> u32 {
    let mut acc = scan.scan_digest;
    for ied in &scan.ieds {
        acc = fnv1a32(acc, ied.substation.as_bytes());
        acc = acc.wrapping_add(ied.voltage_level.len() as u32);
    }
    acc
}
