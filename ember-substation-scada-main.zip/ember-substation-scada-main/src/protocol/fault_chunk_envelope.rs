use crate::util::safe_read::{read_u16_le, slice_at};

#[derive(Debug, Clone)]
pub struct FaultChunkBatch {
    pub chunks: Vec<Vec<u8>>,
    pub batch_roll: u32,
}

pub fn chunk_additive_checksum(data: &[u8]) -> u16 {
    data.iter().map(|&b| u16::from(b)).sum::<u16>() & 0xFFFF
}

pub fn split_lifecycle_envelope(frame: &[u8]) -> Option<(FaultChunkBatch, &[u8])> {
    if frame.len() < 6 {
        return None;
    }
    let env_len = read_u16_le(frame, 0)? as usize;
    if env_len < 2 || 2 + env_len > frame.len() {
        return None;
    }
    let env = &frame[2..2 + env_len];
    let esbf_frame = &frame[2 + env_len..];
    let batch = decode_chunk_envelope(env)?;
    Some((batch, esbf_frame))
}

fn decode_chunk_envelope(env: &[u8]) -> Option<FaultChunkBatch> {
    if env.len() < 2 {
        return None;
    }
    let chunk_count = read_u16_le(env, 0)? as usize;
    let mut off = 2usize;
    let mut chunks = Vec::with_capacity(chunk_count);
    let mut batch_roll = 0x5A17_3C91u32;
    for _ in 0..chunk_count {
        if off + 4 > env.len() {
            return None;
        }
        let len = read_u16_le(env, off)? as usize;
        let csum = read_u16_le(env, off + 2)?;
        off += 4;
        let chunk = slice_at(env, off, len)?;
        if chunk_additive_checksum(chunk) != csum {
            return None;
        }
        off += len;
        chunks.push(chunk.to_vec());
        batch_roll = crate::util::fnv_hash::fnv1a32(batch_roll, chunk);
    }
    Some(FaultChunkBatch { chunks, batch_roll })
}

pub fn encode_chunk_envelope(chunks: &[&[u8]]) -> Vec<u8> {
    let mut body = Vec::new();
    body.extend_from_slice(&(chunks.len() as u16).to_le_bytes());
    for chunk in chunks {
        body.extend_from_slice(&(chunk.len() as u16).to_le_bytes());
        let csum = chunk_additive_checksum(chunk);
        body.extend_from_slice(&csum.to_le_bytes());
        body.extend_from_slice(chunk);
    }
    let mut out = Vec::with_capacity(2 + body.len());
    out.extend_from_slice(&(body.len() as u16).to_le_bytes());
    out.extend_from_slice(&body);
    out
}
