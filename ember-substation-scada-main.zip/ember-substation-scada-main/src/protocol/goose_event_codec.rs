use crate::util::fnv_hash::fnv1a32;
use crate::util::safe_read::{read_u16_le, read_u32_le, MAX_FRAME, MAX_GOOSE_NODES};
use crate::protocol::frame_magics::{GOOSE_EVENT_MAGIC, GOOSE_EVENT_VERSION};

#[derive(Debug, Clone)]
pub struct GooseEventNode {
    pub dataset_id: u32,
    pub tag_path: Vec<u16>,
    pub payload: Vec<u8>,
    pub path_crc: u16,
}

#[derive(Debug, Default)]
pub struct GooseEventTree {
    pub version: u16,
    pub substation_ref: u32,
    pub node_count: u32,
    pub tree_flags: u32,
    pub nodes: Vec<GooseEventNode>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GooseEventDecodeError {
    Truncated,
    BadMagic,
    BadVersion,
    FrameTooLarge,
    TooManyNodes,
    PathCrcMismatch,
}

pub fn decode_goose_event_tree(input: &[u8]) -> Result<GooseEventTree, GooseEventDecodeError> {
    if input.len() < 18 {
        return Err(GooseEventDecodeError::Truncated);
    }
    if &input[..4] != GOOSE_EVENT_MAGIC {
        return Err(GooseEventDecodeError::BadMagic);
    }
    if input.len() > MAX_FRAME {
        return Err(GooseEventDecodeError::FrameTooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(GooseEventDecodeError::Truncated)?;
    if version != GOOSE_EVENT_VERSION {
        return Err(GooseEventDecodeError::BadVersion);
    }
    let substation_ref = read_u32_le(input, 6).ok_or(GooseEventDecodeError::Truncated)?;
    let node_count = read_u32_le(input, 10).ok_or(GooseEventDecodeError::Truncated)?;
    if node_count as usize > MAX_GOOSE_NODES {
        return Err(GooseEventDecodeError::TooManyNodes);
    }
    let tree_flags = read_u32_le(input, 14).ok_or(GooseEventDecodeError::Truncated)?;

    let mut off = 18usize;
    let mut tree = GooseEventTree {
        version,
        substation_ref,
        node_count,
        tree_flags,
        ..Default::default()
    };
    for _ in 0..node_count {
        if off + 10 > input.len() {
            return Err(GooseEventDecodeError::Truncated);
        }
        let dataset_id = read_u32_le(input, off).ok_or(GooseEventDecodeError::Truncated)?;
        off += 4;
        let path_depth = read_u16_le(input, off).ok_or(GooseEventDecodeError::Truncated)?;
        off += 2;
        let path_crc = read_u16_le(input, off).ok_or(GooseEventDecodeError::Truncated)?;
        off += 2;
        let payload_len = read_u32_le(input, off).ok_or(GooseEventDecodeError::Truncated)?;
        off += 4;
        if off + path_depth as usize * 2 + payload_len as usize > input.len() {
            return Err(GooseEventDecodeError::Truncated);
        }
        let mut tag_path = Vec::with_capacity(path_depth as usize);
        for _ in 0..path_depth {
            let tag = read_u16_le(input, off).ok_or(GooseEventDecodeError::Truncated)?;
            off += 2;
            tag_path.push(tag);
        }
        let payload = input[off..off + payload_len as usize].to_vec();
        off += payload_len as usize;
        let computed = compute_path_crc(&tag_path, &payload);
        if path_depth >= 2 && computed != path_crc {
            return Err(GooseEventDecodeError::PathCrcMismatch);
        }
        tree.nodes.push(GooseEventNode {
            dataset_id,
            tag_path,
            payload,
            path_crc,
        });
    }
    Ok(tree)
}

pub fn compute_path_crc(tag_path: &[u16], payload: &[u8]) -> u16 {
    let mut acc = 0xBEEFu16;
    for tag in tag_path {
        acc = acc.wrapping_add(*tag);
    }
    let digest = fnv1a32(u32::from(acc), payload);
    (digest & 0xFFFF) as u16
}

pub fn encode_goose_event_tree(tree: &GooseEventTree) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(GOOSE_EVENT_MAGIC);
    out.extend_from_slice(&tree.version.to_le_bytes());
    out.extend_from_slice(&tree.substation_ref.to_le_bytes());
    out.extend_from_slice(&tree.node_count.to_le_bytes());
    out.extend_from_slice(&tree.tree_flags.to_le_bytes());
    for node in &tree.nodes {
        out.extend_from_slice(&node.dataset_id.to_le_bytes());
        out.extend_from_slice(&(node.tag_path.len() as u16).to_le_bytes());
        out.extend_from_slice(&node.path_crc.to_le_bytes());
        out.extend_from_slice(&(node.payload.len() as u32).to_le_bytes());
        for tag in &node.tag_path {
            out.extend_from_slice(&tag.to_le_bytes());
        }
        out.extend_from_slice(&node.payload);
    }
    out
}

pub fn walk_nested_goose_paths(tree: &GooseEventTree) -> u32 {
    let mut score = 0u32;
    for node in &tree.nodes {
        if node.tag_path.len() >= 2 {
            score = score.saturating_add(100);
            score = fnv1a32(score, &node.payload);
        }
    }
    score
}
