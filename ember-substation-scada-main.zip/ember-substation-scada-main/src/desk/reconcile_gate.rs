//! Desk operator reconcile gate and shift handoff coordination.

use crate::desk::nerc_audit_trail::NercAuditTrail;
use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Default)]
pub struct DeskReconcileGate {
    pub shift_id: u32,
    pub open_alarms: u32,
    pub pending_handoffs: u32,
    pub gate_digest: u32,
}

impl DeskReconcileGate {
    pub fn new(shift_id: u32) -> Self {
        Self {
            shift_id,
            ..Default::default()
        }
    }

    pub fn register_alarm(&mut self, alert_ref: u32, severity: u8) {
        self.open_alarms = self.open_alarms.saturating_add(1);
        self.gate_digest = fnv1a32(self.gate_digest, &alert_ref.to_le_bytes());
        if severity >= 3 {
            self.pending_handoffs += 1;
        }
    }

    pub fn reconcile_shift(&self, trail: &NercAuditTrail) -> u32 {
        let score = trail.compliance_score();
        self.gate_digest
            .wrapping_add(score)
            .wrapping_add(self.shift_id)
            .wrapping_add(self.open_alarms)
    }

    pub fn feeder_reconcile_ready(&self) -> bool {
        self.pending_handoffs == 0 || self.open_alarms < 5
    }
}
