//! Desk epoch rotation policy for multi-shift SCADA reconcile windows.

use crate::util::fnv_hash::fnv1a32;

pub const ROTATION_FRAMES: u32 = 64;

#[derive(Debug, Default)]
pub struct DeskEpochPolicy {
    pub current_epoch: u32,
    pub frames_in_epoch: u32,
    pub rotation_digest: u32,
}

impl DeskEpochPolicy {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn record_frame(&mut self, frame_digest: u32) -> u32 {
        self.frames_in_epoch += 1;
        self.rotation_digest = fnv1a32(self.rotation_digest, &frame_digest.to_le_bytes());
        if self.frames_in_epoch % ROTATION_FRAMES == 0 {
            self.current_epoch = self.current_epoch.wrapping_add(1);
        }
        self.current_epoch
    }

    pub fn should_rotate(&self) -> bool {
        self.frames_in_epoch > 0 && self.frames_in_epoch % ROTATION_FRAMES == 0
    }

    pub fn epoch_fingerprint(&self) -> u32 {
        self.rotation_digest ^ self.current_epoch ^ self.frames_in_epoch
    }
}
