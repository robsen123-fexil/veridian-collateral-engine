//! Emergency Response operator desk handoff and alert digest routing.

use crate::util::fnv_hash::fnv1a32;

pub const SHIFT_START_H: u8 = 0;
pub const SHIFT_END_H: u8 = 24;
pub const SHIFT_NAME: &str = "Emergency Response";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EmergencyHandoffNote {
    pub operator_id: u32,
    pub alert_ref: u32,
    pub severity: u8,
}

#[derive(Debug, Default)]
pub struct EmergencyDeskLedger {
    pub handoffs: Vec<EmergencyHandoffNote>,
    pub shift_digest: u32,
    pub open_alerts: u32,
}

impl EmergencyDeskLedger {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn record_handoff(&mut self, operator_id: u32, alert_ref: u32, severity: u8) {
        self.handoffs.push(EmergencyHandoffNote {
            operator_id,
            alert_ref,
            severity,
        });
        if severity >= 3 {
            self.open_alerts += 1;
        }
        self.shift_digest = fnv1a32(self.shift_digest, &operator_id.to_le_bytes());
        self.shift_digest = self.shift_digest.wrapping_add(alert_ref);
    }

    pub fn is_active_hour(&self, hour: u8) -> bool {
        if SHIFT_START_H < SHIFT_END_H {
            hour >= SHIFT_START_H && hour < SHIFT_END_H
        } else {
            hour >= SHIFT_START_H || hour < SHIFT_END_H
        }
    }

    pub fn nerc_audit_score(&self) -> u32 {
        self.shift_digest
            .wrapping_add(self.open_alerts.saturating_mul(50))
            .wrapping_add(u32::from(SHIFT_START_H))
    }
}
