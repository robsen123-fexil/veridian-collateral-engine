//! NERC CIP audit trail and compliance scoring modules.

use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct NercAuditEvent {
    pub event_id: u32,
    pub substation_id: u32,
    pub category: u8,
    pub epoch_secs: u32,
}

#[derive(Debug, Default)]
pub struct NercAuditTrail {
    pub events: Vec<NercAuditEvent>,
    pub trail_digest: u32,
    pub violation_count: u32,
}

impl NercAuditTrail {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn record_event(&mut self, event: NercAuditEvent) {
        if event.category >= 0x80 {
            self.violation_count += 1;
        }
        self.trail_digest = fnv1a32(self.trail_digest, &event.event_id.to_le_bytes());
        self.trail_digest = self.trail_digest.wrapping_add(event.epoch_secs);
        self.events.push(event);
    }

    pub fn compliance_score(&self) -> u32 {
        let base = 1000u32.saturating_sub(self.violation_count.saturating_mul(50));
        base ^ self.trail_digest
    }

    pub fn spool_epoch_ref(&self) -> u32 {
        self.events.len() as u32 ^ self.trail_digest
    }
}

pub fn classify_nerc_category(alarm_class: u8, severity: u8) -> u8 {
    let mut cat = alarm_class & 0x7F;
    if severity >= 4 {
        cat |= 0x80;
    }
    cat
}

pub fn merge_audit_digests(a: u32, b: u32) -> u32 {
    a.rotate_left(7).wrapping_add(b)
}
