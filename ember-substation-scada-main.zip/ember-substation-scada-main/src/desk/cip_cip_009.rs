//! Recovery Plans — NERC CIP compliance event classification.

use crate::desk::nerc_audit_trail::{NercAuditEvent, NercAuditTrail};
use crate::util::fnv_hash::fnv1a32;

pub const CIP_MASK: u32 = 0x0080;
pub const CIP_TITLE: &str = "Recovery Plans";

#[derive(Debug, Default)]
pub struct Cip009ComplianceBook {
    pub events_logged: u32,
    pub violations: u32,
    pub category_digest: u32,
}

impl Cip009ComplianceBook {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn log_to_trail(&mut self, trail: &mut NercAuditTrail, substation_id: u32, epoch: u32, severity: u8) {
        let category = (CIP_MASK as u8) | if severity >= 4 { 0x80 } else { 0 };
        trail.record_event(NercAuditEvent {
            event_id: self.events_logged.wrapping_add(1),
            substation_id,
            category,
            epoch_secs: epoch,
        });
        self.events_logged += 1;
        if category & 0x80 != 0 {
            self.violations += 1;
        }
        self.category_digest = fnv1a32(self.category_digest, &substation_id.to_le_bytes());
    }

    pub fn audit_readiness(&self) -> u32 {
        let penalty = self.violations.saturating_mul(25);
        CIP_MASK.wrapping_add(self.category_digest).saturating_sub(penalty)
    }

    pub fn spool_cross_ref(&self, spool_digest: u32) -> u32 {
        self.category_digest.rotate_left(5).wrapping_add(spool_digest)
    }
}
