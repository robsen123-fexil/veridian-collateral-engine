//! Electric utility SCADA event router — RTU fault spools, bay alarms, feeder checkpoints.

pub mod audit;
pub mod bay;
pub mod desk;
pub mod feeder;
pub mod protocol;
pub mod scada;
pub mod substation;
pub mod util;

pub use scada::bay_route_runner::route_bay_alarm_stream;
pub use scada::fault_spool_runner::run_fault_spool_pipeline;
pub use scada::feeder_checkpoint_runner::run_feeder_checkpoint_pipeline;
pub use scada::goose_event_runner::run_goose_event_pipeline;
pub use scada::journal_alert_runner::run_journal_alert_pipeline;
pub use scada::wire_dispatch::dispatch_scada_wire;
pub use protocol::scl_config_scanner::scan_scl_config;
