pub mod interlock_matrix;
pub mod protection_coordinator;
include!("alarms_mod.rs");
