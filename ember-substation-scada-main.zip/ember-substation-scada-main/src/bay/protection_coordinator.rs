//! Bay protection zone coordinator and alarm escalation router.

use crate::bay::alarm_overcurrent::OvercurrentAlarmBook;
use crate::util::fnv_hash::fnv1a32;

#[derive(Debug, Default)]
pub struct BayProtectionCoordinator {
    pub active_zones: u32,
    pub escalated_count: u32,
    pub coord_digest: u32,
}

impl BayProtectionCoordinator {
    pub fn route_zone_alarm(&mut self, bay_id: u32, zone: u8, severity: u8) -> u32 {
        self.active_zones = self.active_zones.saturating_add(1);
        if severity >= 4 {
            self.escalated_count += 1;
        }
        self.coord_digest = fnv1a32(self.coord_digest, &bay_id.to_le_bytes());
        self.coord_digest = self.coord_digest.wrapping_add(u32::from(zone));
        self.coord_digest ^ u32::from(severity)
    }

    pub fn merge_overcurrent_book(&self, book: &OvercurrentAlarmBook) -> u32 {
        self.coord_digest
            .wrapping_add(book.desk_escalation_score())
            .wrapping_add(self.escalated_count)
    }
}
