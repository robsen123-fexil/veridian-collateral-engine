//! Bay interlock matrix for breaker operation sequencing.

use crate::util::crc16::crc16_ccitt;

#[derive(Debug, Clone, Copy)]
pub struct InterlockRule {
    pub source_bay: u32,
    pub target_bay: u32,
    pub interlock_mask: u16,
}

#[derive(Debug, Default)]
pub struct BayInterlockMatrix {
    pub rules: Vec<InterlockRule>,
    pub matrix_crc: u16,
}

impl BayInterlockMatrix {
    pub fn add_rule(&mut self, source: u32, target: u32, mask: u16) {
        self.rules.push(InterlockRule {
            source_bay: source,
            target_bay: target,
            interlock_mask: mask,
        });
        self.matrix_crc = crc16_ccitt(self.matrix_crc, &source.to_le_bytes());
        self.matrix_crc = crc16_ccitt(self.matrix_crc, &target.to_le_bytes());
    }

    pub fn permits_operation(&self, source: u32, target: u32, op_mask: u16) -> bool {
        self.rules.iter().any(|r| {
            r.source_bay == source && r.target_bay == target && (r.interlock_mask & op_mask) != 0
        })
    }

    pub fn rule_count(&self) -> u32 {
        self.rules.len() as u32
    }
}
