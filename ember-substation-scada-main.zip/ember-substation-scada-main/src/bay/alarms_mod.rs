// domain modules — electric utility SCADA surface area
pub mod alarm_overcurrent;
pub mod alarm_undervoltage;
pub mod alarm_overvoltage;
pub mod alarm_frequency;
pub mod alarm_breaker_fail;
pub mod alarm_comm_loss;
pub mod alarm_soe;
pub mod alarm_goose_timeout;
pub mod alarm_sync_fail;
pub mod alarm_thermal;
pub mod alarm_ground_fault;
pub mod alarm_recloser;
