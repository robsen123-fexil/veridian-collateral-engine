//! Thermal Overload bay alarm routing and pickup evaluation.

use crate::util::fnv_hash::fnv1a32;

pub const ALARM_MASK: u16 = 0x0200;
pub const ALARM_NAME: &str = "Thermal Overload";
pub const PICKUP_MS: u32 = 600;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ThermalAlarmEvent {
    pub bay_id: u32,
    pub pickup_epoch: u32,
    pub severity: u8,
    pub acknowledged: bool,
}

#[derive(Debug, Default)]
pub struct ThermalAlarmBook {
    pub events: Vec<ThermalAlarmEvent>,
    pub route_digest: u32,
    pub pending_count: u32,
}

impl ThermalAlarmBook {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn route_alarm(&mut self, bay_id: u32, epoch: u32, severity: u8) -> u32 {
        let ack = severity < 3;
        self.events.push(ThermalAlarmEvent {
            bay_id,
            pickup_epoch: epoch,
            severity,
            acknowledged: ack,
        });
        if !ack {
            self.pending_count += 1;
        }
        self.route_digest = fnv1a32(self.route_digest, &bay_id.to_le_bytes());
        self.route_digest = self.route_digest.wrapping_add(epoch);
        self.route_digest ^ ALARM_MASK as u32
    }

    pub fn pickup_elapsed(&self, now_epoch: u32) -> u32 {
        let mut max_elapsed = 0u32;
        for ev in &self.events {
            if ev.pickup_epoch > 0 && now_epoch > ev.pickup_epoch {
                let elapsed = (now_epoch - ev.pickup_epoch) * 1000;
                if elapsed > max_elapsed {
                    max_elapsed = elapsed;
                }
            }
        }
        max_elapsed
    }

    pub fn exceeds_pickup(&self, now_epoch: u32) -> bool {
        self.pickup_elapsed(now_epoch) > PICKUP_MS
    }

    pub fn desk_escalation_score(&self) -> u32 {
        self.pending_count.saturating_mul(100).wrapping_add(self.route_digest)
    }
}
