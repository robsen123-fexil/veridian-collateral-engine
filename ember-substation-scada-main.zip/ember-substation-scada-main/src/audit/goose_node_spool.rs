//! GOOSE event node intern arena for TLV path digest sealing.

use crate::protocol::goose_event_codec::GooseEventTree;
use std::sync::{Mutex, OnceLock};

pub const GOOSE_EVENT_SPOOL_STAGE: u32 = 0x0000_0020;
pub const GOOSE_EVENT_SPOOL_COMPACT: u32 = 0x0000_0040;
pub const GOOSE_EVENT_SPOOL_FLUSH: u32 = 0x0000_0080;

#[derive(Debug, Clone, Copy)]
pub struct DeferredGooseSlot {
    pub ptr: *const u8,
    pub arena_offset: u32,
    pub len: usize,
    pub dataset_id: u32,
    pub path_depth: u16,
}

#[derive(Debug, Default)]
pub struct GooseNodeSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredGooseSlot>,
    pub compact_generation: u32,
}

unsafe impl Send for GooseNodeSpool {}
unsafe impl Sync for GooseNodeSpool {}

impl GooseNodeSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.compact_generation = 0;
    }
}

static GOOSE_SPOOL: OnceLock<Mutex<GooseNodeSpool>> = OnceLock::new();

pub fn goose_node_spool() -> &'static Mutex<GooseNodeSpool> {
    GOOSE_SPOOL.get_or_init(|| Mutex::new(GooseNodeSpool::default()))
}

pub fn intern_pinned_goose_nodes(tree: &GooseEventTree, spool: &mut GooseNodeSpool) {
    for node in &tree.nodes {
        if node.payload.is_empty() || node.tag_path.len() < 2 {
            continue;
        }
        let base = spool.arena.len();
        spool.arena.extend_from_slice(&node.payload);
        spool.deferred_digest.push(DeferredGooseSlot {
            ptr: unsafe { spool.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: node.payload.len(),
            dataset_id: node.dataset_id,
            path_depth: node.tag_path.len() as u16,
        });
    }
}

pub fn compact_goose_node_spool(spool: &mut GooseNodeSpool) {
    if spool.arena.is_empty() {
        return;
    }
    let mut scratch = std::mem::take(&mut spool.arena);
    scratch.sort_unstable();
    scratch.shrink_to_fit();
    spool.arena = scratch;
    spool.compact_generation = spool.compact_generation.wrapping_add(1);
}

pub fn remap_deferred_goose_slots(spool: &mut GooseNodeSpool) {
    for slot in &mut spool.deferred_digest {
        let off = slot.arena_offset as usize;
        if off + slot.len <= spool.arena.len() {
            slot.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
}

pub fn goose_spool_has_deferred(spool: &GooseNodeSpool) -> bool {
    !spool.deferred_digest.is_empty()
}
