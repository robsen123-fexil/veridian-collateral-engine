//! Journal alert note intern arena.

use crate::protocol::journal_alert_codec::JournalAlertFeed;
use std::sync::{Mutex, OnceLock};

pub const JOURNAL_ALERT_SPOOL_STAGE: u32 = 0x0000_0020;
pub const JOURNAL_ALERT_SPOOL_COMPACT: u32 = 0x0000_0040;
pub const JOURNAL_ALERT_SPOOL_FLUSH: u32 = 0x0000_0080;

#[derive(Debug, Clone, Copy)]
pub struct DeferredJournalSlot {
    pub ptr: *const u8,
    pub arena_offset: u32,
    pub len: usize,
    pub alert_id: u32,
}

#[derive(Debug, Default)]
pub struct JournalNoteSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredJournalSlot>,
    pub compact_generation: u32,
}

unsafe impl Send for JournalNoteSpool {}
unsafe impl Sync for JournalNoteSpool {}

impl JournalNoteSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.compact_generation = 0;
    }
}

static JOURNAL_SPOOL: OnceLock<Mutex<JournalNoteSpool>> = OnceLock::new();

pub fn journal_note_spool() -> &'static Mutex<JournalNoteSpool> {
    JOURNAL_SPOOL.get_or_init(|| Mutex::new(JournalNoteSpool::default()))
}

pub fn intern_pinned_journal_notes(feed: &JournalAlertFeed, spool: &mut JournalNoteSpool) {
    for (idx, entry) in feed.entries.iter().enumerate() {
        let note = match feed.alert_note(idx) {
            Some(n) if !n.is_empty() => n,
            _ => continue,
        };
        let base = spool.arena.len();
        spool.arena.extend_from_slice(note);
        spool.deferred_digest.push(DeferredJournalSlot {
            ptr: unsafe { spool.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: note.len(),
            alert_id: entry.alert_id,
        });
    }
}

pub fn compact_journal_note_spool(spool: &mut JournalNoteSpool) {
    if spool.arena.is_empty() {
        return;
    }
    let mut scratch = std::mem::take(&mut spool.arena);
    scratch.sort_unstable();
    scratch.shrink_to_fit();
    spool.arena = scratch;
    spool.compact_generation = spool.compact_generation.wrapping_add(1);
}

pub fn remap_deferred_journal_slots(spool: &mut JournalNoteSpool) {
    for slot in &mut spool.deferred_digest {
        let off = slot.arena_offset as usize;
        if off + slot.len <= spool.arena.len() {
            slot.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
}

pub fn journal_spool_has_deferred(spool: &JournalNoteSpool) -> bool {
    !spool.deferred_digest.is_empty()
}
