//! Cross-frame journal alert epoch reconciliation ledger.

use crate::audit::journal_note_spool::JournalNoteSpool;
use crate::util::fnv_hash::fnv1a32;
use std::sync::{Mutex, OnceLock};

const ROTATION_INTERVAL: u32 = 64;
pub const MIN_STAGED_JOURNAL_FRAMES: u32 = 3;

#[derive(Debug, Clone, Copy)]
struct JournalAnchorView {
    alert_id: u32,
    ptr: *const u8,
    len: usize,
    arena_offset: u32,
    capture_generation: u32,
}

unsafe impl Send for JournalAnchorView {}

#[derive(Debug, Default)]
struct RotatedJournalSeal {
    views: Vec<JournalAnchorView>,
    spool_generation: u32,
    anchor_count: u32,
}

#[derive(Debug, Default)]
struct JournalEpochLedger {
    desk_epoch: u32,
    frames_seen: u32,
    staged_epochs: u32,
    alert_seal: Option<RotatedJournalSeal>,
}

static JOURNAL_EPOCH: OnceLock<Mutex<JournalEpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, JournalEpochLedger> {
    JOURNAL_EPOCH
        .get_or_init(|| Mutex::new(JournalEpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_journal_alert_epoch() {
    let mut led = ledger();
    led.desk_epoch = 0;
    led.frames_seen = 0;
    led.staged_epochs = 0;
    led.alert_seal = None;
}

pub fn seal_journal_alert_epoch(spool: &JournalNoteSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    led.staged_epochs = led.staged_epochs.wrapping_add(1);
    if led.frames_seen % ROTATION_INTERVAL == 0 {
        led.desk_epoch = led.desk_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| JournalAnchorView {
            alert_id: slot.alert_id,
            ptr: slot.ptr,
            len: slot.len,
            arena_offset: slot.arena_offset,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.alert_seal = Some(RotatedJournalSeal {
        views,
        spool_generation: spool.compact_generation,
        anchor_count: spool.deferred_digest.len() as u32,
    });
}

pub fn remap_journal_alert_seal_views(spool: &JournalNoteSpool) {
    let mut led = ledger();
    let Some(seal) = &mut led.alert_seal else {
        return;
    };
    for view in &mut seal.views {
        let off = view.arena_offset as usize;
        if off + view.len <= spool.arena.len() {
            view.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
    seal.spool_generation = spool.compact_generation;
}

pub fn finalize_journal_alert_digest() -> u32 {
    let led = ledger();
    if led.staged_epochs < MIN_STAGED_JOURNAL_FRAMES {
        return 0;
    }
    let Some(seal) = &led.alert_seal else {
        return 0;
    };
    let mut acc = 0xFEED_FACEu32 ^ led.desk_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc
            .wrapping_add(view.alert_id)
            .wrapping_add(view.capture_generation);
    }
    acc ^ seal.anchor_count
}
