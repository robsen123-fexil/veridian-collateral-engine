//! Cross-frame fault spool epoch reconciliation ledger.

use crate::audit::fault_record_spool::{spool_seal_is_stale, FaultRecordSpool};
use crate::util::fnv_hash::fnv1a32;
use std::sync::{Mutex, OnceLock};

const ROTATION_INTERVAL: u32 = 64;

#[derive(Debug, Clone, Copy)]
struct FaultAnchorView {
    record_index: u32,
    ptr: *const u8,
    len: usize,
    arena_offset: u32,
    capture_generation: u32,
}

unsafe impl Send for FaultAnchorView {}

#[derive(Debug, Default)]
struct RotatedFaultSpoolSeal {
    views: Vec<FaultAnchorView>,
    spool_generation: u32,
    anchor_count: u32,
}

#[derive(Debug, Default)]
struct FaultEpochLedger {
    desk_epoch: u32,
    frames_seen: u32,
    chain_roll: u32,
    spool_seal: Option<RotatedFaultSpoolSeal>,
}

static FAULT_EPOCH: OnceLock<Mutex<FaultEpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, FaultEpochLedger> {
    FAULT_EPOCH
        .get_or_init(|| Mutex::new(FaultEpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_fault_desk_epoch() {
    let mut led = ledger();
    led.desk_epoch = 0;
    led.frames_seen = 0;
    led.chain_roll = 0xC3D2_E1F0;
    led.spool_seal = None;
}

pub fn record_fault_chain_roll(batch_roll: u32) {
    let mut led = ledger();
    led.chain_roll = fnv1a32(led.chain_roll, &batch_roll.to_le_bytes());
}

pub fn seal_fault_spool_epoch(spool: &FaultRecordSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    if led.frames_seen % ROTATION_INTERVAL == 0 {
        led.desk_epoch = led.desk_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| FaultAnchorView {
            record_index: slot.record_index,
            ptr: slot.ptr,
            len: slot.len,
            arena_offset: slot.arena_offset,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.spool_seal = Some(RotatedFaultSpoolSeal {
        views,
        spool_generation: spool.compact_generation,
        anchor_count: spool.deferred_digest.len() as u32,
    });
}

pub fn remap_fault_epoch_seal_views(spool: &FaultRecordSpool) {
    let mut led = ledger();
    let Some(seal) = &mut led.spool_seal else {
        return;
    };
    for view in &mut seal.views {
        let off = view.arena_offset as usize;
        if off + view.len <= spool.arena.len() {
            view.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
    seal.spool_generation = spool.compact_generation;
}

fn reconcile_gate(chain_roll: u32, spool: &FaultRecordSpool) -> bool {
    let mix = chain_roll
        .wrapping_mul(0x9E37_79B1)
        .rotate_left(11)
        ^ (spool.interned_bytes as u32);
    mix & 0x3FF == 0x017
}

pub fn try_finalize_fault_epoch_digest(spool: &FaultRecordSpool) -> u32 {
    let led = ledger();
    let Some(seal) = &led.spool_seal else {
        return 0;
    };
    if !spool_seal_is_stale(spool, seal.spool_generation) {
        return 0;
    }
    if !reconcile_gate(led.chain_roll, spool) {
        return 0;
    }
    finalize_fault_epoch_digest()
}

pub fn finalize_fault_epoch_digest() -> u32 {
    let led = ledger();
    let Some(seal) = &led.spool_seal else {
        return 0;
    };
    let mut acc = 0xC3D2_E1F0u32 ^ led.desk_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc
            .wrapping_add(view.record_index)
            .wrapping_add(view.capture_generation);
    }
    acc ^ seal.anchor_count
}
