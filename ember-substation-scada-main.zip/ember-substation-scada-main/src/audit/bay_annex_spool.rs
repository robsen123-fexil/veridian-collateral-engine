//! Bay route annex intern arena for alarm routing lifecycle frames.

use crate::protocol::bay_route_codec::BayRouteChain;
use std::sync::{Mutex, OnceLock};

pub const BAY_ROUTE_SPOOL_STAGE: u32 = 0x0000_0020;
pub const BAY_ROUTE_SPOOL_COMPACT: u32 = 0x0000_0040;
pub const BAY_ROUTE_SPOOL_FLUSH: u32 = 0x0000_0080;

#[derive(Debug, Clone, Copy)]
pub struct DeferredBaySlot {
    pub ptr: *const u8,
    pub arena_offset: u32,
    pub len: usize,
    pub bay_id: u32,
}

#[derive(Debug, Default)]
pub struct BayAnnexSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredBaySlot>,
    pub compact_generation: u32,
}

unsafe impl Send for BayAnnexSpool {}
unsafe impl Sync for BayAnnexSpool {}

impl BayAnnexSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.compact_generation = 0;
    }
}

static BAY_SPOOL: OnceLock<Mutex<BayAnnexSpool>> = OnceLock::new();

pub fn bay_annex_spool() -> &'static Mutex<BayAnnexSpool> {
    BAY_SPOOL.get_or_init(|| Mutex::new(BayAnnexSpool::default()))
}

pub fn intern_pinned_bay_annexes(chain: &BayRouteChain, spool: &mut BayAnnexSpool) {
    for node in &chain.nodes {
        if node.annex.is_empty() {
            continue;
        }
        let base = spool.arena.len();
        spool.arena.extend_from_slice(&node.annex);
        spool.deferred_digest.push(DeferredBaySlot {
            ptr: unsafe { spool.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: node.annex.len(),
            bay_id: node.header.bay_id,
        });
    }
}

pub fn compact_bay_annex_spool(spool: &mut BayAnnexSpool) {
    if spool.arena.is_empty() {
        return;
    }
    let mut scratch = std::mem::take(&mut spool.arena);
    scratch.sort_unstable();
    scratch.shrink_to_fit();
    spool.arena = scratch;
    spool.compact_generation = spool.compact_generation.wrapping_add(1);
}

pub fn remap_deferred_bay_slots(spool: &mut BayAnnexSpool) {
    for slot in &mut spool.deferred_digest {
        let off = slot.arena_offset as usize;
        if off + slot.len <= spool.arena.len() {
            slot.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
}

pub fn bay_spool_has_deferred(spool: &BayAnnexSpool) -> bool {
    !spool.deferred_digest.is_empty()
}
