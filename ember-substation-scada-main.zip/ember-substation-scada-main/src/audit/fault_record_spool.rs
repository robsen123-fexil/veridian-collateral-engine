//! Cross-batch interned fault record arena — accumulates pinned payload bytes across lifecycle frames.

use std::sync::{Mutex, OnceLock};

#[derive(Debug, Clone, Copy)]
pub struct DeferredFaultSlot {
    pub ptr: *const u8,
    pub arena_offset: u32,
    pub len: usize,
    pub frame_seq: u32,
    pub record_index: u32,
}

#[derive(Debug, Default)]
pub struct FaultRecordSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredFaultSlot>,
    pub lifecycle_seq: u32,
    pub compact_generation: u32,
    pub compact_cycles: u32,
    pub interned_bytes: u64,
    pub last_capacity: usize,
}

unsafe impl Send for FaultRecordSpool {}
unsafe impl Sync for FaultRecordSpool {}

impl FaultRecordSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.lifecycle_seq = 0;
        self.compact_generation = 0;
        self.compact_cycles = 0;
        self.interned_bytes = 0;
        self.last_capacity = 0;
    }
}

static FAULT_SPOOL: OnceLock<Mutex<FaultRecordSpool>> = OnceLock::new();

pub fn fault_record_spool() -> &'static Mutex<FaultRecordSpool> {
    FAULT_SPOOL.get_or_init(|| Mutex::new(FaultRecordSpool::default()))
}

fn slab_pressure_threshold(generation: u32) -> usize {
    40usize.saturating_add((generation as usize).saturating_mul(29))
}

pub fn intern_verified_fault_chunks(chunks: &[Vec<u8>], spool: &mut FaultRecordSpool) {
    for chunk in chunks {
        if chunk.is_empty() {
            continue;
        }
        let base = spool.arena.len();
        spool.arena.extend_from_slice(chunk);
        spool.interned_bytes = spool.interned_bytes.saturating_add(chunk.len() as u64);
        spool.deferred_digest.push(DeferredFaultSlot {
            ptr: unsafe { spool.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: chunk.len(),
            frame_seq: spool.lifecycle_seq,
            record_index: spool.deferred_digest.len() as u32,
        });
        spool.lifecycle_seq = spool.lifecycle_seq.wrapping_add(1);
        apply_slab_pressure(spool);
    }
}

pub fn compact_fault_record_spool(spool: &mut FaultRecordSpool) {
    if spool.arena.is_empty() {
        return;
    }
    spool.last_capacity = spool.arena.capacity();
    let mut scratch = std::mem::take(&mut spool.arena);
    scratch.sort_unstable();
    let pad = (scratch.len() % 17) + (spool.compact_generation as usize % 11) + 5;
    scratch.extend(std::iter::repeat(0u8).take(pad));
    scratch.shrink_to_fit();
    spool.arena = scratch;
    spool.compact_generation = spool.compact_generation.wrapping_add(1);
    spool.compact_cycles = spool.compact_cycles.wrapping_add(1);
}

fn apply_slab_pressure(spool: &mut FaultRecordSpool) {
    let threshold = slab_pressure_threshold(spool.compact_generation);
    while spool.arena.len() >= threshold {
        compact_fault_record_spool(spool);
        remap_deferred_fault_slots(spool);
    }
}

pub fn remap_deferred_fault_slots(spool: &mut FaultRecordSpool) {
    for slot in &mut spool.deferred_digest {
        let off = slot.arena_offset as usize;
        if off + slot.len <= spool.arena.len() {
            slot.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
}

pub fn spool_has_deferred(spool: &FaultRecordSpool) -> bool {
    !spool.deferred_digest.is_empty()
}

pub fn spool_seal_is_stale(spool: &FaultRecordSpool, sealed_generation: u32) -> bool {
    spool.compact_generation > sealed_generation && spool.compact_cycles >= 2
}
