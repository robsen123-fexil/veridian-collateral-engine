//! Feeder checkpoint leg annex intern arena.

use crate::protocol::feeder_checkpoint_codec::FeederCheckpointBundle;
use std::sync::{Mutex, OnceLock};

pub const FEEDER_CHECKPOINT_SPOOL_STAGE: u32 = 0x0000_0020;
pub const FEEDER_CHECKPOINT_SPOOL_COMPACT: u32 = 0x0000_0040;
pub const FEEDER_CHECKPOINT_SPOOL_FLUSH: u32 = 0x0000_0080;

#[derive(Debug, Clone, Copy)]
pub struct DeferredFeederSlot {
    pub ptr: *const u8,
    pub arena_offset: u32,
    pub len: usize,
    pub leg_id: u32,
}

#[derive(Debug, Default)]
pub struct FeederLegSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredFeederSlot>,
    pub compact_generation: u32,
}

unsafe impl Send for FeederLegSpool {}
unsafe impl Sync for FeederLegSpool {}

impl FeederLegSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.compact_generation = 0;
    }
}

static FEEDER_SPOOL: OnceLock<Mutex<FeederLegSpool>> = OnceLock::new();

pub fn feeder_leg_spool() -> &'static Mutex<FeederLegSpool> {
    FEEDER_SPOOL.get_or_init(|| Mutex::new(FeederLegSpool::default()))
}

pub fn intern_pinned_feeder_legs(bundle: &FeederCheckpointBundle, spool: &mut FeederLegSpool) {
    for leg in &bundle.legs {
        if leg.annex.is_empty() {
            continue;
        }
        let base = spool.arena.len();
        spool.arena.extend_from_slice(&leg.annex);
        spool.deferred_digest.push(DeferredFeederSlot {
            ptr: unsafe { spool.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: leg.annex.len(),
            leg_id: leg.entry.leg_id,
        });
    }
}

pub fn compact_feeder_leg_spool(spool: &mut FeederLegSpool) {
    if spool.arena.is_empty() {
        return;
    }
    let mut scratch = std::mem::take(&mut spool.arena);
    scratch.sort_unstable();
    scratch.shrink_to_fit();
    spool.arena = scratch;
    spool.compact_generation = spool.compact_generation.wrapping_add(1);
}

pub fn remap_deferred_feeder_slots(spool: &mut FeederLegSpool) {
    for slot in &mut spool.deferred_digest {
        let off = slot.arena_offset as usize;
        if off + slot.len <= spool.arena.len() {
            slot.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
}

pub fn feeder_spool_has_deferred(spool: &FeederLegSpool) -> bool {
    !spool.deferred_digest.is_empty()
}
