pub use mwg_core::{read_i32_le, read_u16_le, read_u32_le};

pub const MAX_FRAME: usize = 65536;
pub const MAX_FAULT_RECORDS: usize = 64;
pub const MAX_BAY_NODES: usize = 32;
pub const MAX_FEEDER_LEGS: usize = 16;
pub const MAX_GOOSE_NODES: usize = 48;

pub fn slice_at<'a>(buf: &'a [u8], off: usize, len: usize) -> Option<&'a [u8]> {
    if len > MAX_FRAME {
        return None;
    }
    mwg_core::slice_at(buf, off, len)
}
