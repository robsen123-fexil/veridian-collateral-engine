pub mod crc16;
pub mod fnv_hash;
pub mod safe_read;
