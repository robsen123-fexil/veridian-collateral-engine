//! FNV-1a 32/64-bit hashing for epoch digests and route fingerprints.

pub fn fnv1a32(seed: u32, data: &[u8]) -> u32 {
    let mut h = seed;
    for &b in data {
        h ^= u32::from(b);
        h = h.wrapping_mul(0x0100_0193);
    }
    h
}

pub fn fnv1a64(seed: u64, data: &[u8]) -> u64 {
    let mut h = seed;
    for &b in data {
        h ^= u64::from(b);
        h = h.wrapping_mul(0x0000_0100_0000_01B3);
    }
    h
}
