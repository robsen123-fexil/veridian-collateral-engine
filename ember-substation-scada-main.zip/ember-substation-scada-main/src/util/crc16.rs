//! CRC-16-CCITT for RTU fault record chain validation.

pub fn crc16_ccitt(seed: u16, data: &[u8]) -> u16 {
    let mut crc = seed;
    for &b in data {
        crc ^= u16::from(b) << 8;
        for _ in 0..8 {
            if crc & 0x8000 != 0 {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc <<= 1;
            }
        }
    }
    crc
}

pub fn rolling_crc16_chain(records: &[&[u8]]) -> u16 {
    let mut acc = 0xFFFFu16;
    for rec in records {
        acc = crc16_ccitt(acc, rec);
    }
    acc
}
