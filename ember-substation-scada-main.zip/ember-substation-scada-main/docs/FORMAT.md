# Ember Substation SCADA — Wire Format Reference

## Binary frame magics

All frames begin with a 4-byte ASCII magic, little-endian version `u16`, and domain-specific header fields.

### ESBF — RTU fault spool batch

| Offset | Type | Field |
|--------|------|-------|
| 0 | `[u8;4]` | `ESBF` |
| 4 | `u16` | version (1) |
| 6 | `u32` | record_count |
| 10 | `u32` | record_blob length |
| 14 | `u32` | epoch_secs |
| 18 | `u32` | flags |
| 22 | `u16` | substation_lane |
| 24 | `record_count × 16` | record table |
| … | `blob_len` | concatenated payloads |

Record table entries: `rtu_id u32`, `fault_class u8`, `severity u8`, `record_seq u16`, `payload_off u32`, `payload_len u32`.

Chain validation uses CRC-16-CCITT across record payloads when `record_count ≥ 3`.

### ESRT — Bay route alarm capsule

| Offset | Type | Field |
|--------|------|-------|
| 0 | `[u8;4]` | `ESRT` |
| 4 | `u16` | version (1) |
| 6 | `u32` | bay_count |
| 10 | `u32` | chain_flags |
| 14 | per-bay | bay nodes |

Bay node: `bay_id u32`, `prior_bay_off u32`, `alarm_class u16`, `pickup_ms u16`, `flags u16`, `annex_len u32`, annex bytes.

### ESCK — Feeder checkpoint bundle

| Offset | Type | Field |
|--------|------|-------|
| 0 | `[u8;4]` | `ESCK` |
| 4 | `u16` | version (1) |
| 6 | `u32` | substation_id |
| 10 | `u32` | leg_count |
| 14 | `u32` | merge_flags |
| 18 | per-leg | leg entries |

Leg entry: `leg_id u32`, `feeder_id u32`, `voltage_kv u16`, `current_amps u16`, `lat_micro i32`, `lon_micro i32`, `annex_len u32`, annex bytes.

### ESGO — GOOSE-like event node tree

| Offset | Type | Field |
|--------|------|-------|
| 0 | `[u8;4]` | `ESGO` |
| 4 | `u16` | version (1) |
| 6 | `u32` | substation_ref |
| 10 | `u32` | node_count |
| 14 | `u32` | tree_flags |
| 18 | per-node | TLV nodes |

Node: `dataset_id u32`, `path_depth u16`, `path_crc u16`, `payload_len u32`, `path_depth × u16` tag path, payload bytes.

Nested path CRC required when `path_depth ≥ 2`.

### ESJR — Journal alert feed

| Offset | Type | Field |
|--------|------|-------|
| 0 | `[u8;4]` | `ESJR` |
| 4 | `u16` | version (1) |
| 6 | `u32` | desk_ref |
| 10 | `u32` | alert_count |
| 14 | `u32` | epoch_secs |
| 18 | per-alert | alert entries |

Alert entry: `alert_id u32`, `substation_id u32`, `severity u8`, `alert_class u8`, `pickup_secs u16`, `note_len u16`, note bytes.

## Lifecycle streams

Lifecycle envelopes prefix a sequence of length-prefixed wire frames:

```
magic [u8;4] + version u16 + frame_count u32 + (frame_len u32 + frame bytes)*
```

| Magic | Wraps | Version |
|-------|-------|---------|
| `ESLF` | ESBF frames with nested chunk envelope | 2 |
| `ESLR` | ESRT frames | 1 |
| `ESCL` | ESCK frames | 1 |
| `ESGL` | ESGO frames | 1 |
| `ESJL` | ESJR frames | 1 |

ESBF lifecycle frames embed a nested chunk envelope before the ESBF body. Chunks use additive `u16` checksum validation.

## SCL-ish config scanner

Text XML subset: parses `<Substation>`, `<VoltageLevel>`, `<Bay>`, `<IED>` elements for topology hints. Invoked via `scan_scl_config`.

## Digest

- **FNV-1a 32-bit** — epoch digests, route fingerprints, merge stamps
- **CRC-16-CCITT** — fault record chain validation
