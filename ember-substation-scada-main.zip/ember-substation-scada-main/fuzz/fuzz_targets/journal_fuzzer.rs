#![no_main]
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    if data.is_empty() {
        return;
    }
    let _ = ember_substation_scada::run_journal_alert_pipeline(data);
});
