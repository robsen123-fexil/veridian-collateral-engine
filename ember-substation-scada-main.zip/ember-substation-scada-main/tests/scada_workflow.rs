mod wire_helpers;

use ember_substation_scada::{
    dispatch_scada_wire, route_bay_alarm_stream, run_fault_spool_pipeline,
    run_feeder_checkpoint_pipeline, run_goose_event_pipeline, run_journal_alert_pipeline,
    scan_scl_config,
};
use wire_helpers::{
    sample_esbf_batch, sample_esck_bundle, sample_esgo_tree, sample_esjr_feed, sample_esrt_chain,
    sample_scl_config,
};

#[test]
fn fault_spool_single_frame() {
    let frame = sample_esbf_batch();
    let digest = run_fault_spool_pipeline(&frame).expect("fault pipeline");
    assert!(digest > 0);
}

#[test]
fn bay_route_single_frame() {
    let frame = sample_esrt_chain();
    let outcome = route_bay_alarm_stream(&frame).expect("bay route");
    assert_eq!(outcome.bays_scanned, 1);
    assert!(outcome.seal_digest > 0);
}

#[test]
fn feeder_checkpoint_single_frame() {
    let frame = sample_esck_bundle();
    let digest = run_feeder_checkpoint_pipeline(&frame).expect("feeder checkpoint");
    assert!(digest > 0);
}

#[test]
fn goose_event_single_frame() {
    let frame = sample_esgo_tree();
    let digest = run_goose_event_pipeline(&frame).expect("goose event");
    assert!(digest > 0);
}

#[test]
fn journal_alert_single_frame() {
    let frame = sample_esjr_feed();
    let digest = run_journal_alert_pipeline(&frame).expect("journal alert");
    assert!(digest > 0);
}

#[test]
fn scl_config_scan() {
    let config = sample_scl_config();
    let scan = scan_scl_config(&config).expect("scl scan");
    assert_eq!(scan.ieds.len(), 1);
    assert!(scan.scan_digest > 0);
}

#[test]
fn wire_dispatch_esbf() {
    let frame = sample_esbf_batch();
    let digest = dispatch_scada_wire(&frame).expect("dispatch");
    assert!(digest > 0);
}

#[test]
fn empty_fault_rejected() {
    assert!(run_fault_spool_pipeline(&[]).is_err());
}

#[test]
fn empty_journal_rejected() {
    assert!(run_journal_alert_pipeline(&[]).is_err());
}
