use ember_substation_scada::protocol::bay_route_codec::{
    encode_bay_route_chain, BayRouteChain, BayRouteHeader, BayRouteNode,
};
use ember_substation_scada::protocol::fault_spool_codec::{
    encode_fault_spool, FaultRecordEntry,
};
use ember_substation_scada::protocol::feeder_checkpoint_codec::{
    encode_feeder_checkpoint, FeederCheckpointBundle, FeederLeg, FeederLegEntry,
};
use ember_substation_scada::protocol::goose_event_codec::{
    encode_goose_event_tree, compute_path_crc, GooseEventNode, GooseEventTree,
};
use ember_substation_scada::protocol::journal_alert_codec::{
    encode_journal_alert_feed, JournalAlertEntry, JournalAlertFeed,
};

pub fn sample_esbf_batch() -> Vec<u8> {
    let payload = b"RTU_FAULT_RECORD_01";
    let entries = vec![FaultRecordEntry {
        rtu_id: 1001,
        fault_class: 0x02,
        severity: 2,
        record_seq: 1,
        payload_off: 0,
        payload_len: payload.len() as u32,
    }];
    encode_fault_spool(&entries, payload, 1_700_000_000, 0, 1)
}

pub fn sample_esrt_chain() -> Vec<u8> {
    let chain = BayRouteChain {
        version: 1,
        bay_count: 1,
        chain_flags: 0,
        nodes: vec![BayRouteNode {
            header: BayRouteHeader {
                bay_id: 7,
                prior_bay_off: 0,
                alarm_class: 0x01,
                pickup_ms: 300,
                flags: 0,
                annex_len: 18,
            },
            annex: b"BAYALARMPAYLOAD!!!".to_vec(),
        }],
    };
    encode_bay_route_chain(&chain)
}

pub fn sample_esck_bundle() -> Vec<u8> {
    let bundle = FeederCheckpointBundle {
        version: 1,
        substation_id: 42,
        leg_count: 1,
        merge_flags: 0,
        legs: vec![FeederLeg {
            entry: FeederLegEntry {
                leg_id: 1,
                feeder_id: 2001,
                voltage_kv: 13,
                current_amps: 450,
                lat_micro: 41_878_100,
                lon_micro: -87_629_800,
                annex_len: 12,
            },
            annex: b"FEEDER_ANNEX".to_vec(),
        }],
    };
    encode_feeder_checkpoint(&bundle)
}

pub fn sample_esgo_tree() -> Vec<u8> {
    let tag_path = vec![0xE001u16, 0xE002u16];
    let payload = b"GOOSE_DATASET_VAL";
    let path_crc = compute_path_crc(&tag_path, payload);
    let tree = GooseEventTree {
        version: 1,
        substation_ref: 99,
        node_count: 1,
        tree_flags: 0,
        nodes: vec![GooseEventNode {
            dataset_id: 1,
            tag_path,
            payload: payload.to_vec(),
            path_crc,
        }],
    };
    encode_goose_event_tree(&tree)
}

pub fn sample_esjr_feed() -> Vec<u8> {
    let note = b"Breaker trip on Bay 7";
    let feed = JournalAlertFeed {
        version: 1,
        desk_ref: 99,
        alert_count: 1,
        epoch_secs: 1_700_000_000,
        entries: vec![JournalAlertEntry {
            alert_id: 1,
            substation_id: 42,
            severity: 3,
            alert_class: 0x10,
            pickup_secs: 5,
            note_len: note.len() as u16,
        }],
        note_blob: note.to_vec(),
    };
    encode_journal_alert_feed(&feed)
}

pub fn sample_scl_config() -> Vec<u8> {
    br#"<Substation name="SS01">
  <VoltageLevel name="VL69">
    <Bay name="Bay7">
      <IED name="RELAY01">
      </IED>
    </Bay>
  </VoltageLevel>
</Substation>
"#
    .to_vec()
}
