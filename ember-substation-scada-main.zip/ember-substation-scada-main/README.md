# Ember Substation SCADA

Electric utility SCADA event router for RTU fault spool batches, bay alarm routing, feeder checkpoint merge, GOOSE-like event trees, and journal alert digests.

**Author:** misgana tsegaye

## Overview

Ember multiplexes IEC-inspired binary event frames from remote terminal units (RTUs), routes bay protection alarms through a desk-side ingress router, merges feeder-leg checkpoints, and seals epoch digests for NERC audit spool reconciliation.

## Build

```bash
cargo check
cargo test
```

## CLI

```bash
cargo run --bin esctl -- fault <file.bin>
cargo run --bin esctl -- bay <file.bin>
cargo run --bin esctl -- feeder <file.bin>
cargo run --bin esctl -- goose <file.bin>
cargo run --bin esctl -- journal <file.bin>
cargo run --bin esctl -- scl <config.xml>
cargo run --bin esctl -- reconcile <file.bin>   # feeder checkpoint alias
```

## Wire formats

| Magic | Purpose |
|-------|---------|
| `ESBF` | RTU fault spool batch |
| `ESRT` | Bay route alarm capsule |
| `ESCK` | Feeder checkpoint bundle |
| `ESGO` | GOOSE-like event node tree |
| `ESJR` | Journal alert feed |

Lifecycle streams (`ESLF`, `ESLR`, `ESCL`, `ESGL`, `ESJL`) wrap length-prefixed frame sequences for multi-frame desk reconciliation. See `docs/FORMAT.md`.

## Module map

| Directory | Role |
|-----------|------|
| `protocol/` | Wire codecs, SCL config scanner, chain validation |
| `substation/` | RTU health, equipment telemetry, topology |
| `bay/` | Alarm routing, protection zones, interlocks |
| `feeder/` | Checkpoint merge, voltage reconciliation |
| `scada/` | Pipeline runners, desk orchestration |
| `desk/` | Shift handoff, NERC CIP compliance |
| `audit/` | Epoch ledgers and intern spools |

## Fuzzing

```bash
cargo fuzz build batch_fuzzer --release --sanitizer address
cargo fuzz build router_fuzzer --release --sanitizer address
cargo fuzz build session_fuzzer --release --sanitizer address
cargo fuzz build goose_fuzzer --release --sanitizer address
cargo fuzz build journal_fuzzer --release --sanitizer address
cargo fuzz build scl_fuzzer --release --sanitizer address
```

ClusterFuzzLite: `bash .clusterfuzzlite/build.sh`

## Digest algorithm

FNV-1a 32-bit for epoch digests and route fingerprints. CRC-16-CCITT for fault record chain validation.
