package com.jarpack;

import org.junit.Test;
import static org.junit.Assert.*;

public class ManifestParserTest {
  @Test
  public void parsesMainAttributes() {
    String raw = "Manifest-Version: 1.0\nCreated-By: jarpack\n\n";
    ManifestDocument doc = ManifestParser.parseUtf8(raw);
    assertEquals("1.0", doc.main().get("Manifest-Version"));
  }

  @Test
  public void foldsLongClasspath() {
    ManifestDocument doc = new ManifestDocument();
    doc.main().put("Manifest-Version", "1.0");
    doc.main().put("Class-Path", "lib/a.jar lib/b.jar lib/c.jar");
    byte[] folded = FoldEngine.foldDocument(doc);
    assertTrue(folded.length > 0);
  }

  @Test
  public void mergeCombinesMain() {
    ManifestDocument a = ManifestParser.parseUtf8("Manifest-Version: 1.0\n");
    ManifestDocument b = ManifestParser.parseUtf8("Main-Class: demo.App\n");
    ManifestDocument m = ManifestMerger.merge(a, b);
    assertEquals("1.0", m.main().get("Manifest-Version"));
    assertEquals("demo.App", m.main().get("Main-Class"));
  }
}
