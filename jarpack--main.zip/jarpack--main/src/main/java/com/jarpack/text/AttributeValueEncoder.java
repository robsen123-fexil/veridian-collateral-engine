package com.jarpack.text;

import com.jarpack.core.ManifestConstants;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Encodes attribute values for manifest output with folding awareness. */
public final class AttributeValueEncoder {
  private AttributeValueEncoder() {}

  public static String escapeForManifest(String value) {
    if (value == null) {
      return "";
    }
    return value.replace("\r\n", " ").replace("\n", " ").replace("\r", " ");
  }

  public static String truncate(String value, String attributeName) {
    if (value == null) {
      return "";
    }
    int max = ManifestConstants.maxValueLengthFor(attributeName);
    if (value.length() <= max) {
      return value;
    }
    return value.substring(0, max);
  }

  public static List<String> foldNameValue(String name, String value) {
    return ManifestLineCodec.splitAttribute(name, escapeForManifest(value));
  }

  public static int encodedByteLength(String name, String value, boolean crlf) {
    List<String> rows = foldNameValue(name, value);
    int len = 0;
    String ending = crlf ? "\r\n" : "\n";
    for (String row : rows) {
      len += row.getBytes(StandardCharsets.UTF_8).length + ending.length();
    }
    return len;
  }

  public static String joinClasspath(List<String> entries) {
    if (entries == null || entries.isEmpty()) {
      return "";
    }
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < entries.size(); i++) {
      if (i > 0) {
        sb.append(' ');
      }
      sb.append(entries.get(i).trim());
    }
    return sb.toString();
  }

  public static List<String> splitClasspath(String raw) {
    List<String> out = new ArrayList<>();
    if (raw == null || raw.isEmpty()) {
      return out;
    }
    StringBuilder token = new StringBuilder();
    for (int i = 0; i < raw.length(); i++) {
      char c = raw.charAt(i);
      if (Character.isWhitespace(c)) {
        if (token.length() > 0) {
          out.add(token.toString());
          token.setLength(0);
        }
      } else {
        token.append(c);
      }
    }
    if (token.length() > 0) {
      out.add(token.toString());
    }
    return out;
  }

  public static boolean needsFolding(String name, String value) {
    String logical = name + ": " + (value == null ? "" : value);
    return logical.length() > ManifestConstants.MAX_PHYSICAL_LINE;
  }

  public static String normalizeWhitespace(String value) {
    if (value == null) {
      return "";
    }
    return value.trim().replaceAll("\\s+", " ");
  }
}
