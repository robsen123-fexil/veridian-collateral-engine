package com.jarpack.text;

import com.jarpack.core.ManifestConstants;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Encodes and decodes manifest logical lines to physical 72-byte rows. */
public final class ManifestLineCodec {
  private ManifestLineCodec() {}

  public static List<String> encodeLogicalLine(String logical) {
    List<String> rows = new ArrayList<>();
    if (logical == null) {
      rows.add("");
      return rows;
    }
    int pos = 0;
    while (pos < logical.length()) {
      int take = Math.min(ManifestConstants.MAX_PHYSICAL_LINE, logical.length() - pos);
      String chunk = logical.substring(pos, pos + take);
      if (pos > 0) {
        chunk = " " + chunk;
      }
      rows.add(chunk);
      pos += take;
    }
    if (rows.isEmpty()) {
      rows.add(logical);
    }
    return rows;
  }

  public static String decodePhysicalRows(List<String> rows) {
    if (rows == null || rows.isEmpty()) {
      return "";
    }
    StringBuilder sb = new StringBuilder();
    for (String row : rows) {
      if (row.startsWith(" ") && sb.length() > 0) {
        sb.append(row.substring(1));
      } else {
        if (sb.length() > 0) {
          sb.append('\n');
        }
        sb.append(row);
      }
    }
    return sb.toString();
  }

  public static byte[] encodeUtf8(String logical, String lineEnding) {
    List<String> rows = encodeLogicalLine(logical);
    String ending = lineEnding == null ? "\n" : lineEnding;
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < rows.size(); i++) {
      if (i > 0) {
        sb.append(ending);
      }
      sb.append(rows.get(i));
    }
    sb.append(ending);
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }

  public static int physicalRowCount(String logical) {
    return encodeLogicalLine(logical).size();
  }

  public static boolean fitsSingleRow(String logical) {
    return logical != null && logical.length() <= ManifestConstants.MAX_PHYSICAL_LINE;
  }

  public static List<String> splitAttribute(String name, String value) {
    return encodeLogicalLine(name + ": " + (value == null ? "" : value));
  }

  public static String joinAttributeRows(List<String> rows) {
    String decoded = decodePhysicalRows(rows);
    int colon = decoded.indexOf(':');
    if (colon < 0) {
      return decoded;
    }
    return decoded.substring(colon + 1).trim();
  }

  public static int estimateDocumentBytes(int mainAttrs, int sections, int avgValueLen) {
    int perAttr = ManifestConstants.MAX_PHYSICAL_LINE + 2;
    return (mainAttrs + sections * 3) * (perAttr + avgValueLen / ManifestConstants.MAX_PHYSICAL_LINE);
  }
}
