package com.jarpack;

public final class BinaryFrameScanner {
  private final byte[] data;
  private int pos;

  public BinaryFrameScanner(byte[] data) {
    this.data = data == null ? new byte[0] : data;
  }

  public boolean hasNext() {
    return pos + 6 <= data.length;
  }

  public Frame next() {
    if (!hasNext()) {
      return null;
    }
    int magic = SafeRead.u32be(data, pos);
    int len = SafeRead.u16be(data, pos + 4);
    pos += 6;
    int clamped = SafeRead.clampLen(len, data.length - pos);
    byte[] payload = SafeRead.slice(data, pos, clamped);
    pos += clamped;
    return new Frame(magic, payload);
  }
}
