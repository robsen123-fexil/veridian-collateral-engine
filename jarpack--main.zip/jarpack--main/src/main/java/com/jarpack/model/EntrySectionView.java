package com.jarpack.model;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** View over a single per-entry manifest section. */
public final class EntrySectionView {
  private final String entryName;
  private final Map<String, String> attrs;

  public EntrySectionView(String entryName, Map<String, String> attrs) {
    this.entryName = entryName;
    this.attrs = attrs == null ? Collections.emptyMap() : attrs;
  }

  public static EntrySectionView from(ManifestDocument doc, String entryName) {
    Map<String, String> section = doc.entries().get(entryName);
    return new EntrySectionView(entryName, section);
  }

  public String entryName() {
    return entryName;
  }

  public Set<String> attributeNames() {
    return Collections.unmodifiableSet(attrs.keySet());
  }

  public String get(String name) {
    return attrs.get(name);
  }

  public boolean isSealed() {
    return "true".equalsIgnoreCase(attrs.get(ManifestConstants.SEALED));
  }

  public Map<String, String> digestAttributes() {
    Map<String, String> digests = new LinkedHashMap<>();
    for (Map.Entry<String, String> e : attrs.entrySet()) {
      if (ManifestConstants.isDigestAttribute(e.getKey())) {
        digests.put(e.getKey(), e.getValue());
      }
    }
    return digests;
  }

  public Optional<String> firstDigest() {
    for (Map.Entry<String, String> e : attrs.entrySet()) {
      if (ManifestConstants.isDigestAttribute(e.getKey())) {
        return Optional.ofNullable(e.getValue());
      }
    }
    return Optional.empty();
  }

  public int attributeCount() {
    return attrs.size();
  }

  public Map<String, String> asMap() {
    return Collections.unmodifiableMap(attrs);
  }
}
