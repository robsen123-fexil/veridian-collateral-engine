package com.jarpack.model;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** Fluent builder for manifest documents with typed attribute setters. */
public final class ManifestBuilder {
  private final ManifestDocument doc = new ManifestDocument();
  private String pendingSection;

  public static ManifestBuilder create() {
    return new ManifestBuilder().manifestVersion("1.0");
  }

  public ManifestBuilder manifestVersion(String version) {
    doc.main().put(ManifestConstants.MANIFEST_VERSION, version);
    return this;
  }

  public ManifestBuilder mainClass(String className) {
    doc.main().put(ManifestConstants.MAIN_CLASS, className);
    return this;
  }

  public ManifestBuilder classPath(String path) {
    doc.main().put(ManifestConstants.CLASS_PATH, path);
    return this;
  }

  public ManifestBuilder sealed(boolean value) {
    doc.main().put(ManifestConstants.SEALED, value ? "true" : "false");
    return this;
  }

  public ManifestBuilder multiRelease(boolean value) {
    doc.main().put(ManifestConstants.MULTI_RELEASE, value ? "true" : "false");
    return this;
  }

  public ManifestBuilder createdBy(String tool) {
    doc.main().put(ManifestConstants.CREATED_BY, tool);
    return this;
  }

  public ManifestBuilder implementation(String title, String version, String vendor) {
    if (title != null) {
      doc.main().put(ManifestConstants.IMPLEMENTATION_TITLE, title);
    }
    if (version != null) {
      doc.main().put(ManifestConstants.IMPLEMENTATION_VERSION, version);
    }
    if (vendor != null) {
      doc.main().put(ManifestConstants.IMPLEMENTATION_VENDOR, vendor);
    }
    return this;
  }

  public ManifestBuilder specification(String title, String version, String vendor) {
    if (title != null) {
      doc.main().put(ManifestConstants.SPECIFICATION_TITLE, title);
    }
    if (version != null) {
      doc.main().put(ManifestConstants.SPECIFICATION_VERSION, version);
    }
    if (vendor != null) {
      doc.main().put(ManifestConstants.SPECIFICATION_VENDOR, vendor);
    }
    return this;
  }

  public ManifestBuilder mainAttribute(String name, String value) {
    Objects.requireNonNull(name, "name");
    doc.main().put(name, value == null ? "" : value);
    return this;
  }

  public ManifestBuilder beginSection(String entryName) {
    pendingSection = entryName;
    doc.entries().put(entryName, new LinkedHashMap<>());
    return this;
  }

  public ManifestBuilder sectionAttribute(String name, String value) {
    if (pendingSection == null) {
      throw new IllegalStateException("no open section");
    }
    doc.entries().get(pendingSection).put(name, value == null ? "" : value);
    return this;
  }

  public ManifestBuilder endSection() {
    pendingSection = null;
    return this;
  }

  public ManifestBuilder mergeFrom(ManifestDocument other) {
    if (other == null) {
      return this;
    }
    doc.main().putAll(other.main());
    for (Map.Entry<String, Map<String, String>> e : other.entries().entrySet()) {
      doc.entries().put(e.getKey(), new LinkedHashMap<>(e.getValue()));
    }
    doc.warnings().addAll(other.warnings());
    return this;
  }

  public ManifestDocument build() {
    return doc.copy();
  }

  public ManifestDocument document() {
    return doc;
  }
}
