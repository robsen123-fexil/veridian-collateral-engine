package com.jarpack.model;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Typed read-only view over main manifest attributes. */
public final class MainAttributesView {
  private final Map<String, String> main;

  public MainAttributesView(ManifestDocument doc) {
    this.main = doc == null ? Collections.emptyMap() : doc.main();
  }

  public String manifestVersion() {
    return main.get(ManifestConstants.MANIFEST_VERSION);
  }

  public Optional<String> mainClass() {
    return optional(ManifestConstants.MAIN_CLASS);
  }

  public Optional<String> classPath() {
    return optional(ManifestConstants.CLASS_PATH);
  }

  public boolean isSealed() {
    return "true".equalsIgnoreCase(main.get(ManifestConstants.SEALED));
  }

  public boolean isMultiRelease() {
    return "true".equalsIgnoreCase(main.get(ManifestConstants.MULTI_RELEASE));
  }

  public Optional<String> createdBy() {
    return optional(ManifestConstants.CREATED_BY);
  }

  public Optional<String> implementationTitle() {
    return optional(ManifestConstants.IMPLEMENTATION_TITLE);
  }

  public Optional<String> implementationVersion() {
    return optional(ManifestConstants.IMPLEMENTATION_VERSION);
  }

  public Optional<String> specificationVersion() {
    return optional(ManifestConstants.SPECIFICATION_VERSION);
  }

  public Set<String> names() {
    return Collections.unmodifiableSet(main.keySet());
  }

  public String get(String name) {
    return main.get(name);
  }

  public boolean has(String name) {
    return main.containsKey(name);
  }

  public int size() {
    return main.size();
  }

  private Optional<String> optional(String key) {
    String val = main.get(key);
    return val == null || val.isEmpty() ? Optional.empty() : Optional.of(val);
  }
}
