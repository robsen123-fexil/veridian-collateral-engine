package com.jarpack.model;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.io.ManifestStreamWriter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Mutable editor with change tracking for manifest documents. */
public final class ManifestEditor {
  private final ManifestDocument doc;
  private final List<String> changes = new ArrayList<>();

  public ManifestEditor(ManifestDocument doc) {
    this.doc = doc == null ? new ManifestDocument() : doc.copy();
  }

  public static ManifestEditor fromBytes(byte[] bytes) {
    return new ManifestEditor(ManifestParser.parse(bytes));
  }

  public ManifestEditor setMain(String name, String value) {
    String old = doc.main().put(name, value);
    changes.add("main:" + name + ":" + old + "->" + value);
    return this;
  }

  public ManifestEditor removeMain(String name) {
    String old = doc.main().remove(name);
    if (old != null) {
      changes.add("remove-main:" + name);
    }
    return this;
  }

  public ManifestEditor putSection(String entry, String attr, String value) {
    Map<String, String> section = doc.entries().computeIfAbsent(entry, k -> new LinkedHashMap<>());
    section.put(attr, value);
    changes.add("section:" + entry + "/" + attr);
    return this;
  }

  public ManifestEditor removeSection(String entry) {
    if (doc.entries().remove(entry) != null) {
      changes.add("remove-section:" + entry);
    }
    return this;
  }

  public ManifestEditor renameSection(String from, String to) {
    Map<String, String> section = doc.entries().remove(from);
    if (section != null) {
      doc.entries().put(to, section);
      changes.add("rename-section:" + from + "->" + to);
    }
    return this;
  }

  public ManifestEditor clearWarnings() {
    doc.warnings().clear();
    return this;
  }

  public ManifestDocument document() {
    return doc;
  }

  public List<String> changeLog() {
    return List.copyOf(changes);
  }

  public byte[] toBytes() throws IOException {
    return ManifestStreamWriter.toByteArray(doc);
  }

  public MainAttributesView mainView() {
    return new MainAttributesView(doc);
  }

  public List<EntrySectionView> sections() {
    List<EntrySectionView> views = new ArrayList<>();
    for (Map.Entry<String, Map<String, String>> e : doc.entries().entrySet()) {
      views.add(new EntrySectionView(e.getKey(), e.getValue()));
    }
    return views;
  }
}
