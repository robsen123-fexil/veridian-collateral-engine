package com.jarpack.io;

import com.jarpack.ManifestDocument;
import com.jarpack.text.ManifestLineCodec;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Encodes manifests using CRLF line endings required for JAR signing tools. */
public final class CrlfManifestEncoder {
  private static final String CRLF = "\r\n";

  private CrlfManifestEncoder() {}

  public static byte[] encode(ManifestDocument doc) {
    List<String> lines = new ArrayList<>();
    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      lines.addAll(ManifestLineCodec.splitAttribute(e.getKey(), e.getValue()));
    }
    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      lines.add("");
      lines.addAll(ManifestLineCodec.splitAttribute("Name", section.getKey()));
      for (Map.Entry<String, String> attr : section.getValue().entrySet()) {
        if ("Name".equals(attr.getKey())) {
          continue;
        }
        lines.addAll(ManifestLineCodec.splitAttribute(attr.getKey(), attr.getValue()));
      }
    }
    StringBuilder sb = new StringBuilder();
    for (String line : lines) {
      sb.append(line).append(CRLF);
    }
    sb.append(CRLF);
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }

  public static int countCrlfBytes(ManifestDocument doc) {
    return encode(doc).length;
  }

  public static boolean differsFromLf(ManifestDocument doc) {
    byte[] crlf = encode(doc);
    byte[] lf = ManifestStreamWriter.toByteArray(doc);
    if (crlf.length != lf.length) {
      return true;
    }
    for (int i = 0; i < crlf.length; i++) {
      if (crlf[i] != lf[i]) {
        return true;
      }
    }
    return false;
  }
}
