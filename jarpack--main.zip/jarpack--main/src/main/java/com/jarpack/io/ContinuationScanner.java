package com.jarpack.io;

import java.util.ArrayList;
import java.util.List;

/** Detects and repairs line-continuation sequences in physical manifest text. */
public final class ContinuationScanner {
  private ContinuationScanner() {}

  public static List<String> unfoldPhysicalLines(List<String> physical) {
    List<String> logical = new ArrayList<>();
    StringBuilder current = new StringBuilder();
    for (String line : physical) {
      if (line.startsWith(" ") || line.startsWith("\t")) {
        if (current.length() > 0) {
          current.append(line.substring(1));
        }
        continue;
      }
      if (current.length() > 0) {
        logical.add(current.toString());
      }
      current = new StringBuilder(line);
    }
    if (current.length() > 0) {
      logical.add(current.toString());
    }
    return logical;
  }

  public static int countContinuations(List<String> physical) {
    int n = 0;
    for (String line : physical) {
      if (line.startsWith(" ") || line.startsWith("\t")) {
        n++;
      }
    }
    return n;
  }

  public static boolean hasOrphanContinuation(List<String> physical) {
    if (physical.isEmpty()) {
      return false;
    }
    return physical.get(0).startsWith(" ");
  }

  public static List<String> splitPhysical(String text) {
    List<String> lines = new ArrayList<>();
    for (String line : text.split("\\r?\\n", -1)) {
      lines.add(line);
    }
    return lines;
  }
}
