package com.jarpack.io;

import com.jarpack.core.ManifestConstants;
import com.jarpack.ManifestDocument;
import com.jarpack.ManifestToken;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Incremental byte-oriented manifest parser with continuation folding. */
public final class ManifestStreamReader implements AutoCloseable {
  private final InputStream in;
  private final LineBuffer buffer = new LineBuffer();
  private boolean eof;
  private long bytesRead;

  public ManifestStreamReader(InputStream in) {
    this.in = in;
  }

  public ManifestDocument readDocument() throws IOException {
    ManifestDocument doc = new ManifestDocument();
    String currentSection = null;
    Map<String, String> sectionAttrs = null;
    LogicalLine line;
    while ((line = nextLogicalLine()) != null) {
      if (line.isEmpty()) {
        currentSection = null;
        sectionAttrs = null;
        continue;
      }
      int colon = line.text().indexOf(':');
      if (colon < 0) {
        doc.warnings().add("missing-colon:" + line.text());
        continue;
      }
      String name = line.text().substring(0, colon).trim();
      String value = line.text().substring(colon + 1).trim();
      if (currentSection == null && name.contains("/") && !name.endsWith(":")) {
        currentSection = name;
        sectionAttrs = new LinkedHashMap<>();
        doc.entries().put(currentSection, sectionAttrs);
        if (!value.isEmpty()) {
          sectionAttrs.put(name, value);
        }
        continue;
      }
      if ("Name".equals(name)) {
        if (currentSection != null && sectionAttrs != null) {
          doc.entries().put(currentSection, sectionAttrs);
        }
        currentSection = value;
        sectionAttrs = new LinkedHashMap<>();
        doc.entries().put(currentSection, sectionAttrs);
        continue;
      }
      if (currentSection != null && sectionAttrs != null) {
        sectionAttrs.put(name, value);
      } else {
        doc.main().put(name, value);
      }
    }
    return doc;
  }

  public LogicalLine nextLogicalLine() throws IOException {
    StringBuilder acc = new StringBuilder();
    String physical;
    while ((physical = buffer.readPhysicalLine(in)) != null) {
      bytesRead += physical.length() + 1;
      if (physical.isEmpty()) {
        if (acc.length() == 0) {
          return LogicalLine.empty();
        }
        return new LogicalLine(acc.toString(), buffer.lineNumber());
      }
      if (physical.startsWith(" ") || physical.startsWith("\t")) {
        if (acc.length() == 0) {
          docWarnContinuationOrphan(physical);
          continue;
        }
        acc.append(physical.substring(1));
        continue;
      }
      if (acc.length() > 0) {
        buffer.pushBack(physical);
        return new LogicalLine(acc.toString(), buffer.lineNumber());
      }
      acc.append(physical);
      if (acc.length() <= ManifestConstants.MAX_PHYSICAL_LINE) {
        return new LogicalLine(acc.toString(), buffer.lineNumber());
      }
    }
    if (acc.length() > 0) {
      return new LogicalLine(acc.toString(), buffer.lineNumber());
    }
    return null;
  }

  private void docWarnContinuationOrphan(String physical) {
    // orphan continuation without predecessor - ignored at stream level
  }

  public long bytesRead() { return bytesRead; }

  public long bytesConsumed() { return bytesRead; }

  public int entryCount(ManifestDocument doc) {
    return doc == null ? 0 : doc.entries().size();
  }

  @Override
  public void close() throws IOException {
    in.close();
  }

  public static ManifestDocument parseBytes(byte[] raw) throws IOException {
    try (InputStream stream = new java.io.ByteArrayInputStream(raw);
         ManifestStreamReader reader = new ManifestStreamReader(stream)) {
      return reader.readDocument();
    }
  }

  public List<ManifestToken> tokenizeAll(byte[] raw) throws IOException {
    List<ManifestToken> tokens = new ArrayList<>();
    try (InputStream stream = new java.io.ByteArrayInputStream(raw);
         ManifestStreamReader reader = new ManifestStreamReader(stream)) {
      LogicalLine line;
      boolean inSection = false;
      while ((line = reader.nextLogicalLine()) != null) {
        if (line.isEmpty()) {
          inSection = false;
          tokens.add(ManifestToken.sectionBreak());
          continue;
        }
        int colon = line.text().indexOf(':');
        if (colon < 0) {
          tokens.add(ManifestToken.invalid(line.text()));
          continue;
        }
        String name = line.text().substring(0, colon).trim();
        String value = line.text().substring(colon + 1).trim();
        if (!inSection && name.contains("/")) {
          inSection = true;
        }
        tokens.add(ManifestToken.pair(name, value, inSection));
      }
    }
    return tokens;
  }
}
