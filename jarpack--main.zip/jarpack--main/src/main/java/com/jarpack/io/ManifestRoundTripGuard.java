package com.jarpack.io;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Verifies parse-serialize-parse structural equality for manifests. */
public final class ManifestRoundTripGuard {
  private ManifestRoundTripGuard() {}

  public static RoundTripReport check(byte[] original) {
    RoundTripReport report = new RoundTripReport();
    if (original == null) {
      report.addIssue("null-input");
      return report;
    }
    ManifestDocument first = ManifestParser.parse(original);
    byte[] serialized = ManifestStreamWriter.toByteArray(first);
    ManifestDocument second = ManifestParser.parse(serialized);
    report.setBytesIn(original.length);
    report.setBytesOut(serialized.length);
    compareMain(first, second, report);
    compareEntries(first, second, report);
    return report;
  }

  public static RoundTripReport checkDocument(ManifestDocument doc) {
    byte[] bytes = ManifestStreamWriter.toByteArray(doc);
    return check(bytes);
  }

  private static void compareMain(ManifestDocument a, ManifestDocument b, RoundTripReport report) {
    if (!Objects.equals(a.main(), b.main())) {
      report.addIssue("main-mismatch");
      for (String key : unionKeys(a.main().keySet(), b.main().keySet())) {
        String va = a.main().get(key);
        String vb = b.main().get(key);
        if (!Objects.equals(va, vb)) {
          report.addIssue("main-attr:" + key);
        }
      }
    }
  }

  private static void compareEntries(ManifestDocument a, ManifestDocument b, RoundTripReport report) {
    if (a.entries().size() != b.entries().size()) {
      report.addIssue("entry-count:" + a.entries().size() + "!=" + b.entries().size());
    }
    for (String name : unionKeys(a.entries().keySet(), b.entries().keySet())) {
      var sa = a.entries().get(name);
      var sb = b.entries().get(name);
      if (sa == null || sb == null) {
        report.addIssue("missing-section:" + name);
        continue;
      }
      if (!Objects.equals(sa, sb)) {
        report.addIssue("section-mismatch:" + name);
      }
    }
  }

  private static List<String> unionKeys(java.util.Set<String> a, java.util.Set<String> b) {
    List<String> keys = new ArrayList<>();
    keys.addAll(a);
    for (String k : b) {
      if (!keys.contains(k)) {
        keys.add(k);
      }
    }
    return keys;
  }

  public static final class RoundTripReport {
    private final List<String> issues = new ArrayList<>();
    private int bytesIn;
    private int bytesOut;

    public void addIssue(String issue) { issues.add(issue); }
    public List<String> issues() { return List.copyOf(issues); }
    public boolean ok() { return issues.isEmpty(); }
    public int bytesIn() { return bytesIn; }
    public int bytesOut() { return bytesOut; }
    void setBytesIn(int v) { bytesIn = v; }
    void setBytesOut(int v) { bytesOut = v; }
  }
}
