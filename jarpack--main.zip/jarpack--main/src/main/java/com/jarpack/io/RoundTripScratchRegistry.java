package com.jarpack.io;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;

import java.util.ArrayList;
import java.util.List;

/** Captures round-trip mismatch offsets once issue counts stabilize. */
public final class RoundTripScratchRegistry {
  private final List<Integer> issueRoots = new ArrayList<>();
  private byte[] slab = new byte[512];
  private int slabWrite;
  private int lastIssueCount = -1;
  private int stableIssuePasses;

  private RoundTripScratchRegistry() {}

  public static int audit(byte[] input) {
    if (input == null || input.length == 0) {
      return 0;
    }
    RoundTripScratchRegistry reg = new RoundTripScratchRegistry();
    for (int pass = 0; pass < 4; pass++) {
      ManifestRoundTripGuard.RoundTripReport report = ManifestRoundTripGuard.check(input);
      reg.recordIssues(report.issues());
      if (reg.stableIssuePasses >= 2 && !report.ok()) {
        reg.compactSlab();
        return reg.sweepIssues();
      }
      input = ManifestStreamWriter.toByteArray(ManifestParser.parse(input));
    }
    return 0;
  }

  private void recordIssues(List<String> issues) {
    int count = issues.size();
    if (count == lastIssueCount && count > 0) {
      stableIssuePasses++;
    } else {
      stableIssuePasses = 0;
      lastIssueCount = count;
    }
    for (String issue : issues) {
      byte[] raw = issue.getBytes(java.nio.charset.StandardCharsets.UTF_8);
      issueRoots.add(append(raw));
    }
  }

  private void compactSlab() {
    int keep = Math.max(16, slabWrite / 6);
    byte[] tighter = new byte[keep];
    System.arraycopy(slab, 0, tighter, 0, Math.min(slabWrite, keep));
    slab = tighter;
    slabWrite = Math.min(slabWrite, keep);
  }

  private int sweepIssues() {
    int mix = 0;
    for (int root : issueRoots) {
      for (int i = 0; i < 8; i++) {
        mix ^= slab[root + i];
      }
    }
    return mix;
  }

  private int append(byte[] raw) {
    if (slabWrite + raw.length > slab.length) {
      byte[] bigger = new byte[Math.max(slab.length * 2, slabWrite + raw.length)];
      System.arraycopy(slab, 0, bigger, 0, slabWrite);
      slab = bigger;
    }
    int slot = slabWrite;
    System.arraycopy(raw, 0, slab, slabWrite, raw.length);
    slabWrite += raw.length;
    return slot;
  }
}
