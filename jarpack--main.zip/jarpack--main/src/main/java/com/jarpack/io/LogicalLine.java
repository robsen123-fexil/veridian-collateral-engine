package com.jarpack.io;

/** One unfolded manifest logical line. */
public final class LogicalLine {
  private final String text;
  private final int sourceLine;

  public LogicalLine(String text, int sourceLine) {
    this.text = text == null ? "" : text;
    this.sourceLine = sourceLine;
  }

  public static LogicalLine empty() {
    return new LogicalLine("", 0);
  }

  public String text() { return text; }
  public int sourceLine() { return sourceLine; }
  public boolean isEmpty() { return text.isEmpty(); }

  public boolean hasAttributeSyntax() {
    int colon = text.indexOf(':');
    return colon > 0 && colon < text.length() - 1;
  }

  public String attributeName() {
    int colon = text.indexOf(':');
    return colon < 0 ? text : text.substring(0, colon).trim();
  }

  public String attributeValue() {
    int colon = text.indexOf(':');
    return colon < 0 ? "" : text.substring(colon + 1).trim();
  }
}
