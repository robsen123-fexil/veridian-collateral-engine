package com.jarpack.io;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;

/** Physical-line reader with push-back for manifest streaming. */
public final class LineBuffer {
  private final Deque<String> pushBack = new ArrayDeque<>();
  private final StringBuilder pending = new StringBuilder();
  private int lineNo;

  public int lineNumber() { return lineNo; }

  public void pushBack(String line) {
    pushBack.addFirst(line);
  }

  public String readPhysicalLine(InputStream in) throws IOException {
    if (!pushBack.isEmpty()) {
      lineNo++;
      return pushBack.removeFirst();
    }
    pending.setLength(0);
    int b;
    while ((b = in.read()) >= 0) {
      char c = (char) b;
      if (c == '\n') {
        lineNo++;
        return pending.toString();
      }
      if (c == '\r') {
        continue;
      }
      pending.append(c);
    }
    if (pending.length() > 0) {
      lineNo++;
      return pending.toString();
    }
    return null;
  }

  public byte[] drainToBytes(InputStream in, int maxLines) throws IOException {
    StringBuilder sb = new StringBuilder();
    int count = 0;
    String line;
    while (count < maxLines && (line = readPhysicalLine(in)) != null) {
      sb.append(line).append('\n');
      count++;
    }
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }

  public void reset() {
    pushBack.clear();
    pending.setLength(0);
    lineNo = 0;
  }
}
