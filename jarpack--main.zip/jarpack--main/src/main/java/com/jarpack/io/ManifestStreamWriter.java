package com.jarpack.io;

import com.jarpack.ManifestDocument;
import com.jarpack.fold.LineFolder;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Writes manifest documents to an output stream with correct line endings. */
public final class ManifestStreamWriter implements AutoCloseable {
  private final OutputStream out;
  private final String lineEnding;
  private long bytesWritten;

  public ManifestStreamWriter(OutputStream out) {
    this(out, "\n");
  }

  public ManifestStreamWriter(OutputStream out, String lineEnding) {
    this.out = out;
    this.lineEnding = lineEnding == null ? "\n" : lineEnding;
  }

  public void writeDocument(ManifestDocument doc) throws IOException {
    byte[] folded = LineFolder.foldDocument(doc);
    out.write(folded);
    bytesWritten += folded.length;
  }

  public void writeMainAttribute(String name, String value) throws IOException {
    writeLogicalLine(name + ": " + (value == null ? "" : value));
  }

  public void writeSectionHeader(String entryName) throws IOException {
    writeLogicalLine("Name: " + entryName);
  }

  public void writeSectionAttribute(String name, String value) throws IOException {
    writeLogicalLine(name + ": " + (value == null ? "" : value));
  }

  public void writeBlankLine() throws IOException {
    byte[] sep = lineEnding.getBytes(StandardCharsets.UTF_8);
    out.write(sep);
    bytesWritten += sep.length;
  }

  private void writeLogicalLine(String logical) throws IOException {
    int max = LineFolder.MAX_ROW;
    int pos = 0;
    while (pos < logical.length()) {
      int take = Math.min(max, logical.length() - pos);
      String chunk = logical.substring(pos, pos + take);
      if (pos > 0) {
        chunk = " " + chunk;
      }
      byte[] bytes = (chunk + lineEnding).getBytes(StandardCharsets.UTF_8);
      out.write(bytes);
      bytesWritten += bytes.length;
      pos += take;
    }
    if (logical.isEmpty()) {
      byte[] bytes = lineEnding.getBytes(StandardCharsets.UTF_8);
      out.write(bytes);
      bytesWritten += bytes.length;
    }
  }

  public long bytesWritten() {
    return bytesWritten;
  }

  @Override
  public void close() throws IOException {
    out.flush();
  }

  public static byte[] toByteArray(ManifestDocument doc) {
    try (java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream()) {
      ManifestStreamWriter w = new ManifestStreamWriter(bos);
      w.writeDocument(doc);
      w.close();
      return bos.toByteArray();
    } catch (IOException ex) {
      return LineFolder.foldDocument(doc);
    }
  }

  public void writeFromMap(Map<String, String> main) throws IOException {
    for (Map.Entry<String, String> e : main.entrySet()) {
      writeMainAttribute(e.getKey(), e.getValue());
    }
  }
}
