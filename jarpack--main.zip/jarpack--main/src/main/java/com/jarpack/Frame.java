package com.jarpack;

public final class Frame {
  private final int magic;
  private final byte[] payload;

  public Frame(int magic, byte[] payload) {
    this.magic = magic;
    this.payload = payload;
  }

  public int magic() { return magic; }
  public byte[] payload() { return payload; }
}
