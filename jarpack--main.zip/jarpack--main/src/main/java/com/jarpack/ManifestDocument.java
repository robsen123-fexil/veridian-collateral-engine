package com.jarpack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ManifestDocument {
  private final Map<String, String> main = new LinkedHashMap<>();
  private final Map<String, Map<String, String>> entries = new LinkedHashMap<>();
  private final List<String> warnings = new ArrayList<>();

  public Map<String, String> main() { return main; }
  public Map<String, Map<String, String>> entries() { return entries; }
  public List<String> warnings() { return warnings; }

  public boolean isEmpty() {
    return main.isEmpty() && entries.isEmpty();
  }

  public ManifestDocument copy() {
    ManifestDocument out = new ManifestDocument();
    out.main.putAll(main);
    for (Map.Entry<String, Map<String, String>> e : entries.entrySet()) {
      out.entries.put(e.getKey(), new LinkedHashMap<>(e.getValue()));
    }
    out.warnings.addAll(warnings);
    return out;
  }
}
