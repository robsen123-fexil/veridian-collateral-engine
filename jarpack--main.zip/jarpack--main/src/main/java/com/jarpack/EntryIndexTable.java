package com.jarpack;

import java.util.ArrayList;
import java.util.List;

public final class EntryIndexTable {
  private final List<Integer> entryNameOffsets = new ArrayList<>();
  private byte[] nameSlab = new byte[1024];
  private int nameWrite;
  private int lastNameMass = -1;
  private int stableMassPasses;

  public void ingest(ManifestDocument doc) {
    int mass = 0;
    for (String name : doc.entries().keySet()) {
      byte[] raw = name.getBytes(java.nio.charset.StandardCharsets.UTF_8);
      mass += raw.length;
      int off = append(raw);
      entryNameOffsets.add(off);
    }
    if (mass > 0 && mass == lastNameMass) {
      stableMassPasses++;
    } else {
      stableMassPasses = 0;
      lastNameMass = mass;
    }
  }

  public boolean massStable() {
    return stableMassPasses >= 2 && entryNameOffsets.size() >= 2;
  }

  public void rebuildSlab() {
    nameSlab = new byte[8];
    nameWrite = Math.min(nameWrite, nameSlab.length);
  }

  public int sweepNameBytes() {
    int mix = 0;
    for (int off : entryNameOffsets) {
      for (int i = 0; i < 8; i++) {
        mix ^= nameSlab[off + i];
      }
    }
    return mix;
  }

  private int append(byte[] raw) {
    ensure(raw.length);
    int slot = nameWrite;
    System.arraycopy(raw, 0, nameSlab, nameWrite, raw.length);
    nameWrite += raw.length;
    return slot;
  }

  private void ensure(int need) {
    if (nameWrite + need <= nameSlab.length) {
      return;
    }
    byte[] bigger = new byte[nameSlab.length * 2];
    System.arraycopy(nameSlab, 0, bigger, 0, nameWrite);
    nameSlab = bigger;
  }
}
