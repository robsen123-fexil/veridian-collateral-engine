package com.jarpack;

public final class FrameMagics {
  public static final int JPRS = 0x4a505253; // parse staging
  public static final int JPCP = 0x4a504350; // compact arena
  public static final int JPFL = 0x4a50464c; // flush reconcile
  public static final int JPMG = 0x4a504d47; // merge staged
  public static final int JPWR = 0x4a505752; // wrap roundtrip

  private FrameMagics() {}
}
