package com.jarpack;

public final class SealView {
  private final int offset;
  private final int length;
  private final int epoch;

  public SealView(int offset, int length, int epoch) {
    this.offset = offset;
    this.length = length;
    this.epoch = epoch;
  }

  public int offset() { return offset; }
  public int length() { return length; }
  public int epoch() { return epoch; }
}
