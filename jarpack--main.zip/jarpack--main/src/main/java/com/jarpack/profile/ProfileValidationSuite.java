package com.jarpack.profile;

import com.jarpack.ManifestDocument;
import com.jarpack.validate.ManifestRuleEngine;
import com.jarpack.validate.ValidationIssue;
import com.jarpack.validate.ValidationResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Profile-specific cross-attribute validation beyond generic manifest rules. */
public final class ProfileValidationSuite {
  private static final Pattern DOTTED_CLASS = Pattern.compile(
      "^[\\w$]+(\\.[\\w$]+)*$");
  private static final Pattern OSGI_SYMBOLIC = Pattern.compile(
      "^[a-zA-Z0-9._-]+$");
  private static final Pattern OSGI_VERSION = Pattern.compile(
      "\\d+(\\.\\d+)*(\\.\\w+)?");

  private ProfileValidationSuite() {}

  public static ValidationResult validate(ManifestDocument doc) {
    ValidationResult base = ManifestRuleEngine.validate(doc);
    JarProfileDetector.DetectionResult detection = JarProfileDetector.detect(doc);
    for (JarProfileDetector.ProfileMatch match : detection.matches()) {
      applyProfileRules(doc, match.type(), base);
    }
    return base;
  }

  private static void applyProfileRules(ManifestDocument doc, JarType type, ValidationResult out) {
    switch (type) {
      case EXECUTABLE:
        checkExecutable(doc, out);
        break;
      case JAVA_AGENT:
      case DYNAMIC_AGENT:
        checkAgent(doc, out);
        break;
      case OSGI_BUNDLE:
        checkOsgi(doc, out);
        break;
      case SPRING_BOOT:
        checkSpringBoot(doc, out);
        break;
      case SIGNED:
        checkSigned(doc, out);
        break;
      case MULTI_RELEASE:
        checkMultiRelease(doc, out);
        break;
      default:
        break;
    }
  }

  private static void checkExecutable(ManifestDocument doc, ValidationResult out) {
    String main = doc.main().get("Main-Class");
    if (main == null || main.isEmpty()) {
      out.add(ValidationIssue.error("profile-executable", "missing-main-class"));
      return;
    }
    if (!DOTTED_CLASS.matcher(main).matches()) {
      out.add(ValidationIssue.error("profile-executable", "invalid-main-class:" + main));
    }
  }

  private static void checkAgent(ManifestDocument doc, ValidationResult out) {
    String premain = doc.main().get("Premain-Class");
    String agent = doc.main().get("Agent-Class");
    if (premain == null && agent == null) {
      out.add(ValidationIssue.error("profile-agent", "missing-agent-entrypoint"));
    }
    if (premain != null && !DOTTED_CLASS.matcher(premain).matches()) {
      out.add(ValidationIssue.error("profile-agent", "invalid-premain:" + premain));
    }
    if (agent != null && !DOTTED_CLASS.matcher(agent).matches()) {
      out.add(ValidationIssue.error("profile-agent", "invalid-agent:" + agent));
    }
    String canRedefine = doc.main().get("Can-Redefine-Classes");
    String canRetransform = doc.main().get("Can-Retransform-Classes");
    if (canRedefine != null && !isBooleanFlag(canRedefine)) {
      out.add(ValidationIssue.warning("profile-agent", "invalid-can-redefine"));
    }
    if (canRetransform != null && !isBooleanFlag(canRetransform)) {
      out.add(ValidationIssue.warning("profile-agent", "invalid-can-retransform"));
    }
  }

  private static void checkOsgi(ManifestDocument doc, ValidationResult out) {
    String symbolic = doc.main().get("Bundle-SymbolicName");
    if (symbolic == null || symbolic.isEmpty()) {
      out.add(ValidationIssue.error("profile-osgi", "missing-bundle-symbolicname"));
      return;
    }
    String baseName = symbolic.split(";")[0].trim();
    if (!OSGI_SYMBOLIC.matcher(baseName).matches()) {
      out.add(ValidationIssue.error("profile-osgi", "invalid-symbolicname"));
    }
    String version = doc.main().get("Bundle-Version");
    if (version != null && !OSGI_VERSION.matcher(version).matches()) {
      out.add(ValidationIssue.warning("profile-osgi", "suspicious-bundle-version"));
    }
    String imports = doc.main().get("Import-Package");
    if (imports != null) {
      validateOsgiHeaderList("Import-Package", imports, out);
    }
    String exports = doc.main().get("Export-Package");
    if (exports != null) {
      validateOsgiHeaderList("Export-Package", exports, out);
    }
  }

  private static void checkSpringBoot(ManifestDocument doc, ValidationResult out) {
    if (!doc.main().containsKey("Spring-Boot-Classes")) {
      out.add(ValidationIssue.error("profile-spring", "missing-spring-boot-classes"));
    }
    String start = doc.main().get("Start-Class");
    if (start != null && !DOTTED_CLASS.matcher(start).matches()) {
      out.add(ValidationIssue.error("profile-spring", "invalid-start-class"));
    }
  }

  private static void checkSigned(ManifestDocument doc, ValidationResult out) {
    if (!doc.main().containsKey("Signature-Version")) {
      out.add(ValidationIssue.warning("profile-signed", "missing-signature-version"));
    }
    boolean hasDigestSection = false;
    for (Map.Entry<String, java.util.Map<String, String>> e : doc.entries().entrySet()) {
      for (String key : e.getValue().keySet()) {
        if (key.toUpperCase(Locale.ROOT).contains("DIGEST")) {
          hasDigestSection = true;
          break;
        }
      }
    }
    if (!hasDigestSection) {
      out.add(ValidationIssue.warning("profile-signed", "no-digest-sections"));
    }
  }

  private static void checkMultiRelease(ManifestDocument doc, ValidationResult out) {
    String flag = doc.main().get("Multi-Release");
    if (!"true".equalsIgnoreCase(flag)) {
      out.add(ValidationIssue.warning("profile-multirelease", "flag-not-true"));
    }
  }

  private static boolean isBooleanFlag(String value) {
    return "true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value);
  }

  private static void validateOsgiHeaderList(String header, String value, ValidationResult sink) {
    String[] parts = value.split(",");
    for (String part : parts) {
      String token = part.trim();
      if (token.isEmpty()) {
        sink.add(ValidationIssue.warning("profile-osgi", "empty-" + header + "-token"));
        continue;
      }
      String pkg = token.split(";")[0].trim();
      if (pkg.isEmpty() || pkg.contains(" ")) {
        sink.add(ValidationIssue.warning("profile-osgi", "malformed-" + header + ":" + token));
      }
    }
  }
}
