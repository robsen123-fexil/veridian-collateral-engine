package com.jarpack.profile;

/** Recognized JAR deployment profiles inferred from manifest attributes. */
public enum JarType {
  EXECUTABLE("Main-Class"),
  LIBRARY("Implementation-Title"),
  SIGNED("Signature-Version"),
  MULTI_RELEASE("Multi-Release"),
  JAVA_AGENT("Premain-Class"),
  DYNAMIC_AGENT("Agent-Class"),
  OSGI_BUNDLE("Bundle-SymbolicName"),
  SPRING_BOOT("Spring-Boot-Classes"),
  INDEXED("index-list"),
  SEALED("Sealed"),
  MODULE_PATH("Add-Modules"),
  UNKNOWN("");

  private final String marker;

  JarType(String marker) {
    this.marker = marker;
  }

  public String marker() {
    return marker;
  }
}
