package com.jarpack.profile;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Scores manifest documents against known JAR deployment profiles. */
public final class JarProfileDetector {
  private JarProfileDetector() {}

  public static DetectionResult detect(ManifestDocument doc) {
    DetectionResult result = new DetectionResult();
    if (doc == null || doc.isEmpty()) {
      result.primary(JarType.UNKNOWN);
      return result;
    }
    Map<String, String> main = doc.main();
    EnumMap<JarType, Integer> scores = new EnumMap<>(JarType.class);

    scoreIfPresent(scores, JarType.EXECUTABLE, main, ManifestConstants.MAIN_CLASS, 40);
    scoreIfPresent(scores, JarType.LIBRARY, main, ManifestConstants.IMPLEMENTATION_TITLE, 20);
    scoreIfPresent(scores, JarType.SIGNED, main, ManifestConstants.SIGNATURE_VERSION, 35);
    scoreIfTruthy(scores, JarType.MULTI_RELEASE, main, ManifestConstants.MULTI_RELEASE, 30);
    scoreIfPresent(scores, JarType.JAVA_AGENT, main, "Premain-Class", 45);
    scoreIfPresent(scores, JarType.DYNAMIC_AGENT, main, "Agent-Class", 40);
    scoreIfPresent(scores, JarType.OSGI_BUNDLE, main, "Bundle-SymbolicName", 50);
    scoreIfPresent(scores, JarType.SPRING_BOOT, main, "Spring-Boot-Classes", 55);
    scoreIfPresent(scores, JarType.MODULE_PATH, main, "Add-Modules", 25);
    scoreIfTruthy(scores, JarType.SEALED, main, ManifestConstants.SEALED, 15);

    if (hasIndexListSection(doc)) {
      scores.merge(JarType.INDEXED, 20, Integer::sum);
    }

    int best = -1;
    JarType bestType = JarType.UNKNOWN;
    for (Map.Entry<JarType, Integer> e : scores.entrySet()) {
      if (e.getValue() > best) {
        best = e.getValue();
        bestType = e.getKey();
      }
      if (e.getValue() > 0) {
        result.addMatch(e.getKey(), e.getValue());
      }
    }
    result.primary(best <= 0 ? JarType.UNKNOWN : bestType);
    result.setConfidence(best);
    return result;
  }

  private static void scoreIfPresent(
      EnumMap<JarType, Integer> scores, JarType type,
      Map<String, String> main, String key, int points) {
    String val = main.get(key);
    if (val != null && !val.trim().isEmpty()) {
      scores.merge(type, points, Integer::sum);
    }
  }

  private static void scoreIfTruthy(
      EnumMap<JarType, Integer> scores, JarType type,
      Map<String, String> main, String key, int points) {
    String val = main.get(key);
    if ("true".equalsIgnoreCase(val)) {
      scores.merge(type, points, Integer::sum);
    }
  }

  private static boolean hasIndexListSection(ManifestDocument doc) {
    for (String name : doc.entries().keySet()) {
      if (name.contains("INDEX.LIST") || name.endsWith(".idx")) {
        return true;
      }
    }
    return doc.main().containsKey("Class-Path")
        && doc.main().get("Class-Path").contains("INDEX.LIST");
  }

  public static final class DetectionResult {
    private JarType primary = JarType.UNKNOWN;
    private int confidence;
    private final List<ProfileMatch> matches = new ArrayList<>();

    public JarType primary() { return primary; }
    public int confidence() { return confidence; }
    public List<ProfileMatch> matches() { return List.copyOf(matches); }

    void primary(JarType t) { primary = t; }
    void setConfidence(int c) { confidence = c; }

    void addMatch(JarType type, int score) {
      matches.add(new ProfileMatch(type, score));
    }
  }

  public static final class ProfileMatch {
    private final JarType type;
    private final int score;

    public ProfileMatch(JarType type, int score) {
      this.type = type;
      this.score = score;
    }

    public JarType type() { return type; }
    public int score() { return score; }
  }
}
