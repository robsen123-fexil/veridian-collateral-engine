package com.jarpack.normalize;

import com.jarpack.ManifestDocument;

import java.util.Map;

public final class WhitespaceNormalizer {
  public void normalizeMain(ManifestDocument doc) {
    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      if (e.getValue() != null) {
        e.setValue(e.getValue().trim().replaceAll("\\s+", " "));
      }
    }
  }

  public void normalizeSections(ManifestDocument doc) {
    for (Map<String, String> section : doc.entries().values()) {
      if (section == null) continue;
      for (Map.Entry<String, String> e : section.entrySet()) {
        if (e.getValue() != null) {
          e.setValue(e.getValue().trim());
        }
      }
    }
  }
}
