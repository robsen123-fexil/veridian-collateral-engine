package com.jarpack.normalize;

import com.jarpack.ManifestDocument;
import com.jarpack.attr.StandardAttributeRegistry;
import com.jarpack.core.ManifestAttributeCatalog;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Full normalization pass applying header order, whitespace, and attribute handlers. */
public final class FullNormalizePass {
  private final StandardAttributeRegistry registry = new StandardAttributeRegistry();
  private boolean trimValues = true;
  private boolean reorderHeaders = true;
  private boolean dropUnknown = false;

  public FullNormalizePass trimValues(boolean value) {
    this.trimValues = value;
    return this;
  }

  public FullNormalizePass reorderHeaders(boolean value) {
    this.reorderHeaders = value;
    return this;
  }

  public FullNormalizePass dropUnknown(boolean value) {
    this.dropUnknown = value;
    return this;
  }

  public NormalizeReport apply(ManifestDocument doc) {
    NormalizeReport report = new NormalizeReport();
    if (doc == null) {
      report.addNote("null-document");
      return report;
    }
    if (trimValues) {
      report.addTrimmed(trimMain(doc));
      report.addTrimmed(trimSections(doc));
    }
    if (reorderHeaders) {
      HeaderOrderPolicy.standard().apply(doc);
      report.setReordered(true);
    }
    for (Map.Entry<String, String> e : new ArrayList<>(doc.main().entrySet())) {
      if (dropUnknown && !ManifestAttributeCatalog.isKnown(e.getKey())) {
        doc.main().remove(e.getKey());
        report.recordDropped(e.getKey());
        continue;
      }
      registry.applyAll(doc);
      report.recordHandler(e.getKey());
    }
    WhitespaceNormalizer ws = new WhitespaceNormalizer();
    ws.normalizeMain(doc);
    ws.normalizeSections(doc);
    report.setComplete(true);
    return report;
  }

  private int trimMain(ManifestDocument doc) {
    int count = 0;
    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      String trimmed = e.getValue() == null ? "" : e.getValue().trim();
      if (!trimmed.equals(e.getValue())) {
        e.setValue(trimmed);
        count++;
      }
    }
    return count;
  }

  private int trimSections(ManifestDocument doc) {
    int count = 0;
    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      for (Map.Entry<String, String> attr : section.getValue().entrySet()) {
        String trimmed = attr.getValue() == null ? "" : attr.getValue().trim();
        if (!trimmed.equals(attr.getValue())) {
          attr.setValue(trimmed);
          count++;
        }
      }
    }
    return count;
  }

  public static final class NormalizeReport {
    private final List<String> notes = new ArrayList<>();
    private final List<String> dropped = new ArrayList<>();
    private final List<String> handlers = new ArrayList<>();
    private int trimmed;
    private boolean reordered;
    private boolean complete;

    void addNote(String n) { notes.add(n); }
    void addTrimmed(int c) { trimmed += c; }
    void recordDropped(String attr) { dropped.add(attr); }
    void recordHandler(String attr) { handlers.add(attr); }
    void setReordered(boolean v) { reordered = v; }
    void setComplete(boolean v) { complete = v; }

    public int trimmedCount() { return trimmed; }
    public boolean reordered() { return reordered; }
    public boolean complete() { return complete; }
    public List<String> droppedAttributes() { return List.copyOf(dropped); }
  }
}
