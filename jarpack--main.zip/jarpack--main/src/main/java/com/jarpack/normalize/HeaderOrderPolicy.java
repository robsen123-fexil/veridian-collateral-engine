package com.jarpack.normalize;

import com.jarpack.core.ManifestConstants;
import com.jarpack.ManifestDocument;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Reorders main attributes to canonical header order. */
public final class HeaderOrderPolicy {
  private static final List<String> ORDER = List.of(
      ManifestConstants.MANIFEST_VERSION,
      ManifestConstants.MAIN_CLASS,
      ManifestConstants.CLASS_PATH,
      ManifestConstants.SEALED,
      ManifestConstants.MULTI_RELEASE
  );

  public static HeaderOrderPolicy standard() { return new HeaderOrderPolicy(); }

  public void apply(ManifestDocument doc) {
    Map<String, String> main = doc.main();
    Map<String, String> ordered = new LinkedHashMap<>();
    for (String key : orderMainKeys(main.keySet())) {
      ordered.put(key, main.get(key));
    }
    main.clear();
    main.putAll(ordered);
  }

  public List<String> orderMainKeys(java.util.Collection<String> keys) {
    Map<String, String> placeholder = new LinkedHashMap<>();
    for (String key : keys) {
      placeholder.put(key, "");
    }
    List<String> ordered = new ArrayList<>();
    for (String key : ORDER) {
      if (placeholder.containsKey(key)) {
        ordered.add(key);
      }
    }
    List<String> rest = new ArrayList<>(keys);
    rest.removeAll(ordered);
    rest.sort(String::compareToIgnoreCase);
    ordered.addAll(rest);
    return ordered;
  }

  public List<String> orderSectionKeys(java.util.Collection<String> keys) {
    List<String> ordered = new ArrayList<>();
    if (keys.contains(ManifestConstants.NAME)) {
      ordered.add(ManifestConstants.NAME);
    }
    List<String> rest = new ArrayList<>(keys);
    rest.remove(ManifestConstants.NAME);
    rest.sort(String::compareToIgnoreCase);
    ordered.addAll(rest);
    return ordered;
  }
}
