package com.jarpack.normalize;

import com.jarpack.ManifestDocument;
import com.jarpack.attr.StandardAttributeRegistry;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Produces canonical manifest ordering and normalized attribute values. */
public final class ManifestCanonicalizer {
  private final StandardAttributeRegistry registry = new StandardAttributeRegistry();

  private ManifestCanonicalizer() {}

  public static ManifestDocument canonicalize(ManifestDocument input) {
    return new ManifestCanonicalizer().canonicalizeDocument(input);
  }

  private ManifestDocument canonicalizeDocument(ManifestDocument input) {
    if (input == null) {
      ManifestDocument empty = new ManifestDocument();
      empty.main().put(ManifestConstants.MANIFEST_VERSION, "1.0");
      return empty;
    }
    ManifestDocument out = new ManifestDocument();
    TreeMap<String, String> sortedMain = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    sortedMain.putAll(input.main());
    if (!sortedMain.containsKey(ManifestConstants.MANIFEST_VERSION)) {
      sortedMain.put(ManifestConstants.MANIFEST_VERSION, "1.0");
    }
    out.main().putAll(sortedMain);
    registry.applyAll(out);
    List<String> sectionNames = new ArrayList<>(input.entries().keySet());
    sectionNames.sort(String.CASE_INSENSITIVE_ORDER);
    for (String name : sectionNames) {
      Map<String, String> attrs = input.entries().get(name);
      if (attrs == null) {
        continue;
      }
      Map<String, String> sorted = new LinkedHashMap<>();
      TreeMap<String, String> tree = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
      tree.putAll(attrs);
      sorted.putAll(tree);
      out.entries().put(name, sorted);
    }
    out.warnings().addAll(input.warnings());
    return out;
  }

  public static String normalizeValue(String key, String value) {
    if (value == null) {
      return "";
    }
    String trimmed = value.trim();
    if (ManifestConstants.CLASS_PATH.equalsIgnoreCase(key)) {
      return trimmed.replaceAll("\\s+", " ");
    }
    if ("Permissions".equalsIgnoreCase(key)) {
      return trimmed.replace("\r\n", "\n");
    }
    return trimmed;
  }

  public static boolean isCanonicalOrder(ManifestDocument doc) {
    String prev = null;
    for (String key : doc.main().keySet()) {
      if (prev != null && key.compareToIgnoreCase(prev) < 0) {
        return false;
      }
      prev = key;
    }
    return true;
  }
}
