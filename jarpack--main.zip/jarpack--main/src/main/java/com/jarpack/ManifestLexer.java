package com.jarpack;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Tokenizes manifest text with JAR line-folding rules. */
public final class ManifestLexer {
  private ManifestLexer() {}

  public static List<String> tokenizeLines(byte[] raw) {
    if (raw == null || raw.length == 0) {
      return Collections.emptyList();
    }
    String text = new String(raw, StandardCharsets.UTF_8);
    String[] physical = text.split("\r?\n", -1);
    List<String> logical = new ArrayList<>();
    StringBuilder current = new StringBuilder();
    for (String line : physical) {
      if (line.startsWith(" ") && !current.isEmpty()) {
        current.append(line.substring(1));
      } else {
        if (!current.isEmpty()) {
          logical.add(current.toString());
        }
        current = new StringBuilder(line);
      }
    }
    if (!current.isEmpty()) {
      logical.add(current.toString());
    }
    return logical;
  }

  public static List<ManifestToken> tokenize(byte[] raw) {
    List<ManifestToken> out = new ArrayList<>();
    boolean inSection = false;
    for (String line : tokenizeLines(raw)) {
      if (line.isEmpty()) {
        inSection = false;
        out.add(ManifestToken.sectionBreak());
        continue;
      }
      int colon = line.indexOf(':');
      if (colon < 0) {
        out.add(ManifestToken.invalid(line));
        continue;
      }
      String name = line.substring(0, colon).trim();
      String value = line.substring(colon + 1).trim();
      if (!inSection && name.contains("/")) {
        inSection = true;
      }
      out.add(ManifestToken.pair(name, value, inSection));
    }
    return out;
  }
}
