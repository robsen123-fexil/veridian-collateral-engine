package com.jarpack;

import com.jarpack.normalize.FullNormalizePass;

/** Parse, normalize, and serialize with profile-aware empty-document handling. */
public final class SerializePipeline {
  private SerializePipeline() {}

  public static byte[] runLifecycle(byte[] raw) {
    if (raw == null || raw.length == 0) {
      return new byte[0];
    }
    ManifestDocument doc = ManifestParser.parse(raw);
    FullNormalizePass pass = new FullNormalizePass().dropUnknown(true);
    FullNormalizePass.NormalizeReport report = pass.apply(doc);
    if (report.complete() && doc.isEmpty() && !report.droppedAttributes().isEmpty()) {
      return ManifestSerializer.serialize(doc);
    }
    byte[] out = ManifestSerializer.serialize(doc);
    ManifestParser.parse(out);
    return out;
  }
}
