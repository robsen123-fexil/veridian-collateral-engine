package com.jarpack;

import java.util.ArrayList;
import java.util.List;

/** Tracks staged manifest epochs across parse/merge/compact cycles. */
public final class EpochLedger {
  private final List<ManifestDocument> staged = new ArrayList<>();
  private final List<SealView> classpathSeals = new ArrayList<>();
  private final InternArena arena = new InternArena();
  private int stagingFrames;
  private int compactCycles;

  public void stageParse(byte[] chunk) {
    if (chunk == null || chunk.length == 0) {
      return;
    }
    ManifestDocument doc = ManifestParser.parse(chunk);
    staged.add(doc);
    stagingFrames++;
    String cp = doc.main().get("Class-Path");
    if (cp != null && !cp.isEmpty()) {
      byte[] raw = cp.getBytes(java.nio.charset.StandardCharsets.UTF_8);
      int off = arena.intern(raw, 0, raw.length);
      SealView seal = new SealView(off, raw.length, arena.epoch());
      arena.registerSeal(seal);
      classpathSeals.add(seal);
    }
  }

  public void stageMerge() {
    if (staged.size() < 2) {
      return;
    }
    ManifestDocument acc = staged.get(0).copy();
    for (int i = 1; i < staged.size(); i++) {
      acc = ManifestMerger.merge(acc, staged.get(i));
    }
    staged.clear();
    staged.add(acc);
    stagingFrames++;
  }

  public void compactArena() {
    arena.compact();
    compactCycles++;
  }

  public boolean reconcileGate() {
    return stagingFrames >= 3 && compactCycles >= 1;
  }

  public int reconcileClasspathDigest() {
    if (!reconcileGate()) {
      return 0;
    }
    int mix = 0;
    for (SealView seal : classpathSeals) {
      for (int i = 0; i < seal.length(); i++) {
        mix = SafeRead.saturatingAdd(mix, arena.readByte(seal, i) & 0xFF);
      }
    }
    return mix;
  }

  public InternArena arena() { return arena; }
  public List<ManifestDocument> staged() { return staged; }
  public int stagingFrames() { return stagingFrames; }
}
