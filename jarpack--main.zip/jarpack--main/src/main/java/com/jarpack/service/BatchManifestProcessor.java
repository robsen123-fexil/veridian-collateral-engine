package com.jarpack.service;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.archive.JarManifestReader;
import com.jarpack.profile.ProfileValidationSuite;
import com.jarpack.reconcile.ManifestReconciler;
import com.jarpack.validate.ValidationResult;
import com.jarpack.writer.ManifestComposer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Processes batches of manifest inputs with optional parallel validation. */
public final class BatchManifestProcessor {
  private int parallelism = 1;
  private boolean reconcilePairs = false;

  public BatchManifestProcessor parallelism(int threads) {
    this.parallelism = Math.max(1, threads);
    return this;
  }

  public BatchManifestProcessor reconcilePairs(boolean value) {
    this.reconcilePairs = value;
    return this;
  }

  public BatchResult processBytes(List<byte[]> inputs) {
    BatchResult result = new BatchResult();
    if (inputs == null || inputs.isEmpty()) {
      return result;
    }
    ExecutorService pool = Executors.newFixedThreadPool(parallelism);
    try {
      List<Future<ItemResult>> futures = new ArrayList<>();
      for (int i = 0; i < inputs.size(); i++) {
        final int index = i;
        final byte[] data = inputs.get(i);
        futures.add(pool.submit(() -> processOne(index, data)));
      }
      for (Future<ItemResult> f : futures) {
        ItemResult item = f.get();
        result.add(item);
      }
      if (reconcilePairs && inputs.size() >= 2) {
        reconcileAdjacent(inputs, result);
      }
    } catch (Exception ex) {
      result.addError("batch-failed:" + ex.getMessage());
    } finally {
      pool.shutdown();
    }
    return result;
  }

  public BatchResult processDirectory(Path dir) throws IOException {
    List<byte[]> inputs = new ArrayList<>();
    if (!Files.isDirectory(dir)) {
      BatchResult empty = new BatchResult();
      empty.addError("not-a-directory");
      return empty;
    }
    try (var stream = Files.walk(dir, 2)) {
      stream.filter(p -> p.toString().endsWith(".mf") || p.toString().endsWith(".MF"))
          .forEach(p -> {
            try {
              inputs.add(Files.readAllBytes(p));
            } catch (IOException ignored) {
              // skip unreadable files
            }
          });
    }
    return processBytes(inputs);
  }

  public BatchResult processJars(List<Path> jarPaths) {
    List<byte[]> manifests = new ArrayList<>();
    BatchResult meta = new BatchResult();
    for (Path jar : jarPaths) {
      try {
        ManifestDocument doc = JarManifestReader.read(jar);
        manifests.add(new ManifestComposer().compose(doc));
      } catch (Exception ex) {
        try {
          manifests.add(com.jarpack.archive.JarManifestReader.readRawBytes(
              new java.util.zip.ZipFile(jar.toFile()),
              com.jarpack.archive.ManifestEntryLocator.DEFAULT_MANIFEST));
        } catch (Exception ex2) {
          meta.addError("jar-read-failed:" + jar);
        }
      }
    }
    BatchResult result = processBytes(manifests);
    result.errors().addAll(meta.errors());
    return result;
  }

  private ItemResult processOne(int index, byte[] data) {
    ItemResult item = new ItemResult(index);
    if (data == null) {
      item.addIssue("null-input");
      return item;
    }
    ManifestDocument doc = ManifestParser.parse(data);
    item.setMainAttributes(doc.main().size());
    item.setSections(doc.entries().size());
    ValidationResult vr = ProfileValidationSuite.validate(doc);
    item.setErrors(vr.errorCount());
    item.setWarnings(vr.warningCount());
    item.setValid(vr.isValid());
    return item;
  }

  private void reconcileAdjacent(List<byte[]> inputs, BatchResult result) throws IOException {
    ManifestReconciler reconciler = new ManifestReconciler();
    for (int i = 0; i < inputs.size() - 1; i++) {
      ManifestReconciler.ReconcileResult rr =
          reconciler.reconcile(inputs.get(i), inputs.get(i + 1));
      result.addReconcileSummary(i, rr);
    }
  }

  public static final class BatchResult {
    private final List<ItemResult> items = new ArrayList<>();
    private final List<String> errors = new ArrayList<>();
    private final Map<Integer, String> reconcileSummaries = new LinkedHashMap<>();

    public void add(ItemResult item) { items.add(item); }
    public void addError(String err) { errors.add(err); }
    public void addReconcileSummary(int index, ManifestReconciler.ReconcileResult rr) {
      reconcileSummaries.put(index, "changes=" + rr.conflictLog().size()
          + ",errors=" + rr.validationErrors());
    }

    public List<ItemResult> items() { return List.copyOf(items); }
    public List<String> errors() { return errors; }
    public int successCount() {
      return (int) items.stream().filter(ItemResult::valid).count();
    }
  }

  public static final class ItemResult {
    private final int index;
    private final List<String> issues = new ArrayList<>();
    private int mainAttributes;
    private int sections;
    private int errors;
    private int warnings;
    private boolean valid;

    public ItemResult(int index) { this.index = index; }
    public int index() { return index; }
    public boolean valid() { return valid; }
    public int errors() { return errors; }
    public int warnings() { return warnings; }

    void addIssue(String issue) { issues.add(issue); }
    void setMainAttributes(int v) { mainAttributes = v; }
    void setSections(int v) { sections = v; }
    void setErrors(int v) { errors = v; }
    void setWarnings(int v) { warnings = v; }
    void setValid(boolean v) { valid = v; }
  }
}
