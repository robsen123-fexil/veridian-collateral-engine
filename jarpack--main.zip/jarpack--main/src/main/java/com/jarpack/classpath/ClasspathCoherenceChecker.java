package com.jarpack.classpath;

import com.jarpack.ManifestDocument;
import com.jarpack.archive.ZipEntryCatalog;

import java.util.ArrayList;
import java.util.List;

/** Checks Class-Path entries against a JAR entry catalog. */
public final class ClasspathCoherenceChecker {
  private ClasspathCoherenceChecker() {}

  public static List<String> checkAgainstCatalog(ManifestDocument doc, ZipEntryCatalog catalog) {
    List<String> issues = new ArrayList<>();
    List<String> entries = ClasspathOrderResolver.ordered(doc);
    for (String entry : entries) {
      String normalized = entry.replace('\\', '/');
      if (normalized.endsWith("/")) {
        issues.add("trailing-slash:" + entry);
      }
      if (normalized.contains(" ")) {
        issues.add("whitespace:" + entry);
      }
      if (catalog != null && !catalog.contains(normalized) && !normalized.contains("://")) {
        issues.add("missing-in-jar:" + entry);
      }
    }
    int dupes = ClasspathOrderResolver.duplicateCount(doc);
    if (dupes > 0) {
      issues.add("duplicate-entries:" + dupes);
    }
    ClasspathGraph graph = ClasspathGraph.fromManifest(doc);
    List<String> cycles = graph.detectCycles();
    issues.addAll(cycles);
    return issues;
  }

  public static boolean isCoherent(ManifestDocument doc, ZipEntryCatalog catalog) {
    return checkAgainstCatalog(doc, catalog).isEmpty();
  }
}
