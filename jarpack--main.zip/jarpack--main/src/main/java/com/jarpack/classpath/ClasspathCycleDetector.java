package com.jarpack.classpath;

import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Detects circular Class-Path references among jar paths. */
public final class ClasspathCycleDetector {
  public List<String> findCycles(List<Path> entries) {
    List<String> cycles = new ArrayList<>();
    Set<String> visiting = new HashSet<>();
    Set<String> visited = new HashSet<>();
    Deque<String> stack = new ArrayDeque<>();
    for (Path p : entries) {
      dfs(p.normalize().toString(), visiting, visited, stack, cycles);
    }
    return cycles;
  }

  private void dfs(String node, Set<String> visiting, Set<String> visited,
                   Deque<String> stack, List<String> cycles) {
    if (visited.contains(node)) return;
    if (!visiting.add(node)) {
      cycles.add(String.join(" -> ", stack) + " -> " + node);
      return;
    }
    stack.addLast(node);
    visiting.remove(node);
    visited.add(node);
    stack.removeLast();
  }
}
