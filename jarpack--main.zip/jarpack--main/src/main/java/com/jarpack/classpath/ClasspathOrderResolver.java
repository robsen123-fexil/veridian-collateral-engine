package com.jarpack.classpath;
import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;
import java.util.*;
public final class ClasspathOrderResolver {
  private ClasspathOrderResolver() {}
  public static List<String> ordered(ManifestDocument doc) {
    List<String> raw = ManifestMerger.splitClasspath(doc.main().get("Class-Path"));
    LinkedHashSet<String> seen = new LinkedHashSet<>();
    List<String> out = new ArrayList<>();
    for (String e : raw) {
      if (seen.add(e)) out.add(e);
    }
    return out;
  }
  public static int duplicateCount(ManifestDocument doc) {
    List<String> raw = ManifestMerger.splitClasspath(doc.main().get("Class-Path"));
    return raw.size() - ordered(doc).size();
  }
}
