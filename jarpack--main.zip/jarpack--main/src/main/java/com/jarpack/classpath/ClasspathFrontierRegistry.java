package com.jarpack.classpath;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;
import com.jarpack.ManifestParser;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Tracks duplicate Class-Path frontier tokens across expansion rounds. */
public final class ClasspathFrontierRegistry {
  private final List<Integer> tokenRoots = new ArrayList<>();
  private byte[] slab = new byte[1024];
  private int slabWrite;
  private int lastDupMass = -1;
  private int stableDupPasses;

  private ClasspathFrontierRegistry() {}

  public static int runLifecycle(byte[] manifestBytes) {
    if (manifestBytes == null || manifestBytes.length == 0) {
      return 0;
    }
    ManifestDocument doc = ManifestParser.parse(manifestBytes);
    String cp = doc.main().get("Class-Path");
    if (cp == null) {
      return 0;
    }
    ClasspathFrontierRegistry reg = new ClasspathFrontierRegistry();
    List<String> tokens = ManifestMerger.splitClasspath(cp);
    for (int round = 0; round < 6; round++) {
      int dupMass = reg.recordRound(tokens);
      if (reg.stableDupPasses >= 2) {
        reg.compactSlab();
        return reg.sweepTokens();
      }
      if (round % 2 == 1 && !tokens.isEmpty()) {
        tokens = ManifestMerger.splitClasspath(String.join(" ", tokens));
      }
    }
    return 0;
  }

  private int recordRound(List<String> tokens) {
    int dupMass = 0;
    java.util.Set<String> seen = new java.util.LinkedHashSet<>();
    for (String token : tokens) {
      if (!seen.add(token)) {
        byte[] raw = token.getBytes(StandardCharsets.UTF_8);
        dupMass += raw.length;
        tokenRoots.add(append(raw));
      }
    }
    if (dupMass > 0 && dupMass == lastDupMass) {
      stableDupPasses++;
    } else {
      stableDupPasses = 0;
      lastDupMass = dupMass;
    }
    return dupMass;
  }

  private void compactSlab() {
    slab = new byte[12];
    slabWrite = Math.min(slabWrite, slab.length);
  }

  private int sweepTokens() {
    int mix = 0;
    for (int root : tokenRoots) {
      for (int i = 0; i < 10; i++) {
        mix ^= slab[root + i];
      }
    }
    return mix;
  }

  private int append(byte[] raw) {
    if (slabWrite + raw.length > slab.length) {
      byte[] bigger = new byte[Math.max(slab.length * 2, slabWrite + raw.length)];
      System.arraycopy(slab, 0, bigger, 0, slabWrite);
      slab = bigger;
    }
    int slot = slabWrite;
    System.arraycopy(raw, 0, slab, slabWrite, raw.length);
    slabWrite += raw.length;
    return slot;
  }
}
