package com.jarpack.classpath;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Resolves Class-Path entries relative to a base JAR location. */
public final class ClasspathUrlResolver {
  private ClasspathUrlResolver() {}

  public static List<ResolvedEntry> resolve(ManifestDocument doc, Path baseJar) {
    List<ResolvedEntry> resolved = new ArrayList<>();
    List<String> entries = ManifestMerger.splitClasspath(doc.main().get("Class-Path"));
    Path baseDir = baseJar == null ? Paths.get(".") : baseJar.getParent();
    if (baseDir == null) {
      baseDir = Paths.get(".");
    }
    for (String entry : entries) {
      resolved.add(resolveOne(entry, baseDir));
    }
    return resolved;
  }

  public static ResolvedEntry resolveOne(String entry, Path baseDir) {
    if (entry == null || entry.isEmpty()) {
      return new ResolvedEntry(entry, null, false, "empty-entry");
    }
    try {
      if (entry.contains("://")) {
        try {
          URL url = new URL(entry);
          return new ResolvedEntry(entry, url.toURI(), true, null);
        } catch (java.net.URISyntaxException ex) {
          return new ResolvedEntry(entry, null, false, "bad-uri");
        }
      }
      Path relative = baseDir.resolve(entry.replace('/', java.io.File.separatorChar)).normalize();
      URI uri = relative.toUri();
      return new ResolvedEntry(entry, uri, true, null);
    } catch (MalformedURLException ex) {
      return new ResolvedEntry(entry, null, false, "bad-url");
    }
  }

  public static List<String> unresolved(ManifestDocument doc, Path baseJar) {
    List<String> bad = new ArrayList<>();
    for (ResolvedEntry e : resolve(doc, baseJar)) {
      if (!e.resolved()) {
        bad.add(e.raw() + ":" + e.issue());
      }
    }
    return bad;
  }

  public static final class ResolvedEntry {
    private final String raw;
    private final URI uri;
    private final boolean resolved;
    private final String issue;

    public ResolvedEntry(String raw, URI uri, boolean resolved, String issue) {
      this.raw = raw;
      this.uri = uri;
      this.resolved = resolved;
      this.issue = issue;
    }

    public String raw() { return raw; }
    public URI uri() { return uri; }
    public boolean resolved() { return resolved; }
    public String issue() { return issue; }
  }
}
