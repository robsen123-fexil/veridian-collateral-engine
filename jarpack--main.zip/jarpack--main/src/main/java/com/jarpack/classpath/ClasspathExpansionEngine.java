package com.jarpack.classpath;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;
import com.jarpack.archive.ZipEntryCatalog;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Expands Class-Path entries by following nested manifest references
 * discovered inside a JAR catalog.
 */
public final class ClasspathExpansionEngine {
  private int maxDepth = 8;
  private boolean includeUrls = true;

  public ClasspathExpansionEngine maxDepth(int depth) {
    this.maxDepth = Math.max(1, depth);
    return this;
  }

  public ClasspathExpansionEngine includeUrls(boolean value) {
    this.includeUrls = value;
    return this;
  }

  public ExpansionResult expand(ManifestDocument root, ZipEntryCatalog catalog) {
    ExpansionResult result = new ExpansionResult();
    Set<String> seen = new LinkedHashSet<>();
    List<String> frontier = ClasspathOrderResolver.ordered(root);
    int depth = 0;
    while (!frontier.isEmpty() && depth < maxDepth) {
      List<String> nextFrontier = new ArrayList<>();
      for (String entry : frontier) {
        if (!seen.add(entry)) {
          result.recordDuplicate(entry);
          continue;
        }
        result.addResolved(entry);
        if (!includeUrls && entry.contains("://")) {
          result.recordSkippedUrl(entry);
          continue;
        }
        if (catalog != null && catalog.contains(entry)) {
          List<String> nested = discoverNestedClasspath(entry, catalog);
          nextFrontier.addAll(nested);
          result.recordNested(entry, nested.size());
        }
      }
      frontier = nextFrontier;
      depth++;
    }
    if (!frontier.isEmpty()) {
      result.setTruncated(true);
      result.setRemainingDepth(frontier.size());
    }
    return result;
  }

  private List<String> discoverNestedClasspath(String jarEntry, ZipEntryCatalog catalog) {
    List<String> nested = new ArrayList<>();
    String prefix = jarEntry.endsWith("/") ? jarEntry : jarEntry + "/";
    for (String name : catalog.names()) {
      if (name.startsWith(prefix) && name.endsWith("MANIFEST.MF")) {
        nested.add(name);
      }
    }
    return nested;
  }

  public List<String> flatten(ManifestDocument doc) {
    List<String> all = new ArrayList<>();
    collect(doc, all, 0);
    return all;
  }

  private void collect(ManifestDocument doc, List<String> out, int depth) {
    if (depth >= maxDepth) {
      return;
    }
    for (String entry : ManifestMerger.splitClasspath(doc.main().get("Class-Path"))) {
      if (out.contains(entry)) {
        continue;
      }
      out.add(entry);
    }
  }

  public static final class ExpansionResult {
    private final List<String> resolved = new ArrayList<>();
    private final List<String> duplicates = new ArrayList<>();
    private final List<String> skippedUrls = new ArrayList<>();
    private final List<String> nestedNotes = new ArrayList<>();
    private boolean truncated;
    private int remainingDepth;

    void addResolved(String entry) { resolved.add(entry); }
    void recordDuplicate(String entry) { duplicates.add(entry); }
    void recordSkippedUrl(String entry) { skippedUrls.add(entry); }
    void recordNested(String entry, int count) {
      nestedNotes.add(entry + ":" + count);
    }

    public List<String> resolved() { return List.copyOf(resolved); }
    public List<String> duplicates() { return List.copyOf(duplicates); }
    public boolean truncated() { return truncated; }

    void setTruncated(boolean v) { truncated = v; }
    void setRemainingDepth(int v) { remainingDepth = v; }
  }
}
