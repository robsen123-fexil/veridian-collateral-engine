package com.jarpack.classpath;

import java.net.MalformedURLException;
import java.net.URL;

/** Parses Class-Path URL and file entries. */
public final class UrlClasspathEntry {
  private final String raw;
  private final boolean absolute;
  private final String protocol;

  public UrlClasspathEntry(String raw) {
    this.raw = raw == null ? "" : raw.trim();
    this.absolute = this.raw.startsWith("/") || this.raw.contains("://");
    this.protocol = detectProtocol(this.raw);
  }

  private static String detectProtocol(String s) {
    int idx = s.indexOf("://");
    return idx > 0 ? s.substring(0, idx) : "file";
  }

  public String raw() { return raw; }
  public boolean absolute() { return absolute; }
  public String protocol() { return protocol; }

  public URL toUrl() throws MalformedURLException {
    if (raw.contains("://")) {
      return new URL(raw);
    }
    return new URL("file:" + raw);
  }

  public boolean isJarExtension() {
    return raw.endsWith(".jar") || raw.endsWith(".zip");
  }
}
