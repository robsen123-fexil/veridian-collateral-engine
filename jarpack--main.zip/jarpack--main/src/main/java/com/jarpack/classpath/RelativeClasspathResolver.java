package com.jarpack.classpath;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;

import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Resolves Class-Path entries relative to a jar base directory. */
public final class RelativeClasspathResolver {
  private final Path baseDir;

  public RelativeClasspathResolver(String baseDir) {
    this.baseDir = baseDir == null || baseDir.isEmpty()
        ? Paths.get(".") : Paths.get(baseDir);
  }

  public List<Path> resolve(ManifestDocument doc) {
    String cp = doc.main().get("Class-Path");
    if (cp == null || cp.isEmpty()) {
      return List.of();
    }
    List<Path> paths = new ArrayList<>();
    for (String entry : ManifestMerger.splitClasspath(cp)) {
      paths.add(resolveEntry(entry));
    }
    return paths;
  }

  public Path resolveEntry(String entry) {
    if (entry.startsWith("/")) {
      return Paths.get(entry);
    }
    if (entry.startsWith("file:")) {
      return Paths.get(URI.create(entry));
    }
    return baseDir.resolve(entry).normalize();
  }

  public boolean referencesParent(String entry) {
    Path p = resolveEntry(entry);
    return p.normalize().toString().contains("..");
  }

  public List<String> toRelativeUris(ManifestDocument doc) {
    List<String> out = new ArrayList<>();
    for (Path p : resolve(doc)) {
      out.add(baseDir.relativize(p).toString().replace('\\', '/'));
    }
    return out;
  }
}
