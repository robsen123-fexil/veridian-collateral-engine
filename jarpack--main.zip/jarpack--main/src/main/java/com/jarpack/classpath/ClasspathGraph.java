package com.jarpack.classpath;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;

import java.net.URI;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Builds a dependency graph from Class-Path manifest attributes. */
public final class ClasspathGraph {
  private final Map<String, List<String>> adjacency = new LinkedHashMap<>();
  private final Set<String> roots = new HashSet<>();

  public static ClasspathGraph fromManifest(ManifestDocument doc) {
    ClasspathGraph graph = new ClasspathGraph();
    List<String> entries = ClasspathOrderResolver.ordered(doc);
    for (String entry : entries) {
      graph.addRoot(entry);
    }
    return graph;
  }

  public void addRoot(String entry) {
    roots.add(entry);
    adjacency.computeIfAbsent(entry, k -> new ArrayList<>());
  }

  public void addEdge(String from, String to) {
    adjacency.computeIfAbsent(from, k -> new ArrayList<>()).add(to);
    adjacency.computeIfAbsent(to, k -> new ArrayList<>());
  }

  public List<String> breadthFirstOrder() {
    List<String> order = new ArrayList<>();
    Set<String> seen = new HashSet<>();
    Deque<String> queue = new ArrayDeque<>(roots);
    while (!queue.isEmpty()) {
      String node = queue.removeFirst();
      if (!seen.add(node)) {
        continue;
      }
      order.add(node);
      for (String next : adjacency.getOrDefault(node, List.of())) {
        if (!seen.contains(next)) {
          queue.addLast(next);
        }
      }
    }
    return order;
  }

  public List<String> detectCycles() {
    List<String> cycles = new ArrayList<>();
    Set<String> visiting = new HashSet<>();
    Set<String> visited = new HashSet<>();
    for (String root : roots) {
      dfsCycle(root, visiting, visited, cycles, new ArrayList<>());
    }
    return cycles;
  }

  private void dfsCycle(
      String node, Set<String> visiting, Set<String> visited,
      List<String> cycles, List<String> path) {
    if (visited.contains(node)) {
      return;
    }
    if (!visiting.add(node)) {
      cycles.add(String.join("->", path) + "->" + node);
      return;
    }
    path.add(node);
    for (String next : adjacency.getOrDefault(node, List.of())) {
      dfsCycle(next, visiting, visited, cycles, path);
    }
    path.remove(path.size() - 1);
    visiting.remove(node);
    visited.add(node);
  }

  public int nodeCount() {
    return adjacency.size();
  }

  public static ClasspathGraph fromNestedManifests(List<ManifestDocument> docs) {
    ClasspathGraph graph = new ClasspathGraph();
    for (ManifestDocument doc : docs) {
      for (String entry : ClasspathOrderResolver.ordered(doc)) {
        graph.addRoot(entry);
      }
    }
    return graph;
  }
}
