package com.jarpack.stats;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestAttributeCatalog;
import com.jarpack.core.ManifestConstants;
import com.jarpack.fold.LineFolder;
import com.jarpack.profile.JarProfileDetector;
import com.jarpack.text.ManifestLineCodec;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Collects quantitative statistics about a manifest document. */
public final class ManifestStatistics {
  private ManifestStatistics() {}

  public static StatsReport analyze(ManifestDocument doc) {
    StatsReport report = new StatsReport();
    if (doc == null) {
      return report;
    }
    report.mainAttributeCount = doc.main().size();
    report.sectionCount = doc.entries().size();
    report.warningCount = doc.warnings().size();

    int totalSectionAttrs = 0;
    int digestAttrs = 0;
    int sealedSections = 0;
    int maxValueLen = 0;
    int foldedRows = 0;

    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      int len = e.getValue() == null ? 0 : e.getValue().length();
      maxValueLen = Math.max(maxValueLen, len);
      foldedRows += LineFolder.estimatePhysicalRows(doc);
      if (ManifestConstants.isDigestAttribute(e.getKey())) {
        digestAttrs++;
      }
      if (ManifestAttributeCatalog.isKnown(e.getKey())) {
        report.knownMainAttributes++;
      } else {
        report.unknownMainAttributes++;
      }
    }

    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      totalSectionAttrs += section.getValue().size();
      if ("true".equalsIgnoreCase(section.getValue().get(ManifestConstants.SEALED))) {
        sealedSections++;
      }
      for (Map.Entry<String, String> attr : section.getValue().entrySet()) {
        if (ManifestConstants.isDigestAttribute(attr.getKey())) {
          digestAttrs++;
        }
        int len = attr.getValue() == null ? 0 : attr.getValue().length();
        maxValueLen = Math.max(maxValueLen, len);
        foldedRows += ManifestLineCodec.physicalRowCount(
            attr.getKey() + ": " + attr.getValue());
      }
    }

    report.sectionAttributeCount = totalSectionAttrs;
    report.digestAttributeCount = digestAttrs;
    report.sealedSectionCount = sealedSections;
    report.maxValueLength = maxValueLen;
    report.estimatedPhysicalRows = foldedRows;

    if (doc.main().containsKey(ManifestConstants.CLASS_PATH)) {
      String cp = doc.main().get(ManifestConstants.CLASS_PATH);
      report.classpathEntries = com.jarpack.ManifestMerger.splitClasspath(cp).size();
    }

    JarProfileDetector.DetectionResult detection = JarProfileDetector.detect(doc);
    report.detectedProfile = detection.primary().name();
    report.profileConfidence = detection.confidence();
    report.profileMatches = detection.matches().size();

    report.attributeHistogram = buildHistogram(doc);
    return report;
  }

  private static Map<String, Integer> buildHistogram(ManifestDocument doc) {
    Map<String, Integer> hist = new LinkedHashMap<>();
    for (String key : doc.main().keySet()) {
      String scope = ManifestAttributeCatalog.lookup(key) == null
          ? "unknown" : ManifestAttributeCatalog.lookup(key).scope;
      hist.merge("main:" + scope, 1, Integer::sum);
    }
    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      for (String key : section.getValue().keySet()) {
        hist.merge("section", 1, Integer::sum);
      }
    }
    return hist;
  }

  public static List<String> compare(StatsReport left, StatsReport right) {
    List<String> deltas = new ArrayList<>();
    if (left.mainAttributeCount != right.mainAttributeCount) {
      deltas.add("main-count:" + left.mainAttributeCount + "->" + right.mainAttributeCount);
    }
    if (left.sectionCount != right.sectionCount) {
      deltas.add("section-count:" + left.sectionCount + "->" + right.sectionCount);
    }
    if (left.digestAttributeCount != right.digestAttributeCount) {
      deltas.add("digest-count:" + left.digestAttributeCount + "->" + right.digestAttributeCount);
    }
    if (!left.detectedProfile.equals(right.detectedProfile)) {
      deltas.add("profile:" + left.detectedProfile + "->" + right.detectedProfile);
    }
    return deltas;
  }

  public static final class StatsReport {
    public int mainAttributeCount;
    public int sectionCount;
    public int sectionAttributeCount;
    public int digestAttributeCount;
    public int sealedSectionCount;
    public int warningCount;
    public int knownMainAttributes;
    public int unknownMainAttributes;
    public int maxValueLength;
    public int estimatedPhysicalRows;
    public int classpathEntries;
    public String detectedProfile = "UNKNOWN";
    public int profileConfidence;
    public int profileMatches;
    public Map<String, Integer> attributeHistogram = Map.of();

    public int totalAttributes() {
      return mainAttributeCount + sectionAttributeCount;
    }

    public String summary() {
      return "main=" + mainAttributeCount
          + ",sections=" + sectionCount
          + ",digests=" + digestAttributeCount
          + ",profile=" + detectedProfile;
    }
  }
}
