package com.jarpack;

public final class ClasspathPipeline {
  private ClasspathPipeline() {}

  public static int runFoldLifecycle(byte[] manifestBytes) {
    if (manifestBytes == null || manifestBytes.length == 0) {
      return 0;
    }
    ManifestDocument doc = ManifestParser.parse(manifestBytes);
    String cp = doc.main().get("Class-Path");
    if (cp == null) {
      return 0;
    }
    FoldTape tape = new FoldTape();
    for (int round = 0; round < 8; round++) {
      byte[] folded = FoldEngine.foldDocument(doc);
      tape.recordFold(folded);
      doc = ManifestParser.parse(folded);
      if (tape.converged()) {
        break;
      }
    }
    return tape.sweepDigest();
  }
}
