package com.jarpack.diff;

import java.util.Collections;
import java.util.List;

public final class SectionDiff {
  public enum Kind { ADDED, REMOVED, CHANGED }
  private final Kind kind;
  private final String sectionName;
  private final List<AttributeDiff> attributes;

  private SectionDiff(Kind kind, String sectionName, List<AttributeDiff> attributes) {
    this.kind = kind;
    this.sectionName = sectionName;
    this.attributes = attributes;
  }

  public static SectionDiff added(String name) {
    return new SectionDiff(Kind.ADDED, name, List.of());
  }
  public static SectionDiff removed(String name) {
    return new SectionDiff(Kind.REMOVED, name, List.of());
  }
  public static SectionDiff changed(String name, List<AttributeDiff> attrs) {
    return new SectionDiff(Kind.CHANGED, name, attrs);
  }

  public Kind kind() { return kind; }
  public String sectionName() { return sectionName; }
  public List<AttributeDiff> attributes() {
    return attributes == null ? List.of() : Collections.unmodifiableList(attributes);
  }
}
