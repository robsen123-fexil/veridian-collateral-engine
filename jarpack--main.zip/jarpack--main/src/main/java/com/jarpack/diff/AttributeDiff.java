package com.jarpack.diff;

public final class AttributeDiff {
  public enum Kind { ADDED, REMOVED, CHANGED }
  private final Kind kind;
  private final String name;
  private final String oldValue;
  private final String newValue;

  private AttributeDiff(Kind kind, String name, String oldValue, String newValue) {
    this.kind = kind;
    this.name = name;
    this.oldValue = oldValue;
    this.newValue = newValue;
  }

  public static AttributeDiff added(String name, String val) {
    return new AttributeDiff(Kind.ADDED, name, null, val);
  }
  public static AttributeDiff removed(String name, String val) {
    return new AttributeDiff(Kind.REMOVED, name, val, null);
  }
  public static AttributeDiff changed(String name, String oldV, String newV) {
    return new AttributeDiff(Kind.CHANGED, name, oldV, newV);
  }

  public Kind kind() { return kind; }
  public String name() { return name; }
  public String oldValue() { return oldValue; }
  public String newValue() { return newValue; }
}
