package com.jarpack.diff;

import com.jarpack.ManifestDocument;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeSet;

/** Computes structural diffs between manifest entry sections. */
public final class SectionDiffEngine {
  private SectionDiffEngine() {}

  public static SectionDiffResult diff(ManifestDocument left, ManifestDocument right) {
    SectionDiffResult result = new SectionDiffResult();
    TreeSet<String> names = new TreeSet<>();
    names.addAll(left.entries().keySet());
    names.addAll(right.entries().keySet());
    for (String name : names) {
      Map<String, String> la = left.entries().get(name);
      Map<String, String> ra = right.entries().get(name);
      if (la == null) {
        result.addAdded(name, ra);
      } else if (ra == null) {
        result.addRemoved(name, la);
      } else {
        AttributeChangeSet changes = AttributeChangeSet.between(la, ra);
        if (!changes.isEmpty()) {
          result.addChanged(name, changes);
        }
      }
    }
    return result;
  }

  public static final class SectionDiffResult {
    private final List<String> added = new ArrayList<>();
    private final List<String> removed = new ArrayList<>();
    private final Map<String, AttributeChangeSet> changed = new LinkedHashMap<>();

    void addAdded(String name, Map<String, String> attrs) {
      added.add(name);
    }

    void addRemoved(String name, Map<String, String> attrs) {
      removed.add(name);
    }

    void addChanged(String name, AttributeChangeSet changes) {
      changed.put(name, changes);
    }

    public List<String> addedSections() { return List.copyOf(added); }
    public List<String> removedSections() { return List.copyOf(removed); }
    public Map<String, AttributeChangeSet> changedSections() { return Map.copyOf(changed); }

    public boolean isEmpty() {
      return added.isEmpty() && removed.isEmpty() && changed.isEmpty();
    }

    public int changeCount() {
      return added.size() + removed.size() + changed.size();
    }
  }
}
