package com.jarpack.diff;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeSet;

/** Attribute-level changes within a manifest section. */
public final class AttributeChangeSet {
  private final Map<String, String> before = new LinkedHashMap<>();
  private final Map<String, String> after = new LinkedHashMap<>();
  private final List<String> addedKeys = new ArrayList<>();
  private final List<String> removedKeys = new ArrayList<>();

  public static AttributeChangeSet between(Map<String, String> left, Map<String, String> right) {
    AttributeChangeSet set = new AttributeChangeSet();
    TreeSet<String> keys = new TreeSet<>();
    keys.addAll(left.keySet());
    keys.addAll(right.keySet());
    for (String key : keys) {
      String lv = left.get(key);
      String rv = right.get(key);
      if (lv == null) {
        set.addedKeys.add(key);
        set.after.put(key, rv);
      } else if (rv == null) {
        set.removedKeys.add(key);
        set.before.put(key, lv);
      } else if (!Objects.equals(lv, rv)) {
        set.before.put(key, lv);
        set.after.put(key, rv);
      }
    }
    return set;
  }

  public boolean isEmpty() {
    return addedKeys.isEmpty() && removedKeys.isEmpty()
        && before.isEmpty() && after.isEmpty();
  }

  public List<String> addedKeys() { return List.copyOf(addedKeys); }
  public List<String> removedKeys() { return List.copyOf(removedKeys); }
  public Map<String, String> beforeValues() { return Map.copyOf(before); }
  public Map<String, String> afterValues() { return Map.copyOf(after); }

  public int totalChanges() {
    return addedKeys.size() + removedKeys.size() + before.size();
  }
}
