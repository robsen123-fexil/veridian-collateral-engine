package com.jarpack.diff;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;
import com.jarpack.stats.ManifestStatistics;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** Detailed main-attribute diff with statistical context. */
public final class MainAttributeDiffEngine {
  private MainAttributeDiffEngine() {}

  public static MainDiffResult diff(ManifestDocument left, ManifestDocument right) {
    MainDiffResult result = new MainDiffResult();
    TreeSet<String> keys = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    keys.addAll(left.main().keySet());
    keys.addAll(right.main().keySet());

    for (String key : keys) {
      String lv = findIgnoreCase(left.main(), key);
      String rv = findIgnoreCase(right.main(), key);
      if (lv == null) {
        result.added.put(key, rv);
      } else if (rv == null) {
        result.removed.put(key, lv);
      } else if (!lv.equals(rv)) {
        result.changed.put(key, new String[] { lv, rv });
      } else {
        result.unchanged.add(key);
      }
    }

    result.leftStats = ManifestStatistics.analyze(left);
    result.rightStats = ManifestStatistics.analyze(right);
    result.deltas = ManifestStatistics.compare(result.leftStats, result.rightStats);
    return result;
  }

  private static String findIgnoreCase(Map<String, String> map, String key) {
    for (Map.Entry<String, String> e : map.entrySet()) {
      if (e.getKey().equalsIgnoreCase(key)) {
        return e.getValue();
      }
    }
    return null;
  }

  public static boolean classpathChanged(MainDiffResult result) {
    return result.changed.containsKey(ManifestConstants.CLASS_PATH)
        || result.added.containsKey(ManifestConstants.CLASS_PATH)
        || result.removed.containsKey(ManifestConstants.CLASS_PATH);
  }

  public static final class MainDiffResult {
    public final Map<String, String> added = new LinkedHashMap<>();
    public final Map<String, String> removed = new LinkedHashMap<>();
    public final Map<String, String[]> changed = new LinkedHashMap<>();
    public final List<String> unchanged = new ArrayList<>();
    public ManifestStatistics.StatsReport leftStats;
    public ManifestStatistics.StatsReport rightStats;
    public List<String> deltas = List.of();

    public int changeCount() {
      return added.size() + removed.size() + changed.size();
    }

    public boolean isEmpty() {
      return changeCount() == 0;
    }
  }
}
