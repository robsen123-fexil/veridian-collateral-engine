package com.jarpack.diff;

import com.jarpack.ManifestDocument;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Computes structural diffs between two manifest documents. */
public final class ManifestDiffer {
  public ManifestDiffResult diff(ManifestDocument left, ManifestDocument right) {
    ManifestDiffResult result = new ManifestDiffResult();
    diffMain(left.main(), right.main(), result);
    diffSections(left.entries(), right.entries(), result);
    return result;
  }

  private void diffMain(Map<String, String> a, Map<String, String> b, ManifestDiffResult result) {
    Set<String> keys = new LinkedHashSet<>();
    keys.addAll(a.keySet());
    keys.addAll(b.keySet());
    for (String key : keys) {
      String va = a.get(key);
      String vb = b.get(key);
      if (va == null) {
        result.add(AttributeDiff.added(key, vb));
      } else if (vb == null) {
        result.add(AttributeDiff.removed(key, va));
      } else if (!va.equals(vb)) {
        result.add(AttributeDiff.changed(key, va, vb));
      }
    }
  }

  private void diffSections(Map<String, Map<String, String>> a,
                            Map<String, Map<String, String>> b,
                            ManifestDiffResult result) {
    Set<String> names = new LinkedHashSet<>();
    names.addAll(a.keySet());
    names.addAll(b.keySet());
    for (String name : names) {
      Map<String, String> sa = a.get(name);
      Map<String, String> sb = b.get(name);
      if (sa == null) {
        result.add(SectionDiff.added(name));
      } else if (sb == null) {
        result.add(SectionDiff.removed(name));
      } else {
        List<AttributeDiff> attrDiffs = diffAttributeMaps(sa, sb);
        if (!attrDiffs.isEmpty()) {
          result.add(SectionDiff.changed(name, attrDiffs));
        }
      }
    }
  }

  private List<AttributeDiff> diffAttributeMaps(Map<String, String> a, Map<String, String> b) {
    List<AttributeDiff> diffs = new ArrayList<>();
    ManifestDiffResult tmp = new ManifestDiffResult();
    diffMain(a, b, tmp);
    diffs.addAll(tmp.attributeChanges());
    return diffs;
  }
}
