package com.jarpack.diff;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ManifestDiffResult {
  private final List<Object> changes = new ArrayList<>();

  public void add(AttributeDiff d) { changes.add(d); }
  public void add(SectionDiff d) { changes.add(d); }

  @SuppressWarnings("unchecked")
  public List<AttributeDiff> attributeChanges() {
    List<AttributeDiff> out = new ArrayList<>();
    for (Object o : changes) {
      if (o instanceof AttributeDiff) out.add((AttributeDiff) o);
    }
    return out;
  }

  public List<Object> changes() { return Collections.unmodifiableList(changes); }
  public boolean isEmpty() { return changes.isEmpty(); }
  public int size() { return changes.size(); }
}
