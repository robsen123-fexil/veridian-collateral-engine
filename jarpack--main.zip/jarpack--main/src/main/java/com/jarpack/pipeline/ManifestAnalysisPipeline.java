package com.jarpack.pipeline;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.diff.MainAttributeDiffEngine;
import com.jarpack.diff.ManifestDiffer;
import com.jarpack.io.CrlfManifestEncoder;
import com.jarpack.io.ManifestRoundTripGuard;
import com.jarpack.merge.ManifestMergeEngine;
import com.jarpack.model.ManifestEditor;
import com.jarpack.normalize.FullNormalizePass;
import com.jarpack.profile.JarProfileDetector;
import com.jarpack.profile.ProfileValidationSuite;
import com.jarpack.reconcile.ManifestReconciler;
import com.jarpack.signature.ManifestDigestPipeline;
import com.jarpack.stats.ManifestStatistics;
import com.jarpack.validate.AttributeSyntaxChecker;
import com.jarpack.validate.ValidationResult;
import com.jarpack.writer.ManifestComposer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * End-to-end manifest analysis pipeline used by integrators and fuzz harnesses
 * to exercise parse, validate, normalize, diff, merge, and digest stages.
 */
public final class ManifestAnalysisPipeline {
  private boolean runNormalize = true;
  private boolean runDigest = false;
  private boolean runRoundTrip = true;
  private boolean runProfile = true;

  public ManifestAnalysisPipeline normalize(boolean value) {
    this.runNormalize = value;
    return this;
  }

  public ManifestAnalysisPipeline digest(boolean value) {
    this.runDigest = value;
    return this;
  }

  public ManifestAnalysisPipeline roundTrip(boolean value) {
    this.runRoundTrip = value;
    return this;
  }

  public ManifestAnalysisPipeline profile(boolean value) {
    this.runProfile = value;
    return this;
  }

  public AnalysisReport analyze(byte[] input) throws IOException {
    AnalysisReport report = new AnalysisReport();
    if (input == null || input.length == 0) {
      report.addStage("empty-input");
      return report;
    }

    ManifestDocument doc = ManifestParser.parse(input);
    report.setParseWarnings(doc.warnings().size());
    report.setStats(ManifestStatistics.analyze(doc));

    ValidationResult validation = ProfileValidationSuite.validate(doc);
    report.setValidationErrors(validation.errorCount());
    report.setValidationWarnings(validation.warningCount());

    List<String> syntax = AttributeSyntaxChecker.lint(doc);
    report.setSyntaxFindings(syntax.size());

    if (runProfile) {
      JarProfileDetector.DetectionResult detection = JarProfileDetector.detect(doc);
      report.setProfile(detection.primary().name());
      report.setProfileConfidence(detection.confidence());
    }

    if (runNormalize) {
      FullNormalizePass pass = new FullNormalizePass();
      FullNormalizePass.NormalizeReport nr = pass.apply(doc.copy());
      report.setNormalized(nr.complete());
      report.setTrimmed(nr.trimmedCount());
    }

    if (runRoundTrip) {
      ManifestRoundTripGuard.RoundTripReport rt = ManifestRoundTripGuard.check(input);
      report.setRoundTripOk(rt.ok());
      if (!rt.ok()) {
        report.addStage("roundtrip-failed");
        com.jarpack.io.RoundTripScratchRegistry.audit(input);
      }
    }

    if (runDigest) {
      ManifestDigestPipeline pipeline = new ManifestDigestPipeline();
      ManifestDigestPipeline.DigestResult dr = pipeline.compute(doc);
      report.setMainDigestPresent(dr.mainDigest() != null);
      report.setEntryDigestCount(dr.entryDigests().size());
    }

    byte[] composed = new ManifestComposer().compose(doc);
    report.setComposedBytes(composed.length);
    report.setCrlfBytes(CrlfManifestEncoder.countCrlfBytes(doc));
    report.setDocument(doc);
    return report;
  }

  public AnalysisReport compare(byte[] left, byte[] right) throws IOException {
    AnalysisReport base = analyze(left);
    ManifestDocument l = ManifestParser.parse(left);
    ManifestDocument r = ManifestParser.parse(right);
    MainAttributeDiffEngine.MainDiffResult mainDiff = MainAttributeDiffEngine.diff(l, r);
    base.setMainDiffCount(mainDiff.changeCount());
    ManifestDiffer differ = new ManifestDiffer();
    base.setFullDiffCount(differ.diff(l, r).size());
    return base;
  }

  public AnalysisReport merge(byte[] left, byte[] right) throws IOException {
    ManifestDocument l = ManifestParser.parse(left);
    ManifestDocument r = ManifestParser.parse(right);
    ManifestMergeEngine engine = new ManifestMergeEngine();
    ManifestMergeEngine.MergeResult merged = engine.merge(l, r);
    AnalysisReport report = analyze(new ManifestComposer().compose(merged.document()));
    report.setMergeConflicts(merged.conflictLog().size());
    return report;
  }

  public AnalysisReport reconcile(byte[] left, byte[] right) throws IOException {
    ManifestReconciler reconciler = new ManifestReconciler();
    ManifestReconciler.ReconcileResult rr = reconciler.reconcile(left, right);
    AnalysisReport report = analyze(new ManifestComposer().compose(rr.document()));
    report.setReconcileConflicts(rr.conflictLog().size());
    report.setRoundTripOk(rr.roundTripOk());
    return report;
  }

  public ManifestEditor edit(byte[] input) {
    return ManifestEditor.fromBytes(input);
  }

  public static AnalysisReport quick(byte[] input) {
    try {
      return new ManifestAnalysisPipeline().analyze(input);
    } catch (IOException ex) {
      AnalysisReport report = new AnalysisReport();
      report.addStage("io-error");
      return report;
    }
  }

  public static final class AnalysisReport {
    private ManifestDocument document;
    private final List<String> stages = new ArrayList<>();
    private ManifestStatistics.StatsReport stats;
    private int parseWarnings;
    private int validationErrors;
    private int validationWarnings;
    private int syntaxFindings;
    private String profile = "UNKNOWN";
    private int profileConfidence;
    private boolean normalized;
    private int trimmed;
    private boolean roundTripOk = true;
    private boolean mainDigestPresent;
    private int entryDigestCount;
    private int composedBytes;
    private int crlfBytes;
    private int mainDiffCount;
    private int fullDiffCount;
    private int mergeConflicts;
    private int reconcileConflicts;

    public ManifestDocument document() { return document; }
    public List<String> stages() { return List.copyOf(stages); }
    public boolean roundTripOk() { return roundTripOk; }
    public int validationErrors() { return validationErrors; }
    public String profile() { return profile; }

    void setDocument(ManifestDocument d) { document = d; }
    void addStage(String s) { stages.add(s); }
    void setStats(ManifestStatistics.StatsReport s) { stats = s; }
    void setParseWarnings(int v) { parseWarnings = v; }
    void setValidationErrors(int v) { validationErrors = v; }
    void setValidationWarnings(int v) { validationWarnings = v; }
    void setSyntaxFindings(int v) { syntaxFindings = v; }
    void setProfile(String p) { profile = p; }
    void setProfileConfidence(int v) { profileConfidence = v; }
    void setNormalized(boolean v) { normalized = v; }
    void setTrimmed(int v) { trimmed = v; }
    void setRoundTripOk(boolean v) { roundTripOk = v; }
    void setMainDigestPresent(boolean v) { mainDigestPresent = v; }
    void setEntryDigestCount(int v) { entryDigestCount = v; }
    void setComposedBytes(int v) { composedBytes = v; }
    void setCrlfBytes(int v) { crlfBytes = v; }
    void setMainDiffCount(int v) { mainDiffCount = v; }
    void setFullDiffCount(int v) { fullDiffCount = v; }
    void setMergeConflicts(int v) { mergeConflicts = v; }
    void setReconcileConflicts(int v) { reconcileConflicts = v; }

    public String summary() {
      return "profile=" + profile
          + ",errors=" + validationErrors
          + ",roundtrip=" + roundTripOk
          + ",bytes=" + composedBytes;
    }
  }
}
