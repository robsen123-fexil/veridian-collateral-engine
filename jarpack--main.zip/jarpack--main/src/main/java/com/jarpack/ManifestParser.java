package com.jarpack;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ManifestParser {
  private ManifestParser() {}

  public static ManifestDocument parse(byte[] raw) {
    ManifestDocument doc = new ManifestDocument();
    List<ManifestToken> tokens = ManifestLexer.tokenize(raw);
    String currentSection = null;
    Map<String, String> sectionAttrs = null;
    for (ManifestToken tok : tokens) {
      switch (tok.kind()) {
        case MAIN_PAIR:
          doc.main().put(tok.name(), tok.value());
          break;
        case SECTION_BREAK:
          currentSection = null;
          sectionAttrs = null;
          break;
        case SECTION_PAIR:
          if (tok.name().endsWith(":") || tok.name().contains("/")) {
            if (currentSection != null && sectionAttrs != null) {
              doc.entries().put(currentSection, sectionAttrs);
            }
            currentSection = tok.name().endsWith(":")
                ? tok.name().substring(0, tok.name().length() - 1)
                : tok.name();
            sectionAttrs = new LinkedHashMap<>();
            if (!tok.value().isEmpty()) {
              sectionAttrs.put(tok.name(), tok.value());
            }
          } else if (sectionAttrs != null) {
            sectionAttrs.put(tok.name(), tok.value());
          } else {
            doc.main().put(tok.name(), tok.value());
          }
          break;
        case INVALID:
          doc.warnings().add("invalid-line:" + tok.name());
          break;
        default:
          break;
      }
    }
    if (currentSection != null && sectionAttrs != null) {
      doc.entries().put(currentSection, sectionAttrs);
    }
    return doc;
  }

  public static ManifestDocument parseUtf8(String text) {
    return parse(text.getBytes(StandardCharsets.UTF_8));
  }
}
