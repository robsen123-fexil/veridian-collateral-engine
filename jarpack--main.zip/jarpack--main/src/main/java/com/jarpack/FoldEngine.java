package com.jarpack;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Wraps manifest logical lines to 72-byte physical rows per JAR spec. */
public final class FoldEngine {
  public static final int MAX_PHYSICAL = 72;

  private FoldEngine() {}

  public static List<String> foldLogicalLine(String name, String value) {
    String logical = name + ": " + value;
    List<String> rows = new ArrayList<>();
    int pos = 0;
    while (pos < logical.length()) {
      int take = Math.min(MAX_PHYSICAL, logical.length() - pos);
      String chunk = logical.substring(pos, pos + take);
      if (pos == 0) {
        rows.add(chunk);
      } else {
        rows.add(" " + chunk);
      }
      pos += take;
    }
    return rows;
  }

  public static byte[] foldDocument(ManifestDocument doc) {
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      for (String row : foldLogicalLine(e.getKey(), e.getValue())) {
        sb.append(row).append('\n');
      }
    }
    if (!doc.main().isEmpty() && !doc.entries().isEmpty()) {
      sb.append('\n');
    }
    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      sb.append("Name: ").append(section.getKey()).append('\n');
      for (Map.Entry<String, String> attr : section.getValue().entrySet()) {
        for (String row : foldLogicalLine(attr.getKey(), attr.getValue())) {
          sb.append(row).append('\n');
        }
      }
      sb.append('\n');
    }
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }
}
