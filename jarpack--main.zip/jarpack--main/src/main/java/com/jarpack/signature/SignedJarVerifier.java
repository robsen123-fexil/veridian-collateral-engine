package com.jarpack.signature;

import com.jarpack.archive.JarManifestReader;
import com.jarpack.archive.ZipEntryCatalog;
import com.jarpack.core.DigestAlgorithm;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipFile;

/** Orchestrates .SF digest checks and PKCS#7 block inspection for signed JARs. */
public final class SignedJarVerifier {
  private DigestAlgorithm defaultAlgorithm = DigestAlgorithm.SHA256;

  public SignedJarVerifier algorithm(DigestAlgorithm alg) {
    if (alg != null) {
      this.defaultAlgorithm = alg;
    }
    return this;
  }

  public VerificationReport verify(Path jarPath) throws IOException {
    try (ZipFile jar = new ZipFile(jarPath.toFile())) {
      return verify(jar);
    }
  }

  public VerificationReport verify(ZipFile jar) throws IOException {
    VerificationReport report = new VerificationReport();
    ZipEntryCatalog catalog = ZipEntryCatalog.scan(jar);
    report.setEntryCount(catalog.entryCount());

    byte[] manifestBytes = JarManifestReader.readRawBytes(
        jar, com.jarpack.archive.ManifestEntryLocator.DEFAULT_MANIFEST);
    com.jarpack.ManifestDocument manifest = com.jarpack.ManifestParser.parse(manifestBytes);

    List<String> sfPaths = new ArrayList<>();
    for (String name : catalog.metaInfEntries()) {
      if (name.endsWith(".SF")) {
        sfPaths.add(name);
      }
    }
    report.setSignatureFileCount(sfPaths.size());

    for (String sfPath : sfPaths) {
      byte[] sfBytes = JarManifestReader.readRawBytes(jar, sfPath);
      SignatureFile sf = SignatureManifestParser.parse(sfBytes);
      report.addIssues("sf:" + sfPath, DigestManifestMatcher.verifyMainAttributes(sf, manifestBytes));
      report.addIssues("sf-entries:" + sfPath,
          JarEntryDigestCalculator.verifyAllEntries(manifest, sf, defaultAlgorithm));

      String base = sfPath.substring(0, sfPath.length() - 3);
      for (String ext : new String[] {".RSA", ".DSA", ".EC"}) {
        String blockPath = base + ext;
        if (catalog.contains(blockPath)) {
          byte[] block = JarManifestReader.readRawBytes(jar, blockPath);
          Pkcs7SignatureBlockParser.Pkcs7Block pkcs7 = Pkcs7SignatureBlockParser.parse(block);
          report.addIssues("pkcs7:" + blockPath, pkcs7.issues());
          report.addIssues("pkcs7-chain:" + blockPath,
              Pkcs7SignatureBlockParser.validateChain(pkcs7));
          report.setSigner(pkcs7.signerSummary());
        }
      }
    }

    if (sfPaths.isEmpty()) {
      report.addIssue("no-signature-files");
    }
    return report;
  }

  public static final class VerificationReport {
    private final List<String> issues = new ArrayList<>();
    private int entryCount;
    private int signatureFileCount;
    private String signer = "unknown";

    public void addIssue(String issue) { issues.add(issue); }

    public void addIssues(String prefix, List<String> more) {
      for (String m : more) {
        issues.add(prefix + ":" + m);
      }
    }

    public List<String> issues() { return List.copyOf(issues); }
    public boolean ok() { return issues.isEmpty(); }
    public int entryCount() { return entryCount; }
    public int signatureFileCount() { return signatureFileCount; }
    public String signer() { return signer; }

    void setEntryCount(int c) { entryCount = c; }
    void setSignatureFileCount(int c) { signatureFileCount = c; }
    void setSigner(String s) { signer = s; }
  }
}
