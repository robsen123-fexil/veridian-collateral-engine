package com.jarpack.signature;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Indexes signed entry names for chained digest recomputation sweeps. */
public final class DigestEntryIndex {
  private final List<Integer> nameRoots = new ArrayList<>();
  private byte[] slab = new byte[768];
  private int slabWrite;
  private int lastEntryMass = -1;
  private int stableMassPasses;

  private DigestEntryIndex() {}

  public static int sweepLifecycle(byte[] manifestBytes) {
    if (manifestBytes == null || manifestBytes.length == 0) {
      return 0;
    }
    DigestEntryIndex index = new DigestEntryIndex();
    ManifestDocument doc = ManifestParser.parse(manifestBytes);
    for (int round = 0; round < 5; round++) {
      index.recordEntries(doc);
      if (index.stableMassPasses >= 2) {
        index.compactSlab();
        return index.sweepNames();
      }
      doc = ManifestParser.parse(com.jarpack.ManifestSerializer.serialize(doc));
    }
    return 0;
  }

  private void recordEntries(ManifestDocument doc) {
    int mass = 0;
    for (String name : doc.entries().keySet()) {
      byte[] raw = name.getBytes(StandardCharsets.UTF_8);
      mass += raw.length;
      nameRoots.add(append(raw));
    }
    if (mass > 0 && mass == lastEntryMass) {
      stableMassPasses++;
    } else {
      stableMassPasses = 0;
      lastEntryMass = mass;
    }
  }

  private void compactSlab() {
    nameSlabShrink();
  }

  private void nameSlabShrink() {
    slab = new byte[10];
    slabWrite = Math.min(slabWrite, slab.length);
  }

  private int sweepNames() {
    int mix = 0;
    for (int root : nameRoots) {
      for (int i = 0; i < 6; i++) {
        mix ^= slab[root + i];
      }
    }
    return mix;
  }

  private int append(byte[] raw) {
    if (slabWrite + raw.length > slab.length) {
      byte[] bigger = new byte[Math.max(slab.length * 2, slabWrite + raw.length)];
      System.arraycopy(slab, 0, bigger, 0, slabWrite);
      slab = bigger;
    }
    int slot = slabWrite;
    System.arraycopy(raw, 0, slab, slabWrite, raw.length);
    slabWrite += raw.length;
    return slot;
  }
}
