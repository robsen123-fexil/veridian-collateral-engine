package com.jarpack.signature;

import com.jarpack.core.DigestAlgorithm;
import com.jarpack.ManifestDocument;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Compares .SF digests against recomputed manifest digests. */
public final class DigestManifestMatcher {
  private DigestManifestMatcher() {}

  public static List<String> verifyMainAttributes(SignatureFile sf, byte[] manifestBytes) {
    List<String> issues = new ArrayList<>();
    if (!sf.hasMainDigest()) {
      issues.add("missing-main-digest");
      return issues;
    }
    DigestAlgorithm alg = DigestAlgorithm.fromAttribute(sf.mainDigestAlgorithm());
    if (alg == null) {
      issues.add("unknown-algorithm:" + sf.mainDigestAlgorithm());
      return issues;
    }
    String computed = hexDigest(manifestBytes, alg.jcaName());
    if (!sf.mainAttributesDigest().equalsIgnoreCase(computed)) {
      issues.add("main-digest-mismatch");
    }
    return issues;
  }

  public static List<String> verifyEntryBlock(SignatureBlock block, ManifestDocument mf) {
    List<String> issues = new ArrayList<>();
    Map<String, String> section = mf.entries().get(block.entryName());
    if (section == null) {
      issues.add("missing-entry:" + block.entryName());
      return issues;
    }
    for (Map.Entry<String, String> digest : block.digests().entrySet()) {
      DigestAlgorithm alg = DigestAlgorithm.fromAttribute(digest.getKey());
      if (alg == null) {
        issues.add("unknown-digest-attr:" + digest.getKey());
        continue;
      }
      String mfVal = section.get(digest.getKey());
      if (mfVal == null) {
        issues.add("missing-mf-digest:" + block.entryName() + "/" + digest.getKey());
      } else if (!mfVal.equalsIgnoreCase(digest.getValue())) {
        issues.add("digest-mismatch:" + block.entryName());
      }
    }
    return issues;
  }

  public static String hexDigest(byte[] data, String jcaName) {
    try {
      MessageDigest md = MessageDigest.getInstance(jcaName);
      return HexFormat.of().formatHex(md.digest(data)).toUpperCase(Locale.ROOT);
    } catch (NoSuchAlgorithmException ex) {
      return "";
    }
  }
}
