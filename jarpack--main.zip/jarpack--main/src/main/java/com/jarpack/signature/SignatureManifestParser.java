package com.jarpack.signature;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Parses PKCS#7 companion .SF signature manifest files. */
public final class SignatureManifestParser {
  private SignatureManifestParser() {}

  public static SignatureFile parse(byte[] sfBytes) {
    ManifestDocument doc = ManifestParser.parse(sfBytes);
    SignatureFile file = new SignatureFile();
    file.setSignatureVersion(doc.main().get("Signature-Version"));
    file.setCreatedBy(doc.main().get("Created-By"));
    String mainDigest = findMainDigest(doc.main());
    file.setMainAttributesDigest(mainDigest);
    file.setMainDigestAlgorithm(detectAlgorithm(doc.main()));
    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      SignatureBlock block = new SignatureBlock(section.getKey());
      Map<String, String> attrs = section.getValue();
      for (Map.Entry<String, String> e : attrs.entrySet()) {
        if (e.getKey().toUpperCase(Locale.ROOT).contains("DIGEST")) {
          block.addDigest(e.getKey(), e.getValue());
        } else {
          block.addMeta(e.getKey(), e.getValue());
        }
      }
      file.addBlock(block);
    }
    return file;
  }

  public static SignatureFile parseUtf8(String text) {
    return parse(text.getBytes(StandardCharsets.UTF_8));
  }

  private static String findMainDigest(Map<String, String> main) {
    for (Map.Entry<String, String> e : main.entrySet()) {
      String key = e.getKey().toUpperCase(Locale.ROOT);
      if (key.contains("-DIGEST") && !key.contains("MANIFEST")) {
        return e.getValue();
      }
    }
    return main.get("SHA-256-Digest");
  }

  private static String detectAlgorithm(Map<String, String> main) {
    for (String key : main.keySet()) {
      String upper = key.toUpperCase(Locale.ROOT);
      if (upper.startsWith("SHA") || upper.startsWith("MD5")) {
        return key;
      }
    }
    return "SHA-256-Digest";
  }

  public static List<String> enumerateSignedEntries(SignatureFile file) {
    List<String> names = new ArrayList<>();
    for (SignatureBlock block : file.blocks()) {
      names.add(block.entryName());
    }
    return names;
  }

  public static Map<String, String> digestMapForEntry(SignatureFile file, String entry) {
    for (SignatureBlock block : file.blocks()) {
      if (block.entryName().equals(entry)) {
        return new LinkedHashMap<>(block.digests());
      }
    }
    return Map.of();
  }
}
