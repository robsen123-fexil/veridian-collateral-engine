package com.jarpack.signature;

import com.jarpack.core.DigestAlgorithm;
import com.jarpack.ManifestDocument;
import com.jarpack.io.ManifestStreamWriter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Builds a .SF signature manifest from a parsed MANIFEST.MF. */
public final class SignatureFileBuilder {
  private String signatureVersion = "1.0";
  private String createdBy = "jarpack";
  private DigestAlgorithm mainDigest = DigestAlgorithm.SHA256;
  private final List<String> signedEntries = new ArrayList<>();

  public SignatureFileBuilder signatureVersion(String v) {
    this.signatureVersion = v;
    return this;
  }

  public SignatureFileBuilder createdBy(String v) {
    this.createdBy = v;
    return this;
  }

  public SignatureFileBuilder mainDigest(DigestAlgorithm alg) {
    if (alg != null) {
      this.mainDigest = alg;
    }
    return this;
  }

  public SignatureFileBuilder signEntry(String entryName) {
    if (entryName != null && !entryName.isEmpty()) {
      signedEntries.add(entryName);
    }
    return this;
  }

  public SignatureFileBuilder signAllEntries(ManifestDocument mf) {
    signedEntries.clear();
    signedEntries.addAll(mf.entries().keySet());
    return this;
  }

  public ManifestDocument buildSfDocument(ManifestDocument manifest) throws IOException {
    ManifestDocument sf = new ManifestDocument();
    sf.main().put("Signature-Version", signatureVersion);
    sf.main().put("Created-By", createdBy);
    byte[] mainBytes = JarEntryDigestCalculator.mainAttributesBytes(manifest);
    String mainHex = JarEntryDigestCalculator.hexDigest(mainBytes, mainDigest.jcaName());
    sf.main().put(mainDigest.manifestName(), mainHex);

    for (String entry : signedEntries) {
      Map<String, String> section = new LinkedHashMap<>();
      Map<String, String> digests = JarEntryDigestCalculator.computeEntryDigests(
          manifest, entry, mainDigest);
      section.putAll(digests);
      sf.entries().put(entry, section);
    }
    return sf;
  }

  public byte[] buildSfBytes(ManifestDocument manifest) throws IOException {
    return ManifestStreamWriter.toByteArray(buildSfDocument(manifest));
  }

  public SignatureFile buildSignatureFile(ManifestDocument manifest) throws IOException {
    return SignatureManifestParser.parse(buildSfBytes(manifest));
  }
}
