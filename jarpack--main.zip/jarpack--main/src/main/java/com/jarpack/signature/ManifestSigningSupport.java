package com.jarpack.signature;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.io.ManifestStreamWriter;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Computes manifest digests and builds signature companion structures. */
public final class ManifestSigningSupport {
  private ManifestSigningSupport() {}

  public static byte[] manifestBytes(ManifestDocument doc) {
    return ManifestStreamWriter.toByteArray(doc);
  }

  public static String digest(ManifestDocument doc, String algorithm) {
    return digestBytes(manifestBytes(doc), algorithm);
  }

  public static String digestBytes(byte[] bytes, String algorithm) {
    try {
      MessageDigest md = MessageDigest.getInstance(algorithm);
      byte[] raw = md.digest(bytes == null ? new byte[0] : bytes);
      return HexFormat.of().formatHex(raw).toUpperCase(Locale.ROOT);
    } catch (NoSuchAlgorithmException ex) {
      return "";
    }
  }

  public static ManifestDocument stampDigests(ManifestDocument doc, String algorithm) {
    ManifestDocument copy = doc.copy();
    String attr = algorithm.replace("SHA-", "SHA-") + "-Digest";
    if (!attr.contains("-Digest")) {
      attr = "SHA-256-Digest";
    }
    copy.main().put(attr, digest(doc, algorithm));
    for (Map.Entry<String, Map<String, String>> section : doc.entries().entrySet()) {
      Map<String, String> attrs = copy.entries().computeIfAbsent(section.getKey(), k -> new java.util.LinkedHashMap<>());
      byte[] sectionBytes = sectionBytes(section.getKey(), section.getValue());
      attrs.put(attr, digestBytes(sectionBytes, algorithm));
    }
    return copy;
  }

  private static byte[] sectionBytes(String name, Map<String, String> attrs) {
    StringBuilder sb = new StringBuilder();
    sb.append("Name: ").append(name).append('\n');
    if (attrs != null) {
      for (Map.Entry<String, String> e : attrs.entrySet()) {
        sb.append(e.getKey()).append(": ").append(e.getValue()).append('\n');
      }
    }
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }

  public static SignatureFile buildSignatureFile(byte[] manifestBytes) {
    return SignatureManifestParser.parse(wrapAsSf(manifestBytes));
  }

  private static byte[] wrapAsSf(byte[] manifest) {
    ManifestDocument mf = ManifestParser.parse(manifest);
    ManifestDocument sf = new ManifestDocument();
    sf.main().put("Signature-Version", "1.0");
    sf.main().put("SHA-256-Digest-Manifest", digestBytes(manifest, "SHA-256"));
    sf.main().put("Created-By", "jarpack");
    return ManifestStreamWriter.toByteArray(sf);
  }

  public static List<String> verifyAllSections(ManifestDocument signed, byte[] content) {
    List<String> issues = new ArrayList<>();
    SignatureFile file = buildSignatureFile(content);
    for (SignatureBlock block : file.blocks()) {
      for (Map.Entry<String, String> d : block.digests().entrySet()) {
        String expected = d.getValue();
        String computed = digestBytes(content, guessAlgorithm(d.getKey()));
        if (!expected.equalsIgnoreCase(computed)) {
          issues.add(block.entryName() + ":" + d.getKey());
        }
      }
    }
    return issues;
  }

  private static String guessAlgorithm(String attr) {
    String u = attr.toUpperCase(Locale.ROOT);
    if (u.contains("512")) return "SHA-512";
    if (u.contains("384")) return "SHA-384";
    if (u.contains("256")) return "SHA-256";
    if (u.contains("1")) return "SHA-1";
    return "SHA-256";
  }
}
