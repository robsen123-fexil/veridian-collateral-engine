package com.jarpack.signature;

import java.io.ByteArrayInputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

/** Parses PKCS#7 signature blocks stored in META-INF/*.RSA / *.DSA / *.EC files. */
public final class Pkcs7SignatureBlockParser {
  private Pkcs7SignatureBlockParser() {}

  public static Pkcs7Block parse(byte[] blockBytes) {
    Pkcs7Block block = new Pkcs7Block();
    if (blockBytes == null || blockBytes.length == 0) {
      block.addIssue("empty-block");
      return block;
    }
    block.setRawLength(blockBytes.length);
    try {
      CertificateFactory cf = CertificateFactory.getInstance("X.509");
      @SuppressWarnings("unchecked")
      List<Certificate> certs = (List<Certificate>) cf.generateCertificates(
          new ByteArrayInputStream(blockBytes));
      for (Certificate cert : certs) {
        if (cert instanceof X509Certificate) {
          block.addCertificate((X509Certificate) cert);
        }
      }
      if (block.certificates().isEmpty()) {
        block.addIssue("no-x509-certificates");
      }
    } catch (Exception ex) {
      block.addIssue("parse-error:" + ex.getClass().getSimpleName());
    }
    block.setContentType(guessContentType(blockBytes));
    return block;
  }

  private static String guessContentType(byte[] data) {
    if (data.length < 4) {
      return "unknown";
    }
    if (data[0] == 0x30) {
      return "pkcs7-der";
    }
    return "opaque";
  }

  public static List<String> validateChain(Pkcs7Block block) {
    List<String> issues = new ArrayList<>();
    if (block == null) {
      issues.add("null-block");
      return issues;
    }
    issues.addAll(block.issues());
    for (X509Certificate cert : block.certificates()) {
      try {
        cert.checkValidity();
      } catch (Exception ex) {
        issues.add("cert-invalid:" + cert.getSubjectX500Principal().getName());
      }
    }
    return issues;
  }

  public static final class Pkcs7Block {
    private final List<X509Certificate> certificates = new ArrayList<>();
    private final List<String> issues = new ArrayList<>();
    private int rawLength;
    private String contentType = "unknown";

    public List<X509Certificate> certificates() {
      return List.copyOf(certificates);
    }

    public List<String> issues() {
      return List.copyOf(issues);
    }

    public int rawLength() { return rawLength; }
    public String contentType() { return contentType; }

    void addCertificate(X509Certificate cert) { certificates.add(cert); }
    void addIssue(String issue) { issues.add(issue); }
    void setRawLength(int len) { rawLength = len; }
    void setContentType(String type) { contentType = type; }

    public String signerSummary() {
      if (certificates.isEmpty()) {
        return "unsigned";
      }
      return certificates.get(0).getSubjectX500Principal().getName();
    }
  }
}
