package com.jarpack.signature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Model of a .SF signature manifest. */
public final class SignatureFile {
  private String signatureVersion = "1.0";
  private String createdBy;
  private String mainAttributesDigest;
  private String mainDigestAlgorithm;
  private final List<SignatureBlock> blocks = new ArrayList<>();

  public String signatureVersion() { return signatureVersion; }
  public void setSignatureVersion(String v) { this.signatureVersion = v; }
  public String createdBy() { return createdBy; }
  public void setCreatedBy(String v) { this.createdBy = v; }
  public String mainAttributesDigest() { return mainAttributesDigest; }
  public void setMainAttributesDigest(String v) { this.mainAttributesDigest = v; }
  public String mainDigestAlgorithm() { return mainDigestAlgorithm; }
  public void setMainDigestAlgorithm(String v) { this.mainDigestAlgorithm = v; }
  public List<SignatureBlock> blocks() { return Collections.unmodifiableList(blocks); }
  public void addBlock(SignatureBlock b) { blocks.add(b); }

  public int blockCount() { return blocks.size(); }

  public boolean hasMainDigest() {
    return mainAttributesDigest != null && !mainAttributesDigest.isEmpty();
  }
}
