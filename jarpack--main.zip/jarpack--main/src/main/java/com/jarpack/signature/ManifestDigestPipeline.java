package com.jarpack.signature;

import com.jarpack.core.DigestAlgorithm;
import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.io.ManifestStreamWriter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Computes manifest digests for signing workflows across all entries. */
public final class ManifestDigestPipeline {
  private DigestAlgorithm algorithm = DigestAlgorithm.SHA256;
  private boolean includeMain = true;
  private boolean includeAllSections = true;

  public ManifestDigestPipeline algorithm(DigestAlgorithm alg) {
    if (alg != null) {
      this.algorithm = alg;
    }
    return this;
  }

  public ManifestDigestPipeline includeMain(boolean value) {
    this.includeMain = value;
    return this;
  }

  public ManifestDigestPipeline includeAllSections(boolean value) {
    this.includeAllSections = value;
    return this;
  }

  public DigestResult compute(byte[] manifestBytes) throws IOException {
    ManifestDocument doc = ManifestParser.parse(manifestBytes);
    return compute(doc);
  }

  public DigestResult compute(ManifestDocument doc) throws IOException {
    DigestResult result = new DigestResult();
    if (includeMain) {
      byte[] mainBytes = JarEntryDigestCalculator.mainAttributesBytes(doc);
      result.setMainDigest(JarEntryDigestCalculator.hexDigest(mainBytes, algorithm.jcaName()));
      result.setMainBytes(mainBytes.length);
    }
    if (includeAllSections) {
      Map<String, String> entryDigests = new LinkedHashMap<>();
      for (String entry : doc.entries().keySet()) {
        byte[] sectionBytes = JarEntryDigestCalculator.entrySectionBytes(doc, entry);
        String hex = JarEntryDigestCalculator.hexDigest(sectionBytes, algorithm.jcaName());
        entryDigests.put(entry, hex);
      }
      result.setEntryDigests(entryDigests);
    }
    result.setAlgorithm(algorithm.manifestName());
    return result;
  }

  public ManifestDocument stampDigests(ManifestDocument doc) throws IOException {
    ManifestDocument stamped = doc.copy();
    DigestResult digests = compute(doc);
    if (digests.mainDigest() != null) {
      stamped.main().put(algorithm.manifestName(), digests.mainDigest());
    }
    for (Map.Entry<String, String> e : digests.entryDigests().entrySet()) {
      Map<String, String> section = stamped.entries().computeIfAbsent(
          e.getKey(), k -> new LinkedHashMap<>());
      section.put(algorithm.manifestName(), e.getValue());
    }
    return stamped;
  }

  public byte[] buildSignedManifestBytes(ManifestDocument doc) throws IOException {
    ManifestDocument stamped = stampDigests(doc);
    return ManifestStreamWriter.toByteArray(stamped);
  }

  public List<String> verifyAgainst(SignatureFile sf, byte[] manifestBytes) throws IOException {
    List<String> issues = new ArrayList<>();
    issues.addAll(DigestManifestMatcher.verifyMainAttributes(sf, manifestBytes));
    ManifestDocument doc = ManifestParser.parse(manifestBytes);
    issues.addAll(JarEntryDigestCalculator.verifyAllEntries(doc, sf, algorithm));
    return issues;
  }

  public static final class DigestResult {
    private String algorithm;
    private String mainDigest;
    private int mainBytes;
    private Map<String, String> entryDigests = Map.of();

    public String algorithm() { return algorithm; }
    public String mainDigest() { return mainDigest; }
    public int mainBytes() { return mainBytes; }
    public Map<String, String> entryDigests() { return entryDigests; }

    void setAlgorithm(String a) { algorithm = a; }
    void setMainDigest(String d) { mainDigest = d; }
    void setMainBytes(int b) { mainBytes = b; }
    void setEntryDigests(Map<String, String> m) { entryDigests = m; }
  }
}
