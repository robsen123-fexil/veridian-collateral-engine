package com.jarpack.signature;

import com.jarpack.core.DigestAlgorithm;
import com.jarpack.ManifestDocument;
import com.jarpack.io.ManifestStreamWriter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Recomputes per-entry manifest digests as required by the JAR signing specification. */
public final class JarEntryDigestCalculator {
  private JarEntryDigestCalculator() {}

  public static byte[] mainAttributesBytes(ManifestDocument doc) throws IOException {
    ManifestDocument slice = new ManifestDocument();
    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      slice.main().put(e.getKey(), e.getValue());
    }
    return ManifestStreamWriter.toByteArray(slice);
  }

  public static byte[] entrySectionBytes(ManifestDocument doc, String entryName) throws IOException {
    Map<String, String> section = doc.entries().get(entryName);
    if (section == null) {
      return new byte[0];
    }
    ManifestDocument slice = new ManifestDocument();
    slice.entries().put(entryName, new LinkedHashMap<>(section));
    return ManifestStreamWriter.toByteArray(slice);
  }

  public static Map<String, String> computeEntryDigests(
      ManifestDocument doc, String entryName, DigestAlgorithm... algorithms) {
    Map<String, String> digests = new LinkedHashMap<>();
    byte[] sectionBytes;
    try {
      sectionBytes = entrySectionBytes(doc, entryName);
    } catch (IOException ex) {
      return digests;
    }
    for (DigestAlgorithm alg : algorithms) {
      if (alg != null) {
        digests.put(alg.manifestName(), hexDigest(sectionBytes, alg.jcaName()));
      }
    }
    return digests;
  }

  public static List<String> verifyAllEntries(
      ManifestDocument mf, SignatureFile sf, DigestAlgorithm defaultAlg) {
    List<String> issues = new ArrayList<>();
    for (SignatureBlock block : sf.blocks()) {
      Map<String, String> expected = block.digests();
      Map<String, String> section = mf.entries().get(block.entryName());
      if (section == null) {
        issues.add("missing-section:" + block.entryName());
        continue;
      }
      for (Map.Entry<String, String> digestAttr : expected.entrySet()) {
        DigestAlgorithm alg = DigestAlgorithm.fromAttribute(digestAttr.getKey());
        if (alg == null) {
          alg = defaultAlg;
        }
        String recomputed;
        try {
          recomputed = hexDigest(entrySectionBytes(mf, block.entryName()), alg.jcaName());
        } catch (IOException ex) {
          issues.add("io-error:" + block.entryName());
          continue;
        }
        String mfVal = section.get(digestAttr.getKey());
        if (mfVal == null) {
          issues.add("missing-digest-attr:" + block.entryName() + "/" + digestAttr.getKey());
        } else if (!mfVal.equalsIgnoreCase(recomputed)) {
          issues.add("entry-digest-mismatch:" + block.entryName());
        }
      }
    }
    return issues;
  }

  public static String hexDigest(byte[] data, String jcaName) {
    try {
      MessageDigest md = MessageDigest.getInstance(jcaName);
      return HexFormat.of().formatHex(md.digest(data)).toUpperCase(Locale.ROOT);
    } catch (NoSuchAlgorithmException ex) {
      return "";
    }
  }

  public static byte[] rawUtf8(String text) {
    return text == null ? new byte[0] : text.getBytes(StandardCharsets.UTF_8);
  }
}
