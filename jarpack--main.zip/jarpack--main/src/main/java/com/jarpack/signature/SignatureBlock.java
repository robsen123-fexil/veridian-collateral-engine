package com.jarpack.signature;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Per-entry digest block inside a .SF file. */
public final class SignatureBlock {
  private final String entryName;
  private final Map<String, String> digests = new LinkedHashMap<>();
  private final Map<String, String> meta = new LinkedHashMap<>();

  public SignatureBlock(String entryName) {
    this.entryName = entryName == null ? "" : entryName;
  }

  public String entryName() { return entryName; }
  public Map<String, String> digests() { return Collections.unmodifiableMap(digests); }
  public Map<String, String> meta() { return Collections.unmodifiableMap(meta); }

  public void addDigest(String alg, String hex) { digests.put(alg, hex); }
  public void addMeta(String key, String val) { meta.put(key, val); }

  public int digestCount() { return digests.size(); }
}
