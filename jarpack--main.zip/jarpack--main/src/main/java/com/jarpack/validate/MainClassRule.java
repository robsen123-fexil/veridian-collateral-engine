package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class MainClassRule implements ManifestRule {

  public String id() { return "main-class"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String mc = doc.main().get(com.jarpack.core.ManifestConstants.MAIN_CLASS);
    if (mc == null || mc.isEmpty()) {
      return;
    }
    if (mc.endsWith(".class")) {
      result.add(ValidationIssue.error("Main-Class", "must-not-end-with-.class"));
    }
    if (!mc.matches("[\\w.$/]+")) {
      result.add(ValidationIssue.error("Main-Class", "illegal-chars"));
    }
    int dots = 0;
    for (int i = 0; i < mc.length(); i++) {
      if (mc.charAt(i) == '.') dots++;
    }
    if (dots == 0) {
      result.add(ValidationIssue.warning("Main-Class", "no-package-separator"));
    }
  }
}
