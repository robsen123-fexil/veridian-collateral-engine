package com.jarpack.validate;

import com.jarpack.ManifestDocument;
import com.jarpack.attr.JpmsDirectiveParser;
import com.jarpack.attr.OsgiHeaderParser;
import com.jarpack.core.DigestAlgorithm;
import com.jarpack.core.ManifestAttributeCatalog;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Deep syntax validation for manifest attribute values. */
public final class AttributeSyntaxChecker implements ManifestRule {
  private static final Pattern DOTTED_NAME = Pattern.compile("^[\\w$]+(\\.[\\w$]+)*$");
  private static final Pattern VERSION = Pattern.compile("^[\\w._+-]+$");
  private static final Pattern BOOLEAN = Pattern.compile("^(?i)true|false$");

  public String id() { return "attribute-syntax"; }

  public void check(ManifestDocument doc, ValidationResult result) {
    for (var entry : doc.main().entrySet()) {
      checkMainAttribute(entry.getKey(), entry.getValue(), result);
    }
    for (var section : doc.entries().entrySet()) {
      for (var attr : section.getValue().entrySet()) {
        checkSectionAttribute(section.getKey(), attr.getKey(), attr.getValue(), result);
      }
    }
  }

  private void checkMainAttribute(String name, String value, ValidationResult result) {
    if (value == null) {
      result.add(ValidationIssue.warning(id(), "null-value:" + name));
      return;
    }
    switch (name) {
      case "Manifest-Version":
        if (!VERSION.matcher(value).matches()) {
          result.add(ValidationIssue.error(id(), "bad-manifest-version"));
        }
        break;
      case "Main-Class":
      case "Module-Main-Class":
      case "Premain-Class":
      case "Agent-Class":
      case "Start-Class":
        if (!DOTTED_NAME.matcher(value).matches()) {
          result.add(ValidationIssue.error(id(), "bad-class-name:" + name));
        }
        break;
      case "Sealed":
      case "Multi-Release":
      case "Trusted-Library":
        if (!BOOLEAN.matcher(value).matches()) {
          result.add(ValidationIssue.error(id(), "bad-boolean:" + name));
        }
        break;
      case "Class-Path":
        checkClasspath(value, result);
        break;
      case "Add-Exports":
      case "Add-Opens":
      case "Add-Modules":
        checkJpmsDirectives(name, value, result);
        break;
      case "Import-Package":
      case "Export-Package":
        checkOsgiHeader(name, value, result);
        break;
      case "Bundle-SymbolicName":
        if (value.split(";")[0].trim().isEmpty()) {
          result.add(ValidationIssue.error(id(), "empty-bundle-symbolicname"));
        }
        break;
      case "Bundle-Version":
      case "Implementation-Version":
      case "Specification-Version":
        if (!VERSION.matcher(value).matches()) {
          result.add(ValidationIssue.warning(id(), "suspicious-version:" + name));
        }
        break;
      default:
        if (ManifestConstants.isDigestAttribute(name)) {
          checkDigest(name, value, result);
        } else if (!ManifestAttributeCatalog.isKnown(name)) {
          result.add(ValidationIssue.info(id(), "unknown-attribute:" + name));
        }
        break;
    }
    if (value.length() > ManifestConstants.maxValueLengthFor(name)) {
      result.add(ValidationIssue.warning(id(), "value-too-long:" + name));
    }
  }

  private void checkSectionAttribute(
      String section, String name, String value, ValidationResult result) {
    if (ManifestConstants.isDigestAttribute(name)) {
      checkDigest(name, value, result);
    }
    if ("Sealed".equals(name) && !BOOLEAN.matcher(value == null ? "" : value).matches()) {
      result.add(ValidationIssue.error(id(), "bad-section-sealed:" + section));
    }
  }

  private void checkClasspath(String value, ValidationResult result) {
    for (String entry : com.jarpack.ManifestMerger.splitClasspath(value)) {
      if (entry.contains("  ")) {
        result.add(ValidationIssue.warning(id(), "classpath-double-space"));
      }
    }
  }

  private void checkJpmsDirectives(String header, String value, ValidationResult result) {
    for (JpmsDirectiveParser.Directive d : JpmsDirectiveParser.parse(value)) {
      if (!d.isValid()) {
        result.add(ValidationIssue.error(id(), "invalid-jpms:" + header + ":" + d.format()));
      }
    }
  }

  private void checkOsgiHeader(String header, String value, ValidationResult result) {
    for (OsgiHeaderParser.PackageClause clause : OsgiHeaderParser.parse(value)) {
      if (!clause.isValid()) {
        result.add(ValidationIssue.error(id(), "invalid-osgi:" + header));
      }
    }
  }

  private void checkDigest(String name, String value, ValidationResult result) {
    DigestAlgorithm alg = DigestAlgorithm.fromAttribute(name);
    if (alg == null) {
      result.add(ValidationIssue.warning(id(), "unknown-digest-algorithm:" + name));
      return;
    }
    if (!alg.isValidHex(value)) {
      result.add(ValidationIssue.error(id(), "invalid-digest-hex:" + name));
    }
  }

  public static List<String> lint(ManifestDocument doc) {
    ValidationResult vr = new ValidationResult();
    new AttributeSyntaxChecker().check(doc, vr);
    List<String> messages = new ArrayList<>();
    for (ValidationIssue issue : vr.issues()) {
      messages.add(issue.severity().name().toLowerCase(Locale.ROOT)
          + ":" + issue.attribute() + ":" + issue.message());
    }
    return messages;
  }
}
