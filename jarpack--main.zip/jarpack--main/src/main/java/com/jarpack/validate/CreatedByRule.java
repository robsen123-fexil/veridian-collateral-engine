package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class CreatedByRule implements ManifestRule {

  public String id() { return "created-by"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String cb = doc.main().get("Created-By");
    if (cb == null) return;
    if (cb.length() < 3) {
      result.add(ValidationIssue.info("Created-By", "short-value"));
    }
  }
}
