package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class DuplicateAttributeRule implements ManifestRule {

  public String id() { return "duplicate-attr"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    java.util.Set<String> seen = new java.util.HashSet<>();
    for (String key : doc.main().keySet()) {
      String fold = com.jarpack.core.AttributeName.foldCase(key);
      if (!seen.add(fold)) {
        result.add(ValidationIssue.error("main", "duplicate:" + key));
      }
    }
  }
}
