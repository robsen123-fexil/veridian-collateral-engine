package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class SpecificationVersionRule implements ManifestRule {

  public String id() { return "specification-version"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String st = doc.main().get("Specification-Title");
    String sv = doc.main().get("Specification-Version");
    if (st != null && sv == null) {
      result.add(ValidationIssue.warning("Specification-Version", "title-without-version"));
    }
  }
}
