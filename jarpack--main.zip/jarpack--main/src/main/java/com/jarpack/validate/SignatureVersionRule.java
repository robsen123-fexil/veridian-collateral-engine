package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class SignatureVersionRule implements ManifestRule {

  public String id() { return "signature-version"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String sv = doc.main().get("Signature-Version");
    if (sv == null) return;
    if (!"1.0".equals(sv.trim())) {
      result.add(ValidationIssue.error("Signature-Version", "expected-1.0"));
    }
  }
}
