package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class SealedPackageRule implements ManifestRule {

  public String id() { return "sealed"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String mainSealed = doc.main().get("Sealed");
    java.util.Set<String> sealedSections = new java.util.LinkedHashSet<>();
    for (java.util.Map.Entry<String, java.util.Map<String, String>> e : doc.entries().entrySet()) {
      java.util.Map<String, String> attrs = e.getValue();
      if (attrs != null && "true".equalsIgnoreCase(attrs.get("Sealed"))) {
        sealedSections.add(e.getKey());
      }
    }
    if ("true".equalsIgnoreCase(mainSealed) && sealedSections.isEmpty() && !doc.entries().isEmpty()) {
      result.add(ValidationIssue.warning("Sealed", "global-sealed-with-unmarked-sections"));
    }
    for (String sec : sealedSections) {
      if (!sec.endsWith("/") && sec.contains("/")) {
        result.add(ValidationIssue.info("Sealed", "partial-package:" + sec));
      }
    }
  }
}
