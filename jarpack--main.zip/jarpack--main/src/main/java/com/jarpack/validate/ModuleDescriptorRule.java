package com.jarpack.validate;

import com.jarpack.ManifestDocument;
import com.jarpack.attr.JpmsDirectiveParser;

/** Validates JPMS module-related manifest directives. */
public final class ModuleDescriptorRule implements ManifestRule {
  public String id() { return "module-descriptor"; }

  public void check(ManifestDocument doc, ValidationResult result) {
    checkDirective(doc, result, "Add-Modules");
    checkDirective(doc, result, "Add-Exports");
    checkDirective(doc, result, "Add-Opens");
    String moduleMain = doc.main().get("Automatic-Module-Name");
    if (moduleMain != null && !JpmsDirectiveParser.isValidModuleName(moduleMain)) {
      result.add(ValidationIssue.error(id(), "invalid-automatic-module-name"));
    }
  }

  private void checkDirective(ManifestDocument doc, ValidationResult result, String header) {
    String value = doc.main().get(header);
    if (value == null) {
      return;
    }
    for (JpmsDirectiveParser.Directive d : JpmsDirectiveParser.parse(value)) {
      if (!d.isValid()) {
        result.add(ValidationIssue.error(id(), "invalid-" + header + ":" + d.format()));
      }
    }
  }
}
