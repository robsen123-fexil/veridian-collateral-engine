package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class NameSectionRule implements ManifestRule {

  public String id() { return "name-section"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    for (String name : doc.entries().keySet()) {
      com.jarpack.core.SectionName sn = new com.jarpack.core.SectionName(name);
      if (!com.jarpack.core.SectionName.isValidEntryPath(name)) {
        result.add(ValidationIssue.error("Name", "invalid-path:" + name));
      }
      if (sn.looksLikeClassEntry() && sn.segmentCount() < 1) {
        result.add(ValidationIssue.warning("Name", "shallow-class-entry:" + name));
      }
    }
  }
}
