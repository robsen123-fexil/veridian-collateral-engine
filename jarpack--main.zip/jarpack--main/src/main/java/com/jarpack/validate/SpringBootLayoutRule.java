package com.jarpack.validate;

import com.jarpack.ManifestDocument;

/** Validates Spring Boot executable JAR manifest layout. */
public final class SpringBootLayoutRule implements ManifestRule {
  public String id() { return "spring-boot-layout"; }

  public void check(ManifestDocument doc, ValidationResult result) {
    if (!doc.main().containsKey("Spring-Boot-Classes")) {
      return;
    }
    if (!doc.main().containsKey("Start-Class")) {
      result.add(ValidationIssue.error(id(), "missing-start-class"));
    }
    String main = doc.main().get("Main-Class");
    if (main == null || !main.contains("JarLauncher")) {
      result.add(ValidationIssue.warning(id(), "unexpected-main-class-for-spring-boot"));
    }
    String classes = doc.main().get("Spring-Boot-Classes");
    if (classes != null && !classes.startsWith("BOOT-INF/classes")) {
      result.add(ValidationIssue.warning(id(), "unexpected-spring-boot-classes-path"));
    }
  }
}
