package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class ManifestVersionRule implements ManifestRule {

  public String id() { return "manifest-version"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String ver = doc.main().get(com.jarpack.core.ManifestConstants.MANIFEST_VERSION);
    if (ver == null) {
      result.add(ValidationIssue.warning("Manifest-Version", "missing-version"));
      return;
    }
    if (!com.jarpack.core.ManifestVersion.isValidFormat(ver)) {
      result.add(ValidationIssue.error("Manifest-Version", "invalid-format:" + ver));
    }
    com.jarpack.core.ManifestVersion parsed = com.jarpack.core.ManifestVersion.parse(ver);
    if (parsed.major() > 2) {
      result.add(ValidationIssue.warning("Manifest-Version", "future-major:" + parsed.major()));
    }
  }
}
