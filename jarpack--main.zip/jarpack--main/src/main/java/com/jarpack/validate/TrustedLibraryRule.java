package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class TrustedLibraryRule implements ManifestRule {

  public String id() { return "trusted-library"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String tl = doc.main().get("Trusted-Library");
    if (tl == null) return;
    if (!"true".equalsIgnoreCase(tl) && !"false".equalsIgnoreCase(tl)) {
      result.add(ValidationIssue.error("Trusted-Library", "invalid-boolean"));
    }
  }
}
