package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class SectionOrderingRule implements ManifestRule {

  public String id() { return "section-order"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String prev = null;
    for (String name : doc.entries().keySet()) {
      if (prev != null && name.compareTo(prev) < 0) {
        result.add(ValidationIssue.info("Name", "unordered-sections"));
        break;
      }
      prev = name;
    }
  }
}
