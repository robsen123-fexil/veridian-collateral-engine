package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class ImplementationVersionRule implements ManifestRule {

  public String id() { return "implementation-version"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String iv = doc.main().get("Implementation-Version");
    if (iv == null) return;
    if (iv.length() > 256) {
      result.add(ValidationIssue.warning("Implementation-Version", "too-long"));
    }
    if (iv.contains(" ")) {
      result.add(ValidationIssue.info("Implementation-Version", "contains-space"));
    }
  }
}
