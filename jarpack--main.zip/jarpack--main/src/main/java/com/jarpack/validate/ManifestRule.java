package com.jarpack.validate;

import com.jarpack.ManifestDocument;

/** Single manifest validation rule. */
public interface ManifestRule {
  String id();
  void check(ManifestDocument doc, ValidationResult result);
}
