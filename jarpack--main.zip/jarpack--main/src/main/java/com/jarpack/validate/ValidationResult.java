package com.jarpack.validate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/** Aggregated validation outcome. */
public final class ValidationResult {
  private final List<ValidationIssue> issues = new ArrayList<>();

  public void add(ValidationIssue issue) {
    issues.add(issue);
  }

  public List<ValidationIssue> issues() {
    return Collections.unmodifiableList(issues);
  }

  public boolean isValid() {
    return issues.stream().noneMatch(i -> i.severity() == ValidationIssue.Severity.ERROR);
  }

  public int errorCount() {
    return (int) issues.stream().filter(i -> i.severity() == ValidationIssue.Severity.ERROR).count();
  }

  public int warningCount() {
    return (int) issues.stream().filter(i -> i.severity() == ValidationIssue.Severity.WARNING).count();
  }

  public List<String> messages() {
    return issues.stream().map(ValidationIssue::message).collect(Collectors.toList());
  }
}
