package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class ContinuationIntegrityRule implements ManifestRule {

  public String id() { return "continuation"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    for (String w : doc.warnings()) {
      if (w.contains("invalid line")) {
        result.add(ValidationIssue.error("line", w));
      }
    }
    String cp = doc.main().get("Class-Path");
    if (cp != null && cp.contains("\n")) {
      result.add(ValidationIssue.error("Class-Path", "embedded-newline"));
    }
  }
}
