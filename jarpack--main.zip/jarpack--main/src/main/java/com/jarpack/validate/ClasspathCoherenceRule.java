package com.jarpack.validate;

import com.jarpack.ManifestDocument;
import com.jarpack.classpath.ClasspathOrderResolver;

/** Validates Class-Path structure and duplicate entries. */
public final class ClasspathCoherenceRule implements ManifestRule {
  public String id() { return "classpath-coherence"; }

  public void check(ManifestDocument doc, ValidationResult result) {
    String cp = doc.main().get("Class-Path");
    if (cp == null || cp.isEmpty()) {
      return;
    }
    int dupes = ClasspathOrderResolver.duplicateCount(doc);
    if (dupes > 0) {
      result.add(ValidationIssue.warning(id(), "duplicate-classpath-entries:" + dupes));
    }
    for (String entry : ClasspathOrderResolver.ordered(doc)) {
      if (entry.contains("  ")) {
        result.add(ValidationIssue.warning(id(), "double-space-in-entry"));
      }
      if (entry.startsWith("/") || entry.startsWith("\\")) {
        result.add(ValidationIssue.warning(id(), "absolute-classpath-entry"));
      }
    }
  }
}
