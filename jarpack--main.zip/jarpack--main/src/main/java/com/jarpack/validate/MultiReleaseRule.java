package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class MultiReleaseRule implements ManifestRule {

  public String id() { return "multi-release"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String mr = doc.main().get("Multi-Release");
    if (mr == null) return;
    if (!"true".equalsIgnoreCase(mr) && !"false".equalsIgnoreCase(mr)) {
      result.add(ValidationIssue.error("Multi-Release", "must-be-boolean:" + mr));
    }
    String ver = doc.main().get("Manifest-Version");
    if ("true".equalsIgnoreCase(mr) && ver != null) {
      com.jarpack.core.ManifestVersion v = com.jarpack.core.ManifestVersion.parse(ver);
      if (!v.supportsMultiRelease()) {
        result.add(ValidationIssue.warning("Multi-Release", "needs-manifest-1.0+"));
      }
    }
  }
}
