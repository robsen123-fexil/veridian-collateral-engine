package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class ClassPathRule implements ManifestRule {

  public String id() { return "class-path"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String cp = doc.main().get(com.jarpack.core.ManifestConstants.CLASS_PATH);
    if (cp == null) return;
    java.util.List<String> entries = com.jarpack.ManifestMerger.splitClasspath(cp);
    for (String entry : entries) {
      if (entry.contains("..")) {
        result.add(ValidationIssue.error("Class-Path", "path-traversal:" + entry));
      }
      if (entry.startsWith("file:")) {
        result.add(ValidationIssue.warning("Class-Path", "absolute-file-url:" + entry));
      }
    }
    if (cp.length() > 8000) {
      result.add(ValidationIssue.warning("Class-Path", "very-long:" + cp.length()));
    }
  }
}
