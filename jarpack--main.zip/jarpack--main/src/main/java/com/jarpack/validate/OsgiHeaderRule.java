package com.jarpack.validate;

import com.jarpack.ManifestDocument;
import com.jarpack.attr.OsgiHeaderParser;

/** Validates OSGi bundle headers when present. */
public final class OsgiHeaderRule implements ManifestRule {
  public String id() { return "osgi-header"; }

  public void check(ManifestDocument doc, ValidationResult result) {
    if (!doc.main().containsKey("Bundle-SymbolicName")) {
      return;
    }
    checkHeader(doc, result, "Import-Package");
    checkHeader(doc, result, "Export-Package");
    String version = doc.main().get("Bundle-Version");
    if (version != null && version.trim().isEmpty()) {
      result.add(ValidationIssue.error(id(), "empty-bundle-version"));
    }
  }

  private void checkHeader(ManifestDocument doc, ValidationResult result, String header) {
    String value = doc.main().get(header);
    if (value == null) {
      return;
    }
    for (OsgiHeaderParser.PackageClause clause : OsgiHeaderParser.parse(value)) {
      if (!clause.isValid()) {
        result.add(ValidationIssue.error(id(), "invalid-" + header + ":" + clause.packageName()));
      }
    }
  }
}
