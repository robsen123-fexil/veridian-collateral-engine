package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class EmptyValueRule implements ManifestRule {

  public String id() { return "empty-value"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    for (java.util.Map.Entry<String, String> e : doc.main().entrySet()) {
      if (e.getValue() != null && e.getValue().isEmpty()
          && !"Class-Path".equals(e.getKey())) {
        result.add(ValidationIssue.warning(e.getKey(), "empty-value"));
      }
    }
  }
}
