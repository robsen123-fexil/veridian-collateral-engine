package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class ExtensionListRule implements ManifestRule {

  public String id() { return "extension-list"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String el = doc.main().get("Extension-List");
    if (el == null) return;
    for (String part : el.split("\\s+")) {
      if (part.isEmpty()) continue;
      String attr = part + "-Extension-Name";
      if (!doc.main().containsKey(attr)) {
        result.add(ValidationIssue.warning("Extension-List", "missing:" + attr));
      }
    }
  }
}
