package com.jarpack.validate;

import com.jarpack.ManifestDocument;

public final class PermissionsRule implements ManifestRule {

  public String id() { return "permissions"; }
  public void check(ManifestDocument doc, ValidationResult result) {
    String perm = doc.main().get("Permissions");
    if (perm == null) return;
    if (!perm.contains("(") || !perm.contains(")")) {
      result.add(ValidationIssue.warning("Permissions", "missing-parens"));
    }
  }
}
