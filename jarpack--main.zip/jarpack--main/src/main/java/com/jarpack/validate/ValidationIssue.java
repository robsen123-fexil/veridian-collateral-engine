package com.jarpack.validate;

/** One validation finding. */
public final class ValidationIssue {
  public enum Severity { ERROR, WARNING, INFO }

  private final Severity severity;
  private final String attribute;
  private final String message;

  private ValidationIssue(Severity severity, String attribute, String message) {
    this.severity = severity;
    this.attribute = attribute;
    this.message = message;
  }

  public static ValidationIssue error(String attribute, String message) {
    return new ValidationIssue(Severity.ERROR, attribute, message);
  }

  public static ValidationIssue warning(String attribute, String message) {
    return new ValidationIssue(Severity.WARNING, attribute, message);
  }

  public static ValidationIssue info(String attribute, String message) {
    return new ValidationIssue(Severity.INFO, attribute, message);
  }

  public Severity severity() { return severity; }
  public String attribute() { return attribute; }
  public String message() { return message; }
}
