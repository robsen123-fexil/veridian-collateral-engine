package com.jarpack.validate;

import com.jarpack.ManifestDocument;

import java.util.regex.Pattern;

/** Validates Java instrumentation agent manifest attributes. */
public final class JavaAgentRule implements ManifestRule {
  private static final Pattern CLASS = Pattern.compile("^[\\w$]+(\\.[\\w$]+)*$");

  public String id() { return "java-agent"; }

  public void check(ManifestDocument doc, ValidationResult result) {
    String premain = doc.main().get("Premain-Class");
    String agent = doc.main().get("Agent-Class");
    if (premain == null && agent == null) {
      return;
    }
    if (premain != null && !CLASS.matcher(premain).matches()) {
      result.add(ValidationIssue.error(id(), "invalid-premain-class"));
    }
    if (agent != null && !CLASS.matcher(agent).matches()) {
      result.add(ValidationIssue.error(id(), "invalid-agent-class"));
    }
    checkFlag(doc, result, "Can-Redefine-Classes");
    checkFlag(doc, result, "Can-Retransform-Classes");
    checkFlag(doc, result, "Can-Set-Native-Method-Prefix");
  }

  private void checkFlag(ManifestDocument doc, ValidationResult result, String name) {
    String val = doc.main().get(name);
    if (val != null && !"true".equalsIgnoreCase(val) && !"false".equalsIgnoreCase(val)) {
      result.add(ValidationIssue.warning(id(), "invalid-flag:" + name));
    }
  }
}
