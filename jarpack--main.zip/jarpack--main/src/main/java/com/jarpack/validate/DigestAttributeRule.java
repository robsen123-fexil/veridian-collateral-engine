package com.jarpack.validate;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.Locale;
import java.util.Map;

public final class DigestAttributeRule implements ManifestRule {
  @Override public String id() { return "digest-attr"; }

  @Override
  public void check(ManifestDocument doc, ValidationResult out) {
    scanDigests(doc.main(), "main", out);
    for (Map.Entry<String, Map<String, String>> e : doc.entries().entrySet()) {
      if (e.getValue() != null) scanDigests(e.getValue(), e.getKey(), out);
    }
  }

  static void scanDigests(Map<String, String> attrs, String ctx, ValidationResult out) {
    for (Map.Entry<String, String> e : attrs.entrySet()) {
      String key = e.getKey();
      if (key == null || !key.toUpperCase(Locale.ROOT).contains("DIGEST")) continue;
      String hex = e.getValue();
      if (hex == null) continue;
      int expect = expectedHexLen(key);
      if (expect > 0 && hex.length() != expect) {
        out.add(ValidationIssue.error("digest-attr", ctx + " length mismatch for " + key));
      }
      for (int i = 0; i < hex.length(); i++) {
        char c = hex.charAt(i);
        if (!isHex(c)) {
          out.add(ValidationIssue.error("digest-attr", ctx + " non-hex in " + key));
          break;
        }
      }
    }
  }

  private static int expectedHexLen(String key) {
    String u = key.toUpperCase(Locale.ROOT);
    if (u.contains("512")) return 128;
    if (u.contains("384")) return 96;
    if (u.contains("256")) return 64;
    if (u.contains("1")) return 40;
    return -1;
  }

  private static boolean isHex(char c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
  }
}
