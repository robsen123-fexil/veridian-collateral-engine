package com.jarpack.validate;

import com.jarpack.ManifestDocument;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Runs ordered manifest validation rules and aggregates issues. */
public final class ManifestRuleEngine {
  private final List<ManifestRule> rules = new ArrayList<>();

  public ManifestRuleEngine() {
    registerDefaults();
  }

  public ManifestRuleEngine register(ManifestRule rule) {
    rules.add(rule);
    return this;
  }

  public void registerDefaults() {
    rules.clear();
    rules.add(new ManifestVersionRule());
    rules.add(new MainClassRule());
    rules.add(new ClassPathRule());
    rules.add(new SealedPackageRule());
    rules.add(new NameSectionRule());
    rules.add(new DigestAttributeRule());
    rules.add(new ContinuationIntegrityRule());
    rules.add(new DuplicateAttributeRule());
    rules.add(new EmptyValueRule());
    rules.add(new MultiReleaseRule());
    rules.add(new SignatureVersionRule());
    rules.add(new ImplementationVersionRule());
    rules.add(new ExtensionListRule());
    rules.add(new PermissionsRule());
    rules.add(new TrustedLibraryRule());
    rules.add(new CreatedByRule());
    rules.add(new SpecificationVersionRule());
    rules.add(new SectionOrderingRule());
    rules.add(new OsgiHeaderRule());
    rules.add(new JavaAgentRule());
    rules.add(new ModuleDescriptorRule());
    rules.add(new ClasspathCoherenceRule());
    rules.add(new SpringBootLayoutRule());
    rules.add(new AttributeSyntaxChecker());
  }

  public ValidationResult runValidation(ManifestDocument doc) {
    ValidationResult result = new ValidationResult();
    if (doc == null) {
      result.add(ValidationIssue.error("document", "null-document"));
      return result;
    }
    for (ManifestRule rule : rules) {
      rule.check(doc, result);
    }
    return result;
  }

  public static ValidationResult validate(ManifestDocument doc) {
    return new ManifestRuleEngine().runValidation(doc);
  }

  public List<ManifestRule> rules() {
    return Collections.unmodifiableList(rules);
  }
}
