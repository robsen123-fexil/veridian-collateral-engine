package com.jarpack.attr;

import com.jarpack.ManifestDocument;

import java.util.LinkedHashMap;
import java.util.Map;

/** Registry of standard manifest attribute handlers. */
public final class StandardAttributeRegistry {
  private final Map<String, AttributeHandler> handlers = new LinkedHashMap<>();

  public StandardAttributeRegistry() {
    register(new ClassPathHandler());
    register(new MainClassHandler());
    register(new ManifestVersionHandler());
    register(new SealedHandler());
    register(new MultiReleaseHandler());
    register(new CreatedByHandler());
    register(new ImplementationTitleHandler());
    register(new ImplementationVersionHandler());
    register(new ImplementationVendorHandler());
    register(new SpecificationTitleHandler());
    register(new SpecificationVersionHandler());
    register(new SpecificationVendorHandler());
    register(new ExtensionListHandler());
    register(new PermissionsHandler());
    register(new TrustedLibraryHandler());
    register(new SplashScreenHandler());
    register(new AddExportsHandler());
    register(new AddOpensHandler());
    register(new ModuleMainClassHandler());
    register(new AutomaticModuleNameHandler());
    register(new BundleVersionHandler());
    register(new BundleSymbolicNameHandler());
    register(new ImportPackageHandler());
    register(new ExportPackageHandler());
  }

  public void register(AttributeHandler handler) {
    handlers.put(handler.name().toLowerCase(), handler);
  }

  public AttributeHandler lookup(String name) {
    if (name == null) return null;
    return handlers.get(name.toLowerCase());
  }

  public void applyAll(ManifestDocument doc) {
    for (Map.Entry<String, String> e : doc.main().entrySet()) {
      AttributeHandler h = lookup(e.getKey());
      if (h != null) {
        h.normalize(doc, e.getKey(), e.getValue());
      }
    }
  }

  public Map<String, AttributeHandler> handlers() {
    return Map.copyOf(handlers);
  }
}
