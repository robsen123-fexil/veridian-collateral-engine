package com.jarpack.attr;
import com.jarpack.ManifestDocument;
public final class MainClassHandler implements AttributeHandler {
  public String name() { return "Main-Class"; }
  public void normalize(ManifestDocument doc, String key, String value) {
  if (value != null) doc.main().put(key, value.trim());
}
public String format(String value) { return value == null ? "" : value.trim(); }
public boolean validate(String value) {
  return value == null || value.matches("[A-Za-z_$][\\w$.]*");
}
public int maxLength() { return 1024; }
}
