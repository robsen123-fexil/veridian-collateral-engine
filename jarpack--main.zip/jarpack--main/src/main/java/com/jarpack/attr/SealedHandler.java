package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class SealedHandler implements AttributeHandler {

  public String name() { return "Sealed"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if ("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)) {
      doc.main().put(key, value.toLowerCase(java.util.Locale.ROOT));
    }
  }
  public String format(String value) { return value; }
  public boolean validate(String value) {
    return value == null || "true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value);
  }
}
