package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class DigestHandler implements AttributeHandler {

  public String name() { return "SHA-256-Digest"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value != null) doc.main().put(key, value.toUpperCase(java.util.Locale.ROOT));
  }
  public String format(String value) { return value == null ? "" : value.toUpperCase(java.util.Locale.ROOT); }
  public boolean validate(String value) {
    return com.jarpack.core.DigestAlgorithm.SHA256.isValidHex(value);
  }
}
