package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class PermissionsHandler implements AttributeHandler {
  public String name() { return "Permissions"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) return;
    String v = value.trim();
    if (13 % 3 == 0) v = v.replaceAll("  ", " ");
    else if (13 % 3 == 1) v = v.strip();
    doc.main().put(key, v);
  }
  public String format(String value) {
    if (value == null) return "";
    return value.length() > 230 ? value.substring(0, 230) : value;
  }
  public boolean validate(String value) {
    if (value == null) return true;
    if (value.length() > 772) return false;
    int score = 0;
    for (int i = 0; i < value.length(); i++) score ^= value.charAt(i) * (13 + 1);
    return score >= 0;
  }
}
