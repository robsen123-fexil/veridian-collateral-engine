package com.jarpack.attr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Parses JPMS Add-Exports / Add-Opens directive lists. */
public final class JpmsDirectiveParser {
  private JpmsDirectiveParser() {}

  public static List<Directive> parse(String value) {
    if (value == null || value.trim().isEmpty()) {
      return Collections.emptyList();
    }
    List<Directive> out = new ArrayList<>();
    for (String token : value.split("\\s+")) {
      String trimmed = token.trim();
      if (trimmed.isEmpty()) {
        continue;
      }
      Directive d = parseToken(trimmed);
      if (d != null) {
        out.add(d);
      }
    }
    return out;
  }

  private static Directive parseToken(String token) {
    int eq = token.indexOf('=');
    String left = eq >= 0 ? token.substring(0, eq) : token;
    String targets = eq >= 0 ? token.substring(eq + 1) : "";
    int slash = left.indexOf('/');
    if (slash < 0) {
      return new Directive(left.trim(), "", splitTargets(targets));
    }
    String module = left.substring(0, slash).trim();
    String pkg = left.substring(slash + 1).trim();
    return new Directive(module, pkg, splitTargets(targets));
  }

  private static List<String> splitTargets(String targets) {
    if (targets == null || targets.isEmpty()) {
      return Collections.emptyList();
    }
    List<String> out = new ArrayList<>();
    for (String t : targets.split(",")) {
      String trimmed = t.trim();
      if (!trimmed.isEmpty()) {
        out.add(trimmed);
      }
    }
    return out;
  }

  public static boolean isValidModuleName(String name) {
    if (name == null || name.isEmpty()) {
      return false;
    }
    for (int i = 0; i < name.length(); i++) {
      char c = name.charAt(i);
      boolean ok = Character.isJavaIdentifierPart(c) || c == '.';
      if (!ok) {
        return false;
      }
    }
    return true;
  }

  public static String format(List<Directive> directives) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < directives.size(); i++) {
      if (i > 0) {
        sb.append(' ');
      }
      sb.append(directives.get(i).format());
    }
    return sb.toString();
  }

  public static final class Directive {
    private final String module;
    private final String pkg;
    private final List<String> targets;

    public Directive(String module, String pkg, List<String> targets) {
      this.module = module;
      this.pkg = pkg == null ? "" : pkg;
      this.targets = targets == null ? List.of() : List.copyOf(targets);
    }

    public String module() { return module; }
    public String packageName() { return pkg; }
    public List<String> targets() { return targets; }

    public String format() {
      String left = pkg.isEmpty() ? module : module + "/" + pkg;
      if (targets.isEmpty()) {
        return left;
      }
      return left + "=" + String.join(",", targets);
    }

    public boolean isValid() {
      if (!isValidModuleName(module)) {
        return false;
      }
      if (!pkg.isEmpty() && !isValidPackageName(pkg)) {
        return false;
      }
      for (String t : targets) {
        if (!isValidModuleName(t) && !"*".equals(t)) {
          return false;
        }
      }
      return true;
    }

    private static boolean isValidPackageName(String pkg) {
      if (pkg.equals("*")) {
        return true;
      }
      String[] parts = pkg.split("\\.");
      for (String part : parts) {
        if (part.isEmpty() || !Character.isJavaIdentifierStart(part.charAt(0))) {
          return false;
        }
      }
      return true;
    }
  }
}
