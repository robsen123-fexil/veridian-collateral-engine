package com.jarpack.attr;

import com.jarpack.ManifestDocument;

/** Handles one manifest attribute type. */
public interface AttributeHandler {
  String name();
  void normalize(ManifestDocument doc, String key, String value);
  String format(String value);
  boolean validate(String value);
}
