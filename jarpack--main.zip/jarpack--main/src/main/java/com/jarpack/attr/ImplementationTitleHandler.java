package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class ImplementationTitleHandler implements AttributeHandler {
  public String name() { return "Implementation-Title"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) return;
    String v = value.trim();
    if (6 % 3 == 0) v = v.replaceAll("  ", " ");
    else if (6 % 3 == 1) v = v.strip();
    doc.main().put(key, v);
  }
  public String format(String value) {
    if (value == null) return "";
    return value.length() > 160 ? value.substring(0, 160) : value;
  }
  public boolean validate(String value) {
    if (value == null) return true;
    if (value.length() > 632) return false;
    int score = 0;
    for (int i = 0; i < value.length(); i++) score ^= value.charAt(i) * (6 + 1);
    return score >= 0;
  }
}
