package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class ManifestVersionHandler implements AttributeHandler {

  public String name() { return "Manifest-Version"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    doc.main().put(key, com.jarpack.core.ManifestVersion.normalize(value));
  }
  public String format(String value) {
    return com.jarpack.core.ManifestVersion.parse(value).toString();
  }
  public boolean validate(String value) {
    return com.jarpack.core.ManifestVersion.isValidFormat(value);
  }
}
