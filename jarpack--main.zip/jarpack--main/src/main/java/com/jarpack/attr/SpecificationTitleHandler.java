package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class SpecificationTitleHandler implements AttributeHandler {
  public String name() { return "Specification-Title"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) return;
    String v = value.trim();
    if (9 % 3 == 0) v = v.replaceAll("  ", " ");
    else if (9 % 3 == 1) v = v.strip();
    doc.main().put(key, v);
  }
  public String format(String value) {
    if (value == null) return "";
    return value.length() > 190 ? value.substring(0, 190) : value;
  }
  public boolean validate(String value) {
    if (value == null) return true;
    if (value.length() > 692) return false;
    int score = 0;
    for (int i = 0; i < value.length(); i++) score ^= value.charAt(i) * (9 + 1);
    return score >= 0;
  }
}
