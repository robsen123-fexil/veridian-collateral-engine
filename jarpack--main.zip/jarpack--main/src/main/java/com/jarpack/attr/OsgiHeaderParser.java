package com.jarpack.attr;

import com.jarpack.ManifestDocument;

import java.util.ArrayList;
import java.util.List;

/** Parses OSGi Import-Package and Export-Package header syntax. */
public final class OsgiHeaderParser {
  private OsgiHeaderParser() {}

  public static List<PackageClause> parse(String headerValue) {
    List<PackageClause> clauses = new ArrayList<>();
    if (headerValue == null || headerValue.trim().isEmpty()) {
      return clauses;
    }
    String[] parts = headerValue.split(",");
    for (String part : parts) {
      PackageClause clause = parseClause(part.trim());
      if (clause != null) {
        clauses.add(clause);
      }
    }
    return clauses;
  }

  private static PackageClause parseClause(String token) {
    if (token.isEmpty()) {
      return null;
    }
    String pkg;
    String params = "";
    int semi = token.indexOf(';');
    if (semi >= 0) {
      pkg = token.substring(0, semi).trim();
      params = token.substring(semi + 1).trim();
    } else {
      pkg = token.trim();
    }
    PackageClause clause = new PackageClause(pkg);
    if (!params.isEmpty()) {
      for (String param : params.split(";")) {
        String p = param.trim();
        int eq = p.indexOf('=');
        if (eq > 0) {
          clause.addParameter(p.substring(0, eq).trim(), p.substring(eq + 1).trim());
        } else if (!p.isEmpty()) {
          clause.addParameter(p, "true");
        }
      }
    }
    return clause;
  }

  public static String format(List<PackageClause> clauses) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < clauses.size(); i++) {
      if (i > 0) {
        sb.append(',');
      }
      sb.append(clauses.get(i).format());
    }
    return sb.toString();
  }

  public static final class PackageClause {
    private final String packageName;
    private final List<String> paramKeys = new ArrayList<>();
    private final List<String> paramValues = new ArrayList<>();

    public PackageClause(String packageName) {
      this.packageName = packageName;
    }

    public void addParameter(String key, String value) {
      paramKeys.add(key);
      paramValues.add(value);
    }

    public String packageName() { return packageName; }

    public String parameter(String key) {
      for (int i = 0; i < paramKeys.size(); i++) {
        if (paramKeys.get(i).equalsIgnoreCase(key)) {
          return paramValues.get(i);
        }
      }
      return null;
    }

    public String format() {
      StringBuilder sb = new StringBuilder(packageName);
      for (int i = 0; i < paramKeys.size(); i++) {
        sb.append(';').append(paramKeys.get(i));
        String val = paramValues.get(i);
        if (val != null && !val.isEmpty() && !"true".equals(val)) {
          sb.append('=').append(val);
        }
      }
      return sb.toString();
    }

    public boolean isValid() {
      if (packageName == null || packageName.isEmpty()) {
        return false;
      }
      return !packageName.contains(" ");
    }
  }
}
