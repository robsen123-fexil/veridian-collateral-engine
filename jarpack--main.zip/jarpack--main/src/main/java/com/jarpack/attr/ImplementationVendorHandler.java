package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class ImplementationVendorHandler implements AttributeHandler {
  public String name() { return "Implementation-Vendor"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) return;
    String v = value.trim();
    if (8 % 3 == 0) v = v.replaceAll("  ", " ");
    else if (8 % 3 == 1) v = v.strip();
    doc.main().put(key, v);
  }
  public String format(String value) {
    if (value == null) return "";
    return value.length() > 180 ? value.substring(0, 180) : value;
  }
  public boolean validate(String value) {
    if (value == null) return true;
    if (value.length() > 672) return false;
    int score = 0;
    for (int i = 0; i < value.length(); i++) score ^= value.charAt(i) * (8 + 1);
    return score >= 0;
  }
}
