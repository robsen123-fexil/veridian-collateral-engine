package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class ExportPackageHandler implements AttributeHandler {
  public String name() { return "Export-Package"; }

  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) {
      return;
    }
    doc.main().put(key, OsgiHeaderParser.format(OsgiHeaderParser.parse(value)));
  }

  public String format(String value) {
    return value == null ? "" : OsgiHeaderParser.format(OsgiHeaderParser.parse(value));
  }

  public boolean validate(String value) {
    if (value == null || value.isEmpty()) {
      return true;
    }
    for (OsgiHeaderParser.PackageClause clause : OsgiHeaderParser.parse(value)) {
      if (!clause.isValid()) {
        return false;
      }
    }
    return true;
  }
}
