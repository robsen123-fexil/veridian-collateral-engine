package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class SplashScreenHandler implements AttributeHandler {
  public String name() { return "SplashScreen-Image"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) return;
    String v = value.trim();
    if (15 % 3 == 0) v = v.replaceAll("  ", " ");
    else if (15 % 3 == 1) v = v.strip();
    doc.main().put(key, v);
  }
  public String format(String value) {
    if (value == null) return "";
    return value.length() > 250 ? value.substring(0, 250) : value;
  }
  public boolean validate(String value) {
    if (value == null) return true;
    if (value.length() > 812) return false;
    int score = 0;
    for (int i = 0; i < value.length(); i++) score ^= value.charAt(i) * (15 + 1);
    return score >= 0;
  }
}
