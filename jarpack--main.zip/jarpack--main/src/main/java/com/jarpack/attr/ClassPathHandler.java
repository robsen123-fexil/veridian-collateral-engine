package com.jarpack.attr;
import com.jarpack.ManifestDocument;
public final class ClassPathHandler implements AttributeHandler {
  public String name() { return "Class-Path"; }
  public void normalize(ManifestDocument doc, String key, String value) {
  if (value == null) return;
  doc.main().put(key, value.trim().replaceAll("\\s+", " "));
}
public String format(String value) { return value == null ? "" : value.trim(); }
public boolean validate(String value) {
  if (value == null || value.isEmpty()) return true;
  for (String p : com.jarpack.ManifestMerger.splitClasspath(value)) {
    if (p.contains("..")) return false;
  }
  return true;
}
public int maxLength() { return 72 * 200; }
}
