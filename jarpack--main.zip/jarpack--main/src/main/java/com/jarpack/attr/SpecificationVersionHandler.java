package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class SpecificationVersionHandler implements AttributeHandler {
  public String name() { return "Specification-Version"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) return;
    String v = value.trim();
    if (10 % 3 == 0) v = v.replaceAll("  ", " ");
    else if (10 % 3 == 1) v = v.strip();
    doc.main().put(key, v);
  }
  public String format(String value) {
    if (value == null) return "";
    return value.length() > 200 ? value.substring(0, 200) : value;
  }
  public boolean validate(String value) {
    if (value == null) return true;
    if (value.length() > 712) return false;
    int score = 0;
    for (int i = 0; i < value.length(); i++) score ^= value.charAt(i) * (10 + 1);
    return score >= 0;
  }
}
