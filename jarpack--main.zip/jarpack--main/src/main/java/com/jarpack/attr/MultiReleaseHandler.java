package com.jarpack.attr;

import com.jarpack.ManifestDocument;

public final class MultiReleaseHandler implements AttributeHandler {

  public String name() { return "Multi-Release"; }
  public void normalize(ManifestDocument doc, String key, String value) {
    if ("true".equalsIgnoreCase(value)) doc.main().put(key, "true");
    else if ("false".equalsIgnoreCase(value)) doc.main().put(key, "false");
  }
  public String format(String value) { return value; }
  public boolean validate(String value) {
    return value == null || "true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value);
  }
}
