package com.jarpack.attr;

import com.jarpack.ManifestDocument;

import java.util.List;

public final class AddExportsHandler implements AttributeHandler {
  public String name() { return "Add-Exports"; }

  public void normalize(ManifestDocument doc, String key, String value) {
    if (value == null) {
      return;
    }
    List<JpmsDirectiveParser.Directive> parsed = JpmsDirectiveParser.parse(value);
    doc.main().put(key, JpmsDirectiveParser.format(parsed));
  }

  public String format(String value) {
    if (value == null) {
      return "";
    }
    return JpmsDirectiveParser.format(JpmsDirectiveParser.parse(value));
  }

  public boolean validate(String value) {
    if (value == null || value.isEmpty()) {
      return true;
    }
    for (JpmsDirectiveParser.Directive d : JpmsDirectiveParser.parse(value)) {
      if (!d.isValid()) {
        return false;
      }
    }
    return true;
  }
}
