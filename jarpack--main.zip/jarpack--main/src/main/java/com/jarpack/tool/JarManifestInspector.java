package com.jarpack.tool;

import com.jarpack.ManifestDocument;
import com.jarpack.archive.JarManifestReader;
import com.jarpack.archive.MultiReleaseManifestResolver;
import com.jarpack.archive.ZipEntryCatalog;
import com.jarpack.classpath.ClasspathCoherenceChecker;
import com.jarpack.io.ManifestRoundTripGuard;
import com.jarpack.profile.JarProfileDetector;
import com.jarpack.profile.ProfileValidationSuite;
import com.jarpack.signature.SignedJarVerifier;
import com.jarpack.validate.ValidationResult;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipFile;

/** High-level inspection report for a JAR manifest and related metadata. */
public final class JarManifestInspector {
  private JarManifestInspector() {}

  public static InspectionReport inspect(Path jarPath) throws IOException {
    InspectionReport report = new InspectionReport();
    try (ZipFile jar = new ZipFile(jarPath.toFile())) {
      JarManifestReader.ManifestReadResult read = JarManifestReader.inspect(jarPath);
      ManifestDocument primary = read.primary();
      report.setDocument(primary);
      report.setMultiRelease(read.isMultiRelease());

      ZipEntryCatalog catalog = read.catalog();
      report.setEntryCount(catalog.entryCount());
      report.addIssues("classpath", ClasspathCoherenceChecker.checkAgainstCatalog(primary, catalog));

      JarProfileDetector.DetectionResult detection = JarProfileDetector.detect(primary);
      report.setJarType(detection.primary().name());
      report.setProfileConfidence(detection.confidence());

      ValidationResult validation = ProfileValidationSuite.validate(primary);
      report.setValidationErrors(validation.errorCount());
      report.setValidationWarnings(validation.warningCount());
      for (var issue : validation.issues()) {
        report.addIssue("validation:" + issue.attribute() + ":" + issue.message());
      }

      byte[] raw = com.jarpack.archive.JarManifestReader.readRawBytes(
          jar, com.jarpack.archive.ManifestEntryLocator.DEFAULT_MANIFEST);
      ManifestRoundTripGuard.RoundTripReport rt = ManifestRoundTripGuard.check(raw);
      if (!rt.ok()) {
        report.addIssues("roundtrip", rt.issues());
      }

      MultiReleaseManifestResolver.ResolvedManifests resolved =
          MultiReleaseManifestResolver.resolve(jar);
      report.addIssues("multirelease",
          MultiReleaseManifestResolver.validateLayout(resolved, catalog));

      SignedJarVerifier verifier = new SignedJarVerifier();
      SignedJarVerifier.VerificationReport sig = verifier.verify(jar);
      if (!sig.ok()) {
        report.addIssues("signature", sig.issues());
      }
      report.setSigner(sig.signer());
    }
    return report;
  }

  public static final class InspectionReport {
    private ManifestDocument document;
    private int entryCount;
    private boolean multiRelease;
    private String jarType = "UNKNOWN";
    private int profileConfidence;
    private int validationErrors;
    private int validationWarnings;
    private String signer = "unknown";
    private final List<String> issues = new ArrayList<>();

    public ManifestDocument document() { return document; }
    public int entryCount() { return entryCount; }
    public boolean multiRelease() { return multiRelease; }
    public String jarType() { return jarType; }
    public int profileConfidence() { return profileConfidence; }
    public int validationErrors() { return validationErrors; }
    public int validationWarnings() { return validationWarnings; }
    public String signer() { return signer; }
    public List<String> issues() { return List.copyOf(issues); }

    void setDocument(ManifestDocument d) { document = d; }
    void setEntryCount(int c) { entryCount = c; }
    void setMultiRelease(boolean v) { multiRelease = v; }
    void setJarType(String t) { jarType = t; }
    void setProfileConfidence(int c) { profileConfidence = c; }
    void setValidationErrors(int c) { validationErrors = c; }
    void setValidationWarnings(int c) { validationWarnings = c; }
    void setSigner(String s) { signer = s; }
    void addIssue(String issue) { issues.add(issue); }

    void addIssues(String prefix, List<String> more) {
      for (String m : more) {
        issues.add(prefix + ":" + m);
      }
    }
  }
}
