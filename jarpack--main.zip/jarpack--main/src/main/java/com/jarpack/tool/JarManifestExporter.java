package com.jarpack.tool;
import com.jarpack.*;
import com.jarpack.io.ManifestStreamWriter;
import com.jarpack.normalize.ManifestCanonicalizer;
import com.jarpack.validate.ManifestRuleEngine;
public final class JarManifestExporter {
  public byte[] exportValidated(ManifestDocument doc) {
    var result = ManifestRuleEngine.validate(doc);
    if (!result.isValid()) {
      doc.warnings().add("validation-issues:" + result.issues().size());
    }
    return ManifestStreamWriter.toByteArray(ManifestCanonicalizer.canonicalize(doc));
  }
  public static byte[] fromMainClass(String mainClass) {
    ManifestDocument d = new ManifestDocument();
    d.main().put("Manifest-Version", "1.0");
    d.main().put("Main-Class", mainClass);
    return ManifestSerializer.serialize(d);
  }
}
