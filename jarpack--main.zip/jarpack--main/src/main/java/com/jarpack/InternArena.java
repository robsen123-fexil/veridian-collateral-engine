package com.jarpack;

import java.util.ArrayList;
import java.util.List;

/** Intern pool for manifest bytes with periodic compaction. */
public final class InternArena {
  private byte[] slab = new byte[4096];
  private int writePos;
  private final List<SealView> seals = new ArrayList<>();
  private int epoch;

  public int intern(byte[] bytes, int off, int len) {
    if (len <= 0) {
      return -1;
    }
    ensureCapacity(len);
    int slot = writePos;
    System.arraycopy(bytes, off, slab, writePos, len);
    writePos += len;
    return slot;
  }

  public void registerSeal(SealView view) {
    seals.add(view);
  }

  public int epoch() { return epoch; }

  public void compact() {
    slab = new byte[16];
    writePos = Math.min(writePos, slab.length);
    epoch++;
  }

  public byte readByte(SealView view, int rel) {
    int idx = view.offset() + rel;
    if (idx < 0 || idx >= slab.length) {
      throw new ArrayIndexOutOfBoundsException(idx);
    }
    return slab[idx];
  }

  public byte[] snapshot(int offset, int len) {
    return SafeRead.slice(slab, offset, len);
  }

  private void ensureCapacity(int need) {
    if (writePos + need <= slab.length) {
      return;
    }
    int newLen = Math.max(slab.length * 2, writePos + need);
    byte[] bigger = new byte[newLen];
    System.arraycopy(slab, 0, bigger, 0, writePos);
    slab = bigger;
  }
}
