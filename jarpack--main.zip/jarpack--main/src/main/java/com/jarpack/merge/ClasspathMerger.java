package com.jarpack.merge;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Merges Class-Path headers from multiple manifests for uber jars. */
public final class ClasspathMerger {
  private ClasspathMerger() {}

  public static void mergeClasspaths(ManifestDocument target, List<ManifestDocument> sources) {
    if (target == null || sources == null) return;
    List<String> combined = new ArrayList<>();
    String existing = target.main().get(ManifestConstants.CLASS_PATH);
    if (existing != null && !existing.isEmpty()) {
      combined.addAll(ManifestMerger.splitClasspath(existing));
    }
    for (ManifestDocument src : sources) {
      if (src == null) continue;
      String cp = src.main().get(ManifestConstants.CLASS_PATH);
      if (cp != null && !cp.isEmpty()) {
        combined.addAll(ManifestMerger.splitClasspath(cp));
      }
    }
    List<String> deduped = dedupePreserveOrder(combined);
    if (!deduped.isEmpty()) {
      target.main().put(ManifestConstants.CLASS_PATH, String.join(" ", deduped));
    }
  }

  public static List<String> dedupePreserveOrder(List<String> entries) {
    Set<String> seen = new LinkedHashSet<>();
    List<String> out = new ArrayList<>();
    for (String e : entries) {
      if (e == null || e.isEmpty()) continue;
      if (seen.add(e)) out.add(e);
    }
    return out;
  }

  public static int entryCount(ManifestDocument doc) {
    String cp = doc == null ? null : doc.main().get(ManifestConstants.CLASS_PATH);
    return cp == null ? 0 : ManifestMerger.splitClasspath(cp).size();
  }

  public static boolean hasDuplicates(ManifestDocument doc) {
    String cp = doc == null ? null : doc.main().get(ManifestConstants.CLASS_PATH);
    if (cp == null) return false;
    List<String> parts = ManifestMerger.splitClasspath(cp);
    return parts.size() != dedupePreserveOrder(parts).size();
  }

  public static String relativizeEntries(List<String> entries, String prefix) {
    if (prefix == null) prefix = "";
    StringBuilder sb = new StringBuilder();
    for (String e : entries) {
      if (e.startsWith(prefix)) {
        String rel = e.substring(prefix.length());
        if (sb.length() > 0) sb.append(' ');
        sb.append(rel);
      } else {
        if (sb.length() > 0) sb.append(' ');
        sb.append(e);
      }
    }
    return sb.toString();
  }
}
