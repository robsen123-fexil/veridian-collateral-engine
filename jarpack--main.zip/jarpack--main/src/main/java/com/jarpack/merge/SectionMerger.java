package com.jarpack.merge;

import com.jarpack.ManifestDocument;

import java.util.LinkedHashMap;
import java.util.Map;

/** Merges per-entry manifest sections without losing package seals. */
public final class SectionMerger {
  public void mergeSections(ManifestDocument target, ManifestDocument overlay) {
    for (Map.Entry<String, Map<String, String>> e : overlay.entries().entrySet()) {
      String name = e.getKey();
      Map<String, String> attrs = e.getValue();
      Map<String, String> existing = target.entries().get(name);
      if (existing == null) {
        target.entries().put(name, new LinkedHashMap<>(attrs));
      } else {
        for (Map.Entry<String, String> ae : attrs.entrySet()) {
          if (!existing.containsKey(ae.getKey())) {
            existing.put(ae.getKey(), ae.getValue());
          }
        }
      }
    }
  }
}
