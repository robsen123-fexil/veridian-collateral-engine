package com.jarpack.merge;
public final class ManifestMergePolicy {
  public boolean preserveCreatedBy = true;
  public boolean mergeClasspaths = true;
  public boolean stripSignatures = true;
  public boolean failOnMainClassConflict = false;
  public static ManifestMergePolicy defaults() { return new ManifestMergePolicy(); }
  public ManifestMergePolicy preserveCreatedBy(boolean v) { preserveCreatedBy = v; return this; }
  public ManifestMergePolicy mergeClasspaths(boolean v) { mergeClasspaths = v; return this; }
}
