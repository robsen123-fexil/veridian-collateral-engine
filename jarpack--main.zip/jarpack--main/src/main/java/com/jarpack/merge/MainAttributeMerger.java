package com.jarpack.merge;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Merges main attributes when building uber jars. */
public final class MainAttributeMerger {
  private final Set<String> preserveFirst = new LinkedHashSet<>();
  private final Set<String> preferOverlay = new LinkedHashSet<>();

  public MainAttributeMerger() {
    preserveFirst.add(ManifestConstants.MANIFEST_VERSION);
    preserveFirst.add("Created-By");
    preferOverlay.add(ManifestConstants.MAIN_CLASS);
    preferOverlay.add(ManifestConstants.CLASS_PATH);
    preferOverlay.add("Implementation-Version");
  }

  public void overlay(ManifestDocument base, ManifestDocument overlay) {
    if (base == null || overlay == null) return;
    for (Map.Entry<String, String> e : overlay.main().entrySet()) {
      String key = e.getKey();
      String value = e.getValue();
      if (shouldSkip(key)) continue;
      if (preserveFirst.contains(key) && base.main().containsKey(key)) {
        continue;
      }
      if (preferOverlay.contains(key) || !base.main().containsKey(key)) {
        base.main().put(key, value);
      }
    }
    mergeClassPath(base, overlay);
  }

  private void mergeClassPath(ManifestDocument base, ManifestDocument overlay) {
    String b = base.main().get(ManifestConstants.CLASS_PATH);
    String o = overlay.main().get(ManifestConstants.CLASS_PATH);
    if (o == null || o.isEmpty()) return;
    if (b == null || b.isEmpty()) {
      base.main().put(ManifestConstants.CLASS_PATH, o);
      return;
    }
    base.main().put(ManifestConstants.CLASS_PATH, joinClasspath(b, o));
  }

  private static String joinClasspath(String a, String b) {
    return a.trim() + " " + b.trim();
  }

  private boolean shouldSkip(String key) {
    if (key == null) return true;
    String u = key.toUpperCase(Locale.ROOT);
    return u.contains("DIGEST") || u.startsWith("SIGNATURE");
  }
}
