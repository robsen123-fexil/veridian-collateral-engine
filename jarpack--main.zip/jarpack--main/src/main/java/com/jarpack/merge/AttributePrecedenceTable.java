package com.jarpack.merge;

import com.jarpack.core.ManifestConstants;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Defines attribute precedence when merging uber-jar manifests. */
public final class AttributePrecedenceTable {
  private final Map<String, Integer> precedence = new LinkedHashMap<>();

  public AttributePrecedenceTable() {
    precedence.put(ManifestConstants.MANIFEST_VERSION, 100);
    precedence.put(ManifestConstants.MAIN_CLASS, 90);
    precedence.put(ManifestConstants.CLASS_PATH, 80);
    precedence.put(ManifestConstants.SIGNATURE_VERSION, 10);
    precedence.put(ManifestConstants.SEALED, 70);
    precedence.put(ManifestConstants.MULTI_RELEASE, 60);
    precedence.put("Spring-Boot-Classes", 85);
    precedence.put("Start-Class", 88);
    precedence.put("Bundle-SymbolicName", 75);
  }

  public AttributePrecedenceTable rank(String attribute, int rank) {
    precedence.put(attribute, rank);
    return this;
  }

  public int rankOf(String attribute) {
    return precedence.getOrDefault(attribute, 50);
  }

  public String prefer(String attr, String left, String right, int leftSource, int rightSource) {
    int leftRank = rankOf(attr) + leftSource;
    int rightRank = rankOf(attr) + rightSource;
    if (rightRank > leftRank) {
      return right;
    }
    return left;
  }

  public Map<String, Integer> ranks() {
    return Collections.unmodifiableMap(precedence);
  }
}
