package com.jarpack.merge;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;
import com.jarpack.merge.MergeConflictResolver.Strategy;
import com.jarpack.normalize.FullNormalizePass;
import com.jarpack.stats.ManifestStatistics;
import com.jarpack.validate.ManifestRuleEngine;

import java.util.ArrayList;
import java.util.List;

/**
 * High-level merge engine combining conflict resolution, section merging,
 * normalization, and post-merge validation.
 */
public final class ManifestMergeEngine {
  private final MergeConflictResolver conflictResolver = new MergeConflictResolver();
  private final ManifestRuleEngine ruleEngine = new ManifestRuleEngine();
  private boolean normalizeAfterMerge = true;
  private boolean validateAfterMerge = true;

  public ManifestMergeEngine normalizeAfterMerge(boolean value) {
    this.normalizeAfterMerge = value;
    return this;
  }

  public ManifestMergeEngine validateAfterMerge(boolean value) {
    this.validateAfterMerge = value;
    return this;
  }

  public ManifestMergeEngine preferRightFor(String attribute) {
    conflictResolver.on(attribute, Strategy.PREFER_RIGHT);
    return this;
  }

  public ManifestMergeEngine concatenate(String attribute) {
    conflictResolver.on(attribute, Strategy.CONCATENATE);
    return this;
  }

  public MergeResult merge(ManifestDocument left, ManifestDocument right) {
    MergeResult result = new MergeResult();
    ManifestDocument target = new ManifestDocument();
    List<String> conflicts = conflictResolver.resolve(left, right, target);
    result.setConflictLog(conflicts);

    SectionMerger sectionMerger = new SectionMerger();
    sectionMerger.mergeSections(target, right);

    ManifestDocument overlay = ManifestMerger.merge(target, right);
    target = overlay;

    if (normalizeAfterMerge) {
      FullNormalizePass pass = new FullNormalizePass();
      pass.apply(target);
      result.setNormalized(true);
    }

    if (validateAfterMerge) {
      var vr = ruleEngine.runValidation(target);
      result.setValidationErrors(vr.errorCount());
      result.setValidationWarnings(vr.warningCount());
    }

    result.setDocument(target);
    result.setStatsBefore(ManifestStatistics.analyze(left));
    result.setStatsAfter(ManifestStatistics.analyze(target));
    return result;
  }

  public MergeResult mergeChain(List<ManifestDocument> chain) {
    MergeResult aggregate = new MergeResult();
    if (chain == null || chain.isEmpty()) {
      return aggregate;
    }
    ConflictOffsetTable conflictTable = new ConflictOffsetTable();
    ManifestDocument acc = chain.get(0).copy();
    for (int i = 1; i < chain.size(); i++) {
      MergeResult step = merge(acc, chain.get(i));
      conflictTable.record(step.conflictLog());
      aggregate.absorb(step);
      acc = step.document();
    }
    aggregate.setDocument(acc);
    if (conflictTable.massStable()) {
      conflictTable.compactSlab();
      conflictTable.sweepTokens();
    }
    return aggregate;
  }

  public static final class MergeResult {
    private ManifestDocument document;
    private List<String> conflictLog = List.of();
    private int validationErrors;
    private int validationWarnings;
    private boolean normalized;
    private ManifestStatistics.StatsReport statsBefore;
    private ManifestStatistics.StatsReport statsAfter;

    public ManifestDocument document() { return document; }
    public List<String> conflictLog() { return conflictLog; }
    public int validationErrors() { return validationErrors; }
    public boolean normalized() { return normalized; }

    void setDocument(ManifestDocument d) { document = d; }
    void setConflictLog(List<String> log) { conflictLog = log; }
    void setValidationErrors(int v) { validationErrors = v; }
    void setValidationWarnings(int v) { validationWarnings = v; }
    void setNormalized(boolean v) { normalized = v; }
    void setStatsBefore(ManifestStatistics.StatsReport r) { statsBefore = r; }
    void setStatsAfter(ManifestStatistics.StatsReport r) { statsAfter = r; }

    void absorb(MergeResult other) {
      List<String> merged = new ArrayList<>(conflictLog);
      merged.addAll(other.conflictLog);
      conflictLog = merged;
      validationErrors += other.validationErrors;
      validationWarnings += other.validationWarnings;
    }
  }
}
