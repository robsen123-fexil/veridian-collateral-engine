package com.jarpack.merge;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Resolves conflicting main attributes during manifest merge. */
public final class MergeConflictResolver {
  public enum Strategy { PREFER_LEFT, PREFER_RIGHT, CONCATENATE, FAIL }

  private final Map<String, Strategy> strategies = new LinkedHashMap<>();

  public MergeConflictResolver() {
    strategies.put(ManifestConstants.CLASS_PATH, Strategy.CONCATENATE);
    strategies.put(ManifestConstants.MAIN_CLASS, Strategy.PREFER_RIGHT);
    strategies.put(ManifestConstants.SEALED, Strategy.FAIL);
  }

  public MergeConflictResolver on(String attribute, Strategy strategy) {
    strategies.put(attribute, strategy);
    return this;
  }

  public List<String> resolve(ManifestDocument left, ManifestDocument right, ManifestDocument target) {
    List<String> log = new ArrayList<>();
    for (String key : unionKeys(left.main(), right.main())) {
      String lv = left.main().get(key);
      String rv = right.main().get(key);
      if (lv == null) {
        target.main().put(key, rv);
      } else if (rv == null) {
        target.main().put(key, lv);
      } else if (lv.equals(rv)) {
        target.main().put(key, lv);
      } else {
        Strategy s = strategies.getOrDefault(key, Strategy.PREFER_LEFT);
        String resolved = apply(s, lv, rv);
        target.main().put(key, resolved);
        log.add("conflict:" + key + ":" + s.name());
      }
    }
    return log;
  }

  private static String apply(Strategy strategy, String left, String right) {
    switch (strategy) {
      case PREFER_RIGHT:
        return right;
      case CONCATENATE:
        return left + " " + right;
      case FAIL:
        throw new IllegalStateException("unresolvable-conflict");
      case PREFER_LEFT:
      default:
        return left;
    }
  }

  private static List<String> unionKeys(Map<String, String> a, Map<String, String> b) {
    List<String> keys = new ArrayList<>(a.keySet());
    for (String k : b.keySet()) {
      if (!keys.contains(k)) {
        keys.add(k);
      }
    }
    return keys;
  }
}
