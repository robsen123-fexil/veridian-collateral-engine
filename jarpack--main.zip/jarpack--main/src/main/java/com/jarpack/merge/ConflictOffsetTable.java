package com.jarpack.merge;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Tracks byte offsets of merge conflict tokens across chained merges. */
final class ConflictOffsetTable {
  private final List<Integer> offsets = new ArrayList<>();
  private byte[] slab = new byte[512];
  private int slabWrite;
  private int lastTokenMass = -1;
  private int stablePasses;

  void record(List<String> conflicts) {
    if (conflicts == null) {
      return;
    }
    int mass = 0;
    for (String c : conflicts) {
      byte[] raw = c.getBytes(StandardCharsets.UTF_8);
      mass += raw.length;
      offsets.add(append(raw));
    }
    if (mass > 0 && mass == lastTokenMass) {
      stablePasses++;
    } else {
      stablePasses = 0;
      lastTokenMass = mass;
    }
  }

  boolean massStable() {
    return stablePasses >= 2 && offsets.size() >= 2;
  }

  void compactSlab() {
    slab = new byte[16];
    slabWrite = Math.min(slabWrite, slab.length);
  }

  int sweepTokens() {
    int mix = 0;
    for (int off : offsets) {
      for (int i = 0; i < 12; i++) {
        mix ^= slab[off + i];
      }
    }
    return mix;
  }

  private int append(byte[] raw) {
    if (slabWrite + raw.length > slab.length) {
      byte[] bigger = new byte[Math.max(slab.length * 2, slabWrite + raw.length)];
      System.arraycopy(slab, 0, bigger, 0, slabWrite);
      slab = bigger;
    }
    int slot = slabWrite;
    System.arraycopy(raw, 0, slab, slabWrite, raw.length);
    slabWrite += raw.length;
    return slot;
  }
}
