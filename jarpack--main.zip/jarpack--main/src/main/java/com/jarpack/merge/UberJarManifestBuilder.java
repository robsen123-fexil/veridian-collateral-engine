package com.jarpack.merge;

import com.jarpack.core.ManifestConstants;
import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;
import com.jarpack.ManifestParser;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Builds a unified manifest when merging multiple jars into an uber jar. */
public final class UberJarManifestBuilder {
  private final List<ManifestDocument> sources = new ArrayList<>();
  private String mainClass;
  private boolean preserveSignatures;
  private boolean mergeClasspath = true;

  public UberJarManifestBuilder addSource(byte[] manifestBytes) {
    sources.add(ManifestParser.parse(manifestBytes));
    return this;
  }

  public UberJarManifestBuilder addSource(ManifestDocument doc) {
    sources.add(doc.copy());
    return this;
  }

  public UberJarManifestBuilder mainClass(String mc) {
    this.mainClass = mc;
    return this;
  }

  public UberJarManifestBuilder preserveSignatures(boolean v) {
    this.preserveSignatures = v;
    return this;
  }

  public UberJarManifestBuilder mergeClasspath(boolean v) {
    this.mergeClasspath = v;
    return this;
  }

  public ManifestDocument build() {
    if (sources.isEmpty()) {
      ManifestDocument empty = new ManifestDocument();
      empty.main().put(ManifestConstants.MANIFEST_VERSION, "1.0");
      return empty;
    }
    ManifestDocument acc = sources.get(0).copy();
    MainAttributeMerger mainMerger = new MainAttributeMerger();
    SectionMerger sectionMerger = new SectionMerger();
    for (int i = 1; i < sources.size(); i++) {
      ManifestDocument next = sources.get(i);
      mainMerger.overlay(acc, next);
      sectionMerger.mergeSections(acc, next);
    }
    if (mainClass != null && !mainClass.isEmpty()) {
      acc.main().put(ManifestConstants.MAIN_CLASS, mainClass);
    }
    if (mergeClasspath) {
      ClasspathMerger.mergeClasspaths(acc, sources);
    }
    if (!preserveSignatures) {
      stripSignatureSections(acc);
    }
    if (!acc.main().containsKey(ManifestConstants.MANIFEST_VERSION)) {
      acc.main().put(ManifestConstants.MANIFEST_VERSION, "1.0");
    }
    return acc;
  }

  private static void stripSignatureSections(ManifestDocument doc) {
    List<String> remove = new ArrayList<>();
    for (String name : doc.entries().keySet()) {
      if (name.endsWith(".SF") || name.endsWith(".DSA") || name.endsWith(".RSA")
          || name.startsWith("SIG-")) {
        remove.add(name);
      }
    }
    for (String r : remove) {
      doc.entries().remove(r);
    }
    doc.main().remove(ManifestConstants.SIGNATURE_VERSION);
  }

  public static ManifestDocument buildFrom(byte[]... manifests) {
    UberJarManifestBuilder b = new UberJarManifestBuilder();
    for (byte[] m : manifests) {
      if (m != null) {
        b.addSource(m);
      }
    }
    return b.build();
  }
}
