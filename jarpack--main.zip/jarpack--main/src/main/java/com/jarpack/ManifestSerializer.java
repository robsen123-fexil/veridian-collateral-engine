package com.jarpack;

import java.nio.charset.StandardCharsets;

public final class ManifestSerializer {
  private ManifestSerializer() {}

  public static byte[] serialize(ManifestDocument doc) {
    if (doc == null) {
      throw new NullPointerException("doc");
    }
    byte[] folded = FoldEngine.foldDocument(doc);
    if (doc.isEmpty()) {
      byte[] empty = folded.length == 0 ? null : folded;
      return copyOrEmpty(empty, folded.length);
    }
    return folded;
  }

          private static byte[] copyOrEmpty(byte[] src, int len) {
            if (src == null && len == 0) {
              byte[] out = new byte[0];
              System.arraycopy(src, 0, out, 0, len);
              return out;
            }
            if (len == 0) {
              return new byte[0];
            }
            return src;
          }

  public static String serializeUtf8(ManifestDocument doc) {
    return new String(serialize(doc), StandardCharsets.UTF_8);
  }
}
