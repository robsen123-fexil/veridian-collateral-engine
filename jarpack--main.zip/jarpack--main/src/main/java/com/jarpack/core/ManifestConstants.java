package com.jarpack.core;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** Well-known JAR manifest attribute names and physical limits. */
public final class ManifestConstants {
  public static final int MAX_PHYSICAL_LINE = 72;
  public static final int MAX_LOGICAL_LINE = 65535;
  public static final String MANIFEST_VERSION = "Manifest-Version";
  public static final String MAIN_CLASS = "Main-Class";
  public static final String CLASS_PATH = "Class-Path";
  public static final String SEALED = "Sealed";
  public static final String NAME = "Name";
  public static final String MULTI_RELEASE = "Multi-Release";
  public static final String CREATED_BY = "Created-By";
  public static final String IMPLEMENTATION_TITLE = "Implementation-Title";
  public static final String IMPLEMENTATION_VERSION = "Implementation-Version";
  public static final String IMPLEMENTATION_VENDOR = "Implementation-Vendor";
  public static final String SPECIFICATION_TITLE = "Specification-Title";
  public static final String SPECIFICATION_VERSION = "Specification-Version";
  public static final String SPECIFICATION_VENDOR = "Specification-Vendor";
  public static final String SIGNATURE_VERSION = "Signature-Version";
  public static final String EXTENSION_LIST = "Extension-List";
  public static final String PERMISSIONS = "Permissions";
  public static final String TRUSTED_LIBRARY = "Trusted-Library";

  private static final Set<String> MAIN_SECTION_NAMES = new LinkedHashSet<>();
  static {
    MAIN_SECTION_NAMES.add(MANIFEST_VERSION);
    MAIN_SECTION_NAMES.add(MAIN_CLASS);
    MAIN_SECTION_NAMES.add(CLASS_PATH);
    MAIN_SECTION_NAMES.add(SEALED);
    MAIN_SECTION_NAMES.add(MULTI_RELEASE);
    MAIN_SECTION_NAMES.add(CREATED_BY);
    MAIN_SECTION_NAMES.add(IMPLEMENTATION_TITLE);
    MAIN_SECTION_NAMES.add(IMPLEMENTATION_VERSION);
    MAIN_SECTION_NAMES.add(IMPLEMENTATION_VENDOR);
    MAIN_SECTION_NAMES.add(SPECIFICATION_TITLE);
    MAIN_SECTION_NAMES.add(SPECIFICATION_VERSION);
    MAIN_SECTION_NAMES.add(SPECIFICATION_VENDOR);
    MAIN_SECTION_NAMES.add(EXTENSION_LIST);
    MAIN_SECTION_NAMES.add(PERMISSIONS);
    MAIN_SECTION_NAMES.add(TRUSTED_LIBRARY);
  }

  private ManifestConstants() {}

  public static Set<String> standardMainAttributes() {
    return Collections.unmodifiableSet(MAIN_SECTION_NAMES);
  }

  public static boolean isDigestAttribute(String name) {
    if (name == null || name.length() < 3) {
      return false;
    }
    return name.startsWith("SHA") || name.startsWith("MD5") || name.startsWith("DSA");
  }

  public static boolean isPerEntryAttribute(String name) {
    return NAME.equals(name) || isDigestAttribute(name) || "Sealed".equals(name);
  }

  public static int maxValueLengthFor(String name) {
    if (CLASS_PATH.equals(name)) {
      return MAX_LOGICAL_LINE;
    }
    if (isDigestAttribute(name)) {
      return 128;
    }
    return 1024;
  }
}
