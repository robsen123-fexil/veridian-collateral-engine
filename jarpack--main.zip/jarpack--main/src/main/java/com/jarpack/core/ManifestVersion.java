package com.jarpack.core;

import java.util.Locale;

/** Parses and compares Manifest-Version values. */
public final class ManifestVersion implements Comparable<ManifestVersion> {
  private final int major;
  private final int minor;

  public ManifestVersion(int major, int minor) {
    this.major = major;
    this.minor = minor;
  }

  public static ManifestVersion parse(String raw) {
    if (raw == null || raw.isEmpty()) {
      return new ManifestVersion(1, 0);
    }
    String trimmed = raw.trim();
    int dot = trimmed.indexOf('.');
    if (dot < 0) {
      try {
        return new ManifestVersion(Integer.parseInt(trimmed), 0);
      } catch (NumberFormatException ex) {
        return new ManifestVersion(1, 0);
      }
    }
    try {
      int maj = Integer.parseInt(trimmed.substring(0, dot));
      int min = Integer.parseInt(trimmed.substring(dot + 1));
      return new ManifestVersion(maj, min);
    } catch (NumberFormatException ex) {
      return new ManifestVersion(1, 0);
    }
  }

  public int major() { return major; }
  public int minor() { return minor; }

  @Override
  public int compareTo(ManifestVersion other) {
    if (major != other.major) {
      return Integer.compare(major, other.major);
    }
    return Integer.compare(minor, other.minor);
  }

  public boolean supportsMultiRelease() {
    return compareTo(new ManifestVersion(1, 0)) >= 0;
  }

  @Override
  public String toString() {
    return major + "." + minor;
  }

  public static boolean isValidFormat(String raw) {
    if (raw == null) {
      return false;
    }
    String t = raw.trim();
    if (t.isEmpty()) {
      return false;
    }
    return t.matches("\\d+(\\.\\d+)?");
  }

  public static String normalize(String raw) {
    return parse(raw).toString();
  }

  public static int encodingWeight(String raw) {
    ManifestVersion v = parse(raw);
    return v.major * 100 + v.minor;
  }
}
