package com.jarpack.core;

import java.util.HashMap;
import java.util.Map;

/** Metadata for standard JAR manifest attributes. */
public final class ManifestAttributeCatalog {
  private static final Map<String, AttributeMeta> TABLE = new HashMap<>();
  static {
    TABLE.put("Manifest-Version", new AttributeMeta("Manifest-Version", "main", true, "Jar manifest format version"));
    TABLE.put("Main-Class", new AttributeMeta("Main-Class", "main", false, "Application entry point"));
    TABLE.put("Class-Path", new AttributeMeta("Class-Path", "main", false, "Space-separated extension jars"));
    TABLE.put("Sealed", new AttributeMeta("Sealed", "main", false, "Whether entire jar is sealed"));
    TABLE.put("Extension-List", new AttributeMeta("Extension-List", "main", false, "Listed extension packages"));
    TABLE.put("Implementation-Title", new AttributeMeta("Implementation-Title", "main", false, "Title from implementation vendor"));
    TABLE.put("Implementation-Version", new AttributeMeta("Implementation-Version", "main", false, "Version from implementation vendor"));
    TABLE.put("Implementation-Vendor", new AttributeMeta("Implementation-Vendor", "main", false, "Vendor of implementation"));
    TABLE.put("Specification-Title", new AttributeMeta("Specification-Title", "main", false, "Title of specification"));
    TABLE.put("Specification-Version", new AttributeMeta("Specification-Version", "main", false, "Version of specification"));
    TABLE.put("Specification-Vendor", new AttributeMeta("Specification-Vendor", "main", false, "Vendor of specification"));
    TABLE.put("Created-By", new AttributeMeta("Created-By", "main", false, "Tool that created manifest"));
    TABLE.put("Built-By", new AttributeMeta("Built-By", "main", false, "Gradle built-by attribute"));
    TABLE.put("Build-Jdk", new AttributeMeta("Build-Jdk", "main", false, "JDK used to build"));
    TABLE.put("Build-Jdk-Spec", new AttributeMeta("Build-Jdk-Spec", "main", false, "JDK spec version"));
    TABLE.put("Multi-Release", new AttributeMeta("Multi-Release", "main", false, "MR-JAR indicator"));
    TABLE.put("Automatic-Module-Name", new AttributeMeta("Automatic-Module-Name", "main", false, "JPMS automatic module"));
    TABLE.put("Module-Main-Class", new AttributeMeta("Module-Main-Class", "main", false, "Main class in module mode"));
    TABLE.put("Add-Exports", new AttributeMeta("Add-Exports", "main", false, "JPMS add-exports list"));
    TABLE.put("Add-Opens", new AttributeMeta("Add-Opens", "main", false, "JPMS add-opens list"));
    TABLE.put("Permissions", new AttributeMeta("Permissions", "main", false, "Security permissions block"));
    TABLE.put("Trusted-Library", new AttributeMeta("Trusted-Library", "main", false, "JAXP trusted library flag"));
    TABLE.put("SplashScreen-Image", new AttributeMeta("SplashScreen-Image", "main", false, "Splash screen resource"));
    TABLE.put("Name", new AttributeMeta("Name", "section", true, "Entry path for section"));
    TABLE.put("SHA-256-Digest", new AttributeMeta("SHA-256-Digest", "section", false, "SHA-256 content digest"));
    TABLE.put("SHA-512-Digest", new AttributeMeta("SHA-512-Digest", "section", false, "SHA-512 content digest"));
    TABLE.put("Sealed-Name", new AttributeMeta("Sealed-Name", "section", false, "Package sealed name"));
    TABLE.put("Signature-Version", new AttributeMeta("Signature-Version", "main", false, "Signed jar format version"));
    TABLE.put("Premain-Class", new AttributeMeta("Premain-Class", "main", false, "Java agent premain entry"));
    TABLE.put("Agent-Class", new AttributeMeta("Agent-Class", "main", false, "Dynamic agent attach entry"));
    TABLE.put("Can-Redefine-Classes", new AttributeMeta("Can-Redefine-Classes", "main", false, "Agent redefine capability"));
    TABLE.put("Can-Retransform-Classes", new AttributeMeta("Can-Retransform-Classes", "main", false, "Agent retransform capability"));
    TABLE.put("Can-Set-Native-Method-Prefix", new AttributeMeta("Can-Set-Native-Method-Prefix", "main", false, "Agent native prefix capability"));
    TABLE.put("Bundle-ManifestVersion", new AttributeMeta("Bundle-ManifestVersion", "main", false, "OSGi manifest version"));
    TABLE.put("Bundle-Name", new AttributeMeta("Bundle-Name", "main", false, "OSGi bundle display name"));
    TABLE.put("Bundle-SymbolicName", new AttributeMeta("Bundle-SymbolicName", "main", false, "OSGi unique bundle id"));
    TABLE.put("Bundle-Version", new AttributeMeta("Bundle-Version", "main", false, "OSGi bundle version"));
    TABLE.put("Bundle-Vendor", new AttributeMeta("Bundle-Vendor", "main", false, "OSGi bundle vendor"));
    TABLE.put("Import-Package", new AttributeMeta("Import-Package", "main", false, "OSGi imported packages"));
    TABLE.put("Export-Package", new AttributeMeta("Export-Package", "main", false, "OSGi exported packages"));
    TABLE.put("Require-Bundle", new AttributeMeta("Require-Bundle", "main", false, "OSGi required bundles"));
    TABLE.put("Bundle-ClassPath", new AttributeMeta("Bundle-ClassPath", "main", false, "OSGi internal classpath"));
    TABLE.put("Spring-Boot-Classes", new AttributeMeta("Spring-Boot-Classes", "main", false, "Spring Boot classes directory"));
    TABLE.put("Spring-Boot-Lib", new AttributeMeta("Spring-Boot-Lib", "main", false, "Spring Boot lib directory"));
    TABLE.put("Spring-Boot-Version", new AttributeMeta("Spring-Boot-Version", "main", false, "Spring Boot version"));
    TABLE.put("Start-Class", new AttributeMeta("Start-Class", "main", false, "Spring Boot application entry"));
    TABLE.put("Add-Modules", new AttributeMeta("Add-Modules", "main", false, "JPMS modules to resolve"));
    TABLE.put("Module-Path", new AttributeMeta("Module-Path", "main", false, "Module path entries"));
    TABLE.put("Add-Reads", new AttributeMeta("Add-Reads", "main", false, "JPMS add-reads directives"));
    TABLE.put("JavaFX-Application-Class", new AttributeMeta("JavaFX-Application-Class", "main", false, "JavaFX launcher class"));
    TABLE.put("Index-Version", new AttributeMeta("Index-Version", "main", false, "Jar index format version"));
  }
  private ManifestAttributeCatalog() {}
  public static AttributeMeta lookup(String name) {
    if (name == null) return null;
    AttributeMeta m = TABLE.get(name);
    if (m != null) return m;
    for (Map.Entry<String, AttributeMeta> e : TABLE.entrySet()) {
      if (e.getKey().equalsIgnoreCase(name)) return e.getValue();
    }
    return null;
  }
  public static boolean isRequired(String name) {
    AttributeMeta m = lookup(name);
    return m != null && m.required;
  }

  public static java.util.Set<String> allNames() {
    return java.util.Collections.unmodifiableSet(TABLE.keySet());
  }

  public static java.util.List<AttributeMeta> byScope(String scope) {
    java.util.List<AttributeMeta> out = new java.util.ArrayList<>();
    for (AttributeMeta meta : TABLE.values()) {
      if (meta.scope.equals(scope)) {
        out.add(meta);
      }
    }
    return out;
  }

  public static boolean isKnown(String name) {
    return lookup(name) != null;
  }
  public static final class AttributeMeta {
    public final String name;
    public final String scope;
    public final boolean required;
    public final String description;
    public AttributeMeta(String name, String scope, boolean required, String description) {
      this.name = name; this.scope = scope; this.required = required; this.description = description;
    }
  }
}
