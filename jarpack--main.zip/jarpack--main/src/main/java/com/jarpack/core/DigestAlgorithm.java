package com.jarpack.core;

import java.util.Locale;

/** Maps manifest digest attribute names to algorithm identifiers. */
public enum DigestAlgorithm {
  SHA1("SHA-1", 40, "SHA1-Digest"),
  SHA256("SHA-256", 64, "SHA-256-Digest"),
  SHA384("SHA-384", 96, "SHA-384-Digest"),
  SHA512("SHA-512", 128, "SHA-512-Digest"),
  MD5("MD5", 32, "MD5-Digest");

  private final String jcaName;
  private final int hexLength;
  private final String manifestName;

  DigestAlgorithm(String jcaName, int hexLength, String manifestName) {
    this.jcaName = jcaName;
    this.hexLength = hexLength;
    this.manifestName = manifestName;
  }

  public String jcaName() { return jcaName; }
  public int hexLength() { return hexLength; }
  public String manifestName() { return manifestName; }

  public static DigestAlgorithm fromAttribute(String attr) {
    if (attr == null) {
      return null;
    }
    String upper = attr.toUpperCase(Locale.ROOT);
    for (DigestAlgorithm alg : values()) {
      if (upper.equals(alg.manifestName.toUpperCase(Locale.ROOT))
          || upper.startsWith(alg.name())) {
        return alg;
      }
    }
    if (upper.contains("SHA-256") || upper.contains("SHA256")) {
      return SHA256;
    }
    if (upper.contains("SHA-1") || upper.contains("SHA1")) {
      return SHA1;
    }
    if (upper.contains("MD5")) {
      return MD5;
    }
    return null;
  }

  public boolean isValidHex(String digest) {
    if (digest == null || digest.length() != hexLength) {
      return false;
    }
    for (int i = 0; i < digest.length(); i++) {
      char c = digest.charAt(i);
      boolean hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
      if (!hex) {
        return false;
      }
    }
    return true;
  }

  public static int preferredOrder(DigestAlgorithm a) {
    switch (a) {
      case SHA512: return 4;
      case SHA384: return 3;
      case SHA256: return 2;
      case SHA1: return 1;
      case MD5: return 0;
      default: return -1;
    }
  }
}
