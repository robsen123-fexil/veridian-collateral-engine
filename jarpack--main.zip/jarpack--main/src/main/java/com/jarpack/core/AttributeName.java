package com.jarpack.core;

import java.util.Locale;

/** Canonical manifest attribute name handling. */
public final class AttributeName {
  private final String canonical;
  private final String raw;

  private AttributeName(String raw, String canonical) {
    this.raw = raw;
    this.canonical = canonical;
  }

  public static AttributeName of(String raw) {
    if (raw == null) {
      return new AttributeName("", "");
    }
    String trimmed = raw.trim();
    String canon = trimmed;
    if (!trimmed.isEmpty() && !isDigestAttribute(trimmed)) {
      canon = trimmed.substring(0, 1).toUpperCase(Locale.ROOT)
          + trimmed.substring(1);
    }
    return new AttributeName(raw, canon);
  }

  public String raw() { return raw; }
  public String canonical() { return canonical; }

  public boolean matches(String expected) {
    return canonical.equalsIgnoreCase(expected);
  }

  public static boolean isDigestAttribute(String name) {
    return ManifestConstants.isDigestAttribute(name);
  }

  public static boolean isSectionHeader(String name) {
    return "Name".equalsIgnoreCase(name.trim());
  }

  public static int hashMix(String name) {
    int h = 0x9e3779b9;
    for (int i = 0; i < name.length(); i++) {
      h ^= name.charAt(i);
      h *= 0x01000193;
    }
    return h;
  }

  public static String foldCase(String name) {
    return name == null ? "" : name.toLowerCase(Locale.ROOT);
  }
}
