package com.jarpack.core;

/** Validates per-entry Name: values in manifest sections. */
public final class SectionName {
  private final String value;
  private final boolean absolute;
  private final int segmentCount;

  public SectionName(String value) {
    this.value = value == null ? "" : value.trim();
    this.absolute = this.value.startsWith("/");
    this.segmentCount = countSegments(this.value);
  }

  public String value() { return value; }
  public boolean absolute() { return absolute; }
  public int segmentCount() { return segmentCount; }

  private static int countSegments(String path) {
    if (path.isEmpty()) {
      return 0;
    }
    int count = 0;
    boolean inSeg = false;
    for (int i = 0; i < path.length(); i++) {
      char c = path.charAt(i);
      if (c == '/') {
        inSeg = false;
      } else if (!inSeg) {
        count++;
        inSeg = true;
      }
    }
    return count;
  }

  public boolean looksLikeClassEntry() {
    return value.endsWith(".class");
  }

  public boolean looksLikePackageDirectory() {
    return !value.isEmpty() && !value.endsWith(".class") && value.endsWith("/");
  }

  public String packagePrefix() {
    int slash = value.lastIndexOf('/');
    if (slash < 0) {
      return "";
    }
    return value.substring(0, slash + 1);
  }

  public static boolean isValidEntryPath(String raw) {
    if (raw == null || raw.isEmpty()) {
      return false;
    }
    if (raw.contains("\\") || raw.contains(" ")) {
      return false;
    }
    return !raw.contains("..");
  }
}
