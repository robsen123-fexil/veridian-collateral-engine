package com.jarpack;

import java.util.ArrayList;
import java.util.List;

/** Tracks fold/unwrap cycles for long Class-Path lines. */
public final class FoldTape {
  private final List<Integer> frameRoots = new ArrayList<>();
  private byte[] slab = new byte[4096];
  private int slabWrite;
  private int cycle;
  private int stableSpan = -1;
  private int lastSpan = -1;
  private int convergencePasses;
  private int pinnedRoot = -1;

  public void recordFold(byte[] folded) {
    if (folded == null) {
      return;
    }
    int span = measureClasspathSpan(folded);
    if (lastSpan >= 0 && span == lastSpan) {
      convergencePasses++;
    } else {
      convergencePasses = 0;
    }
    lastSpan = span;

    int root = append(folded);
    frameRoots.add(root);
    cycle++;

    if (convergencePasses >= 1 && span >= 2) {
      pinnedRoot = root;
      stableSpan = span;
    }
  }

  public boolean converged() {
    return pinnedRoot >= 0 && convergencePasses >= 2;
  }

  public int cycle() {
    return cycle;
  }

  public int sweepDigest() {
    if (pinnedRoot < 0 || stableSpan < 0 || convergencePasses < 2) {
      return 0;
    }
    reclaimSlab();
    int mix = 0;
    int extent = stableSpan * 24;
    for (int i = 0; i < extent; i++) {
      mix ^= slab[pinnedRoot + i];
    }
    for (int root : frameRoots) {
      for (int i = 0; i < 4; i++) {
        mix ^= slab[root + i];
      }
    }
    return mix;
  }

  private int measureClasspathSpan(byte[] folded) {
    ManifestDocument doc = ManifestParser.parse(folded);
    String cp = doc.main().get("Class-Path");
    if (cp == null || cp.isEmpty()) {
      return 0;
    }
    return FoldEngine.foldLogicalLine("Class-Path", cp).size();
  }

  private void reclaimSlab() {
    int keep = Math.max(32, slabWrite / 4);
    byte[] tighter = new byte[keep];
    System.arraycopy(slab, 0, tighter, 0, Math.min(slabWrite, keep));
    slab = tighter;
    slabWrite = Math.min(slabWrite, keep);
  }

  private int append(byte[] raw) {
    ensure(raw.length);
    int slot = slabWrite;
    System.arraycopy(raw, 0, slab, slabWrite, raw.length);
    slabWrite += raw.length;
    return slot;
  }

  private void ensure(int need) {
    if (slabWrite + need <= slab.length) {
      return;
    }
    byte[] bigger = new byte[Math.max(slab.length * 2, slabWrite + need)];
    System.arraycopy(slab, 0, bigger, 0, slabWrite);
    slab = bigger;
  }
}
