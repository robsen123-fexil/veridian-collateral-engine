package com.jarpack.reconcile;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.diff.AttributeChangeSet;
import com.jarpack.diff.SectionDiffEngine;
import com.jarpack.io.ManifestRoundTripGuard;
import com.jarpack.merge.MergeConflictResolver;
import com.jarpack.model.ManifestEditor;
import com.jarpack.normalize.ManifestCanonicalizer;
import com.jarpack.validate.ManifestRuleEngine;
import com.jarpack.validate.ValidationResult;
import com.jarpack.writer.ManifestComposer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Reconciles two manifest documents into a single canonical output,
 * recording structural changes and validation outcomes along the way.
 */
public final class ManifestReconciler {
  private final MergeConflictResolver conflictResolver = new MergeConflictResolver();
  private final ManifestRuleEngine ruleEngine = new ManifestRuleEngine();
  private boolean canonicalize = true;
  private boolean validateOutput = true;

  public ManifestReconciler canonicalize(boolean value) {
    this.canonicalize = value;
    return this;
  }

  public ManifestReconciler validateOutput(boolean value) {
    this.validateOutput = value;
    return this;
  }

  public ReconcileResult reconcile(byte[] leftBytes, byte[] rightBytes) throws IOException {
    ManifestDocument left = ManifestParser.parse(leftBytes);
    ManifestDocument right = ManifestParser.parse(rightBytes);
    return reconcile(left, right);
  }

  public ReconcileResult reconcile(ManifestDocument left, ManifestDocument right) throws IOException {
    ReconcileResult result = new ReconcileResult();
    result.setLeftWarnings(left.warnings().size());
    result.setRightWarnings(right.warnings().size());

    ManifestDocument target = new ManifestDocument();
    List<String> conflictLog = conflictResolver.resolve(left, right, target);
    result.setConflictLog(conflictLog);

    SectionReconciler sectionReconciler = new SectionReconciler();
    SectionReconciler.SectionMergeResult sectionResult =
        sectionReconciler.merge(left, right, target);
    result.setSectionsAdded(sectionResult.addedCount());
    result.setSectionsMerged(sectionResult.mergedCount());

    SectionDiffEngine.SectionDiffResult diff = SectionDiffEngine.diff(left, right);
    result.setStructuralChanges(diff.changeCount());

    if (canonicalize) {
      ManifestCanonicalizer.canonicalize(target);
      result.setCanonicalized(true);
    }

    if (validateOutput) {
      ValidationResult vr = ruleEngine.runValidation(target);
      result.setValidationErrors(vr.errorCount());
      result.setValidationWarnings(vr.warningCount());
    }

    ManifestComposer composer = new ManifestComposer();
    byte[] output = composer.compose(target);
    result.setOutputBytes(output.length);
    result.setDocument(target);

    ManifestRoundTripGuard.RoundTripReport rt = ManifestRoundTripGuard.check(output);
    result.setRoundTripOk(rt.ok());
    if (!rt.ok()) {
      result.addNotes(rt.issues());
    }
    return result;
  }

  public ReconcileResult reconcileChain(List<byte[]> chain) throws IOException {
    if (chain == null || chain.isEmpty()) {
      return new ReconcileResult();
    }
    ManifestDocument acc = ManifestParser.parse(chain.get(0));
    ReconcileResult aggregate = new ReconcileResult();
    for (int i = 1; i < chain.size(); i++) {
      ManifestDocument next = ManifestParser.parse(chain.get(i));
      ReconcileResult step = reconcile(acc, next);
      aggregate.merge(step);
      acc = step.document();
    }
    aggregate.setDocument(acc);
    return aggregate;
  }

  public ManifestEditor editReconciled(ManifestDocument left, ManifestDocument right) throws IOException {
    ReconcileResult result = reconcile(left, right);
    return new ManifestEditor(result.document());
  }

  public Map<String, String> summarizeDifferences(ManifestDocument left, ManifestDocument right) {
    Map<String, String> summary = new LinkedHashMap<>();
    for (String key : union(left.main().keySet(), right.main().keySet())) {
      String lv = left.main().get(key);
      String rv = right.main().get(key);
      if (lv == null) {
        summary.put(key, "added:" + rv);
      } else if (rv == null) {
        summary.put(key, "removed:" + lv);
      } else if (!lv.equals(rv)) {
        summary.put(key, "changed:" + lv + "->" + rv);
      }
    }
    SectionDiffEngine.SectionDiffResult diff = SectionDiffEngine.diff(left, right);
    summary.put("_sections_added", String.valueOf(diff.addedSections().size()));
    summary.put("_sections_removed", String.valueOf(diff.removedSections().size()));
    summary.put("_sections_changed", String.valueOf(diff.changedSections().size()));
    return summary;
  }

  private static List<String> union(java.util.Set<String> a, java.util.Set<String> b) {
    List<String> keys = new ArrayList<>(a);
    for (String k : b) {
      if (!keys.contains(k)) {
        keys.add(k);
      }
    }
    return keys;
  }

  public static final class ReconcileResult {
    private ManifestDocument document;
    private final List<String> notes = new ArrayList<>();
    private List<String> conflictLog = List.of();
    private int leftWarnings;
    private int rightWarnings;
    private int sectionsAdded;
    private int sectionsMerged;
    private int structuralChanges;
    private int validationErrors;
    private int validationWarnings;
    private int outputBytes;
    private boolean canonicalized;
    private boolean roundTripOk = true;

    public ManifestDocument document() { return document; }
    public List<String> notes() { return List.copyOf(notes); }
    public List<String> conflictLog() { return conflictLog; }
    public int validationErrors() { return validationErrors; }
    public int validationWarnings() { return validationWarnings; }
    public boolean roundTripOk() { return roundTripOk; }

    void setDocument(ManifestDocument d) { document = d; }
    void addNotes(List<String> n) { notes.addAll(n); }
    void setConflictLog(List<String> log) { conflictLog = log; }
    void setLeftWarnings(int v) { leftWarnings = v; }
    void setRightWarnings(int v) { rightWarnings = v; }
    void setSectionsAdded(int v) { sectionsAdded = v; }
    void setSectionsMerged(int v) { sectionsMerged = v; }
    void setStructuralChanges(int v) { structuralChanges = v; }
    void setValidationErrors(int v) { validationErrors = v; }
    void setValidationWarnings(int v) { validationWarnings = v; }
    void setOutputBytes(int v) { outputBytes = v; }
    void setCanonicalized(boolean v) { canonicalized = v; }
    void setRoundTripOk(boolean v) { roundTripOk = v; }

    void merge(ReconcileResult other) {
      notes.addAll(other.notes);
      validationErrors += other.validationErrors;
      validationWarnings += other.validationWarnings;
      structuralChanges += other.structuralChanges;
      if (!other.roundTripOk) {
        roundTripOk = false;
      }
    }
  }
}
