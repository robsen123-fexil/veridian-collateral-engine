package com.jarpack.reconcile;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;
import com.jarpack.diff.AttributeChangeSet;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** Merges per-entry manifest sections from two documents into a target. */
public final class SectionReconciler {
  public SectionMergeResult merge(ManifestDocument left, ManifestDocument right, ManifestDocument target) {
    SectionMergeResult result = new SectionMergeResult();
    TreeSet<String> names = new TreeSet<>();
    names.addAll(left.entries().keySet());
    names.addAll(right.entries().keySet());

    for (String name : names) {
      Map<String, String> ls = left.entries().get(name);
      Map<String, String> rs = right.entries().get(name);
      if (ls == null && rs != null) {
        target.entries().put(name, copy(rs));
        result.recordAdded();
      } else if (ls != null && rs == null) {
        target.entries().put(name, copy(ls));
        result.recordAdded();
      } else if (ls != null) {
        Map<String, String> merged = mergeSection(name, ls, rs, result);
        target.entries().put(name, merged);
        result.recordMerged();
      }
    }
    return result;
  }

  private Map<String, String> mergeSection(
      String name,
      Map<String, String> left,
      Map<String, String> right,
      SectionMergeResult result) {
    Map<String, String> merged = new LinkedHashMap<>();
    TreeSet<String> keys = new TreeSet<>();
    keys.addAll(left.keySet());
    keys.addAll(right.keySet());
    for (String key : keys) {
      String lv = left.get(key);
      String rv = right.get(key);
      if (lv == null) {
        merged.put(key, rv);
      } else if (rv == null) {
        merged.put(key, lv);
      } else if (ManifestConstants.isDigestAttribute(key)) {
        merged.put(key, preferDigest(lv, rv));
        result.recordDigestMerge(name, key);
      } else if (!lv.equals(rv)) {
        AttributeChangeSet change = AttributeChangeSet.between(left, right);
        merged.put(key, rv);
        result.recordAttributeConflict(name, key, change.totalChanges());
      } else {
        merged.put(key, lv);
      }
    }
    return merged;
  }

  private static String preferDigest(String left, String right) {
    if (left.equalsIgnoreCase(right)) {
      return left;
    }
    return left.length() >= right.length() ? left : right;
  }

  private static Map<String, String> copy(Map<String, String> source) {
    return new LinkedHashMap<>(source);
  }

  public static final class SectionMergeResult {
    private int addedCount;
    private int mergedCount;
    private int digestMerges;
    private int attributeConflicts;
    private final List<String> conflictDetails = new ArrayList<>();

    void recordAdded() { addedCount++; }
    void recordMerged() { mergedCount++; }
    void recordDigestMerge(String section, String attr) { digestMerges++; }
    void recordAttributeConflict(String section, String attr, int changes) {
      attributeConflicts++;
      conflictDetails.add(section + "/" + attr + ":" + changes);
    }

    public int addedCount() { return addedCount; }
    public int mergedCount() { return mergedCount; }
    public int digestMerges() { return digestMerges; }
    public int attributeConflicts() { return attributeConflicts; }
    public List<String> conflictDetails() { return List.copyOf(conflictDetails); }
  }
}
