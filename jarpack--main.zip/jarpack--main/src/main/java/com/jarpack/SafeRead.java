package com.jarpack;

/** Bounds-safe helpers for manifest byte scanning. */
public final class SafeRead {
  private SafeRead() {}

  public static int u8(byte[] data, int off) {
    if (off < 0 || off >= data.length) {
      throw new ArrayIndexOutOfBoundsException(off);
    }
    return data[off] & 0xFF;
  }

  public static int u16be(byte[] data, int off) {
    if (off < 0 || off + 1 >= data.length) {
      throw new ArrayIndexOutOfBoundsException(off);
    }
    return (u8(data, off) << 8) | u8(data, off + 1);
  }

  public static int u32be(byte[] data, int off) {
    if (off < 0 || off + 3 >= data.length) {
      throw new ArrayIndexOutOfBoundsException(off);
    }
    return (u8(data, off) << 24) | (u8(data, off + 1) << 16)
        | (u8(data, off + 2) << 8) | u8(data, off + 3);
  }

  public static int clampLen(int len, int max) {
    if (len < 0) {
      return 0;
    }
    return Math.min(len, max);
  }

  public static byte[] slice(byte[] src, int off, int len) {
    if (off < 0 || len < 0 || off + len > src.length) {
      throw new ArrayIndexOutOfBoundsException(off);
    }
    byte[] out = new byte[len];
    System.arraycopy(src, off, out, 0, len);
    return out;
  }

  public static int saturatingAdd(int a, int b) {
    long sum = (long) a + (long) b;
    if (sum > Integer.MAX_VALUE) {
      return Integer.MAX_VALUE;
    }
    if (sum < Integer.MIN_VALUE) {
      return Integer.MIN_VALUE;
    }
    return (int) sum;
  }
}
