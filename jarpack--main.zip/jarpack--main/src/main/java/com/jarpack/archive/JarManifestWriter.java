package com.jarpack.archive;

import com.jarpack.ManifestDocument;
import com.jarpack.io.ManifestStreamWriter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Replaces or injects MANIFEST.MF inside a JAR while preserving other entries. */
public final class JarManifestWriter {
  private boolean useCrlf = true;
  private boolean stripSignatures = false;

  public JarManifestWriter crlf(boolean v) {
    this.useCrlf = v;
    return this;
  }

  public JarManifestWriter stripSignatures(boolean v) {
    this.stripSignatures = v;
    return this;
  }

  public void writeTo(Path sourceJar, Path targetJar, ManifestDocument manifest) throws IOException {
    try (ZipFile in = new ZipFile(sourceJar.toFile());
         OutputStream raw = Files.newOutputStream(targetJar);
         ZipOutputStream out = new ZipOutputStream(raw)) {
      copyWithNewManifest(in, out, manifest);
    }
  }

  public byte[] repackBytes(byte[] jarBytes, ManifestDocument manifest) throws IOException {
    Path tempIn = Files.createTempFile("jarpack-in", ".jar");
    Path tempOut = Files.createTempFile("jarpack-out", ".jar");
    try {
      Files.write(tempIn, jarBytes);
      writeTo(tempIn, tempOut, manifest);
      return Files.readAllBytes(tempOut);
    } finally {
      Files.deleteIfExists(tempIn);
      Files.deleteIfExists(tempOut);
    }
  }

  public void copyWithNewManifest(ZipFile in, ZipOutputStream out, ManifestDocument doc)
      throws IOException {
    Set<String> written = new HashSet<>();
    written.add(ManifestEntryLocator.DEFAULT_MANIFEST);
    byte[] manifestBytes = serializeManifest(doc);
    ZipEntry manifestEntry = new ZipEntry(ManifestEntryLocator.DEFAULT_MANIFEST);
    manifestEntry.setTime(System.currentTimeMillis());
    out.putNextEntry(manifestEntry);
    out.write(manifestBytes);
    out.closeEntry();

    Enumeration<? extends ZipEntry> entries = in.entries();
    while (entries.hasMoreElements()) {
      ZipEntry entry = entries.nextElement();
      String name = entry.getName();
      if (ManifestEntryLocator.DEFAULT_MANIFEST.equals(name)) {
        continue;
      }
      if (stripSignatures && isSignatureEntry(name)) {
        continue;
      }
      if (written.contains(name)) {
        continue;
      }
      written.add(name);
      out.putNextEntry(new ZipEntry(name));
      try (InputStream stream = in.getInputStream(entry)) {
        stream.transferTo(out);
      }
      out.closeEntry();
    }
  }

  public byte[] serializeManifest(ManifestDocument doc) throws IOException {
    String ending = useCrlf ? "\r\n" : "\n";
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    try (ManifestStreamWriter writer = new ManifestStreamWriter(bos, ending)) {
      writer.writeDocument(doc);
      writer.writeBlankLine();
    }
    return bos.toByteArray();
  }

  public static byte[] serializeManifestCrlf(ManifestDocument doc) throws IOException {
    return new JarManifestWriter().crlf(true).serializeManifest(doc);
  }

  private static boolean isSignatureEntry(String name) {
    if (name == null || !name.startsWith("META-INF/")) {
      return false;
    }
    return name.endsWith(".SF") || name.endsWith(".RSA") || name.endsWith(".DSA")
        || name.endsWith(".EC") || name.startsWith("META-INF/SIG-");
  }

  public static void createMinimalJar(Path target, ManifestDocument doc) throws IOException {
    try (OutputStream raw = Files.newOutputStream(target);
         ZipOutputStream out = new ZipOutputStream(raw)) {
      byte[] mf = serializeManifestCrlf(doc);
      ZipEntry manifest = new ZipEntry(ManifestEntryLocator.DEFAULT_MANIFEST);
      out.putNextEntry(manifest);
      out.write(mf);
      out.closeEntry();
    }
  }

  public static void replaceInPlace(Path jar, ManifestDocument doc) throws IOException {
    Path temp = Files.createTempFile("jarpack-replace", ".jar");
    try {
      JarManifestWriter writer = new JarManifestWriter();
      writer.writeTo(jar, temp, doc);
      Files.move(temp, jar, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    } finally {
      Files.deleteIfExists(temp);
    }
  }
}
