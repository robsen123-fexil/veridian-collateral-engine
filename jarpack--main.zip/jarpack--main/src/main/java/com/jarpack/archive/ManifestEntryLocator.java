package com.jarpack.archive;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Locates manifest entries inside a JAR zip layout. */
public final class ManifestEntryLocator {
  public static final String DEFAULT_MANIFEST = "META-INF/MANIFEST.MF";

  private ManifestEntryLocator() {}

  public static List<String> findManifestPaths(ZipFile jar) {
    List<String> paths = new ArrayList<>();
    java.util.Enumeration<? extends ZipEntry> entries = jar.entries();
    while (entries.hasMoreElements()) {
      ZipEntry entry = entries.nextElement();
      String name = entry.getName();
      if (isManifestPath(name)) {
        paths.add(name);
      }
    }
    Collections.sort(paths);
    return paths;
  }

  public static boolean isManifestPath(String entryName) {
    if (entryName == null || entryName.isEmpty()) {
      return false;
    }
    String normalized = entryName.replace('\\', '/');
    if (DEFAULT_MANIFEST.equals(normalized)) {
      return true;
    }
    if (normalized.startsWith("META-INF/versions/") && normalized.endsWith("/MANIFEST.MF")) {
      return true;
    }
    return normalized.endsWith("/MANIFEST.MF") && normalized.contains("META-INF");
  }

  public static String primaryManifestPath(ZipFile jar) {
    if (jar.getEntry(DEFAULT_MANIFEST) != null) {
      return DEFAULT_MANIFEST;
    }
    List<String> all = findManifestPaths(jar);
    return all.isEmpty() ? null : all.get(0);
  }

  public static List<String> versionedManifestPaths(ZipFile jar) {
    List<String> versioned = new ArrayList<>();
    java.util.Enumeration<? extends ZipEntry> entries = jar.entries();
    while (entries.hasMoreElements()) {
      String name = entries.nextElement().getName().replace('\\', '/');
      if (name.startsWith("META-INF/versions/") && name.endsWith("/MANIFEST.MF")) {
        versioned.add(name);
      }
    }
    Collections.sort(versioned);
    return versioned;
  }

  public static int parseReleaseVersion(String manifestPath) {
    if (manifestPath == null) {
      return -1;
    }
    String norm = manifestPath.replace('\\', '/').toUpperCase(Locale.ROOT);
    if (!norm.startsWith("META-INF/VERSIONS/")) {
      return -1;
    }
    int slash = norm.indexOf('/', "META-INF/VERSIONS/".length());
    if (slash < 0) {
      return -1;
    }
    String ver = norm.substring("META-INF/VERSIONS/".length(), slash);
    try {
      return Integer.parseInt(ver);
    } catch (NumberFormatException ex) {
      return -1;
    }
  }

  public static String describeLayout(ZipFile jar) {
    StringBuilder sb = new StringBuilder();
    String primary = primaryManifestPath(jar);
    sb.append("primary=").append(primary == null ? "none" : primary);
    List<String> versioned = versionedManifestPaths(jar);
    if (!versioned.isEmpty()) {
      sb.append(";versioned=").append(versioned.size());
    }
    return sb.toString();
  }
}
