package com.jarpack.archive;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipFile;

/** Resolves effective manifest attributes across multi-release JAR layouts. */
public final class MultiReleaseManifestResolver {
  private MultiReleaseManifestResolver() {}

  public static boolean isMultiRelease(ManifestDocument primary) {
    if (primary == null) {
      return false;
    }
    String flag = primary.main().get(ManifestConstants.MULTI_RELEASE);
    return "true".equalsIgnoreCase(flag);
  }

  public static ResolvedManifests resolve(ZipFile jar) throws IOException {
    ManifestDocument primary = JarManifestReader.read(jar);
    Map<Integer, ManifestDocument> versioned = JarManifestReader.readVersionedManifests(jar);
    return new ResolvedManifests(primary, versioned);
  }

  public static ManifestDocument effectiveForRuntime(ResolvedManifests resolved, int runtimeVersion) {
    if (resolved == null || resolved.primary() == null) {
      return new ManifestDocument();
    }
    if (!isMultiRelease(resolved.primary()) || resolved.versioned().isEmpty()) {
      return resolved.primary().copy();
    }
    ManifestDocument base = resolved.primary().copy();
    TreeMap<Integer, ManifestDocument> ordered = new TreeMap<>(resolved.versioned());
    for (Map.Entry<Integer, ManifestDocument> e : ordered.entrySet()) {
      if (e.getKey() <= runtimeVersion) {
        overlayMain(base, e.getValue());
      }
    }
    return base;
  }

  public static List<Integer> declaredVersions(ResolvedManifests resolved) {
    if (resolved == null) {
      return Collections.emptyList();
    }
    List<Integer> versions = new ArrayList<>(resolved.versioned().keySet());
    Collections.sort(versions);
    return versions;
  }

  public static List<String> validateLayout(ResolvedManifests resolved, ZipEntryCatalog catalog) {
    List<String> issues = new ArrayList<>();
    if (resolved == null) {
      issues.add("null-resolved");
      return issues;
    }
    if (isMultiRelease(resolved.primary()) && resolved.versioned().isEmpty()) {
      issues.add("multi-release-without-versioned-manifests");
    }
    for (Integer ver : resolved.versioned().keySet()) {
      String expectedPrefix = "META-INF/versions/" + ver + "/";
      boolean hasClasses = false;
      for (String name : catalog.names()) {
        if (name.startsWith(expectedPrefix) && name.endsWith(".class")) {
          hasClasses = true;
          break;
        }
      }
      if (!hasClasses) {
        issues.add("version-" + ver + "-without-classes");
      }
    }
    return issues;
  }

  private static void overlayMain(ManifestDocument target, ManifestDocument overlay) {
    if (overlay == null) {
      return;
    }
    for (Map.Entry<String, String> e : overlay.main().entrySet()) {
      if (!ManifestConstants.MULTI_RELEASE.equals(e.getKey())) {
        target.main().put(e.getKey(), e.getValue());
      }
    }
  }

  public static final class ResolvedManifests {
    private final ManifestDocument primary;
    private final Map<Integer, ManifestDocument> versioned;

    public ResolvedManifests(ManifestDocument primary, Map<Integer, ManifestDocument> versioned) {
      this.primary = primary;
      this.versioned = versioned == null ? Map.of() : versioned;
    }

    public ManifestDocument primary() { return primary; }
    public Map<Integer, ManifestDocument> versioned() { return versioned; }
  }
}
