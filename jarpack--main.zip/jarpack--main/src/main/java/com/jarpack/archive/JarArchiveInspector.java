package com.jarpack.archive;

import com.jarpack.ManifestDocument;
import com.jarpack.classpath.ClasspathCoherenceChecker;
import com.jarpack.classpath.ClasspathExpansionEngine;
import com.jarpack.classpath.ClasspathUrlResolver;
import com.jarpack.signature.SignedJarVerifier;
import com.jarpack.stats.ManifestStatistics;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipFile;

/** Full archive-level inspection combining manifest, classpath, and signature checks. */
public final class JarArchiveInspector {
  private boolean expandClasspath = true;
  private boolean verifySignatures = true;

  public JarArchiveInspector expandClasspath(boolean value) {
    this.expandClasspath = value;
    return this;
  }

  public JarArchiveInspector verifySignatures(boolean value) {
    this.verifySignatures = value;
    return this;
  }

  public ArchiveReport inspect(Path jarPath) throws IOException {
    try (ZipFile jar = new ZipFile(jarPath.toFile())) {
      return inspect(jar, jarPath);
    }
  }

  public ArchiveReport inspect(ZipFile jar, Path jarPath) throws IOException {
    ArchiveReport report = new ArchiveReport();
    report.setJarPath(jarPath == null ? "memory" : jarPath.toString());

    ZipEntryCatalog catalog = ZipEntryCatalog.scan(jar);
    report.setTotalEntries(catalog.entryCount());
    report.setMetaInfCount(catalog.metaInfEntries().size());
    report.setSignatureFiles(catalog.signatureRelated().size());

    ManifestDocument manifest = JarManifestReader.read(jar);
    report.setManifest(manifest);
    report.setStats(ManifestStatistics.analyze(manifest));

    String primaryPath = ManifestEntryLocator.primaryManifestPath(jar);
    report.setManifestPath(primaryPath == null ? "none" : primaryPath);

    List<String> classpathIssues =
        ClasspathCoherenceChecker.checkAgainstCatalog(manifest, catalog);
    report.addIssues("classpath", classpathIssues);

    if (jarPath != null) {
      List<ClasspathUrlResolver.ResolvedEntry> resolved =
          ClasspathUrlResolver.resolve(manifest, jarPath);
      int unresolved = 0;
      for (ClasspathUrlResolver.ResolvedEntry entry : resolved) {
        if (!entry.resolved()) {
          unresolved++;
        }
      }
      report.setUnresolvedClasspath(unresolved);
    }

    if (expandClasspath) {
      ClasspathExpansionEngine engine = new ClasspathExpansionEngine();
      ClasspathExpansionEngine.ExpansionResult expansion = engine.expand(manifest, catalog);
      report.setExpandedClasspath(expansion.resolved().size());
      if (expansion.truncated()) {
        report.addIssue("classpath-truncated");
      }
    }

    MultiReleaseManifestResolver.ResolvedManifests mr = MultiReleaseManifestResolver.resolve(jar);
    report.setMultiRelease(MultiReleaseManifestResolver.isMultiRelease(mr.primary()));
    report.addIssues("multirelease",
        MultiReleaseManifestResolver.validateLayout(mr, catalog));

    List<String> versioned = ManifestEntryLocator.versionedManifestPaths(jar);
    report.setVersionedManifests(versioned.size());

    if (verifySignatures) {
      SignedJarVerifier verifier = new SignedJarVerifier();
      SignedJarVerifier.VerificationReport sig = verifier.verify(jar);
      report.setSigner(sig.signer());
      report.setSignatureFileCount(sig.signatureFileCount());
      if (!sig.ok()) {
        report.addIssues("signature", sig.issues());
      }
    }

    return report;
  }

  public static final class ArchiveReport {
    private String jarPath;
    private ManifestDocument manifest;
    private ManifestStatistics.StatsReport stats;
    private String manifestPath;
    private int totalEntries;
    private int metaInfCount;
    private int signatureFiles;
    private int signatureFileCount;
    private int unresolvedClasspath;
    private int expandedClasspath;
    private int versionedManifests;
    private boolean multiRelease;
    private String signer = "unknown";
    private final List<String> issues = new ArrayList<>();

    public String jarPath() { return jarPath; }
    public ManifestDocument manifest() { return manifest; }
    public List<String> issues() { return List.copyOf(issues); }
    public boolean multiRelease() { return multiRelease; }
    public String signer() { return signer; }

    void setJarPath(String p) { jarPath = p; }
    void setManifest(ManifestDocument m) { manifest = m; }
    void setStats(ManifestStatistics.StatsReport s) { stats = s; }
    void setManifestPath(String p) { manifestPath = p; }
    void setTotalEntries(int v) { totalEntries = v; }
    void setMetaInfCount(int v) { metaInfCount = v; }
    void setSignatureFiles(int v) { signatureFiles = v; }
    void setSignatureFileCount(int v) { signatureFileCount = v; }
    void setUnresolvedClasspath(int v) { unresolvedClasspath = v; }
    void setExpandedClasspath(int v) { expandedClasspath = v; }
    void setVersionedManifests(int v) { versionedManifests = v; }
    void setMultiRelease(boolean v) { multiRelease = v; }
    void setSigner(String s) { signer = s; }
    void addIssue(String issue) { issues.add(issue); }

    void addIssues(String prefix, List<String> more) {
      for (String m : more) {
        issues.add(prefix + ":" + m);
      }
    }

    public String summary() {
      return "entries=" + totalEntries
          + ",manifest=" + manifestPath
          + ",issues=" + issues.size()
          + ",signer=" + signer;
    }
  }
}
