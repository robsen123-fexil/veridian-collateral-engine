package com.jarpack.archive;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Index of zip entries for manifest cross-checks. */
public final class ZipEntryCatalog {
  private final Map<String, ZipEntryInfo> byName = new HashMap<>();
  private final List<String> ordered = new ArrayList<>();
  private long totalUncompressed;

  public static ZipEntryCatalog scan(ZipFile jar) {
    ZipEntryCatalog catalog = new ZipEntryCatalog();
    java.util.Enumeration<? extends ZipEntry> entries = jar.entries();
    while (entries.hasMoreElements()) {
      catalog.add(entries.nextElement());
    }
    return catalog;
  }

  public void add(ZipEntry entry) {
    if (entry == null) {
      return;
    }
    String name = entry.getName().replace('\\', '/');
    ZipEntryInfo info = new ZipEntryInfo(
        name,
        entry.getSize(),
        entry.getCompressedSize(),
        entry.getCrc(),
        entry.isDirectory());
    byName.put(name, info);
    ordered.add(name);
    if (!entry.isDirectory() && entry.getSize() > 0) {
      totalUncompressed += entry.getSize();
    }
  }

  public boolean contains(String path) {
    return byName.containsKey(normalize(path));
  }

  public ZipEntryInfo get(String path) {
    return byName.get(normalize(path));
  }

  public List<String> names() {
    return Collections.unmodifiableList(ordered);
  }

  public Set<String> metaInfEntries() {
    LinkedHashSet<String> out = new LinkedHashSet<>();
    for (String name : ordered) {
      if (name.startsWith("META-INF/")) {
        out.add(name);
      }
    }
    return out;
  }

  public Set<String> signatureRelated() {
    LinkedHashSet<String> out = new LinkedHashSet<>();
    for (String name : ordered) {
      if (name.startsWith("META-INF/") && (name.endsWith(".SF")
          || name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith(".EC"))) {
        out.add(name);
      }
    }
    return out;
  }

  public long totalUncompressedBytes() {
    return totalUncompressed;
  }

  public int entryCount() {
    return ordered.size();
  }

  public List<String> missingPaths(List<String> required) {
    List<String> missing = new ArrayList<>();
    for (String path : required) {
      if (!contains(path)) {
        missing.add(path);
      }
    }
    return missing;
  }

  private static String normalize(String path) {
    return path == null ? "" : path.replace('\\', '/');
  }

  public static final class ZipEntryInfo {
    private final String name;
    private final long size;
    private final long compressedSize;
    private final long crc;
    private final boolean directory;

    public ZipEntryInfo(String name, long size, long compressedSize, long crc, boolean directory) {
      this.name = name;
      this.size = size;
      this.compressedSize = compressedSize;
      this.crc = crc;
      this.directory = directory;
    }

    public String name() { return name; }
    public long size() { return size; }
    public long compressedSize() { return compressedSize; }
    public long crc() { return crc; }
    public boolean directory() { return directory; }
  }
}
