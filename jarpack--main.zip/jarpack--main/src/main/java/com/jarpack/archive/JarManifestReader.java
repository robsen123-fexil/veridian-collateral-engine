package com.jarpack.archive;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.io.ManifestStreamReader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Reads META-INF/MANIFEST.MF from on-disk JAR archives. */
public final class JarManifestReader {
  private JarManifestReader() {}

  public static ManifestDocument read(Path jarPath) throws IOException {
    try (ZipFile jar = new ZipFile(jarPath.toFile())) {
      return read(jar);
    }
  }

  public static ManifestDocument read(ZipFile jar) throws IOException {
    String path = ManifestEntryLocator.primaryManifestPath(jar);
    if (path == null) {
      ManifestDocument empty = new ManifestDocument();
      empty.warnings().add("no-manifest-entry");
      return empty;
    }
    return readEntry(jar, path);
  }

  public static ManifestDocument readEntry(ZipFile jar, String entryPath) throws IOException {
    ZipEntry entry = jar.getEntry(entryPath);
    if (entry == null) {
      ManifestDocument missing = new ManifestDocument();
      missing.warnings().add("missing-entry:" + entryPath);
      return missing;
    }
    try (InputStream in = jar.getInputStream(entry)) {
      byte[] bytes = in.readAllBytes();
      ManifestDocument doc = ManifestParser.parse(bytes);
      doc.warnings().add("source:" + entryPath);
      return doc;
    }
  }

  public static Map<Integer, ManifestDocument> readVersionedManifests(ZipFile jar) throws IOException {
    Map<Integer, ManifestDocument> out = new LinkedHashMap<>();
    for (String path : ManifestEntryLocator.versionedManifestPaths(jar)) {
      int version = ManifestEntryLocator.parseReleaseVersion(path);
      if (version > 0) {
        out.put(version, readEntry(jar, path));
      }
    }
    return out;
  }

  public static byte[] readRawBytes(ZipFile jar, String entryPath) throws IOException {
    ZipEntry entry = jar.getEntry(entryPath);
    if (entry == null) {
      return new byte[0];
    }
    try (InputStream in = jar.getInputStream(entry)) {
      return in.readAllBytes();
    }
  }

  public static ManifestReadResult inspect(Path jarPath) throws IOException {
    try (ZipFile jar = new ZipFile(jarPath.toFile())) {
      ZipEntryCatalog catalog = ZipEntryCatalog.scan(jar);
      ManifestDocument primary = read(jar);
      Map<Integer, ManifestDocument> versioned = readVersionedManifests(jar);
      List<String> sfFiles = new ArrayList<>();
      for (String name : catalog.metaInfEntries()) {
        if (name.endsWith(".SF")) {
          sfFiles.add(name);
        }
      }
      return new ManifestReadResult(primary, versioned, catalog, sfFiles);
    }
  }

  public static ManifestDocument readStreaming(InputStream manifestStream) throws IOException {
    try (ManifestStreamReader reader = new ManifestStreamReader(manifestStream)) {
      return reader.readDocument();
    }
  }

  public static final class ManifestReadResult {
    private final ManifestDocument primary;
    private final Map<Integer, ManifestDocument> versioned;
    private final ZipEntryCatalog catalog;
    private final List<String> signatureFiles;

    public ManifestReadResult(
        ManifestDocument primary,
        Map<Integer, ManifestDocument> versioned,
        ZipEntryCatalog catalog,
        List<String> signatureFiles) {
      this.primary = primary;
      this.versioned = versioned;
      this.catalog = catalog;
      this.signatureFiles = signatureFiles;
    }

    public ManifestDocument primary() { return primary; }
    public Map<Integer, ManifestDocument> versioned() { return versioned; }
    public ZipEntryCatalog catalog() { return catalog; }
    public List<String> signatureFiles() { return signatureFiles; }

    public boolean isMultiRelease() {
      return "true".equalsIgnoreCase(primary.main().get("Multi-Release"))
          || !versioned.isEmpty();
    }
  }
}
