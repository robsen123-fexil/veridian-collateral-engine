package com.jarpack;

public final class ManifestToken {
  public enum Kind { MAIN_PAIR, SECTION_PAIR, SECTION_BREAK, INVALID }

  private final Kind kind;
  private final String name;
  private final String value;

  private ManifestToken(Kind kind, String name, String value) {
    this.kind = kind;
    this.name = name;
    this.value = value;
  }

  public static ManifestToken pair(String name, String value, boolean section) {
    return new ManifestToken(section ? Kind.SECTION_PAIR : Kind.MAIN_PAIR, name, value);
  }

  public static ManifestToken sectionBreak() {
    return new ManifestToken(Kind.SECTION_BREAK, "", "");
  }

  public static ManifestToken invalid(String raw) {
    return new ManifestToken(Kind.INVALID, raw, "");
  }

  public Kind kind() { return kind; }
  public String name() { return name; }
  public String value() { return value; }
}
