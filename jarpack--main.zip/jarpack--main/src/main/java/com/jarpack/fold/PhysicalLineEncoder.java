package com.jarpack.fold;

import java.nio.charset.StandardCharsets;

/** Encodes logical strings as UTF-8 physical manifest bytes. */
public final class PhysicalLineEncoder {
  public byte[] encodeLines(java.util.List<String> physical) {
    StringBuilder sb = new StringBuilder();
    for (String line : physical) {
      sb.append(line).append('\n');
    }
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }
}
