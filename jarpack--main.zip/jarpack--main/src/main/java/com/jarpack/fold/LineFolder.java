package com.jarpack.fold;

import com.jarpack.FoldEngine;
import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;

import java.util.ArrayList;
import java.util.List;

/** Folds logical manifest lines into 72-byte physical rows. */
public final class LineFolder {
  public static final int MAX_ROW = ManifestConstants.MAX_PHYSICAL_LINE;

  private LineFolder() {}

  public static byte[] foldDocument(ManifestDocument doc) {
    return FoldEngine.foldDocument(doc);
  }

  public static int estimatePhysicalRows(ManifestDocument doc) {
    if (doc == null) {
      return 0;
    }
    LineFolder folder = new LineFolder();
    int rows = 0;
    for (java.util.Map.Entry<String, String> e : doc.main().entrySet()) {
      rows += folder.fold(e.getKey(), e.getValue()).size();
    }
    return rows;
  }

  public List<String> fold(String name, String value) {
    String logical = name + ": " + (value == null ? "" : value);
    List<String> rows = new ArrayList<>();
    int pos = 0;
    while (pos < logical.length()) {
      int take = Math.min(ManifestConstants.MAX_PHYSICAL_LINE, logical.length() - pos);
      String chunk = logical.substring(pos, pos + take);
      if (pos == 0) {
        rows.add(chunk);
      } else {
        rows.add(" " + chunk);
      }
      pos += take;
    }
    if (rows.isEmpty()) {
      rows.add(name + ": ");
    }
    return rows;
  }

  public int physicalLineCount(String name, String value) {
    return fold(name, value).size();
  }
}
