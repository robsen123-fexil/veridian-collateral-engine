package com.jarpack.fold;

/** Policy for when to fold manifest attribute values. */
public final class FoldPolicy {
  private final int maxPhysical;
  private final boolean foldAll;

  public FoldPolicy(int maxPhysical, boolean foldAll) {
    this.maxPhysical = maxPhysical;
    this.foldAll = foldAll;
  }

  public static FoldPolicy jarDefault() {
    return new FoldPolicy(72, false);
  }

  public boolean shouldFold(String name, String value) {
    if (foldAll) return true;
    int len = name.length() + 2 + (value == null ? 0 : value.length());
    return len > maxPhysical;
  }

  public int maxPhysical() { return maxPhysical; }
}
