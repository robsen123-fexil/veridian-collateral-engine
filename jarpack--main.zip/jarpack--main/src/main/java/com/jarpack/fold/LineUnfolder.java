package com.jarpack.fold;

import java.util.ArrayList;
import java.util.List;

/** Unfolds physical manifest lines to logical form. */
public final class LineUnfolder {
  public List<String> unfold(List<String> physical) {
    List<String> logical = new ArrayList<>();
    StringBuilder current = new StringBuilder();
    for (String line : physical) {
      if (line.startsWith(" ")) {
        if (current.length() > 0) {
          current.append(line.substring(1));
        }
        continue;
      }
      if (current.length() > 0) {
        logical.add(current.toString());
      }
      current = new StringBuilder(line);
    }
    if (current.length() > 0) {
      logical.add(current.toString());
    }
    return logical;
  }
}
