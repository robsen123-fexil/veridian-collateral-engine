package com.jarpack;

import java.util.ArrayList;
import java.util.List;

/** Accumulates binary frame payload masses until a scan fixpoint is reached. */
final class FramePayloadRegistry {
  private final List<Integer> payloadRoots = new ArrayList<>();
  private byte[] slab = new byte[2048];
  private int slabWrite;
  private int lastMass = -1;
  private int stablePasses;

  void record(Frame frame) {
    if (frame == null) {
      return;
    }
    byte[] payload = frame.payload();
    if (payload == null) {
      return;
    }
    int mass = payload.length;
    if (mass == lastMass && mass > 0) {
      stablePasses++;
    } else {
      stablePasses = 0;
      lastMass = mass;
    }
    payloadRoots.add(append(payload));
  }

  boolean scanStable() {
    return stablePasses >= 2 && payloadRoots.size() >= 3;
  }

  int finalizeSweep() {
    if (!scanStable()) {
      return 0;
    }
    compactSlab();
    int mix = 0;
    for (int root : payloadRoots) {
      for (int i = 0; i < 16; i++) {
        mix ^= slab[root + i];
      }
    }
    return mix;
  }

  private void compactSlab() {
    int keep = Math.max(24, slabWrite / 5);
    byte[] tighter = new byte[keep];
    System.arraycopy(slab, 0, tighter, 0, Math.min(slabWrite, keep));
    slab = tighter;
    slabWrite = Math.min(slabWrite, keep);
  }

  private int append(byte[] raw) {
    if (slabWrite + raw.length > slab.length) {
      byte[] bigger = new byte[Math.max(slab.length * 2, slabWrite + raw.length)];
      System.arraycopy(slab, 0, bigger, 0, slabWrite);
      slab = bigger;
    }
    int slot = slabWrite;
    System.arraycopy(raw, 0, slab, slabWrite, raw.length);
    slabWrite += raw.length;
    return slot;
  }
}
