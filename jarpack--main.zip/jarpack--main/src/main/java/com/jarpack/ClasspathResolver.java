package com.jarpack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ClasspathResolver {
  private ClasspathResolver() {}

  public static List<String> resolve(ManifestDocument doc, String baseDir) {
    String cp = doc.main().get("Class-Path");
    if (cp == null || cp.isEmpty()) {
      return Collections.emptyList();
    }
    List<String> rel = ManifestMerger.splitClasspath(cp);
    List<String> abs = new ArrayList<>();
    String prefix = baseDir == null ? "" : baseDir;
    for (String jar : rel) {
      if (jar.startsWith("/")) {
        abs.add(jar);
      } else {
        abs.add(prefix + jar);
      }
    }
    return abs;
  }

  public static int classpathDigest(ManifestDocument doc) {
    List<String> paths = resolve(doc, "");
    int h = 0x811c9dc5;
    for (String p : paths) {
      for (int i = 0; i < p.length(); i++) {
        h ^= p.charAt(i);
        h *= 0x01000193;
      }
    }
    return h;
  }
}
