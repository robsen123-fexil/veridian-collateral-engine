package com.jarpack.writer;

import com.jarpack.ManifestDocument;
import com.jarpack.core.ManifestConstants;
import com.jarpack.io.ManifestStreamWriter;
import com.jarpack.normalize.HeaderOrderPolicy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Composes manifest byte output with deterministic attribute ordering
 * and optional CRLF line endings for signed-jar compatibility.
 */
public final class ManifestComposer {
  private boolean crlf = true;
  private boolean trailingNewline = true;
  private HeaderOrderPolicy orderPolicy = HeaderOrderPolicy.standard();

  public ManifestComposer crlf(boolean value) {
    this.crlf = value;
    return this;
  }

  public ManifestComposer trailingNewline(boolean value) {
    this.trailingNewline = value;
    return this;
  }

  public ManifestComposer orderPolicy(HeaderOrderPolicy policy) {
    if (policy != null) {
      this.orderPolicy = policy;
    }
    return this;
  }

  public byte[] compose(ManifestDocument doc) throws IOException {
    if (doc == null) {
      return new byte[0];
    }
    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
    String ending = crlf ? "\r\n" : "\n";
    ManifestStreamWriter writer = new ManifestStreamWriter(bos, ending);
    composeMain(writer, doc);
    composeSections(writer, doc);
    if (trailingNewline) {
      writer.writeBlankLine();
    }
    writer.close();
    return bos.toByteArray();
  }

  private void composeMain(ManifestStreamWriter writer, ManifestDocument doc) throws IOException {
    List<String> ordered = orderPolicy.orderMainKeys(doc.main().keySet());
    for (String key : ordered) {
      writer.writeMainAttribute(key, doc.main().get(key));
    }
  }

  private void composeSections(ManifestStreamWriter writer, ManifestDocument doc) throws IOException {
    List<String> sectionNames = new ArrayList<>(doc.entries().keySet());
    sectionNames.sort(String::compareTo);
    for (String sectionName : sectionNames) {
      writer.writeBlankLine();
      writer.writeSectionHeader(sectionName);
      Map<String, String> attrs = doc.entries().get(sectionName);
      if (attrs == null) {
        continue;
      }
      List<String> keys = orderPolicy.orderSectionKeys(attrs.keySet());
      for (String key : keys) {
        if (ManifestConstants.NAME.equals(key)) {
          continue;
        }
        writer.writeSectionAttribute(key, attrs.get(key));
      }
    }
  }

  public ManifestDocument decompose(byte[] bytes) {
    return com.jarpack.ManifestParser.parse(bytes);
  }

  public ComposeStats stats(ManifestDocument doc) {
    ComposeStats stats = new ComposeStats();
    if (doc == null) {
      return stats;
    }
    stats.mainAttributes = doc.main().size();
    stats.sections = doc.entries().size();
    for (Map.Entry<String, Map<String, String>> e : doc.entries().entrySet()) {
      stats.sectionAttributes += e.getValue().size();
    }
    try {
      stats.outputBytes = compose(doc).length;
    } catch (IOException ex) {
      stats.outputBytes = -1;
    }
    return stats;
  }

  public ManifestDocument mergeCompose(List<ManifestDocument> parts) {
    ManifestDocument merged = new ManifestDocument();
    for (ManifestDocument part : parts) {
      if (part == null) {
        continue;
      }
      for (Map.Entry<String, String> e : part.main().entrySet()) {
        merged.main().putIfAbsent(e.getKey(), e.getValue());
      }
      for (Map.Entry<String, Map<String, String>> e : part.entries().entrySet()) {
        merged.entries().putIfAbsent(e.getKey(), new LinkedHashMap<>(e.getValue()));
      }
      merged.warnings().addAll(part.warnings());
    }
    return merged;
  }

  public static final class ComposeStats {
    public int mainAttributes;
    public int sections;
    public int sectionAttributes;
    public int outputBytes;
  }
}
