package com.jarpack.guide;
import com.jarpack.ManifestDocument;
import com.jarpack.ManifestParser;
import com.jarpack.validate.ManifestRuleEngine;

/** Worked manifest examples for integrators. */
public final class ManifestExamples {
  private ManifestExamples() {}
  public static ManifestDocument minimalExecutable() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nMain-Class: app.Main\n\n");
  }
  public static int validateMinimalExecutable() {
    return ManifestRuleEngine.validate(minimalExecutable()).issues().size();
  }

  public static ManifestDocument withClasspath() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nClass-Path: lib/a.jar lib/b.jar\n\n");
  }
  public static int validateWithClasspath() {
    return ManifestRuleEngine.validate(withClasspath()).issues().size();
  }

  public static ManifestDocument signedStub() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nSignature-Version: 1.0\nCreated-By: jarpack\n\n");
  }
  public static int validateSignedStub() {
    return ManifestRuleEngine.validate(signedStub()).issues().size();
  }

  public static ManifestDocument multiRelease() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nMulti-Release: true\n\n");
  }
  public static int validateMultiRelease() {
    return ManifestRuleEngine.validate(multiRelease()).issues().size();
  }

  public static ManifestDocument sealedPackage() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nSealed: true\n\nName: com/acme/pkg/\nSealed-Name: com/acme/pkg/\n\n");
  }
  public static int validateSealedPackage() {
    return ManifestRuleEngine.validate(sealedPackage()).issues().size();
  }

  public static ManifestDocument modulePath() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nModule-Path: deps/a.jar\n\n");
  }
  public static int validateModulePath() {
    return ManifestRuleEngine.validate(modulePath()).issues().size();
  }

  public static ManifestDocument implementationInfo() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nImplementation-Title: Demo\nImplementation-Version: 1.2\n\n");
  }
  public static int validateImplementationInfo() {
    return ManifestRuleEngine.validate(implementationInfo()).issues().size();
  }

  public static ManifestDocument specificationInfo() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nSpecification-Title: API\nSpecification-Version: 2.0\n\n");
  }
  public static int validateSpecificationInfo() {
    return ManifestRuleEngine.validate(specificationInfo()).issues().size();
  }

  public static ManifestDocument permissionsBlock() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nPermissions: (\"allPermissions\" )\n\n");
  }
  public static int validatePermissionsBlock() {
    return ManifestRuleEngine.validate(permissionsBlock()).issues().size();
  }

  public static ManifestDocument extensionList() {
    return ManifestParser.parseUtf8("Manifest-Version: 1.0\nExtension-List: meta-inf/ext\n\n");
  }
  public static int validateExtensionList() {
    return ManifestRuleEngine.validate(extensionList()).issues().size();
  }

}
