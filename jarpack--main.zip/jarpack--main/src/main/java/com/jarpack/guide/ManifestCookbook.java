package com.jarpack.guide;

import com.jarpack.ManifestDocument;
import com.jarpack.model.ManifestBuilder;
import com.jarpack.writer.ManifestComposer;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reference manifest examples for common JAR types.
 * Used by integrators and documentation tooling.
 */
public final class ManifestCookbook {
  private ManifestCookbook() {}

  public static ManifestDocument executableJar(String mainClass) {
    return ManifestBuilder.create()
        .mainClass(mainClass)
        .createdBy("jarpack")
        .implementation("jarpack-app", "1.0", "misgana tsegaye")
        .build();
  }

  public static ManifestDocument libraryJar(String title, String version) {
    return ManifestBuilder.create()
        .implementation(title, version, "misgana tsegaye")
        .specification(title, version, "misgana tsegaye")
        .build();
  }

  public static ManifestDocument signedJarStub() {
    ManifestDocument doc = ManifestBuilder.create().build();
    doc.main().put("Signature-Version", "1.0");
    Map<String, String> section = new LinkedHashMap<>();
    section.put("SHA-256-Digest", "00".repeat(32));
    doc.entries().put("META-INF/EXAMPLE.SF", section);
    return doc;
  }

  public static ManifestDocument multiReleaseJar() {
    return ManifestBuilder.create()
        .multiRelease(true)
        .implementation("mr-jar", "1.0", "jarpack")
        .build();
  }

  public static ManifestDocument javaAgent(String premainClass) {
    ManifestDocument doc = ManifestBuilder.create().build();
    doc.main().put("Premain-Class", premainClass);
    doc.main().put("Can-Redefine-Classes", "true");
    doc.main().put("Can-Retransform-Classes", "true");
    return doc;
  }

  public static ManifestDocument osgiBundle(String symbolicName, String version) {
    ManifestDocument doc = ManifestBuilder.create().build();
    doc.main().put("Bundle-ManifestVersion", "2");
    doc.main().put("Bundle-SymbolicName", symbolicName);
    doc.main().put("Bundle-Version", version);
    doc.main().put("Import-Package", "java.util;version=\"[1.8,2)\"");
    doc.main().put("Export-Package", "com.example.api;version=\"1.0.0\"");
    return doc;
  }

  public static ManifestDocument springBootExecutable(String startClass) {
    ManifestDocument doc = ManifestBuilder.create()
        .mainClass("org.springframework.boot.loader.JarLauncher")
        .build();
    doc.main().put("Start-Class", startClass);
    doc.main().put("Spring-Boot-Classes", "BOOT-INF/classes/");
    doc.main().put("Spring-Boot-Lib", "BOOT-INF/lib/");
    doc.main().put("Spring-Boot-Version", "3.0.0");
    return doc;
  }

  public static ManifestDocument classpathExtension(String... jars) {
    ManifestBuilder builder = ManifestBuilder.create();
    builder.classPath(String.join(" ", jars));
    return builder.build();
  }

  public static ManifestDocument sealedPackage(String packagePath) {
    ManifestDocument doc = ManifestBuilder.create().sealed(true).build();
    Map<String, String> section = new LinkedHashMap<>();
    section.put("Sealed", "true");
    doc.entries().put(packagePath.replace('.', '/') + "/", section);
    return doc;
  }

  public static ManifestDocument jpmsAutomaticModule(String moduleName) {
    ManifestDocument doc = ManifestBuilder.create().build();
    doc.main().put("Automatic-Module-Name", moduleName);
    return doc;
  }

  public static ManifestDocument jpmsAddExports(String module, String pkg, String target) {
    ManifestDocument doc = ManifestBuilder.create().build();
    doc.main().put("Add-Exports", module + "/" + pkg + "=" + target);
    return doc;
  }

  public static byte[] toBytes(ManifestDocument doc) throws IOException {
    return new ManifestComposer().crlf(true).compose(doc);
  }

  public static Map<String, ManifestDocument> allSamples() {
    Map<String, ManifestDocument> samples = new LinkedHashMap<>();
    samples.put("executable", executableJar("com.example.Main"));
    samples.put("library", libraryJar("example-lib", "1.0"));
    samples.put("signed", signedJarStub());
    samples.put("multi-release", multiReleaseJar());
    samples.put("agent", javaAgent("com.example.Agent"));
    samples.put("osgi", osgiBundle("com.example.bundle", "1.0.0"));
    samples.put("spring-boot", springBootExecutable("com.example.Application"));
    samples.put("classpath", classpathExtension("lib/a.jar", "lib/b.jar"));
    samples.put("sealed", sealedPackage("com.example.internal"));
    samples.put("jpms-auto", jpmsAutomaticModule("com.example"));
    samples.put("jpms-exports", jpmsAddExports("com.example", "com.example.api", "other.module"));
    return samples;
  }
}
