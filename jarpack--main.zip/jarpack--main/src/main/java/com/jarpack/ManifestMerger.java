package com.jarpack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ManifestMerger {
  private ManifestMerger() {}

  public static ManifestDocument merge(ManifestDocument base, ManifestDocument overlay) {
    ManifestDocument out = base.copy();
    for (Map.Entry<String, String> e : overlay.main().entrySet()) {
      out.main().put(e.getKey(), e.getValue());
    }
    for (Map.Entry<String, Map<String, String>> e : overlay.entries().entrySet()) {
      Map<String, String> existing = out.entries().get(e.getKey());
      if (existing == null) {
        out.entries().put(e.getKey(), new LinkedHashMap<>(e.getValue()));
      } else {
        existing.putAll(e.getValue());
      }
    }
    out.warnings().addAll(overlay.warnings());
    return out;
  }

  public static List<String> splitClasspath(String raw) {
    List<String> jars = new ArrayList<>();
    if (raw == null || raw.isEmpty()) {
      return jars;
    }
    String[] parts = raw.split("\\s+");
    for (String p : parts) {
      if (!p.isEmpty()) {
        jars.add(p);
      }
    }
    return jars;
  }
}
