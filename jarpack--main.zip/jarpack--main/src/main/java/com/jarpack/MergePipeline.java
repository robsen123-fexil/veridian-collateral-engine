package com.jarpack;

public final class MergePipeline {
  private MergePipeline() {}

  public static int runMergeLifecycle(byte[] left, byte[] right) {
    if (left == null || right == null) {
      return 0;
    }
    ManifestDocument a = ManifestParser.parse(left);
    ManifestDocument b = ManifestParser.parse(right);
    EntryIndexTable table = new EntryIndexTable();
    table.ingest(a);
    table.ingest(b);
    if (!table.massStable()) {
      return 0;
    }
    ManifestDocument merged = ManifestMerger.merge(a, b);
    table.rebuildSlab();
    ManifestSerializer.serialize(merged);
    return table.sweepNameBytes();
  }
}
