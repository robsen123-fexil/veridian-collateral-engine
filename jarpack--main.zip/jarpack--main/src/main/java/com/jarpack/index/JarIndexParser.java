package com.jarpack.index;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parses META-INF/INDEX.LIST jar index format. */
public final class JarIndexParser {
  private JarIndexParser() {}

  public static JarIndex parse(byte[] raw) {
    String text = new String(raw, StandardCharsets.UTF_8);
    String[] lines = text.split("\\r?\\n");
    JarIndex index = new JarIndex();
    String currentJar = null;
    List<String> currentPackages = null;
    for (String line : lines) {
      if (line.isEmpty()) {
        continue;
      }
      if (!line.startsWith(" ")) {
        if (currentJar != null && currentPackages != null) {
          index.putJar(currentJar, currentPackages);
        }
        currentJar = line.trim();
        currentPackages = new ArrayList<>();
        continue;
      }
      if (currentPackages != null) {
        currentPackages.add(line.trim());
      }
    }
    if (currentJar != null && currentPackages != null) {
      index.putJar(currentJar, currentPackages);
    }
    return index;
  }

  public static byte[] serialize(JarIndex index) {
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, List<String>> e : index.jars().entrySet()) {
      sb.append(e.getKey()).append('\n');
      for (String pkg : e.getValue()) {
        sb.append(' ').append(pkg).append('\n');
      }
    }
    return sb.toString().getBytes(StandardCharsets.UTF_8);
  }

  public static String locateJarForClass(JarIndex index, String className) {
    String pkg = packagePrefix(className);
    for (Map.Entry<String, List<String>> e : index.jars().entrySet()) {
      for (String listed : e.getValue()) {
        if (pkg.startsWith(listed) || listed.startsWith(pkg)) {
          return e.getKey();
        }
      }
    }
    return null;
  }

  private static String packagePrefix(String className) {
    int dot = className.lastIndexOf('.');
    if (dot < 0) {
      return "";
    }
    return className.substring(0, dot + 1);
  }
}
