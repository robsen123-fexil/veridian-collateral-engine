package com.jarpack.index;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Resolves class/resource paths using jar index roots. */
public final class IndexRootResolver {
  private final JarIndex index;

  public IndexRootResolver(JarIndex index) {
    this.index = index == null ? new JarIndex() : index;
  }

  public List<String> candidateJars(String resourcePath) {
    List<String> hits = new ArrayList<>();
    String pkg = toPackagePrefix(resourcePath);
    for (Map.Entry<String, List<String>> e : index.jars().entrySet()) {
      for (String root : e.getValue()) {
        if (pkg.startsWith(root) || root.startsWith(pkg)) {
          hits.add(e.getKey());
          break;
        }
      }
    }
    return hits;
  }

  private static String toPackagePrefix(String path) {
    if (path.endsWith(".class")) {
      int slash = path.lastIndexOf('/');
      if (slash < 0) {
        return "";
      }
      return path.substring(0, slash + 1);
    }
    if (!path.endsWith("/")) {
      int slash = path.lastIndexOf('/');
      if (slash >= 0) {
        return path.substring(0, slash + 1);
      }
    }
    return path;
  }
}
