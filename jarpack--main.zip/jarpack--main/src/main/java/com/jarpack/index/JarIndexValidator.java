package com.jarpack.index;

import com.jarpack.ManifestDocument;
import com.jarpack.classpath.ClasspathOrderResolver;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Validates INDEX.LIST consistency with manifest Class-Path. */
public final class JarIndexValidator {
  private JarIndexValidator() {}

  public static List<String> validate(JarIndex index, ManifestDocument manifest) {
    List<String> issues = new ArrayList<>();
    if (index == null) {
      issues.add("null-index");
      return issues;
    }
    if (index.jarCount() == 0) {
      issues.add("empty-index");
    }
    List<String> classpath = ClasspathOrderResolver.ordered(manifest);
    for (Map.Entry<String, List<String>> entry : index.jars().entrySet()) {
      String jar = entry.getKey();
      List<String> pkgs = entry.getValue();
      if (jar == null || jar.trim().isEmpty()) {
        issues.add("empty-jar-entry");
      }
      for (String pkg : pkgs) {
        if (pkg == null || pkg.trim().isEmpty()) {
          issues.add("empty-package-in:" + jar);
        }
      }
      boolean onClasspath = classpath.stream().anyMatch(cp -> cp.endsWith(jar) || cp.equals(jar));
      if (!onClasspath && !classpath.isEmpty()) {
        issues.add("index-jar-not-on-classpath:" + jar);
      }
    }
    return issues;
  }

  public static boolean isValid(JarIndex index, ManifestDocument manifest) {
    return validate(index, manifest).isEmpty();
  }
}
