package com.jarpack.index;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** In-memory model of META-INF/INDEX.LIST jar index. */
public final class JarIndex {
  private final Map<String, List<String>> jars = new LinkedHashMap<>();

  public void putJar(String jarPath, List<String> packages) {
    if (jarPath == null) return;
    jars.put(jarPath, packages == null ? new ArrayList<>() : new ArrayList<>(packages));
  }

  public Map<String, List<String>> jars() {
    return Collections.unmodifiableMap(jars);
  }

  public List<String> packagesFor(String jar) {
    List<String> pkgs = jars.get(jar);
    return pkgs == null ? List.of() : Collections.unmodifiableList(pkgs);
  }

  public int jarCount() { return jars.size(); }

  public int totalPackages() {
    int n = 0;
    for (List<String> pkgs : jars.values()) n += pkgs.size();
    return n;
  }

  public boolean containsPackage(String pkg) {
    for (List<String> pkgs : jars.values()) {
      if (pkgs.contains(pkg)) return true;
    }
    return false;
  }

  public String findJarForPackage(String pkg) {
    for (Map.Entry<String, List<String>> e : jars.entrySet()) {
      if (e.getValue().contains(pkg)) return e.getKey();
    }
    return null;
  }
}
