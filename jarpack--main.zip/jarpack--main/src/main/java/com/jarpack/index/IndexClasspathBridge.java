package com.jarpack.index;

import com.jarpack.ManifestDocument;
import com.jarpack.ManifestMerger;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Bridges INDEX.LIST jar references with Class-Path manifest entries. */
public final class IndexClasspathBridge {
  private IndexClasspathBridge() {}

  public static List<String> referencedJars(JarIndex index) {
    if (index == null) {
      return List.of();
    }
    return List.copyOf(index.jars().keySet());
  }

  public static List<String> synchronizeClasspath(ManifestDocument manifest, JarIndex index) {
    List<String> changes = new ArrayList<>();
    if (index == null) {
      return changes;
    }
    Set<String> existing = new LinkedHashSet<>(ManifestMerger.splitClasspath(
        manifest.main().get("Class-Path")));
    for (String jar : index.jars().keySet()) {
      if (existing.add(jar)) {
        changes.add("added:" + jar);
      }
    }
    if (!changes.isEmpty()) {
      manifest.main().put("Class-Path", String.join(" ", existing));
    }
    return changes;
  }

  public static List<String> packagesForJar(JarIndex index, String jarName) {
    if (index == null) {
      return List.of();
    }
    return index.packagesFor(jarName);
  }
}
