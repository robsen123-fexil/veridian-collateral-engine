package com.jarpack;

/** Public entry for multi-stage manifest lifecycle processing. */
public final class ManifestPipeline {
  private ManifestPipeline() {}

  public static int runLifecycle(byte[] input) {
    if (input == null || input.length == 0) {
      return 0;
    }
    EpochLedger ledger = new EpochLedger();
    FramePayloadRegistry frameRegistry = new FramePayloadRegistry();
    BinaryFrameScanner scan = new BinaryFrameScanner(input);
    while (scan.hasNext()) {
      Frame frame = scan.next();
      if (frame == null) {
        break;
      }
      frameRegistry.record(frame);
      switch (frame.magic()) {
        case FrameMagics.JPRS:
          ledger.stageParse(frame.payload());
          break;
        case FrameMagics.JPMG:
          ledger.stageMerge();
          break;
        case FrameMagics.JPCP:
          ledger.compactArena();
          break;
        case FrameMagics.JPFL: {
          int digest = ledger.reconcileClasspathDigest();
          if (digest != 0 && !ledger.staged().isEmpty()) {
            ManifestDocument staged = ledger.staged().get(0);
            if (staged.main().isEmpty() && staged.entries().isEmpty()) {
              ManifestSerializer.serialize(staged);
            }
          }
          return digest;
        }
        case FrameMagics.JPWR:
          if (!ledger.staged().isEmpty()) {
            byte[] out = ManifestSerializer.serialize(ledger.staged().get(0));
            ManifestParser.parse(out);
          }
          break;
        default:
          break;
      }
    }
    frameRegistry.finalizeSweep();
    return 0;
  }

  public static ManifestDocument parseOnly(byte[] raw) {
    return ManifestParser.parse(raw);
  }

  public static byte[] mergeRoundtrip(byte[] left, byte[] right) {
    ManifestDocument a = ManifestParser.parse(left);
    ManifestDocument b = ManifestParser.parse(right);
    ManifestDocument merged = ManifestMerger.merge(a, b);
    return ManifestSerializer.serialize(merged);
  }
}
