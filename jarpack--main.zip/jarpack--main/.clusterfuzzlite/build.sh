#!/bin/bash -eu
# ClusterFuzzLite JVM build for jarpack

cd "${SRC:-.}"

# Build library jar
mkdir -p "$OUT/classes"
find src/main/java -name '*.java' > sources.txt
javac -encoding UTF-8 -d "$OUT/classes" @sources.txt
jar --create --file "$OUT/jarpack.jar" -C "$OUT/classes" .

PROJECT_JARS="jarpack.jar"
BUILD_CLASSPATH="$OUT/jarpack.jar:$JAZZER_API_PATH"
RUNTIME_CLASSPATH="\$this_dir/jarpack.jar:\$this_dir/harness:\$this_dir"

mkdir -p "$OUT/harness"
for fuzzer in fuzz/*Fuzzer.java; do
  fuzzer_basename=$(basename -s .java "$fuzzer")
  javac -encoding UTF-8 -cp "$BUILD_CLASSPATH" -d "$OUT/harness" "$fuzzer"

  echo "#!/bin/bash
# LLVMFuzzerTestOneInput shim for JVM
this_dir=\$(dirname \"\$0\")
if [[ \"\$@\" =~ (^| )-runs=[0-9]+($| ) ]]; then
  mem_settings='-Xmx1900m:-Xss900k'
else
  mem_settings='-Xmx2048m:-Xss1024k'
fi
LD_LIBRARY_PATH=\"$JVM_LD_LIBRARY_PATH\":\$this_dir \
\$this_dir/jazzer_driver --agent_path=\$this_dir/jazzer_agent_deploy.jar \
--cp=$RUNTIME_CLASSPATH \
--target_class=$fuzzer_basename \
--jvm_args=\"\$mem_settings:-Djava.awt.headless=true\" \
\$@" > "$OUT/$fuzzer_basename"
  chmod +x "$OUT/$fuzzer_basename"
done
