import com.jarpack.*;

/**
 * Jazzer fuzz target for jarpack.
 * ClusterFuzzLite compiles this file with JAZZER_API_PATH.
 */
public class SerializeFuzzer {
  public static void fuzzerTestOneInput(byte[] data) {
    if (data == null) {
      return;
    }
    try {
      SerializePipeline.runLifecycle(data);
    } catch (RuntimeException ex) {
      throw ex;
    }
  }
}
