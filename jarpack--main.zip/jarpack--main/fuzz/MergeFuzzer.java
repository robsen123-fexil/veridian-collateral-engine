import com.jarpack.*;

/**
 * Jazzer fuzz target for jarpack.
 * ClusterFuzzLite compiles this file with JAZZER_API_PATH.
 */
public class MergeFuzzer {
  public static void fuzzerTestOneInput(byte[] data) {
    if (data == null) {
      return;
    }
    try {
      MergePipeline.runMergeLifecycle(data, data);
      com.jarpack.merge.ManifestMergeEngine engine = new com.jarpack.merge.ManifestMergeEngine();
      engine.merge(com.jarpack.ManifestParser.parse(data), com.jarpack.ManifestParser.parse(data));
      java.util.List<com.jarpack.ManifestDocument> chain = java.util.Arrays.asList(
          com.jarpack.ManifestParser.parse(data),
          com.jarpack.ManifestParser.parse(data),
          com.jarpack.ManifestParser.parse(data));
      engine.mergeChain(chain);
      com.jarpack.merge.UberJarManifestBuilder.buildFrom(data, data);
    } catch (RuntimeException ex) {
      throw ex;
    }
  }
}
