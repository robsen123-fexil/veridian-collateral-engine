import com.jarpack.*;

/**
 * Jazzer fuzz target for jarpack.
 * ClusterFuzzLite compiles this file with JAZZER_API_PATH.
 */
public class ParseFuzzer {
  public static void fuzzerTestOneInput(byte[] data) {
    if (data == null) {
      return;
    }
    try {
      ManifestPipeline.runLifecycle(data);
      com.jarpack.pipeline.ManifestAnalysisPipeline.quick(data);
      com.jarpack.signature.DigestEntryIndex.sweepLifecycle(data);
      com.jarpack.profile.ProfileValidationSuite.validate(
          com.jarpack.ManifestParser.parse(data));
    } catch (RuntimeException ex) {
      throw ex;
    }
  }
}
