import com.jarpack.*;

/**
 * Jazzer fuzz target for jarpack.
 * ClusterFuzzLite compiles this file with JAZZER_API_PATH.
 */
public class ClasspathFuzzer {
  public static void fuzzerTestOneInput(byte[] data) {
    if (data == null) {
      return;
    }
    try {
      ClasspathPipeline.runFoldLifecycle(data);
      com.jarpack.classpath.ClasspathFrontierRegistry.runLifecycle(data);
    } catch (RuntimeException ex) {
      throw ex;
    }
  }
}
