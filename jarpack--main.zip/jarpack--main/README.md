# jarpack

**jarpack** is a Java 11 library for parsing, merging, folding, validating, and
serializing JAR `META-INF/MANIFEST.MF` files — including `Main-Class`,
`Class-Path` continuation lines, per-entry `Name:` sections, signed-jar digests,
multi-release layouts, and OSGi/JPMS/Spring Boot attribute profiles.

**Author:** misgana tsegaye (`misge1stt@gmail.com`)

Private repo: `Misge1st/jarpack-`

## Features

- Manifest lexer and stream reader with JAR line-folding (72-byte physical rows)
- Parse main attributes and per-entry sections
- Merge and reconcile multiple manifest documents
- JAR archive I/O (`JarManifestReader`, `JarManifestWriter`)
- PKCS#7 signature block parsing and digest verification pipeline
- Classpath graph expansion and coherence checks
- Profile detection (executable, signed, OSGi, Spring Boot, Java agent, etc.)
- Validation rule engine with JPMS/OSGi/syntax rules
- CRLF encoding for signed-jar compatibility
- Multi-stage lifecycle pipeline for batch manifest reconciliation

## Build

Requirements: JDK 11+, Maven 3.6+ (or use ClusterFuzzLite Docker image).

```bash
mvn -q package
mvn -q test
```

## Fuzz harnesses (Jazzer / ClusterFuzzLite)

| Harness | Exercises |
|---------|-----------|
| `ParseFuzzer` | Binary lifecycle frames → parse/profile validation |
| `MergeFuzzer` | Dual-manifest merge engine + uber-jar builder |
| `ClasspathFuzzer` | Class-Path fold tape sweep across rounds |
| `SerializeFuzzer` | Parse → serialize roundtrip |
| `PipelineFuzzer` | Full manifest lifecycle + analysis pipeline |

Seeds: `fuzz/corpus/<Harness>/`

```bash
bash .clusterfuzzlite/build.sh
```

## Layout

```
jarpack/
  src/main/java/com/jarpack/
    archive/      JAR zip manifest I/O
    attr/         Per-attribute handlers (JPMS, OSGi)
    classpath/    Class-Path resolution and graphs
    diff/         Structural manifest diffs
    fold/         72-byte line folding
    index/        INDEX.LIST support
    io/           Stream readers/writers, CRLF encoding
    merge/        Uber-jar merge engine
    model/        Builder, editor, typed views
    normalize/    Canonical ordering and whitespace
    pipeline/     End-to-end analysis pipeline
    profile/      Jar-type detection and validation
    reconcile/    Two-way manifest reconciliation
    service/      Batch manifest processing
    signature/    .SF parsing, PKCS#7, digest pipeline
    stats/        Manifest statistics
    validate/     Rule engine and syntax checker
    writer/       Deterministic manifest composition
  src/test/java/               Unit tests (valid inputs only)
  fuzz/                        Jazzer targets + neutral seeds
  examples/                    Sample manifests
  .clusterfuzzlite/            Platform build entry
```

## License

MIT — see LICENSE.
