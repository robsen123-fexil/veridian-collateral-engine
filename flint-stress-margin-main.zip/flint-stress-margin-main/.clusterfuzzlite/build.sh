#!/bin/bash -eu

cd "${SRC:-.}"

if ! command -v cargo-fuzz &>/dev/null; then
  echo "error: cargo-fuzz not found in PATH (network install disabled in ClusterFuzzLite)" >&2
  exit 1
fi

export RUSTFLAGS="${RUSTFLAGS:-} -Cdebuginfo=1 -Cforce-frame-pointers=yes"

FUZZ_TARGETS=(batch_fuzzer router_fuzzer session_fuzzer fix_fuzzer swift_fuzzer)

for target in "${FUZZ_TARGETS[@]}"; do
  cargo fuzz build "${target}" --release --sanitizer address
  cp "fuzz/target/x86_64-unknown-linux-gnu/release/${target}" "${OUT:-.}/${target}"
done
