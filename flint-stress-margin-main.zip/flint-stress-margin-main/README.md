# flint-stress-margin

Derivatives portfolio stress testing and margin aggregation library for desk risk workflows.

**Author:** misgana tsegaye

## Build

```bash
cargo build --release
cargo test
```

CLI binary:

```bash
cargo run --bin fsmctl -- stress <batch.bin>
cargo run --bin fsmctl -- scenario <envelope.bin>
cargo run --bin fsmctl -- desk-smoke
```

## Fuzzing

Install `cargo-fuzz` locally, then:

```bash
cargo fuzz build batch_fuzzer --release --sanitizer address
cargo fuzz run batch_fuzzer fuzz/corpus/batch_fuzzer/
```

ClusterFuzzLite build (Linux):

```bash
export SRC="$PWD" OUT=/tmp/fsm_out && mkdir -p "$OUT"
bash .clusterfuzzlite/build.sh
```

## Exercises

| Harness | Entry API | Wire |
|---------|-----------|------|
| `batch_fuzzer` | `run_stress_batch_pipeline` | FSMB / FSML lifecycle |
| `router_fuzzer` | `process_ingress_stream` | FSME / FSMR lifecycle |
| `session_fuzzer` | `merge_portfolio_sessions` | FSMS / FSMC lifecycle |
| `fix_fuzzer` | `run_fix_margin_pipeline` | FIX 4.4 / FSMX lifecycle |
| `swift_fuzzer` | `run_mt940_collateral_pipeline` | MT940 / FSMW lifecycle |

## Module map

| Module | Responsibility |
|--------|----------------|
| `wire/batch_codec` | FSMB stress batch encode/decode |
| `wire/envelope_codec` | FSME nested scenario envelope tree |
| `wire/fix_parser` | FIX 4.4 tag scanner and frame parser |
| `wire/fix_tag_tables` | FIX tag registry and field metadata |
| `wire/fix_validation_engine` | FIX margin message validation |
| `wire/swift_mt940` | SWIFT MT940 statement parser |
| `wire/swift_field_scanner` | SWIFT field tag scanner |
| `wire/stress_wire_rules` | Wire magic classifier |
| `wire/magics` | FSMB/FSME/FSMS magic constants |
| `ingress/dispatch` | Wire dispatch and ingress routing |
| `ingress/scenario_staging` | Scenario envelope staging board |
| `ingress/stress_tape` | Deferred channel digest tape |
| `engine/stress_pipeline` | Stress batch margin pipeline |
| `engine/intern_arena` | Cross-batch FSMB intern payload spool |
| `engine/deferred_byte_spool` | Shared deferred byte arena for lifecycles |
| `engine/session_lifecycle` | FSMC portfolio session lifecycle |
| `engine/fix_tag_lifecycle` | FSMX FIX tag-value lifecycle |
| `engine/mt940_line_lifecycle` | FSMW MT940 line lifecycle |
| `ingress/scenario_lifecycle` | FSMR scenario envelope lifecycle |
| `util/lifecycle_wire` | Multi-frame lifecycle wire parser |
| `engine/scenario_merge` | Portfolio session merge pipeline |
| `engine/orchestrator` | Batch normalization orchestrator |
| `engine/margin_staging` | Batch digest pin staging |
| `engine/position_pin_board` | Session leg pin board |
| `engine/fix_margin_pipeline` | FIX margin execution pipeline |
| `engine/mt940_collateral_pipeline` | MT940 collateral ingestion |
| `ledger/margin_digest_chain` | Batch margin audit digest chain |
| `ledger/spool_epoch_ledger` | Cross-frame batch spool epoch reconciliation |
| `ledger/scenario_spool_ledger` | Scenario channel spool epoch reconciliation |
| `ledger/session_spool_ledger` | Portfolio session leg spool epoch reconciliation |
| `ledger/fix_spool_ledger` | FIX margin tag spool epoch reconciliation |
| `ledger/mt940_spool_ledger` | MT940 collateral line spool epoch reconciliation |
| `ledger/checkpoint_anchor` | Session merge checkpoint digest |
| `desk/var_grid_engine` | VaR grid stress engine |
| `desk/greek_aggregation` | Portfolio Greek aggregation |
| `desk/margin_call_scheduler` | Margin call scheduling |
| `desk/haircut_engine` | Collateral haircut grid |
| `desk/scenario_shock_table` | Scenario shock factor table |
| `desk/ccp_margin_calculator` | CCP initial margin calculator |
| `desk/isda_csa_terms` | ISDA CSA term interpreter |
| `desk/delta_ladder_builder` | Delta ladder construction |
| `desk/gamma_convexity_grid` | Gamma convexity stress grid |
| `desk/vega_surface_stress` | Vega surface shock |
| `desk/theta_decay_schedule` | Theta decay schedule |
| `desk/rho_curve_shift` | Rho curve parallel shift |
| `desk/fx_delta_netter` | FX delta netting |
| `desk/irs_bucket_allocator` | IRS bucket allocation |
| `desk/cds_spread_stressor` | CDS spread stress |
| `desk/equity_beta_shock` | Equity beta shock |
| `desk/commodity_basis_grid` | Commodity basis grid |
| `desk/options_iv_shock` | Options IV shock surface |
| `desk/cross_gamma_matrix` | Cross-gamma correlation matrix |
| `desk/portfolio_nav_tracker` | Portfolio NAV tracker |
| `desk/collateral_eligibility` | Collateral eligibility rules |
| `desk/funding_spread_ladder` | Funding spread ladder |
| `desk/liquidity_horizon_grid` | Liquidity horizon grid |
| `desk/exposure_limit_guard` | Exposure limit guard |
| `desk/stress_correlation_break` | Correlation break stress |
| `desk/swap_reset_calendar` | Swap reset calendar |
| `desk/futures_roll_stress` | Futures roll stress |
| `desk/basis_swap_spread` | Basis swap spread stress |
| `desk/portfolio_stress_ledger` | Portfolio stress sweep ledger |
| `desk/stress_checkpoint` | Stress checkpoint recorder |
| `desk/position_reconciler` | Session position reconciler |
| `desk/integration_bridge` | Desk module integration smoke |
| `util/bounded` | Bounded wire read helpers |
| `util/fnv1a` | FNV-1a digest helper |
| `bin/fsmctl` | CLI control binary |

Wire layout details: [docs/FORMAT.md](docs/FORMAT.md).
