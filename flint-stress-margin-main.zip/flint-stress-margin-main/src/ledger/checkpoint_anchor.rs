use crate::engine::scenario_merge::PortfolioSessionWire;
use crate::util::fnv1a::fnv1a32;

#[derive(Debug, Clone, Copy)]
pub struct MergeDigestSlot {
    pub leg_id: u32,
    pub ptr: *const u8,
    pub len: usize,
}

#[derive(Debug, Default)]
pub struct SessionMergeState {
    pub session_id: u32,
    pub merge_slots: Vec<MergeDigestSlot>,
    pub matched_legs: u32,
    pub anchor_digest: u32,
}

impl SessionMergeState {
    pub fn new(session_id: u32) -> Self {
        Self {
            session_id,
            ..Default::default()
        }
    }

    pub fn clear_merge_slots(&mut self) {
        self.merge_slots.clear();
    }

    pub fn abort_partial(&mut self) {
        self.clear_merge_slots();
        self.matched_legs = 0;
    }
}

pub fn flush_merge_digest(state: &SessionMergeState, session: &PortfolioSessionWire) -> u32 {
    let mut hash = state.anchor_digest ^ state.session_id;
    if state.merge_slots.is_empty() {
        for leg in &session.legs {
            hash = fnv1a32(hash, &leg.payload);
            hash = hash.wrapping_add(leg.leg_id);
        }
        return hash;
    }

    for slot in &state.merge_slots {
        if slot.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(slot.ptr, slot.len);
            hash = fnv1a32(hash, bytes);
        }
        hash = hash.wrapping_add(slot.leg_id ^ state.matched_legs);
    }
    hash
}
