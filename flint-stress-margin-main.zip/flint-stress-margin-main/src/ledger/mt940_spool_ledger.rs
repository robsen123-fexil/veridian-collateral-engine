//! MT940 collateral line spool epoch ledger for FSMW lifecycle reconciliation.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::util::fnv1a::fnv1a32;
use std::sync::{Mutex, OnceLock};

const MT940_ROTATION: u32 = 56;

#[derive(Debug, Clone, Copy)]
struct LineAnchorView {
    line_index: u32,
    ptr: *const u8,
    len: usize,
    capture_generation: u32,
}

unsafe impl Send for LineAnchorView {}

#[derive(Debug, Default)]
struct RotatedMt940Seal {
    views: Vec<LineAnchorView>,
    spool_generation: u32,
    line_count: u32,
}

#[derive(Debug, Default)]
struct Mt940EpochLedger {
    statement_epoch: u32,
    frames_seen: u32,
    line_seal: Option<RotatedMt940Seal>,
}

static MT940_EPOCH: OnceLock<Mutex<Mt940EpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, Mt940EpochLedger> {
    MT940_EPOCH
        .get_or_init(|| Mutex::new(Mt940EpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_mt940_desk_epoch() {
    let mut led = ledger();
    led.statement_epoch = 0;
    led.frames_seen = 0;
    led.line_seal = None;
}

pub fn seal_mt940_line_epoch(spool: &DeferredByteSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    if led.frames_seen % MT940_ROTATION == 0 {
        led.statement_epoch = led.statement_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| LineAnchorView {
            line_index: slot.record_index,
            ptr: slot.ptr,
            len: slot.len,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.line_seal = Some(RotatedMt940Seal {
        views,
        spool_generation: spool.compact_generation,
        line_count: spool.deferred_digest.len() as u32,
    });
}

pub fn reconcile_mt940_line_anchor() -> u32 {
    let led = ledger();
    let Some(seal) = &led.line_seal else {
        return 0;
    };
    let mut acc = 0x2f8b_22d1u32 ^ led.statement_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc
            .wrapping_add(view.line_index)
            .wrapping_add(view.capture_generation);
    }
    acc ^ seal.line_count
}
