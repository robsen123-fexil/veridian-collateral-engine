//! Portfolio session spool epoch ledger for FSMC lifecycle reconciliation.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::util::fnv1a::fnv1a32;
use std::sync::{Mutex, OnceLock};

const SESSION_ROTATION: u32 = 32;

#[derive(Debug, Clone, Copy)]
struct LegAnchorView {
    leg_id: u32,
    ptr: *const u8,
    len: usize,
    capture_generation: u32,
}

unsafe impl Send for LegAnchorView {}

#[derive(Debug, Default)]
struct RotatedSessionSeal {
    views: Vec<LegAnchorView>,
    spool_generation: u32,
    leg_count: u32,
}

#[derive(Debug, Default)]
struct SessionEpochLedger {
    merge_epoch: u32,
    frames_seen: u32,
    leg_seal: Option<RotatedSessionSeal>,
}

static SESSION_EPOCH: OnceLock<Mutex<SessionEpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, SessionEpochLedger> {
    SESSION_EPOCH
        .get_or_init(|| Mutex::new(SessionEpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_session_desk_epoch() {
    let mut led = ledger();
    led.merge_epoch = 0;
    led.frames_seen = 0;
    led.leg_seal = None;
}

pub fn seal_session_leg_epoch(spool: &DeferredByteSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    if led.frames_seen % SESSION_ROTATION == 0 {
        led.merge_epoch = led.merge_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| LegAnchorView {
            leg_id: slot.record_index,
            ptr: slot.ptr,
            len: slot.len,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.leg_seal = Some(RotatedSessionSeal {
        views,
        spool_generation: spool.compact_generation,
        leg_count: spool.deferred_digest.len() as u32,
    });
}

pub fn reconcile_session_leg_anchor() -> u32 {
    let led = ledger();
    let Some(seal) = &led.leg_seal else {
        return 0;
    };
    let mut acc = 0x811c_9dc5u32 ^ led.merge_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc.wrapping_add(view.leg_id ^ view.capture_generation);
    }
    acc ^ seal.leg_count
}
