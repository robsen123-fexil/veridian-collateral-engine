//! Scenario envelope spool epoch ledger for FSMR lifecycle reconciliation.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::util::fnv1a::fnv1a32;
use std::sync::{Mutex, OnceLock};

const SCENARIO_ROTATION: u32 = 48;

#[derive(Debug, Clone, Copy)]
struct ChannelAnchorView {
    channel_id: u32,
    ptr: *const u8,
    len: usize,
    capture_generation: u32,
}

unsafe impl Send for ChannelAnchorView {}

#[derive(Debug, Default)]
struct RotatedScenarioSeal {
    views: Vec<ChannelAnchorView>,
    spool_generation: u32,
    channel_count: u32,
}

#[derive(Debug, Default)]
struct ScenarioEpochLedger {
    ingress_epoch: u32,
    frames_seen: u32,
    channel_seal: Option<RotatedScenarioSeal>,
}

static SCENARIO_EPOCH: OnceLock<Mutex<ScenarioEpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, ScenarioEpochLedger> {
    SCENARIO_EPOCH
        .get_or_init(|| Mutex::new(ScenarioEpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_scenario_desk_epoch() {
    let mut led = ledger();
    led.ingress_epoch = 0;
    led.frames_seen = 0;
    led.channel_seal = None;
}

pub fn seal_scenario_channel_epoch(spool: &DeferredByteSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    if led.frames_seen % SCENARIO_ROTATION == 0 {
        led.ingress_epoch = led.ingress_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| ChannelAnchorView {
            channel_id: slot.record_index,
            ptr: slot.ptr,
            len: slot.len,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.channel_seal = Some(RotatedScenarioSeal {
        views,
        spool_generation: spool.compact_generation,
        channel_count: spool.deferred_digest.len() as u32,
    });
}

pub fn reconcile_scenario_channel_anchor() -> u32 {
    let led = ledger();
    let Some(seal) = &led.channel_seal else {
        return 0;
    };
    let mut acc = 0xcbf2_9ce4u32 ^ led.ingress_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc
            .wrapping_add(view.channel_id)
            .wrapping_add(view.capture_generation);
    }
    acc ^ seal.channel_count
}
