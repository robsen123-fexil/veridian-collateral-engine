//! Cross-frame stress batch spool epoch reconciliation ledger.

use crate::engine::intern_arena::InternPayloadSpool;
use crate::util::fnv1a::fnv1a32;
use std::sync::{Mutex, OnceLock};

const ROTATION_INTERVAL: u32 = 64;

#[derive(Debug, Clone, Copy)]
struct SpoolAnchorView {
    record_index: u32,
    ptr: *const u8,
    len: usize,
    capture_generation: u32,
}

unsafe impl Send for SpoolAnchorView {}

#[derive(Debug, Default)]
struct RotatedBatchSpoolSeal {
    views: Vec<SpoolAnchorView>,
    spool_generation: u32,
    anchor_count: u32,
}

#[derive(Debug, Default)]
struct SpoolEpochLedger {
    desk_epoch: u32,
    frames_seen: u32,
    spool_seal: Option<RotatedBatchSpoolSeal>,
}

static BATCH_EPOCH: OnceLock<Mutex<SpoolEpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, SpoolEpochLedger> {
    BATCH_EPOCH
        .get_or_init(|| Mutex::new(SpoolEpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_batch_desk_epoch() {
    let mut led = ledger();
    led.desk_epoch = 0;
    led.frames_seen = 0;
    led.spool_seal = None;
}

pub fn seal_batch_spool_epoch(spool: &InternPayloadSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    if led.frames_seen % ROTATION_INTERVAL == 0 {
        led.desk_epoch = led.desk_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| SpoolAnchorView {
            record_index: slot.record_index,
            ptr: slot.ptr,
            len: slot.len,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.spool_seal = Some(RotatedBatchSpoolSeal {
        views,
        spool_generation: spool.compact_generation,
        anchor_count: spool.deferred_digest.len() as u32,
    });
}

pub fn reconcile_batch_spool_anchor() -> u32 {
    let led = ledger();
    let Some(seal) = &led.spool_seal else {
        return 0;
    };
    let mut acc = 0x1465_0bc1u32 ^ led.desk_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc
            .wrapping_add(view.record_index)
            .wrapping_add(view.capture_generation);
    }
    acc ^ seal.anchor_count
}
