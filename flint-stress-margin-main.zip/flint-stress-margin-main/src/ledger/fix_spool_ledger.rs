//! FIX margin tag spool epoch ledger for FSMX lifecycle reconciliation.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::util::fnv1a::fnv1a32;
use std::sync::{Mutex, OnceLock};

const FIX_ROTATION: u32 = 40;

#[derive(Debug, Clone, Copy)]
struct TagAnchorView {
    tag: u32,
    ptr: *const u8,
    len: usize,
    capture_generation: u32,
}

unsafe impl Send for TagAnchorView {}

#[derive(Debug, Default)]
struct RotatedFixSeal {
    views: Vec<TagAnchorView>,
    spool_generation: u32,
    tag_count: u32,
}

#[derive(Debug, Default)]
struct FixEpochLedger {
    session_epoch: u32,
    frames_seen: u32,
    tag_seal: Option<RotatedFixSeal>,
}

static FIX_EPOCH: OnceLock<Mutex<FixEpochLedger>> = OnceLock::new();

fn ledger() -> std::sync::MutexGuard<'static, FixEpochLedger> {
    FIX_EPOCH
        .get_or_init(|| Mutex::new(FixEpochLedger::default()))
        .lock()
        .unwrap_or_else(|e| e.into_inner())
}

pub fn reset_fix_desk_epoch() {
    let mut led = ledger();
    led.session_epoch = 0;
    led.frames_seen = 0;
    led.tag_seal = None;
}

pub fn seal_fix_tag_epoch(spool: &DeferredByteSpool) {
    let mut led = ledger();
    led.frames_seen = led.frames_seen.wrapping_add(1);
    if led.frames_seen % FIX_ROTATION == 0 {
        led.session_epoch = led.session_epoch.wrapping_add(1);
    }
    if spool.deferred_digest.is_empty() {
        return;
    }
    let views = spool
        .deferred_digest
        .iter()
        .filter(|slot| slot.len > 0)
        .map(|slot| TagAnchorView {
            tag: slot.record_index,
            ptr: slot.ptr,
            len: slot.len,
            capture_generation: spool.compact_generation,
        })
        .collect();
    led.tag_seal = Some(RotatedFixSeal {
        views,
        spool_generation: spool.compact_generation,
        tag_count: spool.deferred_digest.len() as u32,
    });
}

pub fn reconcile_fix_tag_anchor() -> u32 {
    let led = ledger();
    let Some(seal) = &led.tag_seal else {
        return 0;
    };
    let mut acc = 0x0100_0193u32 ^ led.session_epoch ^ seal.spool_generation;
    for view in &seal.views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc.wrapping_add(view.tag ^ view.capture_generation);
    }
    acc ^ seal.tag_count
}
