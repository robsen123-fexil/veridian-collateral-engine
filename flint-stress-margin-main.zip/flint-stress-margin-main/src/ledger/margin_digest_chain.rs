use crate::engine::margin_staging::BatchSlotTable;
use crate::util::fnv1a::fnv1a32;
use crate::wire::batch_codec::BatchWireState;

#[derive(Debug, Clone, Copy)]
pub struct DeferredInternSlot {
    pub ptr: *const u8,
    pub arena_offset: u32,
    pub len: usize,
    pub batch_seq: u32,
    pub record_index: u32,
}

pub fn flush_intern_deferred_digest(slots: &[DeferredInternSlot], compact_generation: u32) -> u32 {
    let mut acc = 0x1465_0bc1u32 ^ compact_generation;
    for slot in slots {
        if slot.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(slot.ptr, slot.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc
            .wrapping_add(slot.record_index)
            .wrapping_add(slot.batch_seq);
    }
    acc
}

pub fn flush_batch_digest_from_table(table: &BatchSlotTable) -> u32 {
    let mut acc = 0x1465_0bc1u32;
    for slot in &table.slots {
        if slot.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(slot.ptr, slot.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc.wrapping_add(slot.record_index ^ table.capture_generation);
    }
    acc
}

pub fn flush_batch_digest_accumulator(state: &BatchWireState) -> u32 {
    let mut acc = 0x1465_0bc1u32;
    if state.digest_slots.is_empty() {
        for (idx, hdr) in state.headers.iter().enumerate() {
            if let Some(payload) = state.record_payload(idx) {
                acc = fnv1a32(acc, payload);
                let _ = hdr.portfolio_tag;
            }
        }
        return acc;
    }

    for slot in &state.digest_slots {
        if slot.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(slot.ptr, slot.len);
            acc = fnv1a32(acc, bytes);
        }
        acc = acc.wrapping_add(slot.record_index);
    }
    acc
}

pub fn link_margin_audit_chain(prev: u32, batch_digest: u32, checkpoint_id: u32) -> u32 {
    let mut buf = [0u8; 12];
    buf[0..4].copy_from_slice(&prev.to_le_bytes());
    buf[4..8].copy_from_slice(&batch_digest.to_le_bytes());
    buf[8..12].copy_from_slice(&checkpoint_id.to_le_bytes());
    fnv1a32(0, &buf)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::batch_codec::{BatchRecordHeader, BatchWireState};
    use crate::wire::magics::BATCH_VERSION;

    #[test]
    fn flush_without_slots() {
        let mut st = BatchWireState::default();
        st.version = BATCH_VERSION;
        st.headers.push(BatchRecordHeader {
            record_type: 1,
            flags: 0,
            payload_offset: 0,
            payload_len: 3,
            portfolio_tag: 1,
        });
        st.payload_blob = vec![1, 2, 3];
        let d = flush_batch_digest_accumulator(&st);
        assert_ne!(d, 0);
    }
}
