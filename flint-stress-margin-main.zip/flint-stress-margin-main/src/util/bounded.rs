//! Bounded wire read helpers for stress-margin wire frames.

pub const MAX_WIRE_FRAME: usize = 1_048_576;
pub const MAX_BATCH_RECORDS: usize = 4096;
pub const MAX_SCENARIO_NODES: usize = 256;
pub const MAX_SESSION_LEGS: usize = 512;
pub const MAX_FIX_FIELDS: usize = 128;
pub const MAX_ENVELOPE_DEPTH: usize = 32;

pub fn read_u16_le(buf: &[u8], offset: usize) -> Option<u16> {
    let s = slice_at(buf, offset, 2)?;
    Some(u16::from_le_bytes([s[0], s[1]]))
}

pub fn read_u32_le(buf: &[u8], offset: usize) -> Option<u32> {
    let s = slice_at(buf, offset, 4)?;
    Some(u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
}

pub fn read_i64_le(buf: &[u8], offset: usize) -> Option<i64> {
    let s = slice_at(buf, offset, 8)?;
    let mut arr = [0u8; 8];
    arr.copy_from_slice(s);
    Some(i64::from_le_bytes(arr))
}

pub fn slice_at<'a>(buf: &'a [u8], offset: usize, len: usize) -> Option<&'a [u8]> {
    if len > MAX_WIRE_FRAME {
        return None;
    }
    let end = offset.checked_add(len)?;
    buf.get(offset..end)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn read_le_fields() {
        let buf = [0x01, 0x00, 0x34, 0x12, 0x00, 0x00, 0x00, 0x00];
        assert_eq!(read_u16_le(&buf, 0), Some(1));
        assert_eq!(read_u32_le(&buf, 2), Some(0x1234));
    }
}
