//! FNV-1a digest for margin audit chains.

pub fn fnv1a32(seed: u32, data: &[u8]) -> u32 {
    let mut hash = seed;
    for &b in data {
        hash ^= u32::from(b);
        hash = hash.wrapping_mul(0x0100_0193);
    }
    hash
}

pub fn fnv1a64(seed: u64, data: &[u8]) -> u64 {
    let mut hash = seed;
    for &b in data {
        hash ^= u64::from(b);
        hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
    }
    hash
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fnv_nonzero() {
        assert_ne!(fnv1a32(0, b"margin"), 0);
    }
}
