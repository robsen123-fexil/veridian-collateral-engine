//! Length-prefixed multi-frame lifecycle wire parsing.

use crate::util::bounded::{read_u16_le, read_u32_le, slice_at, MAX_WIRE_FRAME};

pub const LIFECYCLE_VERSION: u16 = 1;
pub const MAX_LIFECYCLE_FRAMES: usize = 16;

pub const OP_INTERN: u16 = 0x0010;
pub const OP_COMPACT: u16 = 0x0020;
pub const OP_FLUSH: u16 = 0x0040;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LifecycleWireError {
    Truncated,
    BadMagic,
    BadVersion,
    TooManyFrames,
    FrameSize,
    TrailingBytes,
}

pub struct LifecycleFrame<'a> {
    pub op: u16,
    pub payload: &'a [u8],
}

pub fn parse_lifecycle_header(
    input: &[u8],
    magic: &[u8; 4],
) -> Result<(u16, u32), LifecycleWireError> {
    if input.len() < 10 {
        return Err(LifecycleWireError::Truncated);
    }
    if &input[..4] != magic {
        return Err(LifecycleWireError::BadMagic);
    }
    let version = read_u16_le(input, 4).ok_or(LifecycleWireError::Truncated)?;
    if version != LIFECYCLE_VERSION {
        return Err(LifecycleWireError::BadVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(LifecycleWireError::Truncated)?;
    Ok((version, frame_count))
}

pub fn walk_lifecycle_frames<'a>(
    input: &'a [u8],
    magic: &[u8; 4],
    mut f: impl FnMut(LifecycleFrame<'a>) -> Result<(), LifecycleWireError>,
) -> Result<u32, LifecycleWireError> {
    let (_, frame_count) = parse_lifecycle_header(input, magic)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(LifecycleWireError::TooManyFrames);
    }
    let mut offset = 10usize;
    let mut processed = 0u32;
    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(LifecycleWireError::Truncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len < 2 || frame_len > MAX_WIRE_FRAME {
            return Err(LifecycleWireError::FrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(LifecycleWireError::Truncated)?;
        offset = offset.saturating_add(frame_len);
        let op = read_u16_le(frame, 0).ok_or(LifecycleWireError::Truncated)?;
        let payload = frame.get(2..).unwrap_or(&[]);
        f(LifecycleFrame { op, payload })?;
        processed = processed.wrapping_add(1);
    }
    if offset != input.len() {
        return Err(LifecycleWireError::TrailingBytes);
    }
    Ok(processed)
}

pub fn wrap_lifecycle_frames(magic: &[u8; 4], frames: &[(u16, &[u8])]) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(magic);
    out.extend_from_slice(&LIFECYCLE_VERSION.to_le_bytes());
    out.extend_from_slice(&(frames.len() as u32).to_le_bytes());
    for (op, payload) in frames {
        let frame_len = 2u32 + payload.len() as u32;
        out.extend_from_slice(&frame_len.to_le_bytes());
        out.extend_from_slice(&op.to_le_bytes());
        out.extend_from_slice(payload);
    }
    out
}
