//! Flint Stress Margin — derivatives portfolio stress testing and margin aggregation.
//!
//! Wire codecs, scenario ingress, stress batch pipelines, and margin desk algorithms.

pub mod desk;
pub mod engine;
pub mod ingress;
pub mod ledger;
pub mod util;
pub mod wire;

pub use engine::fix_margin_pipeline::run_fix_margin_pipeline;
pub use engine::mt940_collateral_pipeline::run_mt940_collateral_pipeline;
pub use engine::stress_pipeline::{merge_portfolio_sessions, run_stress_batch_pipeline};
pub use ingress::dispatch::{dispatch_wire_bytes, process_ingress_stream};
pub use wire::fix_parser::parse_fix_message;
pub use wire::swift_mt940::fsm_parse_mt940 as parse_mt940_statement;
