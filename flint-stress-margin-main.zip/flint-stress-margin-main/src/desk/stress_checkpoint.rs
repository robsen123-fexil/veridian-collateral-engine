use crate::wire::batch_codec::BatchWireState;

pub fn record_stress_checkpoint(state: &BatchWireState, sweep_total: i64) {
    let _ = (state.record_count, sweep_total);
}
