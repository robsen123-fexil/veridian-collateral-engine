//! FX delta netting across currency pairs

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmFxDeltaNetterCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmFxDeltaNetter {
    pub cells: Vec<FsmFxDeltaNetterCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmFxDeltaNetter {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmFxDeltaNetterCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_fx_delta_netter_evaluate(desk: &FsmFxDeltaNetter, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_fx_delta_netter_usdeur(long_minor: i64, short_minor: i64) -> i64 {
    long_minor.saturating_add(short_minor).saturating_mul(108) / 100
}

pub fn fsm_fx_delta_netter_usdgbp(long_minor: i64, short_minor: i64) -> i64 {
    long_minor.saturating_add(short_minor).saturating_mul(108) / 100
}

pub fn fsm_fx_delta_netter_usdjpy(long_minor: i64, short_minor: i64) -> i64 {
    long_minor.saturating_add(short_minor).saturating_mul(108) / 100
}

pub fn fsm_fx_delta_netter_eurgbp(long_minor: i64, short_minor: i64) -> i64 {
    long_minor.saturating_add(short_minor).saturating_mul(108) / 100
}

pub fn fsm_fx_delta_netter_eurjpy(long_minor: i64, short_minor: i64) -> i64 {
    long_minor.saturating_add(short_minor).saturating_mul(108) / 100
}

pub fn fsm_fx_delta_netter_gbpjpy(long_minor: i64, short_minor: i64) -> i64 {
    long_minor.saturating_add(short_minor).saturating_mul(108) / 100
}

pub fn fsm_fx_delta_netter_pair_00(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (1)
}

pub fn fsm_fx_delta_netter_pair_01(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (2)
}

pub fn fsm_fx_delta_netter_pair_02(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (3)
}

pub fn fsm_fx_delta_netter_pair_03(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (4)
}

pub fn fsm_fx_delta_netter_pair_04(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (5)
}

pub fn fsm_fx_delta_netter_pair_05(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (1)
}

pub fn fsm_fx_delta_netter_pair_06(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (2)
}

pub fn fsm_fx_delta_netter_pair_07(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (3)
}

pub fn fsm_fx_delta_netter_pair_08(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (4)
}

pub fn fsm_fx_delta_netter_pair_09(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (5)
}

pub fn fsm_fx_delta_netter_pair_10(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (1)
}

pub fn fsm_fx_delta_netter_pair_11(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (2)
}

pub fn fsm_fx_delta_netter_pair_12(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (3)
}

pub fn fsm_fx_delta_netter_pair_13(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (4)
}

pub fn fsm_fx_delta_netter_pair_14(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (5)
}

pub fn fsm_fx_delta_netter_pair_15(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (1)
}

pub fn fsm_fx_delta_netter_pair_16(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (2)
}

pub fn fsm_fx_delta_netter_pair_17(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (3)
}

pub fn fsm_fx_delta_netter_pair_18(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (4)
}

pub fn fsm_fx_delta_netter_pair_19(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (5)
}

pub fn fsm_fx_delta_netter_pair_20(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (1)
}

pub fn fsm_fx_delta_netter_pair_21(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (2)
}

pub fn fsm_fx_delta_netter_pair_22(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (3)
}

pub fn fsm_fx_delta_netter_pair_23(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (4)
}

pub fn fsm_fx_delta_netter_pair_24(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (5)
}

pub fn fsm_fx_delta_netter_pair_25(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (1)
}

pub fn fsm_fx_delta_netter_pair_26(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (2)
}

pub fn fsm_fx_delta_netter_pair_27(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (3)
}

pub fn fsm_fx_delta_netter_pair_28(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (4)
}

pub fn fsm_fx_delta_netter_pair_29(a: i64, b: i64, c: i64) -> i64 {
    a.saturating_sub(b).saturating_add(c) / (5)
}
