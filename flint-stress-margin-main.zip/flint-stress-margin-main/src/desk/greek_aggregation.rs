//! Cross-book Greek aggregation with bucket netting.

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmGreekLeg {
    pub delta: i64,
    pub gamma: i64,
    pub vega: i64,
    pub theta: i64,
    pub rho: i64,
}

#[derive(Debug, Default, Clone)]
pub struct FsmGreekBook {
    pub legs: Vec<(u32, FsmGreekLeg)>,
    pub ccy: u16,
}

impl FsmGreekBook {
    pub fn net_delta(&self) -> i64 {
        self.legs.iter().map(|(_, g)| g.delta).sum()
    }

    pub fn net_gamma(&self) -> i64 {
        self.legs.iter().map(|(_, g)| g.gamma).sum()
    }

    pub fn absorb(&mut self, trade_id: u32, leg: FsmGreekLeg) {
        self.legs.push((trade_id, leg));
    }
}

pub fn fsm_merge_greek_books(a: &FsmGreekBook, b: &FsmGreekBook) -> FsmGreekBook {
    let mut out = a.clone();
    for (tid, leg) in &b.legs {
        out.absorb(*tid, *leg);
    }
    out
}

pub fn fsm_greek_bucket_00(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (1);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (5);
    let t = -(2 as i64);
    let r = (0 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_01(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (2);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (8);
    let t = -(3 as i64);
    let r = (1 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_02(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (3);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (11);
    let t = -(4 as i64);
    let r = (2 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_03(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (4);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (14);
    let t = -(5 as i64);
    let r = (3 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_04(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (5);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (17);
    let t = -(6 as i64);
    let r = (4 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_05(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (6);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (20);
    let t = -(7 as i64);
    let r = (5 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_06(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (7);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (23);
    let t = -(8 as i64);
    let r = (6 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_07(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (8);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (26);
    let t = -(9 as i64);
    let r = (7 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_08(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (9);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (29);
    let t = -(10 as i64);
    let r = (8 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_09(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (10);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (32);
    let t = -(11 as i64);
    let r = (9 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_10(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (11);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (35);
    let t = -(12 as i64);
    let r = (10 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_11(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (12);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (38);
    let t = -(13 as i64);
    let r = (11 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_12(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (13);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (41);
    let t = -(14 as i64);
    let r = (12 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_13(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (14);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (44);
    let t = -(15 as i64);
    let r = (13 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_14(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (15);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (47);
    let t = -(16 as i64);
    let r = (14 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_15(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (16);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (50);
    let t = -(17 as i64);
    let r = (15 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_16(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (17);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (53);
    let t = -(18 as i64);
    let r = (16 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_17(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (18);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (56);
    let t = -(19 as i64);
    let r = (17 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_18(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (19);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (59);
    let t = -(20 as i64);
    let r = (18 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_19(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (20);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (62);
    let t = -(21 as i64);
    let r = (19 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_20(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (21);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (65);
    let t = -(22 as i64);
    let r = (20 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_21(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (22);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (68);
    let t = -(23 as i64);
    let r = (21 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_22(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (23);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (71);
    let t = -(24 as i64);
    let r = (22 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_23(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (24);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (74);
    let t = -(25 as i64);
    let r = (23 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_24(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (25);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (77);
    let t = -(26 as i64);
    let r = (24 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_25(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (26);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (80);
    let t = -(27 as i64);
    let r = (25 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_26(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (27);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (83);
    let t = -(28 as i64);
    let r = (26 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_27(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (28);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (86);
    let t = -(29 as i64);
    let r = (27 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_28(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (29);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (89);
    let t = -(30 as i64);
    let r = (28 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_29(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (30);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (92);
    let t = -(31 as i64);
    let r = (29 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_30(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (31);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (95);
    let t = -(32 as i64);
    let r = (30 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_greek_bucket_31(spot_shift_bps: i32, vol_shift_bps: i32) -> FsmGreekLeg {
    let d = (spot_shift_bps as i64) * (32);
    let g = (spot_shift_bps as i64).saturating_mul(spot_shift_bps as i64) / 10_000;
    let v = (vol_shift_bps as i64) * (98);
    let t = -(33 as i64);
    let r = (31 as i64) * 11;
    FsmGreekLeg { delta: d, gamma: g, vega: v, theta: t, rho: r }
}

pub fn fsm_stress_greeks(book: &FsmGreekBook, spot_bps: i32, vol_bps: i32) -> FsmGreekLeg {
    let d = book.net_delta().saturating_mul(100 + spot_bps as i64) / 100;
    let g = book.net_gamma().saturating_mul(100 + vol_bps as i64) / 100;
    FsmGreekLeg { delta: d, gamma: g, vega: 0, theta: 0, rho: 0 }
}
