use crate::wire::batch_codec::BatchWireState;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SweepError {
    EmptyBatch,
}

pub fn apply_batch_margin_sweeps(state: &BatchWireState) -> Result<i64, SweepError> {
    if state.headers.is_empty() {
        return Err(SweepError::EmptyBatch);
    }
    let mut total: i64 = 0;
    for (idx, hdr) in state.headers.iter().enumerate() {
        let notional = i64::from(hdr.portfolio_tag) * i64::from(hdr.record_type);
        if let Some(payload) = state.record_payload(idx) {
            let shock = payload.iter().map(|b| i64::from(*b)).sum::<i64>();
            total = total.saturating_add(notional.saturating_add(shock));
        } else {
            total = total.saturating_add(notional);
        }
    }
    Ok(total)
}
