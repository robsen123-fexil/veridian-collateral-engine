//! Collateral haircut engine with asset-class grids.

#[derive(Debug, Clone, Copy)]
pub struct FsmHaircutBand { pub asset_class: u8, pub rating_bucket: u8, pub tenor_days: u16, pub haircut_bps: u32 }

pub const FSM_HAIRCUT_TABLE: &[FsmHaircutBand] = &[
    FsmHaircutBand { asset_class: 0, rating_bucket: 0, tenor_days: 30, haircut_bps: 200 },
    FsmHaircutBand { asset_class: 0, rating_bucket: 1, tenor_days: 30, haircut_bps: 280 },
    FsmHaircutBand { asset_class: 0, rating_bucket: 2, tenor_days: 30, haircut_bps: 360 },
    FsmHaircutBand { asset_class: 0, rating_bucket: 3, tenor_days: 30, haircut_bps: 440 },
    FsmHaircutBand { asset_class: 0, rating_bucket: 4, tenor_days: 30, haircut_bps: 520 },
    FsmHaircutBand { asset_class: 1, rating_bucket: 0, tenor_days: 45, haircut_bps: 235 },
    FsmHaircutBand { asset_class: 1, rating_bucket: 1, tenor_days: 45, haircut_bps: 315 },
    FsmHaircutBand { asset_class: 1, rating_bucket: 2, tenor_days: 45, haircut_bps: 395 },
    FsmHaircutBand { asset_class: 1, rating_bucket: 3, tenor_days: 45, haircut_bps: 475 },
    FsmHaircutBand { asset_class: 1, rating_bucket: 4, tenor_days: 45, haircut_bps: 555 },
    FsmHaircutBand { asset_class: 2, rating_bucket: 0, tenor_days: 60, haircut_bps: 270 },
    FsmHaircutBand { asset_class: 2, rating_bucket: 1, tenor_days: 60, haircut_bps: 350 },
    FsmHaircutBand { asset_class: 2, rating_bucket: 2, tenor_days: 60, haircut_bps: 430 },
    FsmHaircutBand { asset_class: 2, rating_bucket: 3, tenor_days: 60, haircut_bps: 510 },
    FsmHaircutBand { asset_class: 2, rating_bucket: 4, tenor_days: 60, haircut_bps: 590 },
    FsmHaircutBand { asset_class: 3, rating_bucket: 0, tenor_days: 75, haircut_bps: 305 },
    FsmHaircutBand { asset_class: 3, rating_bucket: 1, tenor_days: 75, haircut_bps: 385 },
    FsmHaircutBand { asset_class: 3, rating_bucket: 2, tenor_days: 75, haircut_bps: 465 },
    FsmHaircutBand { asset_class: 3, rating_bucket: 3, tenor_days: 75, haircut_bps: 545 },
    FsmHaircutBand { asset_class: 3, rating_bucket: 4, tenor_days: 75, haircut_bps: 625 },
    FsmHaircutBand { asset_class: 4, rating_bucket: 0, tenor_days: 90, haircut_bps: 340 },
    FsmHaircutBand { asset_class: 4, rating_bucket: 1, tenor_days: 90, haircut_bps: 420 },
    FsmHaircutBand { asset_class: 4, rating_bucket: 2, tenor_days: 90, haircut_bps: 500 },
    FsmHaircutBand { asset_class: 4, rating_bucket: 3, tenor_days: 90, haircut_bps: 580 },
    FsmHaircutBand { asset_class: 4, rating_bucket: 4, tenor_days: 90, haircut_bps: 660 },
    FsmHaircutBand { asset_class: 5, rating_bucket: 0, tenor_days: 105, haircut_bps: 375 },
    FsmHaircutBand { asset_class: 5, rating_bucket: 1, tenor_days: 105, haircut_bps: 455 },
    FsmHaircutBand { asset_class: 5, rating_bucket: 2, tenor_days: 105, haircut_bps: 535 },
    FsmHaircutBand { asset_class: 5, rating_bucket: 3, tenor_days: 105, haircut_bps: 615 },
    FsmHaircutBand { asset_class: 5, rating_bucket: 4, tenor_days: 105, haircut_bps: 695 },
    FsmHaircutBand { asset_class: 6, rating_bucket: 0, tenor_days: 120, haircut_bps: 410 },
    FsmHaircutBand { asset_class: 6, rating_bucket: 1, tenor_days: 120, haircut_bps: 490 },
    FsmHaircutBand { asset_class: 6, rating_bucket: 2, tenor_days: 120, haircut_bps: 570 },
    FsmHaircutBand { asset_class: 6, rating_bucket: 3, tenor_days: 120, haircut_bps: 650 },
    FsmHaircutBand { asset_class: 6, rating_bucket: 4, tenor_days: 120, haircut_bps: 730 },
    FsmHaircutBand { asset_class: 7, rating_bucket: 0, tenor_days: 135, haircut_bps: 445 },
    FsmHaircutBand { asset_class: 7, rating_bucket: 1, tenor_days: 135, haircut_bps: 525 },
    FsmHaircutBand { asset_class: 7, rating_bucket: 2, tenor_days: 135, haircut_bps: 605 },
    FsmHaircutBand { asset_class: 7, rating_bucket: 3, tenor_days: 135, haircut_bps: 685 },
    FsmHaircutBand { asset_class: 7, rating_bucket: 4, tenor_days: 135, haircut_bps: 765 },
    FsmHaircutBand { asset_class: 8, rating_bucket: 0, tenor_days: 150, haircut_bps: 480 },
    FsmHaircutBand { asset_class: 8, rating_bucket: 1, tenor_days: 150, haircut_bps: 560 },
    FsmHaircutBand { asset_class: 8, rating_bucket: 2, tenor_days: 150, haircut_bps: 640 },
    FsmHaircutBand { asset_class: 8, rating_bucket: 3, tenor_days: 150, haircut_bps: 720 },
    FsmHaircutBand { asset_class: 8, rating_bucket: 4, tenor_days: 150, haircut_bps: 800 },
    FsmHaircutBand { asset_class: 9, rating_bucket: 0, tenor_days: 165, haircut_bps: 515 },
    FsmHaircutBand { asset_class: 9, rating_bucket: 1, tenor_days: 165, haircut_bps: 595 },
    FsmHaircutBand { asset_class: 9, rating_bucket: 2, tenor_days: 165, haircut_bps: 675 },
    FsmHaircutBand { asset_class: 9, rating_bucket: 3, tenor_days: 165, haircut_bps: 755 },
    FsmHaircutBand { asset_class: 9, rating_bucket: 4, tenor_days: 165, haircut_bps: 835 },
    FsmHaircutBand { asset_class: 10, rating_bucket: 0, tenor_days: 180, haircut_bps: 550 },
    FsmHaircutBand { asset_class: 10, rating_bucket: 1, tenor_days: 180, haircut_bps: 630 },
    FsmHaircutBand { asset_class: 10, rating_bucket: 2, tenor_days: 180, haircut_bps: 710 },
    FsmHaircutBand { asset_class: 10, rating_bucket: 3, tenor_days: 180, haircut_bps: 790 },
    FsmHaircutBand { asset_class: 10, rating_bucket: 4, tenor_days: 180, haircut_bps: 870 },
    FsmHaircutBand { asset_class: 11, rating_bucket: 0, tenor_days: 195, haircut_bps: 585 },
    FsmHaircutBand { asset_class: 11, rating_bucket: 1, tenor_days: 195, haircut_bps: 665 },
    FsmHaircutBand { asset_class: 11, rating_bucket: 2, tenor_days: 195, haircut_bps: 745 },
    FsmHaircutBand { asset_class: 11, rating_bucket: 3, tenor_days: 195, haircut_bps: 825 },
    FsmHaircutBand { asset_class: 11, rating_bucket: 4, tenor_days: 195, haircut_bps: 905 },
];

pub fn fsm_lookup_haircut(asset_class: u8, rating: u8, tenor_days: u16) -> u32 {
    FSM_HAIRCUT_TABLE.iter()
        .find(|b| b.asset_class == asset_class && b.rating_bucket == rating && b.tenor_days <= tenor_days)
        .map(|b| b.haircut_bps).unwrap_or(5_000)
}

pub fn fsm_apply_haircut(notional_minor: i64, haircut_bps: u32) -> i64 {
    notional_minor - (notional_minor.abs() * haircut_bps as i64 / 10_000)
}

pub fn fsm_haircut_stress_overlay_00(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((0 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_01(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((1 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_02(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((2 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_03(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((3 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_04(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((4 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_05(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((5 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_06(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((6 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_07(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((7 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_08(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((8 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_09(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((9 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_10(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((10 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_11(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((11 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_12(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((12 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_13(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((13 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_14(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((14 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_15(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((15 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_16(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((16 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_17(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((17 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_18(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((18 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_19(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((19 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_20(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((20 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_21(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((21 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_22(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((22 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_23(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((23 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_24(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((24 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_25(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((25 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_26(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((26 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_27(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((27 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_28(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((28 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_29(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((29 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_30(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((30 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_31(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((31 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_32(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((32 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_33(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((33 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_34(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((34 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_35(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((35 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_36(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((36 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_37(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((37 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_38(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((38 % 7 + 1) * liquidity_score / 100).min(9_500)
}

pub fn fsm_haircut_stress_overlay_39(base_bps: u32, liquidity_score: u32) -> u32 {
    base_bps.saturating_add((39 % 7 + 1) * liquidity_score / 100).min(9_500)
}
