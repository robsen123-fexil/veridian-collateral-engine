//! Historical-simulation VaR grid for multi-tenor derivative books.

#[derive(Debug, Clone, Copy)]
pub struct FsmVarCell {
    pub tenor_days: u16,
    pub confidence_bps: u16,
    pub loss_minor: i64,
    pub observation_count: u32,
}

#[derive(Debug, Default, Clone)]
pub struct FsmVarGrid {
    pub cells: Vec<FsmVarCell>,
    pub portfolio_id: u32,
    pub as_of_seq: u64,
}

impl FsmVarGrid {
    pub fn new(portfolio_id: u32) -> Self {
        Self { cells: Vec::new(), portfolio_id, as_of_seq: 0 }
    }

    pub fn push_return(&mut self, tenor_days: u16, confidence_bps: u16, pnl_minor: i64) {
        if let Some(cell) = self.cells.iter_mut().find(|c| c.tenor_days == tenor_days && c.confidence_bps == confidence_bps) {
            cell.observation_count += 1;
            if pnl_minor < cell.loss_minor {
                cell.loss_minor = pnl_minor;
            }
        } else {
            self.cells.push(FsmVarCell {
                tenor_days,
                confidence_bps,
                loss_minor: pnl_minor,
                observation_count: 1,
            });
        }
    }

    pub fn rank_worst(&self, tenor_days: u16, rank: usize) -> Option<i64> {
        let mut losses: Vec<i64> = self.cells.iter()
            .filter(|c| c.tenor_days == tenor_days)
            .map(|c| c.loss_minor)
            .collect();
        if losses.is_empty() { return None; }
        losses.sort_unstable();
        losses.get(rank).copied()
    }
}

pub fn fsm_var_grid_from_pnl_series(portfolio_id: u32, series: &[(u16, i64)]) -> FsmVarGrid {
    let mut grid = FsmVarGrid::new(portfolio_id);
    for (tenor, pnl) in series {
        grid.push_return(*tenor, 9_900, *pnl);
        grid.push_return(*tenor, 9_950, *pnl);
        grid.push_return(*tenor, 9_990, *pnl);
    }
    grid.as_of_seq = series.len() as u64;
    grid
}

pub fn fsm_var_floor_t1_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (1 as i64)
}

pub fn fsm_var_floor_t1_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (1 as i64)
}

pub fn fsm_var_floor_t1_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (1 as i64)
}

pub fn fsm_var_floor_t1_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (1 as i64)
}

pub fn fsm_var_floor_t5_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (5 as i64)
}

pub fn fsm_var_floor_t5_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (5 as i64)
}

pub fn fsm_var_floor_t5_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (5 as i64)
}

pub fn fsm_var_floor_t5_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (5 as i64)
}

pub fn fsm_var_floor_t10_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (10 as i64)
}

pub fn fsm_var_floor_t10_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (10 as i64)
}

pub fn fsm_var_floor_t10_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (10 as i64)
}

pub fn fsm_var_floor_t10_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (10 as i64)
}

pub fn fsm_var_floor_t21_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (21 as i64)
}

pub fn fsm_var_floor_t21_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (21 as i64)
}

pub fn fsm_var_floor_t21_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (21 as i64)
}

pub fn fsm_var_floor_t21_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (21 as i64)
}

pub fn fsm_var_floor_t63_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (63 as i64)
}

pub fn fsm_var_floor_t63_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (63 as i64)
}

pub fn fsm_var_floor_t63_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (63 as i64)
}

pub fn fsm_var_floor_t63_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (63 as i64)
}

pub fn fsm_var_floor_t126_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (126 as i64)
}

pub fn fsm_var_floor_t126_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (126 as i64)
}

pub fn fsm_var_floor_t126_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (126 as i64)
}

pub fn fsm_var_floor_t126_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (126 as i64)
}

pub fn fsm_var_floor_t252_c9500(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9500 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (252 as i64)
}

pub fn fsm_var_floor_t252_c9750(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9750 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (252 as i64)
}

pub fn fsm_var_floor_t252_c9900(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9900 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (252 as i64)
}

pub fn fsm_var_floor_t252_c9950(notional_minor: i64, vol_bps: u32) -> i64 {
    let z = match 9950 {
        9500 => 164,
        9750 => 196,
        9900 => 233,
        9950 => 257,
        _ => 150,
    };
    let sigma = (notional_minor.abs() * vol_bps as i64) / 10_000;
    -(sigma * z / 100) - (252 as i64)
}

pub fn fsm_aggregate_var_cells(cells: &[FsmVarCell]) -> i64 {
    cells.iter().map(|c| c.loss_minor).min().unwrap_or(0)
}
