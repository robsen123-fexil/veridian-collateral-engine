//! Delta ladder by maturity bucket

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmDeltaLadderBuilderCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmDeltaLadderBuilder {
    pub cells: Vec<FsmDeltaLadderBuilderCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmDeltaLadderBuilder {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmDeltaLadderBuilderCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_delta_ladder_builder_evaluate(desk: &FsmDeltaLadderBuilder, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_delta_ladder_builder_rung_00(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (1)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_01(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (2)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_02(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (3)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_03(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (4)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_04(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (5)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_05(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (6)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_06(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (7)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_07(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (8)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_08(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (9)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_09(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (10)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_10(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (11)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_11(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (12)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_12(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (13)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_13(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (14)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_14(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (15)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_15(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (16)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_16(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (17)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_17(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (18)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_18(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (19)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_19(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (20)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_20(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (21)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_21(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (22)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_22(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (23)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_23(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (24)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_24(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (25)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_25(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (26)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_26(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (27)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_27(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (28)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_28(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (29)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_29(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (30)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_30(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (31)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_31(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (32)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_32(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (33)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_33(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (34)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_34(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (35)) / 10_000
}

pub fn fsm_delta_ladder_builder_rung_35(dv01: i64, shift_bps: i32) -> i64 {
    dv01.saturating_mul(shift_bps as i64 * (36)) / 10_000
}
