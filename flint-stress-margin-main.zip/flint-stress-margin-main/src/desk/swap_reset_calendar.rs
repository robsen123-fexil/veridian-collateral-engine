//! Swap reset date calendar

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmSwapResetCalendarCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmSwapResetCalendar {
    pub cells: Vec<FsmSwapResetCalendarCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmSwapResetCalendar {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmSwapResetCalendarCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_swap_reset_calendar_evaluate(desk: &FsmSwapResetCalendar, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_swap_reset_calendar_day_00(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(1) / 60
}

pub fn fsm_swap_reset_calendar_day_01(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(2) / 60
}

pub fn fsm_swap_reset_calendar_day_02(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(3) / 60
}

pub fn fsm_swap_reset_calendar_day_03(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(4) / 60
}

pub fn fsm_swap_reset_calendar_day_04(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(5) / 60
}

pub fn fsm_swap_reset_calendar_day_05(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(6) / 60
}

pub fn fsm_swap_reset_calendar_day_06(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(7) / 60
}

pub fn fsm_swap_reset_calendar_day_07(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(8) / 60
}

pub fn fsm_swap_reset_calendar_day_08(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(9) / 60
}

pub fn fsm_swap_reset_calendar_day_09(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(10) / 60
}

pub fn fsm_swap_reset_calendar_day_10(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(11) / 60
}

pub fn fsm_swap_reset_calendar_day_11(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(12) / 60
}

pub fn fsm_swap_reset_calendar_day_12(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(13) / 60
}

pub fn fsm_swap_reset_calendar_day_13(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(14) / 60
}

pub fn fsm_swap_reset_calendar_day_14(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(15) / 60
}

pub fn fsm_swap_reset_calendar_day_15(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(16) / 60
}

pub fn fsm_swap_reset_calendar_day_16(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(17) / 60
}

pub fn fsm_swap_reset_calendar_day_17(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(18) / 60
}

pub fn fsm_swap_reset_calendar_day_18(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(19) / 60
}

pub fn fsm_swap_reset_calendar_day_19(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(20) / 60
}

pub fn fsm_swap_reset_calendar_day_20(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(21) / 60
}

pub fn fsm_swap_reset_calendar_day_21(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(22) / 60
}

pub fn fsm_swap_reset_calendar_day_22(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(23) / 60
}

pub fn fsm_swap_reset_calendar_day_23(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(24) / 60
}

pub fn fsm_swap_reset_calendar_day_24(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(25) / 60
}

pub fn fsm_swap_reset_calendar_day_25(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(26) / 60
}

pub fn fsm_swap_reset_calendar_day_26(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(27) / 60
}

pub fn fsm_swap_reset_calendar_day_27(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(28) / 60
}

pub fn fsm_swap_reset_calendar_day_28(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(29) / 60
}

pub fn fsm_swap_reset_calendar_day_29(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(30) / 60
}

pub fn fsm_swap_reset_calendar_day_30(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(31) / 60
}

pub fn fsm_swap_reset_calendar_day_31(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(32) / 60
}

pub fn fsm_swap_reset_calendar_day_32(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(33) / 60
}

pub fn fsm_swap_reset_calendar_day_33(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(34) / 60
}

pub fn fsm_swap_reset_calendar_day_34(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(35) / 60
}

pub fn fsm_swap_reset_calendar_day_35(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(36) / 60
}

pub fn fsm_swap_reset_calendar_day_36(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(37) / 60
}

pub fn fsm_swap_reset_calendar_day_37(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(38) / 60
}

pub fn fsm_swap_reset_calendar_day_38(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(39) / 60
}

pub fn fsm_swap_reset_calendar_day_39(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(40) / 60
}

pub fn fsm_swap_reset_calendar_day_40(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(41) / 60
}

pub fn fsm_swap_reset_calendar_day_41(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(42) / 60
}

pub fn fsm_swap_reset_calendar_day_42(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(43) / 60
}

pub fn fsm_swap_reset_calendar_day_43(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(44) / 60
}

pub fn fsm_swap_reset_calendar_day_44(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(45) / 60
}

pub fn fsm_swap_reset_calendar_day_45(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(46) / 60
}

pub fn fsm_swap_reset_calendar_day_46(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(47) / 60
}

pub fn fsm_swap_reset_calendar_day_47(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(48) / 60
}

pub fn fsm_swap_reset_calendar_day_48(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(49) / 60
}

pub fn fsm_swap_reset_calendar_day_49(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(50) / 60
}

pub fn fsm_swap_reset_calendar_day_50(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(51) / 60
}

pub fn fsm_swap_reset_calendar_day_51(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(52) / 60
}

pub fn fsm_swap_reset_calendar_day_52(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(53) / 60
}

pub fn fsm_swap_reset_calendar_day_53(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(54) / 60
}

pub fn fsm_swap_reset_calendar_day_54(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(55) / 60
}

pub fn fsm_swap_reset_calendar_day_55(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(56) / 60
}

pub fn fsm_swap_reset_calendar_day_56(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(57) / 60
}

pub fn fsm_swap_reset_calendar_day_57(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(58) / 60
}

pub fn fsm_swap_reset_calendar_day_58(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(59) / 60
}

pub fn fsm_swap_reset_calendar_day_59(notional: i64, fix_rate_bps: u32) -> i64 {
    let accrual = notional * fix_rate_bps as i64 / 36_500;
    accrual.saturating_mul(60) / 60
}
