//! Commodity basis risk grid

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmCommodityBasisGridCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmCommodityBasisGrid {
    pub cells: Vec<FsmCommodityBasisGridCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmCommodityBasisGrid {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmCommodityBasisGridCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_commodity_basis_grid_evaluate(desk: &FsmCommodityBasisGrid, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_commodity_basis_grid_band_00(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(90) / 100 + (0 as i64)
}

pub fn fsm_commodity_basis_grid_band_01(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(97) / 100 + (1 as i64)
}

pub fn fsm_commodity_basis_grid_band_02(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(14) / 100 + (2 as i64)
}

pub fn fsm_commodity_basis_grid_band_03(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(21) / 100 + (3 as i64)
}

pub fn fsm_commodity_basis_grid_band_04(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(28) / 100 + (4 as i64)
}

pub fn fsm_commodity_basis_grid_band_05(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(35) / 100 + (5 as i64)
}

pub fn fsm_commodity_basis_grid_band_06(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(42) / 100 + (6 as i64)
}

pub fn fsm_commodity_basis_grid_band_07(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(49) / 100 + (7 as i64)
}

pub fn fsm_commodity_basis_grid_band_08(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(56) / 100 + (8 as i64)
}

pub fn fsm_commodity_basis_grid_band_09(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(63) / 100 + (9 as i64)
}

pub fn fsm_commodity_basis_grid_band_10(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(70) / 100 + (10 as i64)
}

pub fn fsm_commodity_basis_grid_band_11(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(77) / 100 + (11 as i64)
}

pub fn fsm_commodity_basis_grid_band_12(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(84) / 100 + (12 as i64)
}

pub fn fsm_commodity_basis_grid_band_13(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(91) / 100 + (13 as i64)
}

pub fn fsm_commodity_basis_grid_band_14(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(98) / 100 + (14 as i64)
}

pub fn fsm_commodity_basis_grid_band_15(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(15) / 100 + (15 as i64)
}

pub fn fsm_commodity_basis_grid_band_16(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(22) / 100 + (16 as i64)
}

pub fn fsm_commodity_basis_grid_band_17(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(29) / 100 + (17 as i64)
}

pub fn fsm_commodity_basis_grid_band_18(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(36) / 100 + (18 as i64)
}

pub fn fsm_commodity_basis_grid_band_19(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(43) / 100 + (19 as i64)
}

pub fn fsm_commodity_basis_grid_band_20(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(50) / 100 + (20 as i64)
}

pub fn fsm_commodity_basis_grid_band_21(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(57) / 100 + (21 as i64)
}

pub fn fsm_commodity_basis_grid_band_22(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(64) / 100 + (22 as i64)
}

pub fn fsm_commodity_basis_grid_band_23(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(71) / 100 + (23 as i64)
}

pub fn fsm_commodity_basis_grid_band_24(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(78) / 100 + (24 as i64)
}

pub fn fsm_commodity_basis_grid_band_25(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(85) / 100 + (25 as i64)
}

pub fn fsm_commodity_basis_grid_band_26(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(92) / 100 + (26 as i64)
}

pub fn fsm_commodity_basis_grid_band_27(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(99) / 100 + (27 as i64)
}

pub fn fsm_commodity_basis_grid_band_28(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(16) / 100 + (28 as i64)
}

pub fn fsm_commodity_basis_grid_band_29(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(23) / 100 + (29 as i64)
}

pub fn fsm_commodity_basis_grid_band_30(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(30) / 100 + (30 as i64)
}

pub fn fsm_commodity_basis_grid_band_31(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(37) / 100 + (31 as i64)
}

pub fn fsm_commodity_basis_grid_band_32(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(44) / 100 + (32 as i64)
}

pub fn fsm_commodity_basis_grid_band_33(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(51) / 100 + (33 as i64)
}

pub fn fsm_commodity_basis_grid_band_34(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(58) / 100 + (34 as i64)
}

pub fn fsm_commodity_basis_grid_band_35(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(65) / 100 + (35 as i64)
}

pub fn fsm_commodity_basis_grid_band_36(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(72) / 100 + (36 as i64)
}

pub fn fsm_commodity_basis_grid_band_37(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(79) / 100 + (37 as i64)
}

pub fn fsm_commodity_basis_grid_band_38(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(86) / 100 + (38 as i64)
}

pub fn fsm_commodity_basis_grid_band_39(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(93) / 100 + (39 as i64)
}

pub fn fsm_commodity_basis_grid_band_40(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(10) / 100 + (40 as i64)
}

pub fn fsm_commodity_basis_grid_band_41(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(17) / 100 + (41 as i64)
}

pub fn fsm_commodity_basis_grid_band_42(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(24) / 100 + (42 as i64)
}

pub fn fsm_commodity_basis_grid_band_43(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(31) / 100 + (43 as i64)
}

pub fn fsm_commodity_basis_grid_band_44(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(38) / 100 + (44 as i64)
}
