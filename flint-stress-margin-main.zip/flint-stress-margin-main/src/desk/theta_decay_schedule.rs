//! Theta decay accrual schedule

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmThetaDecayScheduleCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmThetaDecaySchedule {
    pub cells: Vec<FsmThetaDecayScheduleCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmThetaDecaySchedule {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmThetaDecayScheduleCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_theta_decay_schedule_evaluate(desk: &FsmThetaDecaySchedule, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_theta_decay_schedule_band_00(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(45) / 100 + (0 as i64)
}

pub fn fsm_theta_decay_schedule_band_01(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(52) / 100 + (1 as i64)
}

pub fn fsm_theta_decay_schedule_band_02(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(59) / 100 + (2 as i64)
}

pub fn fsm_theta_decay_schedule_band_03(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(66) / 100 + (3 as i64)
}

pub fn fsm_theta_decay_schedule_band_04(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(73) / 100 + (4 as i64)
}

pub fn fsm_theta_decay_schedule_band_05(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(80) / 100 + (5 as i64)
}

pub fn fsm_theta_decay_schedule_band_06(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(87) / 100 + (6 as i64)
}

pub fn fsm_theta_decay_schedule_band_07(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(94) / 100 + (7 as i64)
}

pub fn fsm_theta_decay_schedule_band_08(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(11) / 100 + (8 as i64)
}

pub fn fsm_theta_decay_schedule_band_09(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(18) / 100 + (9 as i64)
}

pub fn fsm_theta_decay_schedule_band_10(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(25) / 100 + (10 as i64)
}

pub fn fsm_theta_decay_schedule_band_11(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(32) / 100 + (11 as i64)
}

pub fn fsm_theta_decay_schedule_band_12(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(39) / 100 + (12 as i64)
}

pub fn fsm_theta_decay_schedule_band_13(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(46) / 100 + (13 as i64)
}

pub fn fsm_theta_decay_schedule_band_14(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(53) / 100 + (14 as i64)
}

pub fn fsm_theta_decay_schedule_band_15(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(60) / 100 + (15 as i64)
}

pub fn fsm_theta_decay_schedule_band_16(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(67) / 100 + (16 as i64)
}

pub fn fsm_theta_decay_schedule_band_17(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(74) / 100 + (17 as i64)
}

pub fn fsm_theta_decay_schedule_band_18(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(81) / 100 + (18 as i64)
}

pub fn fsm_theta_decay_schedule_band_19(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(88) / 100 + (19 as i64)
}

pub fn fsm_theta_decay_schedule_band_20(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(95) / 100 + (20 as i64)
}

pub fn fsm_theta_decay_schedule_band_21(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(12) / 100 + (21 as i64)
}

pub fn fsm_theta_decay_schedule_band_22(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(19) / 100 + (22 as i64)
}

pub fn fsm_theta_decay_schedule_band_23(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(26) / 100 + (23 as i64)
}

pub fn fsm_theta_decay_schedule_band_24(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(33) / 100 + (24 as i64)
}

pub fn fsm_theta_decay_schedule_band_25(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(40) / 100 + (25 as i64)
}

pub fn fsm_theta_decay_schedule_band_26(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(47) / 100 + (26 as i64)
}

pub fn fsm_theta_decay_schedule_band_27(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(54) / 100 + (27 as i64)
}

pub fn fsm_theta_decay_schedule_band_28(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(61) / 100 + (28 as i64)
}

pub fn fsm_theta_decay_schedule_band_29(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(68) / 100 + (29 as i64)
}

pub fn fsm_theta_decay_schedule_band_30(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(75) / 100 + (30 as i64)
}

pub fn fsm_theta_decay_schedule_band_31(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(82) / 100 + (31 as i64)
}

pub fn fsm_theta_decay_schedule_band_32(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(89) / 100 + (32 as i64)
}

pub fn fsm_theta_decay_schedule_band_33(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(96) / 100 + (33 as i64)
}

pub fn fsm_theta_decay_schedule_band_34(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(13) / 100 + (34 as i64)
}

pub fn fsm_theta_decay_schedule_band_35(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(20) / 100 + (35 as i64)
}

pub fn fsm_theta_decay_schedule_band_36(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(27) / 100 + (36 as i64)
}

pub fn fsm_theta_decay_schedule_band_37(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(34) / 100 + (37 as i64)
}

pub fn fsm_theta_decay_schedule_band_38(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(41) / 100 + (38 as i64)
}

pub fn fsm_theta_decay_schedule_band_39(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(48) / 100 + (39 as i64)
}

pub fn fsm_theta_decay_schedule_band_40(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(55) / 100 + (40 as i64)
}

pub fn fsm_theta_decay_schedule_band_41(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(62) / 100 + (41 as i64)
}

pub fn fsm_theta_decay_schedule_band_42(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(69) / 100 + (42 as i64)
}

pub fn fsm_theta_decay_schedule_band_43(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(76) / 100 + (43 as i64)
}

pub fn fsm_theta_decay_schedule_band_44(exposure_minor: i64, collateral_minor: i64) -> i64 {
    let gap = exposure_minor - collateral_minor;
    gap.saturating_mul(83) / 100 + (44 as i64)
}
