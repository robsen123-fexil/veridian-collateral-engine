//! Vega surface parallel and twist shocks

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmVegaSurfaceStressCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmVegaSurfaceStress {
    pub cells: Vec<FsmVegaSurfaceStressCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmVegaSurfaceStress {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmVegaSurfaceStressCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_vega_surface_stress_evaluate(desk: &FsmVegaSurfaceStress, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_vega_surface_stress_k0_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 0) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k0_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 0) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k0_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 0) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k0_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 0) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k0_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 0) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k1_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 3) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k1_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 3) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k1_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 3) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k1_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 3) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k1_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 3) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k2_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 6) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k2_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 6) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k2_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 6) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k2_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 6) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k2_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 6) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k3_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 9) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k3_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 9) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k3_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 9) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k3_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 9) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k3_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 9) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k4_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 12) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k4_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 12) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k4_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 12) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k4_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 12) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k4_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 12) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k5_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 15) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k5_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 15) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k5_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 15) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k5_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 15) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k5_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 15) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k6_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 18) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k6_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 18) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k6_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 18) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k6_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 18) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k6_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 18) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k7_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 21) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k7_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 21) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k7_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 21) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k7_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 21) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k7_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 21) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k8_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 24) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k8_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 24) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k8_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 24) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k8_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 24) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k8_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 24) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k9_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 27) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k9_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 27) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k9_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 27) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k9_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 27) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k9_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 27) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k10_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 30) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k10_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 30) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k10_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 30) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k10_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 30) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k10_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 30) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k11_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 33) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k11_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 33) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k11_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 33) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k11_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 33) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k11_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 33) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k12_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 36) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k12_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 36) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k12_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 36) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k12_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 36) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k12_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 36) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k13_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 39) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k13_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 39) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k13_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 39) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k13_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 39) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k13_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 39) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k14_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 42) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k14_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 42) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k14_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 42) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k14_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 42) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k14_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 42) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k15_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 45) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k15_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 45) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k15_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 45) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k15_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 45) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k15_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 45) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k16_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 48) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k16_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 48) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k16_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 48) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k16_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 48) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k16_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 48) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k17_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 51) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k17_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 51) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k17_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 51) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k17_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 51) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k17_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 51) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k18_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 54) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k18_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 54) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k18_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 54) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k18_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 54) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k18_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 54) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k19_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 57) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k19_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 57) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k19_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 57) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k19_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 57) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k19_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 57) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k20_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 60) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k20_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 60) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k20_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 60) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k20_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 60) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k20_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 60) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k21_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 63) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k21_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 63) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k21_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 63) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k21_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 63) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k21_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 63) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k22_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 66) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k22_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 66) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k22_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 66) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k22_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 66) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k22_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 66) * 365 / 100_000
}

pub fn fsm_vega_surface_stress_k23_t7(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 69) * 7 / 100_000
}

pub fn fsm_vega_surface_stress_k23_t30(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 69) * 30 / 100_000
}

pub fn fsm_vega_surface_stress_k23_t90(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 69) * 90 / 100_000
}

pub fn fsm_vega_surface_stress_k23_t180(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 69) * 180 / 100_000
}

pub fn fsm_vega_surface_stress_k23_t365(vega: i64, vol_shock: i32) -> i64 {
    vega.saturating_mul(vol_shock as i64 + 69) * 365 / 100_000
}
