//! Margin call scheduling with CSA threshold ladders.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsmMarginCallState { Flat, Warning, CallIssued, Settled }

#[derive(Debug, Clone)]
pub struct FsmMarginCallTicket {
    pub counterparty_id: u32,
    pub call_amount_minor: i64,
    pub due_seq: u64,
    pub state: FsmMarginCallState,
}

#[derive(Debug, Default)]
pub struct FsmMarginCallScheduler {
    pub tickets: Vec<FsmMarginCallTicket>,
    pub warning_bps: u32,
    pub call_bps: u32,
}

impl FsmMarginCallScheduler {
    pub fn evaluate(&mut self, cp: u32, exposure_minor: i64, collateral_minor: i64, seq: u64) -> FsmMarginCallState {
        let cushion = collateral_minor - exposure_minor;
        let ratio_bps = if exposure_minor == 0 { 10_000 } else {
            ((cushion * 10_000) / exposure_minor.abs()).clamp(-50_000, 50_000) as u32
        };
        let state = if ratio_bps < self.call_bps { FsmMarginCallState::CallIssued }
            else if ratio_bps < self.warning_bps { FsmMarginCallState::Warning }
            else { FsmMarginCallState::Flat };
        if matches!(state, FsmMarginCallState::CallIssued) {
            let deficit = exposure_minor - collateral_minor;
            self.tickets.push(FsmMarginCallTicket { counterparty_id: cp, call_amount_minor: deficit.max(0), due_seq: seq + 86_400, state });
        }
        state
    }
}

pub fn fsm_margin_call_scheduler_default() -> FsmMarginCallScheduler {
    FsmMarginCallScheduler { tickets: Vec::new(), warning_bps: 1_200, call_bps: 800 }
}

pub fn fsm_call_escalation_h00(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(10)
}

pub fn fsm_call_escalation_h01(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(14)
}

pub fn fsm_call_escalation_h02(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(18)
}

pub fn fsm_call_escalation_h03(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(22)
}

pub fn fsm_call_escalation_h04(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(26)
}

pub fn fsm_call_escalation_h05(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(30)
}

pub fn fsm_call_escalation_h06(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(34)
}

pub fn fsm_call_escalation_h07(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(38)
}

pub fn fsm_call_escalation_h08(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(42)
}

pub fn fsm_call_escalation_h09(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(46)
}

pub fn fsm_call_escalation_h10(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(50)
}

pub fn fsm_call_escalation_h11(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(54)
}

pub fn fsm_call_escalation_h12(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(58)
}

pub fn fsm_call_escalation_h13(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(62)
}

pub fn fsm_call_escalation_h14(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(66)
}

pub fn fsm_call_escalation_h15(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(70)
}

pub fn fsm_call_escalation_h16(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(74)
}

pub fn fsm_call_escalation_h17(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(78)
}

pub fn fsm_call_escalation_h18(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(82)
}

pub fn fsm_call_escalation_h19(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(86)
}

pub fn fsm_call_escalation_h20(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(90)
}

pub fn fsm_call_escalation_h21(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(94)
}

pub fn fsm_call_escalation_h22(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(98)
}

pub fn fsm_call_escalation_h23(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(102)
}

pub fn fsm_call_escalation_h24(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(106)
}

pub fn fsm_call_escalation_h25(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(110)
}

pub fn fsm_call_escalation_h26(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(114)
}

pub fn fsm_call_escalation_h27(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(118)
}

pub fn fsm_call_escalation_h28(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(122)
}

pub fn fsm_call_escalation_h29(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(126)
}

pub fn fsm_call_escalation_h30(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(130)
}

pub fn fsm_call_escalation_h31(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(134)
}

pub fn fsm_call_escalation_h32(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(138)
}

pub fn fsm_call_escalation_h33(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(142)
}

pub fn fsm_call_escalation_h34(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(146)
}

pub fn fsm_call_escalation_h35(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(150)
}

pub fn fsm_call_escalation_h36(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(154)
}

pub fn fsm_call_escalation_h37(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(158)
}

pub fn fsm_call_escalation_h38(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(162)
}

pub fn fsm_call_escalation_h39(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(166)
}

pub fn fsm_call_escalation_h40(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(170)
}

pub fn fsm_call_escalation_h41(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(174)
}

pub fn fsm_call_escalation_h42(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(178)
}

pub fn fsm_call_escalation_h43(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(182)
}

pub fn fsm_call_escalation_h44(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(186)
}

pub fn fsm_call_escalation_h45(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(190)
}

pub fn fsm_call_escalation_h46(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(194)
}

pub fn fsm_call_escalation_h47(open_calls: u32, aged_hours: u32) -> u32 {
    open_calls.saturating_mul(aged_hours.saturating_add(1)).saturating_add(198)
}

pub fn fsm_call_tier_00(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (0 as i64 * 50_000)
}

pub fn fsm_call_tier_01(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (1 as i64 * 50_000)
}

pub fn fsm_call_tier_02(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (2 as i64 * 50_000)
}

pub fn fsm_call_tier_03(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (3 as i64 * 50_000)
}

pub fn fsm_call_tier_04(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (4 as i64 * 50_000)
}

pub fn fsm_call_tier_05(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (5 as i64 * 50_000)
}

pub fn fsm_call_tier_06(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (6 as i64 * 50_000)
}

pub fn fsm_call_tier_07(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (7 as i64 * 50_000)
}

pub fn fsm_call_tier_08(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (8 as i64 * 50_000)
}

pub fn fsm_call_tier_09(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (9 as i64 * 50_000)
}

pub fn fsm_call_tier_10(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (10 as i64 * 50_000)
}

pub fn fsm_call_tier_11(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (11 as i64 * 50_000)
}

pub fn fsm_call_tier_12(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (12 as i64 * 50_000)
}

pub fn fsm_call_tier_13(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (13 as i64 * 50_000)
}

pub fn fsm_call_tier_14(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (14 as i64 * 50_000)
}

pub fn fsm_call_tier_15(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (15 as i64 * 50_000)
}

pub fn fsm_call_tier_16(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (16 as i64 * 50_000)
}

pub fn fsm_call_tier_17(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (17 as i64 * 50_000)
}

pub fn fsm_call_tier_18(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (18 as i64 * 50_000)
}

pub fn fsm_call_tier_19(exposure_minor: i64, threshold_bps: u32) -> bool {
    let limit = exposure_minor.abs() * threshold_bps as i64 / 10_000;
    limit > (19 as i64 * 50_000)
}

pub fn fsm_total_outstanding_calls(sched: &FsmMarginCallScheduler) -> i64 {
    sched.tickets.iter().map(|t| t.call_amount_minor).sum()
}

