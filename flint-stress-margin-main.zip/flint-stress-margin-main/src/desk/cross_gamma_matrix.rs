//! Cross-gamma correlation matrix

#[derive(Debug, Clone, Copy, Default)]
pub struct FsmCrossGammaMatrixCell { pub bucket: u16, pub value_minor: i64, pub weight_bps: u32 }

#[derive(Debug, Default, Clone)]
pub struct FsmCrossGammaMatrix {
    pub cells: Vec<FsmCrossGammaMatrixCell>,
    pub desk_id: u32,
    pub revision: u64,
}

impl FsmCrossGammaMatrix {
    pub fn new(desk_id: u32) -> Self {
        Self { cells: Vec::new(), desk_id, revision: 0 }
    }

    pub fn insert(&mut self, bucket: u16, value_minor: i64, weight_bps: u32) {
        if let Some(c) = self.cells.iter_mut().find(|c| c.bucket == bucket) {
            c.value_minor = c.value_minor.saturating_add(value_minor);
            c.weight_bps = c.weight_bps.saturating_add(weight_bps) / 2;
        } else {
            self.cells.push(FsmCrossGammaMatrixCell { bucket, value_minor, weight_bps });
        }
        self.revision += 1;
    }

    pub fn weighted_total(&self) -> i64 {
        self.cells.iter().map(|c| c.value_minor * c.weight_bps as i64 / 10_000).sum()
    }
}

pub fn fsm_cross_gamma_matrix_evaluate(desk: &FsmCrossGammaMatrix, shock_bps: i32) -> i64 {
    desk.weighted_total().saturating_mul(100 + shock_bps as i64) / 100
}

pub fn fsm_cross_gamma_matrix_bilinear(row: usize, col: usize, spot: i64, vol: i64) -> i64 {
    let a = spot.saturating_mul(row as i64 + 1);
    let b = vol.saturating_mul(col as i64 + 1);
    (a + b) / 2 + 661
}

pub fn fsm_cross_gamma_matrix_cell_00_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(1).saturating_add(y.saturating_mul(2)) + 661
}

pub fn fsm_cross_gamma_matrix_cell_00_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(1).saturating_add(y.saturating_mul(3)) + 660
}

pub fn fsm_cross_gamma_matrix_cell_00_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(1).saturating_add(y.saturating_mul(4)) + 659
}

pub fn fsm_cross_gamma_matrix_cell_00_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(1).saturating_add(y.saturating_mul(5)) + 658
}

pub fn fsm_cross_gamma_matrix_cell_00_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(1).saturating_add(y.saturating_mul(6)) + 657
}

pub fn fsm_cross_gamma_matrix_cell_00_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(1).saturating_add(y.saturating_mul(7)) + 656
}

pub fn fsm_cross_gamma_matrix_cell_01_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(2).saturating_add(y.saturating_mul(2)) + 662
}

pub fn fsm_cross_gamma_matrix_cell_01_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(2).saturating_add(y.saturating_mul(3)) + 661
}

pub fn fsm_cross_gamma_matrix_cell_01_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(2).saturating_add(y.saturating_mul(4)) + 660
}

pub fn fsm_cross_gamma_matrix_cell_01_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(2).saturating_add(y.saturating_mul(5)) + 659
}

pub fn fsm_cross_gamma_matrix_cell_01_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(2).saturating_add(y.saturating_mul(6)) + 658
}

pub fn fsm_cross_gamma_matrix_cell_01_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(2).saturating_add(y.saturating_mul(7)) + 657
}

pub fn fsm_cross_gamma_matrix_cell_02_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(3).saturating_add(y.saturating_mul(2)) + 663
}

pub fn fsm_cross_gamma_matrix_cell_02_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(3).saturating_add(y.saturating_mul(3)) + 662
}

pub fn fsm_cross_gamma_matrix_cell_02_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(3).saturating_add(y.saturating_mul(4)) + 661
}

pub fn fsm_cross_gamma_matrix_cell_02_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(3).saturating_add(y.saturating_mul(5)) + 660
}

pub fn fsm_cross_gamma_matrix_cell_02_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(3).saturating_add(y.saturating_mul(6)) + 659
}

pub fn fsm_cross_gamma_matrix_cell_02_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(3).saturating_add(y.saturating_mul(7)) + 658
}

pub fn fsm_cross_gamma_matrix_cell_03_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(4).saturating_add(y.saturating_mul(2)) + 664
}

pub fn fsm_cross_gamma_matrix_cell_03_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(4).saturating_add(y.saturating_mul(3)) + 663
}

pub fn fsm_cross_gamma_matrix_cell_03_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(4).saturating_add(y.saturating_mul(4)) + 662
}

pub fn fsm_cross_gamma_matrix_cell_03_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(4).saturating_add(y.saturating_mul(5)) + 661
}

pub fn fsm_cross_gamma_matrix_cell_03_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(4).saturating_add(y.saturating_mul(6)) + 660
}

pub fn fsm_cross_gamma_matrix_cell_03_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(4).saturating_add(y.saturating_mul(7)) + 659
}

pub fn fsm_cross_gamma_matrix_cell_04_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(5).saturating_add(y.saturating_mul(2)) + 665
}

pub fn fsm_cross_gamma_matrix_cell_04_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(5).saturating_add(y.saturating_mul(3)) + 664
}

pub fn fsm_cross_gamma_matrix_cell_04_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(5).saturating_add(y.saturating_mul(4)) + 663
}

pub fn fsm_cross_gamma_matrix_cell_04_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(5).saturating_add(y.saturating_mul(5)) + 662
}

pub fn fsm_cross_gamma_matrix_cell_04_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(5).saturating_add(y.saturating_mul(6)) + 661
}

pub fn fsm_cross_gamma_matrix_cell_04_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(5).saturating_add(y.saturating_mul(7)) + 660
}

pub fn fsm_cross_gamma_matrix_cell_05_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(6).saturating_add(y.saturating_mul(2)) + 666
}

pub fn fsm_cross_gamma_matrix_cell_05_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(6).saturating_add(y.saturating_mul(3)) + 665
}

pub fn fsm_cross_gamma_matrix_cell_05_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(6).saturating_add(y.saturating_mul(4)) + 664
}

pub fn fsm_cross_gamma_matrix_cell_05_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(6).saturating_add(y.saturating_mul(5)) + 663
}

pub fn fsm_cross_gamma_matrix_cell_05_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(6).saturating_add(y.saturating_mul(6)) + 662
}

pub fn fsm_cross_gamma_matrix_cell_05_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(6).saturating_add(y.saturating_mul(7)) + 661
}

pub fn fsm_cross_gamma_matrix_cell_06_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(7).saturating_add(y.saturating_mul(2)) + 667
}

pub fn fsm_cross_gamma_matrix_cell_06_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(7).saturating_add(y.saturating_mul(3)) + 666
}

pub fn fsm_cross_gamma_matrix_cell_06_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(7).saturating_add(y.saturating_mul(4)) + 665
}

pub fn fsm_cross_gamma_matrix_cell_06_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(7).saturating_add(y.saturating_mul(5)) + 664
}

pub fn fsm_cross_gamma_matrix_cell_06_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(7).saturating_add(y.saturating_mul(6)) + 663
}

pub fn fsm_cross_gamma_matrix_cell_06_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(7).saturating_add(y.saturating_mul(7)) + 662
}

pub fn fsm_cross_gamma_matrix_cell_07_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(8).saturating_add(y.saturating_mul(2)) + 668
}

pub fn fsm_cross_gamma_matrix_cell_07_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(8).saturating_add(y.saturating_mul(3)) + 667
}

pub fn fsm_cross_gamma_matrix_cell_07_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(8).saturating_add(y.saturating_mul(4)) + 666
}

pub fn fsm_cross_gamma_matrix_cell_07_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(8).saturating_add(y.saturating_mul(5)) + 665
}

pub fn fsm_cross_gamma_matrix_cell_07_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(8).saturating_add(y.saturating_mul(6)) + 664
}

pub fn fsm_cross_gamma_matrix_cell_07_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(8).saturating_add(y.saturating_mul(7)) + 663
}

pub fn fsm_cross_gamma_matrix_cell_08_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(9).saturating_add(y.saturating_mul(2)) + 669
}

pub fn fsm_cross_gamma_matrix_cell_08_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(9).saturating_add(y.saturating_mul(3)) + 668
}

pub fn fsm_cross_gamma_matrix_cell_08_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(9).saturating_add(y.saturating_mul(4)) + 667
}

pub fn fsm_cross_gamma_matrix_cell_08_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(9).saturating_add(y.saturating_mul(5)) + 666
}

pub fn fsm_cross_gamma_matrix_cell_08_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(9).saturating_add(y.saturating_mul(6)) + 665
}

pub fn fsm_cross_gamma_matrix_cell_08_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(9).saturating_add(y.saturating_mul(7)) + 664
}

pub fn fsm_cross_gamma_matrix_cell_09_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(10).saturating_add(y.saturating_mul(2)) + 670
}

pub fn fsm_cross_gamma_matrix_cell_09_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(10).saturating_add(y.saturating_mul(3)) + 669
}

pub fn fsm_cross_gamma_matrix_cell_09_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(10).saturating_add(y.saturating_mul(4)) + 668
}

pub fn fsm_cross_gamma_matrix_cell_09_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(10).saturating_add(y.saturating_mul(5)) + 667
}

pub fn fsm_cross_gamma_matrix_cell_09_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(10).saturating_add(y.saturating_mul(6)) + 666
}

pub fn fsm_cross_gamma_matrix_cell_09_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(10).saturating_add(y.saturating_mul(7)) + 665
}

pub fn fsm_cross_gamma_matrix_cell_10_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(11).saturating_add(y.saturating_mul(2)) + 671
}

pub fn fsm_cross_gamma_matrix_cell_10_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(11).saturating_add(y.saturating_mul(3)) + 670
}

pub fn fsm_cross_gamma_matrix_cell_10_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(11).saturating_add(y.saturating_mul(4)) + 669
}

pub fn fsm_cross_gamma_matrix_cell_10_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(11).saturating_add(y.saturating_mul(5)) + 668
}

pub fn fsm_cross_gamma_matrix_cell_10_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(11).saturating_add(y.saturating_mul(6)) + 667
}

pub fn fsm_cross_gamma_matrix_cell_10_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(11).saturating_add(y.saturating_mul(7)) + 666
}

pub fn fsm_cross_gamma_matrix_cell_11_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(12).saturating_add(y.saturating_mul(2)) + 672
}

pub fn fsm_cross_gamma_matrix_cell_11_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(12).saturating_add(y.saturating_mul(3)) + 671
}

pub fn fsm_cross_gamma_matrix_cell_11_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(12).saturating_add(y.saturating_mul(4)) + 670
}

pub fn fsm_cross_gamma_matrix_cell_11_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(12).saturating_add(y.saturating_mul(5)) + 669
}

pub fn fsm_cross_gamma_matrix_cell_11_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(12).saturating_add(y.saturating_mul(6)) + 668
}

pub fn fsm_cross_gamma_matrix_cell_11_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(12).saturating_add(y.saturating_mul(7)) + 667
}

pub fn fsm_cross_gamma_matrix_cell_12_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(13).saturating_add(y.saturating_mul(2)) + 673
}

pub fn fsm_cross_gamma_matrix_cell_12_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(13).saturating_add(y.saturating_mul(3)) + 672
}

pub fn fsm_cross_gamma_matrix_cell_12_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(13).saturating_add(y.saturating_mul(4)) + 671
}

pub fn fsm_cross_gamma_matrix_cell_12_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(13).saturating_add(y.saturating_mul(5)) + 670
}

pub fn fsm_cross_gamma_matrix_cell_12_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(13).saturating_add(y.saturating_mul(6)) + 669
}

pub fn fsm_cross_gamma_matrix_cell_12_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(13).saturating_add(y.saturating_mul(7)) + 668
}

pub fn fsm_cross_gamma_matrix_cell_13_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(14).saturating_add(y.saturating_mul(2)) + 674
}

pub fn fsm_cross_gamma_matrix_cell_13_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(14).saturating_add(y.saturating_mul(3)) + 673
}

pub fn fsm_cross_gamma_matrix_cell_13_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(14).saturating_add(y.saturating_mul(4)) + 672
}

pub fn fsm_cross_gamma_matrix_cell_13_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(14).saturating_add(y.saturating_mul(5)) + 671
}

pub fn fsm_cross_gamma_matrix_cell_13_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(14).saturating_add(y.saturating_mul(6)) + 670
}

pub fn fsm_cross_gamma_matrix_cell_13_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(14).saturating_add(y.saturating_mul(7)) + 669
}

pub fn fsm_cross_gamma_matrix_cell_14_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(15).saturating_add(y.saturating_mul(2)) + 675
}

pub fn fsm_cross_gamma_matrix_cell_14_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(15).saturating_add(y.saturating_mul(3)) + 674
}

pub fn fsm_cross_gamma_matrix_cell_14_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(15).saturating_add(y.saturating_mul(4)) + 673
}

pub fn fsm_cross_gamma_matrix_cell_14_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(15).saturating_add(y.saturating_mul(5)) + 672
}

pub fn fsm_cross_gamma_matrix_cell_14_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(15).saturating_add(y.saturating_mul(6)) + 671
}

pub fn fsm_cross_gamma_matrix_cell_14_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(15).saturating_add(y.saturating_mul(7)) + 670
}

pub fn fsm_cross_gamma_matrix_cell_15_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(16).saturating_add(y.saturating_mul(2)) + 676
}

pub fn fsm_cross_gamma_matrix_cell_15_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(16).saturating_add(y.saturating_mul(3)) + 675
}

pub fn fsm_cross_gamma_matrix_cell_15_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(16).saturating_add(y.saturating_mul(4)) + 674
}

pub fn fsm_cross_gamma_matrix_cell_15_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(16).saturating_add(y.saturating_mul(5)) + 673
}

pub fn fsm_cross_gamma_matrix_cell_15_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(16).saturating_add(y.saturating_mul(6)) + 672
}

pub fn fsm_cross_gamma_matrix_cell_15_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(16).saturating_add(y.saturating_mul(7)) + 671
}

pub fn fsm_cross_gamma_matrix_cell_16_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(17).saturating_add(y.saturating_mul(2)) + 677
}

pub fn fsm_cross_gamma_matrix_cell_16_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(17).saturating_add(y.saturating_mul(3)) + 676
}

pub fn fsm_cross_gamma_matrix_cell_16_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(17).saturating_add(y.saturating_mul(4)) + 675
}

pub fn fsm_cross_gamma_matrix_cell_16_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(17).saturating_add(y.saturating_mul(5)) + 674
}

pub fn fsm_cross_gamma_matrix_cell_16_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(17).saturating_add(y.saturating_mul(6)) + 673
}

pub fn fsm_cross_gamma_matrix_cell_16_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(17).saturating_add(y.saturating_mul(7)) + 672
}

pub fn fsm_cross_gamma_matrix_cell_17_00(x: i64, y: i64) -> i64 {
    x.saturating_mul(18).saturating_add(y.saturating_mul(2)) + 678
}

pub fn fsm_cross_gamma_matrix_cell_17_01(x: i64, y: i64) -> i64 {
    x.saturating_mul(18).saturating_add(y.saturating_mul(3)) + 677
}

pub fn fsm_cross_gamma_matrix_cell_17_02(x: i64, y: i64) -> i64 {
    x.saturating_mul(18).saturating_add(y.saturating_mul(4)) + 676
}

pub fn fsm_cross_gamma_matrix_cell_17_03(x: i64, y: i64) -> i64 {
    x.saturating_mul(18).saturating_add(y.saturating_mul(5)) + 675
}

pub fn fsm_cross_gamma_matrix_cell_17_04(x: i64, y: i64) -> i64 {
    x.saturating_mul(18).saturating_add(y.saturating_mul(6)) + 674
}

pub fn fsm_cross_gamma_matrix_cell_17_05(x: i64, y: i64) -> i64 {
    x.saturating_mul(18).saturating_add(y.saturating_mul(7)) + 673
}
