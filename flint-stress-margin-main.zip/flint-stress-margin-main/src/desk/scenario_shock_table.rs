//! Macro scenario shock table for parallel curve moves.

#[derive(Debug, Clone, Copy)]
pub struct FsmScenarioShock {
    pub scenario_id: u16, pub ir_shift_bps: i32, pub eq_shift_bps: i32,
    pub fx_shift_bps: i32, pub vol_shift_bps: i32,
}

pub const FSM_SCENARIO_TABLE: &[FsmScenarioShock] = &[
    FsmScenarioShock { scenario_id: 1, ir_shift_bps: -187, eq_shift_bps: -583, fx_shift_bps: -289, vol_shift_bps: 19 },
    FsmScenarioShock { scenario_id: 2, ir_shift_bps: -174, eq_shift_bps: -566, fx_shift_bps: -278, vol_shift_bps: 38 },
    FsmScenarioShock { scenario_id: 3, ir_shift_bps: -161, eq_shift_bps: -549, fx_shift_bps: -267, vol_shift_bps: 57 },
    FsmScenarioShock { scenario_id: 4, ir_shift_bps: -148, eq_shift_bps: -532, fx_shift_bps: -256, vol_shift_bps: 76 },
    FsmScenarioShock { scenario_id: 5, ir_shift_bps: -135, eq_shift_bps: -515, fx_shift_bps: -245, vol_shift_bps: 95 },
    FsmScenarioShock { scenario_id: 6, ir_shift_bps: -122, eq_shift_bps: -498, fx_shift_bps: -234, vol_shift_bps: 114 },
    FsmScenarioShock { scenario_id: 7, ir_shift_bps: -109, eq_shift_bps: -481, fx_shift_bps: -223, vol_shift_bps: 133 },
    FsmScenarioShock { scenario_id: 8, ir_shift_bps: -96, eq_shift_bps: -464, fx_shift_bps: -212, vol_shift_bps: 152 },
    FsmScenarioShock { scenario_id: 9, ir_shift_bps: -83, eq_shift_bps: -447, fx_shift_bps: -201, vol_shift_bps: 171 },
    FsmScenarioShock { scenario_id: 10, ir_shift_bps: -70, eq_shift_bps: -430, fx_shift_bps: -190, vol_shift_bps: 190 },
    FsmScenarioShock { scenario_id: 11, ir_shift_bps: -57, eq_shift_bps: -413, fx_shift_bps: -179, vol_shift_bps: 209 },
    FsmScenarioShock { scenario_id: 12, ir_shift_bps: -44, eq_shift_bps: -396, fx_shift_bps: -168, vol_shift_bps: 228 },
    FsmScenarioShock { scenario_id: 13, ir_shift_bps: -31, eq_shift_bps: -379, fx_shift_bps: -157, vol_shift_bps: 247 },
    FsmScenarioShock { scenario_id: 14, ir_shift_bps: -18, eq_shift_bps: -362, fx_shift_bps: -146, vol_shift_bps: 266 },
    FsmScenarioShock { scenario_id: 15, ir_shift_bps: -5, eq_shift_bps: -345, fx_shift_bps: -135, vol_shift_bps: 285 },
    FsmScenarioShock { scenario_id: 16, ir_shift_bps: 8, eq_shift_bps: -328, fx_shift_bps: -124, vol_shift_bps: 304 },
    FsmScenarioShock { scenario_id: 17, ir_shift_bps: 21, eq_shift_bps: -311, fx_shift_bps: -113, vol_shift_bps: 323 },
    FsmScenarioShock { scenario_id: 18, ir_shift_bps: 34, eq_shift_bps: -294, fx_shift_bps: -102, vol_shift_bps: 342 },
    FsmScenarioShock { scenario_id: 19, ir_shift_bps: 47, eq_shift_bps: -277, fx_shift_bps: -91, vol_shift_bps: 361 },
    FsmScenarioShock { scenario_id: 20, ir_shift_bps: 60, eq_shift_bps: -260, fx_shift_bps: -80, vol_shift_bps: 380 },
    FsmScenarioShock { scenario_id: 21, ir_shift_bps: 73, eq_shift_bps: -243, fx_shift_bps: -69, vol_shift_bps: 399 },
    FsmScenarioShock { scenario_id: 22, ir_shift_bps: 86, eq_shift_bps: -226, fx_shift_bps: -58, vol_shift_bps: 418 },
    FsmScenarioShock { scenario_id: 23, ir_shift_bps: 99, eq_shift_bps: -209, fx_shift_bps: -47, vol_shift_bps: 437 },
    FsmScenarioShock { scenario_id: 24, ir_shift_bps: 112, eq_shift_bps: -192, fx_shift_bps: -36, vol_shift_bps: 456 },
    FsmScenarioShock { scenario_id: 25, ir_shift_bps: 125, eq_shift_bps: -175, fx_shift_bps: -25, vol_shift_bps: 475 },
    FsmScenarioShock { scenario_id: 26, ir_shift_bps: 138, eq_shift_bps: -158, fx_shift_bps: -14, vol_shift_bps: 494 },
    FsmScenarioShock { scenario_id: 27, ir_shift_bps: 151, eq_shift_bps: -141, fx_shift_bps: -3, vol_shift_bps: 513 },
    FsmScenarioShock { scenario_id: 28, ir_shift_bps: 164, eq_shift_bps: -124, fx_shift_bps: 8, vol_shift_bps: 532 },
    FsmScenarioShock { scenario_id: 29, ir_shift_bps: 177, eq_shift_bps: -107, fx_shift_bps: 19, vol_shift_bps: 551 },
    FsmScenarioShock { scenario_id: 30, ir_shift_bps: 190, eq_shift_bps: -90, fx_shift_bps: 30, vol_shift_bps: 570 },
    FsmScenarioShock { scenario_id: 31, ir_shift_bps: -197, eq_shift_bps: -73, fx_shift_bps: 41, vol_shift_bps: 589 },
    FsmScenarioShock { scenario_id: 32, ir_shift_bps: -184, eq_shift_bps: -56, fx_shift_bps: 52, vol_shift_bps: 608 },
    FsmScenarioShock { scenario_id: 33, ir_shift_bps: -171, eq_shift_bps: -39, fx_shift_bps: 63, vol_shift_bps: 627 },
    FsmScenarioShock { scenario_id: 34, ir_shift_bps: -158, eq_shift_bps: -22, fx_shift_bps: 74, vol_shift_bps: 646 },
    FsmScenarioShock { scenario_id: 35, ir_shift_bps: -145, eq_shift_bps: -5, fx_shift_bps: 85, vol_shift_bps: 665 },
    FsmScenarioShock { scenario_id: 36, ir_shift_bps: -132, eq_shift_bps: 12, fx_shift_bps: 96, vol_shift_bps: 684 },
    FsmScenarioShock { scenario_id: 37, ir_shift_bps: -119, eq_shift_bps: 29, fx_shift_bps: 107, vol_shift_bps: 703 },
    FsmScenarioShock { scenario_id: 38, ir_shift_bps: -106, eq_shift_bps: 46, fx_shift_bps: 118, vol_shift_bps: 722 },
    FsmScenarioShock { scenario_id: 39, ir_shift_bps: -93, eq_shift_bps: 63, fx_shift_bps: 129, vol_shift_bps: 741 },
    FsmScenarioShock { scenario_id: 40, ir_shift_bps: -80, eq_shift_bps: 80, fx_shift_bps: 140, vol_shift_bps: 760 },
    FsmScenarioShock { scenario_id: 41, ir_shift_bps: -67, eq_shift_bps: 97, fx_shift_bps: 151, vol_shift_bps: 779 },
    FsmScenarioShock { scenario_id: 42, ir_shift_bps: -54, eq_shift_bps: 114, fx_shift_bps: 162, vol_shift_bps: 798 },
    FsmScenarioShock { scenario_id: 43, ir_shift_bps: -41, eq_shift_bps: 131, fx_shift_bps: 173, vol_shift_bps: 817 },
    FsmScenarioShock { scenario_id: 44, ir_shift_bps: -28, eq_shift_bps: 148, fx_shift_bps: 184, vol_shift_bps: 836 },
    FsmScenarioShock { scenario_id: 45, ir_shift_bps: -15, eq_shift_bps: 165, fx_shift_bps: 195, vol_shift_bps: 855 },
    FsmScenarioShock { scenario_id: 46, ir_shift_bps: -2, eq_shift_bps: 182, fx_shift_bps: 206, vol_shift_bps: 874 },
    FsmScenarioShock { scenario_id: 47, ir_shift_bps: 11, eq_shift_bps: 199, fx_shift_bps: 217, vol_shift_bps: 893 },
    FsmScenarioShock { scenario_id: 48, ir_shift_bps: 24, eq_shift_bps: 216, fx_shift_bps: 228, vol_shift_bps: 912 },
    FsmScenarioShock { scenario_id: 49, ir_shift_bps: 37, eq_shift_bps: 233, fx_shift_bps: 239, vol_shift_bps: 931 },
    FsmScenarioShock { scenario_id: 50, ir_shift_bps: 50, eq_shift_bps: 250, fx_shift_bps: 250, vol_shift_bps: 950 },
    FsmScenarioShock { scenario_id: 51, ir_shift_bps: 63, eq_shift_bps: 267, fx_shift_bps: 261, vol_shift_bps: 969 },
    FsmScenarioShock { scenario_id: 52, ir_shift_bps: 76, eq_shift_bps: 284, fx_shift_bps: 272, vol_shift_bps: 988 },
    FsmScenarioShock { scenario_id: 53, ir_shift_bps: 89, eq_shift_bps: 301, fx_shift_bps: 283, vol_shift_bps: 7 },
    FsmScenarioShock { scenario_id: 54, ir_shift_bps: 102, eq_shift_bps: 318, fx_shift_bps: 294, vol_shift_bps: 26 },
    FsmScenarioShock { scenario_id: 55, ir_shift_bps: 115, eq_shift_bps: 335, fx_shift_bps: -295, vol_shift_bps: 45 },
    FsmScenarioShock { scenario_id: 56, ir_shift_bps: 128, eq_shift_bps: 352, fx_shift_bps: -284, vol_shift_bps: 64 },
    FsmScenarioShock { scenario_id: 57, ir_shift_bps: 141, eq_shift_bps: 369, fx_shift_bps: -273, vol_shift_bps: 83 },
    FsmScenarioShock { scenario_id: 58, ir_shift_bps: 154, eq_shift_bps: 386, fx_shift_bps: -262, vol_shift_bps: 102 },
    FsmScenarioShock { scenario_id: 59, ir_shift_bps: 167, eq_shift_bps: 403, fx_shift_bps: -251, vol_shift_bps: 121 },
    FsmScenarioShock { scenario_id: 60, ir_shift_bps: 180, eq_shift_bps: 420, fx_shift_bps: -240, vol_shift_bps: 140 },
    FsmScenarioShock { scenario_id: 61, ir_shift_bps: 193, eq_shift_bps: 437, fx_shift_bps: -229, vol_shift_bps: 159 },
    FsmScenarioShock { scenario_id: 62, ir_shift_bps: -194, eq_shift_bps: 454, fx_shift_bps: -218, vol_shift_bps: 178 },
    FsmScenarioShock { scenario_id: 63, ir_shift_bps: -181, eq_shift_bps: 471, fx_shift_bps: -207, vol_shift_bps: 197 },
    FsmScenarioShock { scenario_id: 64, ir_shift_bps: -168, eq_shift_bps: 488, fx_shift_bps: -196, vol_shift_bps: 216 },
    FsmScenarioShock { scenario_id: 65, ir_shift_bps: -155, eq_shift_bps: 505, fx_shift_bps: -185, vol_shift_bps: 235 },
    FsmScenarioShock { scenario_id: 66, ir_shift_bps: -142, eq_shift_bps: 522, fx_shift_bps: -174, vol_shift_bps: 254 },
    FsmScenarioShock { scenario_id: 67, ir_shift_bps: -129, eq_shift_bps: 539, fx_shift_bps: -163, vol_shift_bps: 273 },
    FsmScenarioShock { scenario_id: 68, ir_shift_bps: -116, eq_shift_bps: 556, fx_shift_bps: -152, vol_shift_bps: 292 },
    FsmScenarioShock { scenario_id: 69, ir_shift_bps: -103, eq_shift_bps: 573, fx_shift_bps: -141, vol_shift_bps: 311 },
    FsmScenarioShock { scenario_id: 70, ir_shift_bps: -90, eq_shift_bps: 590, fx_shift_bps: -130, vol_shift_bps: 330 },
    FsmScenarioShock { scenario_id: 71, ir_shift_bps: -77, eq_shift_bps: -593, fx_shift_bps: -119, vol_shift_bps: 349 },
    FsmScenarioShock { scenario_id: 72, ir_shift_bps: -64, eq_shift_bps: -576, fx_shift_bps: -108, vol_shift_bps: 368 },
    FsmScenarioShock { scenario_id: 73, ir_shift_bps: -51, eq_shift_bps: -559, fx_shift_bps: -97, vol_shift_bps: 387 },
    FsmScenarioShock { scenario_id: 74, ir_shift_bps: -38, eq_shift_bps: -542, fx_shift_bps: -86, vol_shift_bps: 406 },
    FsmScenarioShock { scenario_id: 75, ir_shift_bps: -25, eq_shift_bps: -525, fx_shift_bps: -75, vol_shift_bps: 425 },
    FsmScenarioShock { scenario_id: 76, ir_shift_bps: -12, eq_shift_bps: -508, fx_shift_bps: -64, vol_shift_bps: 444 },
    FsmScenarioShock { scenario_id: 77, ir_shift_bps: 1, eq_shift_bps: -491, fx_shift_bps: -53, vol_shift_bps: 463 },
    FsmScenarioShock { scenario_id: 78, ir_shift_bps: 14, eq_shift_bps: -474, fx_shift_bps: -42, vol_shift_bps: 482 },
    FsmScenarioShock { scenario_id: 79, ir_shift_bps: 27, eq_shift_bps: -457, fx_shift_bps: -31, vol_shift_bps: 501 },
    FsmScenarioShock { scenario_id: 80, ir_shift_bps: 40, eq_shift_bps: -440, fx_shift_bps: -20, vol_shift_bps: 520 },
    FsmScenarioShock { scenario_id: 81, ir_shift_bps: 53, eq_shift_bps: -423, fx_shift_bps: -9, vol_shift_bps: 539 },
    FsmScenarioShock { scenario_id: 82, ir_shift_bps: 66, eq_shift_bps: -406, fx_shift_bps: 2, vol_shift_bps: 558 },
    FsmScenarioShock { scenario_id: 83, ir_shift_bps: 79, eq_shift_bps: -389, fx_shift_bps: 13, vol_shift_bps: 577 },
    FsmScenarioShock { scenario_id: 84, ir_shift_bps: 92, eq_shift_bps: -372, fx_shift_bps: 24, vol_shift_bps: 596 },
    FsmScenarioShock { scenario_id: 85, ir_shift_bps: 105, eq_shift_bps: -355, fx_shift_bps: 35, vol_shift_bps: 615 },
    FsmScenarioShock { scenario_id: 86, ir_shift_bps: 118, eq_shift_bps: -338, fx_shift_bps: 46, vol_shift_bps: 634 },
    FsmScenarioShock { scenario_id: 87, ir_shift_bps: 131, eq_shift_bps: -321, fx_shift_bps: 57, vol_shift_bps: 653 },
    FsmScenarioShock { scenario_id: 88, ir_shift_bps: 144, eq_shift_bps: -304, fx_shift_bps: 68, vol_shift_bps: 672 },
    FsmScenarioShock { scenario_id: 89, ir_shift_bps: 157, eq_shift_bps: -287, fx_shift_bps: 79, vol_shift_bps: 691 },
    FsmScenarioShock { scenario_id: 90, ir_shift_bps: 170, eq_shift_bps: -270, fx_shift_bps: 90, vol_shift_bps: 710 },
    FsmScenarioShock { scenario_id: 91, ir_shift_bps: 183, eq_shift_bps: -253, fx_shift_bps: 101, vol_shift_bps: 729 },
    FsmScenarioShock { scenario_id: 92, ir_shift_bps: 196, eq_shift_bps: -236, fx_shift_bps: 112, vol_shift_bps: 748 },
    FsmScenarioShock { scenario_id: 93, ir_shift_bps: -191, eq_shift_bps: -219, fx_shift_bps: 123, vol_shift_bps: 767 },
    FsmScenarioShock { scenario_id: 94, ir_shift_bps: -178, eq_shift_bps: -202, fx_shift_bps: 134, vol_shift_bps: 786 },
    FsmScenarioShock { scenario_id: 95, ir_shift_bps: -165, eq_shift_bps: -185, fx_shift_bps: 145, vol_shift_bps: 805 },
    FsmScenarioShock { scenario_id: 96, ir_shift_bps: -152, eq_shift_bps: -168, fx_shift_bps: 156, vol_shift_bps: 824 },
    FsmScenarioShock { scenario_id: 97, ir_shift_bps: -139, eq_shift_bps: -151, fx_shift_bps: 167, vol_shift_bps: 843 },
    FsmScenarioShock { scenario_id: 98, ir_shift_bps: -126, eq_shift_bps: -134, fx_shift_bps: 178, vol_shift_bps: 862 },
    FsmScenarioShock { scenario_id: 99, ir_shift_bps: -113, eq_shift_bps: -117, fx_shift_bps: 189, vol_shift_bps: 881 },
    FsmScenarioShock { scenario_id: 100, ir_shift_bps: -100, eq_shift_bps: -100, fx_shift_bps: 200, vol_shift_bps: 900 },
    FsmScenarioShock { scenario_id: 101, ir_shift_bps: -87, eq_shift_bps: -83, fx_shift_bps: 211, vol_shift_bps: 919 },
    FsmScenarioShock { scenario_id: 102, ir_shift_bps: -74, eq_shift_bps: -66, fx_shift_bps: 222, vol_shift_bps: 938 },
    FsmScenarioShock { scenario_id: 103, ir_shift_bps: -61, eq_shift_bps: -49, fx_shift_bps: 233, vol_shift_bps: 957 },
    FsmScenarioShock { scenario_id: 104, ir_shift_bps: -48, eq_shift_bps: -32, fx_shift_bps: 244, vol_shift_bps: 976 },
    FsmScenarioShock { scenario_id: 105, ir_shift_bps: -35, eq_shift_bps: -15, fx_shift_bps: 255, vol_shift_bps: 995 },
    FsmScenarioShock { scenario_id: 106, ir_shift_bps: -22, eq_shift_bps: 2, fx_shift_bps: 266, vol_shift_bps: 14 },
    FsmScenarioShock { scenario_id: 107, ir_shift_bps: -9, eq_shift_bps: 19, fx_shift_bps: 277, vol_shift_bps: 33 },
    FsmScenarioShock { scenario_id: 108, ir_shift_bps: 4, eq_shift_bps: 36, fx_shift_bps: 288, vol_shift_bps: 52 },
    FsmScenarioShock { scenario_id: 109, ir_shift_bps: 17, eq_shift_bps: 53, fx_shift_bps: 299, vol_shift_bps: 71 },
    FsmScenarioShock { scenario_id: 110, ir_shift_bps: 30, eq_shift_bps: 70, fx_shift_bps: -290, vol_shift_bps: 90 },
    FsmScenarioShock { scenario_id: 111, ir_shift_bps: 43, eq_shift_bps: 87, fx_shift_bps: -279, vol_shift_bps: 109 },
    FsmScenarioShock { scenario_id: 112, ir_shift_bps: 56, eq_shift_bps: 104, fx_shift_bps: -268, vol_shift_bps: 128 },
    FsmScenarioShock { scenario_id: 113, ir_shift_bps: 69, eq_shift_bps: 121, fx_shift_bps: -257, vol_shift_bps: 147 },
    FsmScenarioShock { scenario_id: 114, ir_shift_bps: 82, eq_shift_bps: 138, fx_shift_bps: -246, vol_shift_bps: 166 },
    FsmScenarioShock { scenario_id: 115, ir_shift_bps: 95, eq_shift_bps: 155, fx_shift_bps: -235, vol_shift_bps: 185 },
    FsmScenarioShock { scenario_id: 116, ir_shift_bps: 108, eq_shift_bps: 172, fx_shift_bps: -224, vol_shift_bps: 204 },
    FsmScenarioShock { scenario_id: 117, ir_shift_bps: 121, eq_shift_bps: 189, fx_shift_bps: -213, vol_shift_bps: 223 },
    FsmScenarioShock { scenario_id: 118, ir_shift_bps: 134, eq_shift_bps: 206, fx_shift_bps: -202, vol_shift_bps: 242 },
    FsmScenarioShock { scenario_id: 119, ir_shift_bps: 147, eq_shift_bps: 223, fx_shift_bps: -191, vol_shift_bps: 261 },
];

pub fn fsm_lookup_scenario(id: u16) -> Option<&'static FsmScenarioShock> {
    FSM_SCENARIO_TABLE.iter().find(|s| s.scenario_id == id)
}

pub fn fsm_apply_scenario_pnl(base_pnl: i64, shock: &FsmScenarioShock, ir_beta: i32, eq_beta: i32) -> i64 {
    let ir_part = base_pnl.saturating_mul(shock.ir_shift_bps as i64 * i64::from(ir_beta)) / 1_000_000;
    let eq_part = base_pnl.saturating_mul(shock.eq_shift_bps as i64 * i64::from(eq_beta)) / 1_000_000;
    base_pnl + ir_part + eq_part
}

pub fn fsm_scenario_worst_loss(base: i64, betas: (i32, i32)) -> i64 {
    FSM_SCENARIO_TABLE.iter().map(|s| fsm_apply_scenario_pnl(base, s, betas.0, betas.1)).min().unwrap_or(base)
}

pub fn fsm_scenario_overlay_00(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(0).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_01(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(1).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_02(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(2).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_03(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(3).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_04(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(4).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_05(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(5).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_06(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(6).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_07(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(7).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_08(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(8).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_09(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(9).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_10(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(10).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_11(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(11).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_12(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(12).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_13(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(13).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_14(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(14).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_15(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(15).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_16(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(16).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_17(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(17).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_18(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(18).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_19(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(19).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_20(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(20).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_21(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(21).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_22(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(22).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_23(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(23).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_24(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(24).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_25(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(25).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_26(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(26).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_27(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(27).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_28(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(28).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}

pub fn fsm_scenario_overlay_29(pnl: i64, fx_beta: i32) -> i64 {
    let shock = FSM_SCENARIO_TABLE.get(29).copied().unwrap_or(FSM_SCENARIO_TABLE[0]);
    pnl.saturating_add(shock.fx_shift_bps as i64 * i64::from(fx_beta) / 10_000)
}
