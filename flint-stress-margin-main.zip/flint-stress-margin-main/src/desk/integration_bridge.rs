//! Integration bridge invoking desk public entry points.

use super::*;

#[derive(Debug, Default)]
pub struct FsmDeskIntegrationReport {
    pub total_stressed_minor: i64,
    pub modules_touched: u32,
}

pub fn fsm_run_desk_integration_smoke(exposure: i64, collateral: i64) -> FsmDeskIntegrationReport {
    let mut report = FsmDeskIntegrationReport::default();
    {
        let grid = var_grid_engine::fsm_var_grid_from_pnl_series(1, &[(21, -exposure / 10)]);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            var_grid_engine::fsm_aggregate_var_cells(&grid.cells));
        report.modules_touched += 1;
    }
    {
        let book = greek_aggregation::FsmGreekBook::default();
        let leg = greek_aggregation::fsm_stress_greeks(&book, 50, 25);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(leg.delta);
        report.modules_touched += 1;
    }
    {
        let mut sched = margin_call_scheduler::fsm_margin_call_scheduler_default();
        let _ = sched.evaluate(1, exposure, collateral, 1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            margin_call_scheduler::fsm_total_outstanding_calls(&sched));
        report.modules_touched += 1;
    }
    {
        let hc = haircut_engine::fsm_lookup_haircut(1, 2, 90);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            haircut_engine::fsm_apply_haircut(collateral, hc));
        report.modules_touched += 1;
    }
    {
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            scenario_shock_table::fsm_scenario_worst_loss(exposure, (100, 80)));
        report.modules_touched += 1;
    }
    {
        let desk = ccp_margin_calculator::FsmCcpMarginCalculator::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            ccp_margin_calculator::fsm_ccp_margin_calculator_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = isda_csa_terms::FsmIsdaCsaTerms::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            isda_csa_terms::fsm_isda_csa_terms_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = delta_ladder_builder::FsmDeltaLadderBuilder::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            delta_ladder_builder::fsm_delta_ladder_builder_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = gamma_convexity_grid::FsmGammaConvexityGrid::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            gamma_convexity_grid::fsm_gamma_convexity_grid_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = vega_surface_stress::FsmVegaSurfaceStress::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            vega_surface_stress::fsm_vega_surface_stress_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = theta_decay_schedule::FsmThetaDecaySchedule::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            theta_decay_schedule::fsm_theta_decay_schedule_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = rho_curve_shift::FsmRhoCurveShift::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            rho_curve_shift::fsm_rho_curve_shift_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = fx_delta_netter::FsmFxDeltaNetter::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            fx_delta_netter::fsm_fx_delta_netter_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = irs_bucket_allocator::FsmIrsBucketAllocator::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            irs_bucket_allocator::fsm_irs_bucket_allocator_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = cds_spread_stressor::FsmCdsSpreadStressor::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            cds_spread_stressor::fsm_cds_spread_stressor_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = equity_beta_shock::FsmEquityBetaShock::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            equity_beta_shock::fsm_equity_beta_shock_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = commodity_basis_grid::FsmCommodityBasisGrid::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            commodity_basis_grid::fsm_commodity_basis_grid_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = options_iv_shock::FsmOptionsIvShock::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            options_iv_shock::fsm_options_iv_shock_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = cross_gamma_matrix::FsmCrossGammaMatrix::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            cross_gamma_matrix::fsm_cross_gamma_matrix_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = portfolio_nav_tracker::FsmPortfolioNavTracker::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            portfolio_nav_tracker::fsm_portfolio_nav_tracker_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = collateral_eligibility::FsmCollateralEligibility::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            collateral_eligibility::fsm_collateral_eligibility_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = funding_spread_ladder::FsmFundingSpreadLadder::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            funding_spread_ladder::fsm_funding_spread_ladder_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = liquidity_horizon_grid::FsmLiquidityHorizonGrid::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            liquidity_horizon_grid::fsm_liquidity_horizon_grid_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = exposure_limit_guard::FsmExposureLimitGuard::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            exposure_limit_guard::fsm_exposure_limit_guard_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = stress_correlation_break::FsmStressCorrelationBreak::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            stress_correlation_break::fsm_stress_correlation_break_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = swap_reset_calendar::FsmSwapResetCalendar::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            swap_reset_calendar::fsm_swap_reset_calendar_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = futures_roll_stress::FsmFuturesRollStress::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            futures_roll_stress::fsm_futures_roll_stress_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    {
        let desk = basis_swap_spread::FsmBasisSwapSpread::new(1);
        report.total_stressed_minor = report.total_stressed_minor.saturating_add(
            basis_swap_spread::fsm_basis_swap_spread_evaluate(&desk, 100));
        report.modules_touched += 1;
    }
    report
}
