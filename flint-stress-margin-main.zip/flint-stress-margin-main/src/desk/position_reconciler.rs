use crate::engine::scenario_merge::PortfolioSessionWire;

pub fn match_session_positions(session: &PortfolioSessionWire) -> u32 {
    let mut matched = 0u32;
    for leg in &session.legs {
        if leg.notional_minor != 0 && !leg.payload.is_empty() {
            matched += 1;
        }
    }
    matched
}
