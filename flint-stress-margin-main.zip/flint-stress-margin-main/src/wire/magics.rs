/// FSM stress batch wire magic `FSMB`.
pub const BATCH_MAGIC: [u8; 4] = *b"FSMB";

/// Scenario envelope capsule magic `FSME`.
pub const ENVELOPE_MAGIC: [u8; 4] = *b"FSME";

/// Portfolio session checkpoint magic `FSMS`.
pub const SESSION_MAGIC: [u8; 4] = *b"FSMS";

/// FIX margin confirmation frame `FSMF`.
pub const FIX_FRAME_MAGIC: [u8; 4] = *b"FSMF";

/// SWIFT collateral statement wrapper `FSMM`.
pub const MT940_FRAME_MAGIC: [u8; 4] = *b"FSMM";

pub const BATCH_VERSION: u16 = 1;
pub const ENVELOPE_VERSION: u16 = 1;
pub const SESSION_VERSION: u16 = 1;

pub fn matches_magic(buf: &[u8], magic: &[u8; 4]) -> bool {
    buf.len() >= 4 && &buf[..4] == magic
}
