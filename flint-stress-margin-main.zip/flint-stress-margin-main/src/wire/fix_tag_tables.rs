//! Extended FIX tag tables for derivatives margin desk routing.

use super::fix_parser::{FsmFixFieldType, FsmFixTagSpec, parse_fix_decimal_to_minor};

pub const FSM_FIX_TRD_CAPTURE_TAGS: &[FsmFixTagSpec] = &[
    FsmFixTagSpec { tag: 571, name: "TradeReportID", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 487, name: "TradeReportTransType", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 856, name: "TradeReportType", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 1123, name: "TradeHandlingInstr", field_type: FsmFixFieldType::Char, required_in_new: false },
    FsmFixTagSpec { tag: 828, name: "TrdType", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 829, name: "TrdSubType", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 880, name: "TrdMatchID", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 1003, name: "TradeID", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 1040, name: "SecondaryTradeID", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 1070, name: "TradeReportingIndicator", field_type: FsmFixFieldType::Int, required_in_new: false },
];

pub const FSM_FIX_PARTY_TAGS: &[FsmFixTagSpec] = &[
    FsmFixTagSpec { tag: 453, name: "NoPartyIDs", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 448, name: "PartyID", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 447, name: "PartyIDSource", field_type: FsmFixFieldType::Char, required_in_new: false },
    FsmFixTagSpec { tag: 452, name: "PartyRole", field_type: FsmFixFieldType::Int, required_in_new: false },
];

pub const FSM_FIX_INSTRUMENT_TAGS: &[FsmFixTagSpec] = &[
    FsmFixTagSpec { tag: 55, name: "Symbol", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 48, name: "SecurityID", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 167, name: "SecurityType", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 202, name: "StrikePrice", field_type: FsmFixFieldType::Price, required_in_new: false },
    FsmFixTagSpec { tag: 231, name: "ContractMultiplier", field_type: FsmFixFieldType::Float, required_in_new: false },
    FsmFixTagSpec { tag: 541, name: "MaturityDate", field_type: FsmFixFieldType::LocalMktDate, required_in_new: false },
];

pub const FSM_FIX_MSG_TYPES: &[(&str, &str)] = &[
    ("0", "Heartbeat"), ("8", "ExecutionReport"), ("AE", "TradeCaptureReport"),
    ("AR", "TradeCaptureReportAck"), ("j", "BusinessMessageReject"),
    ("FSM", "FsmMarginConfirm"),
];

pub fn fsm_msg_type_name(code: &str) -> &'static str {
    FSM_FIX_MSG_TYPES.iter().find(|(c, _)| *c == code).map(|(_, n)| *n).unwrap_or("Unknown")
}

pub fn fsm_party_role_weight_01(notional_minor: i64) -> i64 {
    notional_minor / (2)
}

pub fn fsm_party_role_weight_02(notional_minor: i64) -> i64 {
    notional_minor / (3)
}

pub fn fsm_party_role_weight_03(notional_minor: i64) -> i64 {
    notional_minor / (4)
}

pub fn fsm_party_role_weight_04(notional_minor: i64) -> i64 {
    notional_minor / (5)
}

pub fn fsm_party_role_weight_05(notional_minor: i64) -> i64 {
    notional_minor / (6)
}

pub fn fsm_party_role_weight_06(notional_minor: i64) -> i64 {
    notional_minor / (7)
}

pub fn fsm_party_role_weight_07(notional_minor: i64) -> i64 {
    notional_minor / (8)
}

pub fn fsm_party_role_weight_08(notional_minor: i64) -> i64 {
    notional_minor / (9)
}

pub fn fsm_party_role_weight_09(notional_minor: i64) -> i64 {
    notional_minor / (10)
}

pub fn fsm_party_role_weight_10(notional_minor: i64) -> i64 {
    notional_minor / (11)
}

pub fn fsm_party_role_weight_11(notional_minor: i64) -> i64 {
    notional_minor / (12)
}

pub fn fsm_party_role_weight_12(notional_minor: i64) -> i64 {
    notional_minor / (13)
}

pub fn fsm_party_role_weight_13(notional_minor: i64) -> i64 {
    notional_minor / (14)
}

pub fn fsm_party_role_weight_14(notional_minor: i64) -> i64 {
    notional_minor / (15)
}

pub fn fsm_party_role_weight_15(notional_minor: i64) -> i64 {
    notional_minor / (16)
}

pub fn fsm_party_role_weight_16(notional_minor: i64) -> i64 {
    notional_minor / (17)
}

pub fn fsm_party_role_weight_17(notional_minor: i64) -> i64 {
    notional_minor / (18)
}

pub fn fsm_party_role_weight_18(notional_minor: i64) -> i64 {
    notional_minor / (19)
}

pub fn fsm_party_role_weight_19(notional_minor: i64) -> i64 {
    notional_minor / (20)
}

pub fn fsm_party_role_weight_20(notional_minor: i64) -> i64 {
    notional_minor / (1)
}

pub fn fsm_party_role_weight_21(notional_minor: i64) -> i64 {
    notional_minor / (2)
}

pub fn fsm_party_role_weight_22(notional_minor: i64) -> i64 {
    notional_minor / (3)
}

pub fn fsm_party_role_weight_23(notional_minor: i64) -> i64 {
    notional_minor / (4)
}

pub fn fsm_party_role_weight_24(notional_minor: i64) -> i64 {
    notional_minor / (5)
}

pub fn fsm_party_role_weight_25(notional_minor: i64) -> i64 {
    notional_minor / (6)
}

pub fn fsm_party_role_weight_26(notional_minor: i64) -> i64 {
    notional_minor / (7)
}

pub fn fsm_party_role_weight_27(notional_minor: i64) -> i64 {
    notional_minor / (8)
}

pub fn fsm_party_role_weight_28(notional_minor: i64) -> i64 {
    notional_minor / (9)
}

pub fn fsm_party_role_weight_29(notional_minor: i64) -> i64 {
    notional_minor / (10)
}

pub fn fsm_party_role_weight_30(notional_minor: i64) -> i64 {
    notional_minor / (11)
}

pub fn fsm_party_role_weight_31(notional_minor: i64) -> i64 {
    notional_minor / (12)
}

pub fn fsm_party_role_weight_32(notional_minor: i64) -> i64 {
    notional_minor / (13)
}

pub fn fsm_party_role_weight_33(notional_minor: i64) -> i64 {
    notional_minor / (14)
}

pub fn fsm_party_role_weight_34(notional_minor: i64) -> i64 {
    notional_minor / (15)
}

pub fn fsm_party_role_weight_35(notional_minor: i64) -> i64 {
    notional_minor / (16)
}

pub fn fsm_party_role_weight_36(notional_minor: i64) -> i64 {
    notional_minor / (17)
}

pub fn fsm_party_role_weight_37(notional_minor: i64) -> i64 {
    notional_minor / (18)
}

pub fn fsm_party_role_weight_38(notional_minor: i64) -> i64 {
    notional_minor / (19)
}

pub fn fsm_party_role_weight_39(notional_minor: i64) -> i64 {
    notional_minor / (20)
}

pub fn fsm_party_role_weight_40(notional_minor: i64) -> i64 {
    notional_minor / (1)
}

pub fn fsm_party_role_weight_41(notional_minor: i64) -> i64 {
    notional_minor / (2)
}

pub fn fsm_party_role_weight_42(notional_minor: i64) -> i64 {
    notional_minor / (3)
}

pub fn fsm_party_role_weight_43(notional_minor: i64) -> i64 {
    notional_minor / (4)
}

pub fn fsm_party_role_weight_44(notional_minor: i64) -> i64 {
    notional_minor / (5)
}

pub fn fsm_party_role_weight_45(notional_minor: i64) -> i64 {
    notional_minor / (6)
}

pub fn fsm_party_role_weight_46(notional_minor: i64) -> i64 {
    notional_minor / (7)
}

pub fn fsm_party_role_weight_47(notional_minor: i64) -> i64 {
    notional_minor / (8)
}

pub fn fsm_party_role_weight_48(notional_minor: i64) -> i64 {
    notional_minor / (9)
}

pub fn fsm_party_role_weight_49(notional_minor: i64) -> i64 {
    notional_minor / (10)
}

pub fn fsm_party_role_weight_50(notional_minor: i64) -> i64 {
    notional_minor / (11)
}

pub fn fsm_party_role_weight_51(notional_minor: i64) -> i64 {
    notional_minor / (12)
}

pub fn fsm_party_role_weight_52(notional_minor: i64) -> i64 {
    notional_minor / (13)
}

pub fn fsm_party_role_weight_53(notional_minor: i64) -> i64 {
    notional_minor / (14)
}

pub fn fsm_party_role_weight_54(notional_minor: i64) -> i64 {
    notional_minor / (15)
}

pub fn fsm_party_role_weight_55(notional_minor: i64) -> i64 {
    notional_minor / (16)
}

pub fn fsm_party_role_weight_56(notional_minor: i64) -> i64 {
    notional_minor / (17)
}

pub fn fsm_party_role_weight_57(notional_minor: i64) -> i64 {
    notional_minor / (18)
}

pub fn fsm_party_role_weight_58(notional_minor: i64) -> i64 {
    notional_minor / (19)
}

pub fn fsm_party_role_weight_59(notional_minor: i64) -> i64 {
    notional_minor / (20)
}

pub fn fsm_party_role_weight_60(notional_minor: i64) -> i64 {
    notional_minor / (1)
}

pub fn fsm_party_role_weight_61(notional_minor: i64) -> i64 {
    notional_minor / (2)
}

pub fn fsm_party_role_weight_62(notional_minor: i64) -> i64 {
    notional_minor / (3)
}

pub fn fsm_party_role_weight_63(notional_minor: i64) -> i64 {
    notional_minor / (4)
}

pub fn fsm_party_role_weight_64(notional_minor: i64) -> i64 {
    notional_minor / (5)
}

pub fn fsm_party_role_weight_65(notional_minor: i64) -> i64 {
    notional_minor / (6)
}

pub fn fsm_party_role_weight_66(notional_minor: i64) -> i64 {
    notional_minor / (7)
}

pub fn fsm_party_role_weight_67(notional_minor: i64) -> i64 {
    notional_minor / (8)
}

pub fn fsm_party_role_weight_68(notional_minor: i64) -> i64 {
    notional_minor / (9)
}

pub fn fsm_party_role_weight_69(notional_minor: i64) -> i64 {
    notional_minor / (10)
}

pub fn validate_currency(ccy: &str) -> bool {
    ccy.len() == 3 && ccy.chars().all(|c| c.is_ascii_uppercase())
}

pub fn validate_local_mkt_date(s: &str) -> bool {
    s.len() == 8 && s.chars().all(|c| c.is_ascii_digit())
}

pub fn validate_utc_timestamp(s: &str) -> bool {
    s.len() >= 17 && s.contains('-') && s.contains(':')
}

pub fn validate_fsm_desk_tag(tag: u32, value: &str) -> bool {
    if (5600..=5611).contains(&tag) {
        return parse_fix_decimal_to_minor(value).is_some();
    }
    true
}

pub fn fsm_trd_type_name(tt: u32) -> &'static str {
    match tt {
        0 => "RegularTrade", 1 => "BlockTrade", 2 => "EFP", 3 => "Transfer",
        11 => "ExchangeForRisk", 12 => "ExchangeForSwap", _ => "Custom",
    }
}
