//! FIX 4.4 parser for trade-capture and margin confirmation frames.

use crate::util::bounded::{MAX_FIX_FIELDS, MAX_WIRE_FRAME};
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsmFixFieldType {
    String, Char, Int, Float, Qty, Price, Amt, Boolean, UtcTimestamp, LocalMktDate,
}

#[derive(Debug, Clone, Copy)]
pub struct FsmFixTagSpec {
    pub tag: u32,
    pub name: &'static str,
    pub field_type: FsmFixFieldType,
    pub required_in_new: bool,
}

pub const FSM_FIX_HEADER_TAGS: &[FsmFixTagSpec] = &[
    FsmFixTagSpec { tag: 8, name: "BeginString", field_type: FsmFixFieldType::String, required_in_new: true },
    FsmFixTagSpec { tag: 9, name: "BodyLength", field_type: FsmFixFieldType::Int, required_in_new: true },
    FsmFixTagSpec { tag: 35, name: "MsgType", field_type: FsmFixFieldType::String, required_in_new: true },
    FsmFixTagSpec { tag: 49, name: "SenderCompID", field_type: FsmFixFieldType::String, required_in_new: true },
    FsmFixTagSpec { tag: 56, name: "TargetCompID", field_type: FsmFixFieldType::String, required_in_new: true },
    FsmFixTagSpec { tag: 34, name: "MsgSeqNum", field_type: FsmFixFieldType::Int, required_in_new: true },
    FsmFixTagSpec { tag: 52, name: "SendingTime", field_type: FsmFixFieldType::UtcTimestamp, required_in_new: true },
];

pub const FSM_FIX_MARGIN_TAGS: &[FsmFixTagSpec] = &[
    FsmFixTagSpec { tag: 15, name: "Currency", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 54, name: "Side", field_type: FsmFixFieldType::Char, required_in_new: false },
    FsmFixTagSpec { tag: 55, name: "Symbol", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 167, name: "SecurityType", field_type: FsmFixFieldType::String, required_in_new: false },
    FsmFixTagSpec { tag: 381, name: "GrossTradeAmt", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 715, name: "ClearingInstruction", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 828, name: "TrdType", field_type: FsmFixFieldType::Int, required_in_new: false },
    FsmFixTagSpec { tag: 880, name: "TrdMatchID", field_type: FsmFixFieldType::String, required_in_new: false },
];

pub const FSM_FIX_DESK_TAGS: &[FsmFixTagSpec] = &[
    FsmFixTagSpec { tag: 5600, name: "FsmDeskTag0", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5601, name: "FsmDeskTag1", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5602, name: "FsmDeskTag2", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5603, name: "FsmDeskTag3", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5604, name: "FsmDeskTag4", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5605, name: "FsmDeskTag5", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5606, name: "FsmDeskTag6", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5607, name: "FsmDeskTag7", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5608, name: "FsmDeskTag8", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5609, name: "FsmDeskTag9", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5610, name: "FsmDeskTag10", field_type: FsmFixFieldType::Amt, required_in_new: false },
    FsmFixTagSpec { tag: 5611, name: "FsmDeskTag11", field_type: FsmFixFieldType::Amt, required_in_new: false },
];

#[derive(Debug, Clone, PartialEq)]
pub struct FsmFixField { pub tag: u32, pub value: String }

#[derive(Debug, Clone, PartialEq)]
pub struct FsmFixMessage { pub fields: Vec<FsmFixField>, pub checksum: u32 }

impl FsmFixMessage {
    pub fn get(&self, tag: u32) -> Option<&str> {
        self.fields.iter().find(|f| f.tag == tag).map(|f| f.value.as_str())
    }
    pub fn msg_type(&self) -> Option<&str> { self.get(35) }
}

pub fn parse_fix_decimal_to_minor(value: &str) -> Option<i64> {
    let neg = value.starts_with('-');
    let digits: String = value.chars().filter(|c| c.is_ascii_digit()).collect();
    let whole: i64 = digits.parse().ok()?;
    Some(if neg { -whole } else { whole })
}

pub fn parse_fix_message(raw: &str) -> Result<FsmFixMessage, &'static str> {
    if raw.len() > MAX_WIRE_FRAME { return Err("frame too large"); }
    let mut fields = Vec::new();
    for part in raw.split('\x01') {
        if part.is_empty() { continue; }
        let Some((tag_s, val)) = part.split_once('=') else { return Err("bad field"); };
        let tag: u32 = tag_s.parse().map_err(|_| "bad tag")?;
        if fields.len() >= MAX_FIX_FIELDS { return Err("too many fields"); }
        fields.push(FsmFixField { tag, value: val.to_string() });
    }
    let checksum = fields.iter().fold(0u32, |acc, f| acc.wrapping_add(f.tag));
    Ok(FsmFixMessage { fields, checksum })
}

pub fn build_tag_lookup() -> HashMap<u32, &'static FsmFixTagSpec> {
    let mut m = HashMap::new();
    for spec in FSM_FIX_HEADER_TAGS.iter().chain(FSM_FIX_MARGIN_TAGS.iter()).chain(FSM_FIX_DESK_TAGS.iter()) {
        m.insert(spec.tag, spec);
    }
    m
}

pub fn fsm_fix_side_scale_00(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_01(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_02(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_03(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_04(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_05(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_06(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_07(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_08(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_09(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_10(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_11(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_12(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_13(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_14(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_15(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_16(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_17(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_18(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_19(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_20(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_21(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_22(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_23(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_24(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_25(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_26(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_27(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_28(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_29(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_30(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_31(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_32(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_33(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_34(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_35(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_36(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_37(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_38(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_39(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_40(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_41(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_42(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_43(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_44(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_45(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_46(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_47(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_48(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_49(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_50(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_51(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}

pub fn fsm_fix_side_scale_52(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (3) }
}

pub fn fsm_fix_side_scale_53(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (4) }
}

pub fn fsm_fix_side_scale_54(qty_minor: i64, side: char) -> i64 {
    match side { '1' => qty_minor, '2' => -qty_minor, _ => qty_minor / (2) }
}
