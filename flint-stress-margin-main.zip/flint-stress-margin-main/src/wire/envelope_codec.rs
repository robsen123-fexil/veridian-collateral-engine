use crate::util::bounded::{read_u16_le, read_u32_le, slice_at, MAX_ENVELOPE_DEPTH, MAX_WIRE_FRAME};
use crate::wire::magics::{ENVELOPE_MAGIC, ENVELOPE_VERSION};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EnvelopeHeader {
    pub channel_id: u16,
    pub depth: u16,
    pub payload_len: u32,
    pub child_count: u16,
    pub flags: u16,
}

#[derive(Debug, Clone)]
pub struct EnvelopeNode {
    pub header: EnvelopeHeader,
    pub payload: Vec<u8>,
    pub children: Vec<EnvelopeNode>,
}

#[derive(Debug, Default)]
pub struct EnvelopeWireTree {
    pub roots: Vec<EnvelopeNode>,
    pub total_nodes: usize,
}

impl EnvelopeWireTree {
    pub fn abort_partial(&mut self) {
        self.roots.clear();
        self.total_nodes = 0;
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EnvelopeDecodeError {
    BadMagic,
    Truncated,
    DepthExceeded,
    FrameTooLarge,
    ChildOverflow,
}

pub fn decode_envelope_tree(input: &[u8]) -> Result<EnvelopeWireTree, EnvelopeDecodeError> {
    if input.len() < 8 {
        return Err(EnvelopeDecodeError::Truncated);
    }
    if &input[..4] != ENVELOPE_MAGIC {
        return Err(EnvelopeDecodeError::BadMagic);
    }
    if input.len() > MAX_WIRE_FRAME {
        return Err(EnvelopeDecodeError::FrameTooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(EnvelopeDecodeError::Truncated)?;
    if version != ENVELOPE_VERSION {
        return Err(EnvelopeDecodeError::Truncated);
    }
    let root_count = read_u16_le(input, 6).ok_or(EnvelopeDecodeError::Truncated)?;
    let mut offset = 8usize;
    let mut tree = EnvelopeWireTree::default();

    for _ in 0..root_count {
        let (node, next) = parse_envelope_node(input, offset, 0)?;
        offset = next;
        tree.total_nodes += 1 + count_descendants(&node);
        tree.roots.push(node);
    }
    Ok(tree)
}

fn count_descendants(node: &EnvelopeNode) -> usize {
    node.children.iter().map(|c| 1 + count_descendants(c)).sum()
}

fn parse_envelope_node(
    input: &[u8],
    offset: usize,
    depth: usize,
) -> Result<(EnvelopeNode, usize), EnvelopeDecodeError> {
    if depth > MAX_ENVELOPE_DEPTH {
        return Err(EnvelopeDecodeError::DepthExceeded);
    }
    if offset + 12 > input.len() {
        return Err(EnvelopeDecodeError::Truncated);
    }
    let channel_id = read_u16_le(input, offset).ok_or(EnvelopeDecodeError::Truncated)?;
    let node_depth = read_u16_le(input, offset + 2).ok_or(EnvelopeDecodeError::Truncated)?;
    let payload_len = read_u32_le(input, offset + 4).ok_or(EnvelopeDecodeError::Truncated)?;
    let child_count = read_u16_le(input, offset + 8).ok_or(EnvelopeDecodeError::Truncated)?;
    let flags = read_u16_le(input, offset + 10).ok_or(EnvelopeDecodeError::Truncated)?;
    let mut pos = offset + 12;

    let payload = slice_at(input, pos, payload_len as usize)
        .ok_or(EnvelopeDecodeError::Truncated)?
        .to_vec();
    pos += payload_len as usize;

    if child_count as usize > MAX_ENVELOPE_DEPTH {
        return Err(EnvelopeDecodeError::ChildOverflow);
    }

    let header = EnvelopeHeader {
        channel_id,
        depth: node_depth,
        payload_len,
        child_count,
        flags,
    };

    let mut children = Vec::with_capacity(child_count as usize);
    for _ in 0..child_count {
        let (child, next) = parse_envelope_node(input, pos, depth + 1)?;
        pos = next;
        children.push(child);
    }

    Ok((
        EnvelopeNode {
            header,
            payload,
            children,
        },
        pos,
    ))
}

pub fn wrap_envelope_wire(nodes: &[EnvelopeNode]) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&ENVELOPE_MAGIC);
    out.extend_from_slice(&ENVELOPE_VERSION.to_le_bytes());
    out.extend_from_slice(&(nodes.len() as u16).to_le_bytes());
    for n in nodes {
        append_node(&mut out, n);
    }
    out
}

fn append_node(out: &mut Vec<u8>, node: &EnvelopeNode) {
    out.extend_from_slice(&node.header.channel_id.to_le_bytes());
    out.extend_from_slice(&node.header.depth.to_le_bytes());
    out.extend_from_slice(&(node.payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&(node.children.len() as u16).to_le_bytes());
    out.extend_from_slice(&node.header.flags.to_le_bytes());
    out.extend_from_slice(&node.payload);
    for child in &node.children {
        append_node(out, child);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_envelope() {
        let node = EnvelopeNode {
            header: EnvelopeHeader {
                channel_id: 7,
                depth: 0,
                payload_len: 3,
                child_count: 0,
                flags: 1,
            },
            payload: vec![1, 2, 3],
            children: vec![],
        };
        let wire = wrap_envelope_wire(&[node]);
        let tree = decode_envelope_tree(&wire).expect("decode");
        assert_eq!(tree.roots.len(), 1);
    }
}
