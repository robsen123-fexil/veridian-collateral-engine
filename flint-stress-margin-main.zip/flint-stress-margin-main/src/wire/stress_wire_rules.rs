use crate::wire::magics::{BATCH_MAGIC, ENVELOPE_MAGIC, SESSION_MAGIC};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WireClass {
    StressBatch,
    ScenarioEnvelope,
    PortfolioSession,
    Unknown,
}

pub fn classify_wire_prefix(input: &[u8]) -> WireClass {
    if input.len() < 4 {
        return WireClass::Unknown;
    }
    match &input[..4] {
        b if b == BATCH_MAGIC => WireClass::StressBatch,
        b if b == ENVELOPE_MAGIC => WireClass::ScenarioEnvelope,
        b if b == SESSION_MAGIC => WireClass::PortfolioSession,
        _ => WireClass::Unknown,
    }
}
