//! Wire codecs for FSM stress-margin frames.

pub mod magics;
pub mod batch_codec;
pub mod envelope_codec;
pub mod stress_wire_rules;
pub mod fix_parser;
pub mod fix_tag_tables;
pub mod fix_validation_engine;
pub mod swift_field_scanner;
pub mod swift_mt940;
