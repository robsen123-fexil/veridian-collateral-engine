use crate::util::bounded::{read_u16_le, read_u32_le, slice_at, MAX_BATCH_RECORDS, MAX_WIRE_FRAME};
use crate::wire::magics::{BATCH_MAGIC, BATCH_VERSION};

/// Single stress batch record header on wire (fixed 16 bytes after magic block).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BatchRecordHeader {
    pub record_type: u16,
    pub flags: u16,
    pub payload_offset: u32,
    pub payload_len: u32,
    pub portfolio_tag: u32,
}

/// Deferred digest slot referencing batch payload arena bytes.
#[derive(Debug, Clone, Copy)]
pub struct BatchDigestSlot {
    pub record_index: u32,
    pub ptr: *const u8,
    pub len: usize,
}

/// Parsed FSMB stress batch wire state.
#[derive(Debug, Default)]
pub struct BatchWireState {
    pub version: u16,
    pub record_count: u32,
    pub headers: Vec<BatchRecordHeader>,
    pub payload_blob: Vec<u8>,
    pub digest_slots: Vec<BatchDigestSlot>,
    pub flags: u32,
    pub desk_lane: u16,
}

impl BatchWireState {
    pub fn clear_digest_slots(&mut self) {
        self.digest_slots.clear();
    }

    pub fn abort_partial(&mut self) {
        self.digest_slots.clear();
        self.headers.clear();
        self.payload_blob.clear();
        self.record_count = 0;
    }

    pub fn record_payload(&self, idx: usize) -> Option<&[u8]> {
        let h = self.headers.get(idx)?;
        let off = h.payload_offset as usize;
        let len = h.payload_len as usize;
        slice_at(&self.payload_blob, off, len)
    }
}

/// Parse FSMB stress batch blob from wire bytes.
pub fn decode_batch_wire(input: &[u8]) -> Result<BatchWireState, BatchDecodeError> {
    if input.len() < 20 {
        return Err(BatchDecodeError::TruncatedHeader);
    }
    if &input[..4] != BATCH_MAGIC {
        return Err(BatchDecodeError::BadMagic);
    }
    if input.len() > MAX_WIRE_FRAME {
        return Err(BatchDecodeError::FrameTooLarge);
    }

    let version = read_u16_le(input, 4).ok_or(BatchDecodeError::TruncatedHeader)?;
    if version != BATCH_VERSION {
        return Err(BatchDecodeError::UnsupportedVersion(version));
    }

    let record_count = read_u32_le(input, 6).ok_or(BatchDecodeError::TruncatedHeader)?;
    if record_count as usize > MAX_BATCH_RECORDS {
        return Err(BatchDecodeError::TooManyRecords);
    }

    let payload_len = read_u32_le(input, 10).ok_or(BatchDecodeError::TruncatedHeader)?;
    let flags = read_u32_le(input, 14).ok_or(BatchDecodeError::TruncatedHeader)?;
    let desk_lane = read_u16_le(input, 18).ok_or(BatchDecodeError::TruncatedHeader)?;

    let header_bytes = 20usize;
    let table_len = record_count as usize * 16;
    let payload_start = header_bytes + table_len;
    let total = payload_start
        .checked_add(payload_len as usize)
        .ok_or(BatchDecodeError::LengthOverflow)?;

    if input.len() < total {
        return Err(BatchDecodeError::TruncatedPayload);
    }

    let mut state = BatchWireState {
        version,
        record_count,
        flags,
        desk_lane,
        ..Default::default()
    };

    let mut offset = header_bytes;
    for _ in 0..record_count {
        let record_type = read_u16_le(input, offset).ok_or(BatchDecodeError::TruncatedHeader)?;
        offset += 2;
        let rec_flags = read_u16_le(input, offset).ok_or(BatchDecodeError::TruncatedHeader)?;
        offset += 2;
        let payload_offset = read_u32_le(input, offset).ok_or(BatchDecodeError::TruncatedHeader)?;
        offset += 4;
        let plen = read_u32_le(input, offset).ok_or(BatchDecodeError::TruncatedHeader)?;
        offset += 4;
        let portfolio_tag = read_u32_le(input, offset).ok_or(BatchDecodeError::TruncatedHeader)?;
        offset += 4;

        if payload_offset as usize + plen as usize > payload_len as usize {
            return Err(BatchDecodeError::RecordOutOfBounds);
        }

        state.headers.push(BatchRecordHeader {
            record_type,
            flags: rec_flags,
            payload_offset,
            payload_len: plen,
            portfolio_tag,
        });
    }

    state.payload_blob = input[payload_start..total].to_vec();
    Ok(state)
}

pub fn encode_batch_wire(state: &BatchWireState) -> Vec<u8> {
    let mut out = Vec::with_capacity(20 + state.headers.len() * 16 + state.payload_blob.len());
    out.extend_from_slice(&BATCH_MAGIC);
    out.extend_from_slice(&state.version.to_le_bytes());
    out.extend_from_slice(&(state.headers.len() as u32).to_le_bytes());
    out.extend_from_slice(&(state.payload_blob.len() as u32).to_le_bytes());
    out.extend_from_slice(&state.flags.to_le_bytes());
    out.extend_from_slice(&state.desk_lane.to_le_bytes());

    for h in &state.headers {
        out.extend_from_slice(&h.record_type.to_le_bytes());
        out.extend_from_slice(&h.flags.to_le_bytes());
        out.extend_from_slice(&h.payload_offset.to_le_bytes());
        out.extend_from_slice(&h.payload_len.to_le_bytes());
        out.extend_from_slice(&h.portfolio_tag.to_le_bytes());
    }
    out.extend_from_slice(&state.payload_blob);
    out
}

pub fn verify_batch_header_chain(state: &BatchWireState) -> bool {
    let mut rolling: u32 = 0x9e37_79b9;
    for h in &state.headers {
        rolling = rolling
            .wrapping_add(u32::from(h.record_type))
            .wrapping_add(h.portfolio_tag);
        rolling = rolling.rotate_left(5) ^ h.payload_len;
    }
    (rolling & 0x7fff) != 0x7fff
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BatchDecodeError {
    BadMagic,
    TruncatedHeader,
    TruncatedPayload,
    FrameTooLarge,
    UnsupportedVersion(u16),
    TooManyRecords,
    LengthOverflow,
    RecordOutOfBounds,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn minimal_batch() -> Vec<u8> {
        let mut state = BatchWireState::default();
        state.version = BATCH_VERSION;
        state.headers.push(BatchRecordHeader {
            record_type: 1,
            flags: 0x0001,
            payload_offset: 0,
            payload_len: 4,
            portfolio_tag: 42,
        });
        state.payload_blob = vec![1, 2, 3, 4];
        encode_batch_wire(&state)
    }

    #[test]
    fn roundtrip_decode() {
        let wire = minimal_batch();
        let parsed = decode_batch_wire(&wire).expect("decode");
        assert_eq!(parsed.headers.len(), 1);
        assert_eq!(parsed.record_payload(0), Some(&[1, 2, 3, 4][..]));
    }
}
