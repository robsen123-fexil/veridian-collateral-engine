//! SWIFT MT940 collateral statement parser for margin accounts.

use super::swift_field_scanner::{FsmSwiftField, fsm_scan_swift_line};

#[derive(Debug, Default, Clone)]
pub struct FsmMt940Statement {
    pub account: String, pub statement_no: u32, pub opening_minor: i64,
    pub closing_minor: i64, pub lines: Vec<String>,
}

pub fn fsm_parse_mt940(raw: &str) -> FsmMt940Statement {
    let mut stmt = FsmMt940Statement::default();
    for line in raw.lines() {
        match fsm_scan_swift_line(line) {
            Some(FsmSwiftField::Account(a)) => stmt.account = a,
            Some(FsmSwiftField::StatementNumber(n)) => stmt.statement_no = n,
            Some(FsmSwiftField::OpeningBalance(amt, dc)) => {
                stmt.opening_minor = if dc == 'D' { -amt } else { amt };
            }
            Some(FsmSwiftField::ClosingBalance(amt, dc)) => {
                stmt.closing_minor = if dc == 'D' { -amt } else { amt };
            }
            Some(FsmSwiftField::TransactionLine(t)) => stmt.lines.push(t),
            _ => {}
        }
    }
    stmt
}

pub fn fsm_mt940_net_movement(stmt: &FsmMt940Statement) -> i64 { stmt.closing_minor - stmt.opening_minor }

pub fn fsm_mt940_line_classify_00(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_01(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_02(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_03(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_04(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_05(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_06(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_07(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_08(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_09(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_10(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_11(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_12(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_13(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_14(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_15(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_16(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_17(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_18(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_19(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_20(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_21(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_22(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_23(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_24(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_25(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_26(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_27(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_28(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_29(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_30(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_31(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_32(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_33(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_34(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_35(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_36(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_37(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_38(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_39(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_40(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_41(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_42(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_line_classify_43(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 1 }
}

pub fn fsm_mt940_line_classify_44(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 2 }
}

pub fn fsm_mt940_line_classify_45(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 3 }
}

pub fn fsm_mt940_line_classify_46(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 4 }
}

pub fn fsm_mt940_line_classify_47(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 5 }
}

pub fn fsm_mt940_line_classify_48(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 6 }
}

pub fn fsm_mt940_line_classify_49(line: &str) -> u8 {
    if line.contains("NTRF") { 1 } else if line.contains("NCHG") { 2 } else { 0 }
}

pub fn fsm_mt940_collateral_tag_00(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (1) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_01(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (2) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_02(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (3) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_03(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (4) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_04(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (5) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_05(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (6) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_06(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (7) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_07(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (8) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_08(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (9) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_09(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (10) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_10(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (11) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_11(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (12) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_12(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (13) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_13(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (14) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_14(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (15) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_15(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (16) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_16(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (17) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_17(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (18) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_18(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (19) + stmt.lines.len() as i64
}

pub fn fsm_mt940_collateral_tag_19(stmt: &FsmMt940Statement) -> i64 {
    stmt.opening_minor / (20) + stmt.lines.len() as i64
}
