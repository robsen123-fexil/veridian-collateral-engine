//! SWIFT field scanner for collateral statement tags.

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FsmSwiftField {
    Account(String), StatementNumber(u32), OpeningBalance(i64, char),
    ClosingBalance(i64, char), TransactionLine(String), Unknown(String, String),
}

pub fn fsm_scan_swift_line(line: &str) -> Option<FsmSwiftField> {
    let line = line.trim();
    if line.starts_with(":20:") { return Some(FsmSwiftField::Account(line[4..].to_string())); }
    if line.starts_with(":28C:") {
        let num: u32 = line[5..].chars().filter(|c| c.is_ascii_digit()).collect::<String>().parse().ok()?;
        return Some(FsmSwiftField::StatementNumber(num));
    }
    if line.starts_with(":60F:") || line.starts_with(":60M:") { return parse_balance_line(line, true); }
    if line.starts_with(":62F:") || line.starts_with(":62M:") { return parse_balance_line(line, false); }
    if line.starts_with(":61:") { return Some(FsmSwiftField::TransactionLine(line[4..].to_string())); }
    None
}

fn parse_balance_line(line: &str, opening: bool) -> Option<FsmSwiftField> {
    let payload = line.split(':').nth(2)?;
    if payload.len() < 2 { return None; }
    let dc = payload.chars().next()?;
    let amt_s: String = payload[1..].chars().filter(|c| c.is_ascii_digit() || *c == ',').collect();
    let minor = (amt_s.replace(',', ".").parse::<f64>().ok()? * 100.0).round() as i64;
    if opening { Some(FsmSwiftField::OpeningBalance(minor, dc)) }
    else { Some(FsmSwiftField::ClosingBalance(minor, dc)) }
}

pub fn fsm_swift_tag_weight_00(line: &str) -> u32 {
    line.len() as u32 + 0 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_01(line: &str) -> u32 {
    line.len() as u32 + 1 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_02(line: &str) -> u32 {
    line.len() as u32 + 2 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_03(line: &str) -> u32 {
    line.len() as u32 + 3 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_04(line: &str) -> u32 {
    line.len() as u32 + 4 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_05(line: &str) -> u32 {
    line.len() as u32 + 5 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_06(line: &str) -> u32 {
    line.len() as u32 + 6 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_07(line: &str) -> u32 {
    line.len() as u32 + 7 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_08(line: &str) -> u32 {
    line.len() as u32 + 8 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_09(line: &str) -> u32 {
    line.len() as u32 + 9 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_10(line: &str) -> u32 {
    line.len() as u32 + 10 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_11(line: &str) -> u32 {
    line.len() as u32 + 11 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_12(line: &str) -> u32 {
    line.len() as u32 + 12 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_13(line: &str) -> u32 {
    line.len() as u32 + 13 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_14(line: &str) -> u32 {
    line.len() as u32 + 14 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_15(line: &str) -> u32 {
    line.len() as u32 + 15 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_16(line: &str) -> u32 {
    line.len() as u32 + 16 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_17(line: &str) -> u32 {
    line.len() as u32 + 17 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_18(line: &str) -> u32 {
    line.len() as u32 + 18 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_19(line: &str) -> u32 {
    line.len() as u32 + 19 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_20(line: &str) -> u32 {
    line.len() as u32 + 20 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_21(line: &str) -> u32 {
    line.len() as u32 + 21 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_22(line: &str) -> u32 {
    line.len() as u32 + 22 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_23(line: &str) -> u32 {
    line.len() as u32 + 23 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_24(line: &str) -> u32 {
    line.len() as u32 + 24 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_25(line: &str) -> u32 {
    line.len() as u32 + 25 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_26(line: &str) -> u32 {
    line.len() as u32 + 26 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_27(line: &str) -> u32 {
    line.len() as u32 + 27 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_28(line: &str) -> u32 {
    line.len() as u32 + 28 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_29(line: &str) -> u32 {
    line.len() as u32 + 29 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_30(line: &str) -> u32 {
    line.len() as u32 + 30 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_31(line: &str) -> u32 {
    line.len() as u32 + 31 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_32(line: &str) -> u32 {
    line.len() as u32 + 32 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_33(line: &str) -> u32 {
    line.len() as u32 + 33 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_34(line: &str) -> u32 {
    line.len() as u32 + 34 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_35(line: &str) -> u32 {
    line.len() as u32 + 35 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_36(line: &str) -> u32 {
    line.len() as u32 + 36 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_37(line: &str) -> u32 {
    line.len() as u32 + 37 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_38(line: &str) -> u32 {
    line.len() as u32 + 38 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_39(line: &str) -> u32 {
    line.len() as u32 + 39 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_40(line: &str) -> u32 {
    line.len() as u32 + 40 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_41(line: &str) -> u32 {
    line.len() as u32 + 41 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_42(line: &str) -> u32 {
    line.len() as u32 + 42 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_43(line: &str) -> u32 {
    line.len() as u32 + 43 + line.matches(':').count() as u32
}

pub fn fsm_swift_tag_weight_44(line: &str) -> u32 {
    line.len() as u32 + 44 + line.matches(':').count() as u32
}
