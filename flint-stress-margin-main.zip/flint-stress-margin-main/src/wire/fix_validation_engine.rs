//! FIX validation engine for margin confirmation messages.

use super::fix_parser::{FsmFixMessage, parse_fix_message};
use super::fix_tag_tables::{validate_currency, validate_fsm_desk_tag, validate_utc_timestamp};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FsmFixValidationError { ParseFailed, MissingMsgType, BadCurrency, BadTimestamp, BadDeskTag }

pub struct FsmFixValidationReport { pub errors: Vec<FsmFixValidationError>, pub warnings: u32 }

impl FsmFixValidationReport { pub fn ok(&self) -> bool { self.errors.is_empty() } }

pub fn fsm_validate_fix_margin_frame(raw: &str) -> FsmFixValidationReport {
    let mut report = FsmFixValidationReport { errors: Vec::new(), warnings: 0 };
    let msg = match parse_fix_message(raw) {
        Ok(m) => m,
        Err(_) => { report.errors.push(FsmFixValidationError::ParseFailed); return report; }
    };
    if msg.msg_type().is_none() { report.errors.push(FsmFixValidationError::MissingMsgType); }
    if let Some(ccy) = msg.get(15) { if !validate_currency(ccy) { report.errors.push(FsmFixValidationError::BadCurrency); } }
    if let Some(ts) = msg.get(52) { if !validate_utc_timestamp(ts) { report.errors.push(FsmFixValidationError::BadTimestamp); } }
    for field in &msg.fields {
        if !validate_fsm_desk_tag(field.tag, &field.value) {
            report.errors.push(FsmFixValidationError::BadDeskTag); break;
        }
    }
    report
}

pub fn fsm_validate_trade_capture(msg: &FsmFixMessage) -> bool {
    msg.msg_type() == Some("AE") && msg.get(55).is_some()
}

pub fn fsm_validation_rule_00(msg: &FsmFixMessage) -> u32 {
    let mut score = 0;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_01(msg: &FsmFixMessage) -> u32 {
    let mut score = 1;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_02(msg: &FsmFixMessage) -> u32 {
    let mut score = 2;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_03(msg: &FsmFixMessage) -> u32 {
    let mut score = 3;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_04(msg: &FsmFixMessage) -> u32 {
    let mut score = 4;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_05(msg: &FsmFixMessage) -> u32 {
    let mut score = 5;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_06(msg: &FsmFixMessage) -> u32 {
    let mut score = 6;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_07(msg: &FsmFixMessage) -> u32 {
    let mut score = 7;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_08(msg: &FsmFixMessage) -> u32 {
    let mut score = 8;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_09(msg: &FsmFixMessage) -> u32 {
    let mut score = 9;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_10(msg: &FsmFixMessage) -> u32 {
    let mut score = 10;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_11(msg: &FsmFixMessage) -> u32 {
    let mut score = 11;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_12(msg: &FsmFixMessage) -> u32 {
    let mut score = 12;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_13(msg: &FsmFixMessage) -> u32 {
    let mut score = 13;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_14(msg: &FsmFixMessage) -> u32 {
    let mut score = 14;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_15(msg: &FsmFixMessage) -> u32 {
    let mut score = 15;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_16(msg: &FsmFixMessage) -> u32 {
    let mut score = 16;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_17(msg: &FsmFixMessage) -> u32 {
    let mut score = 17;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_18(msg: &FsmFixMessage) -> u32 {
    let mut score = 18;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_19(msg: &FsmFixMessage) -> u32 {
    let mut score = 19;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_20(msg: &FsmFixMessage) -> u32 {
    let mut score = 20;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_21(msg: &FsmFixMessage) -> u32 {
    let mut score = 21;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_22(msg: &FsmFixMessage) -> u32 {
    let mut score = 22;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_23(msg: &FsmFixMessage) -> u32 {
    let mut score = 23;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_24(msg: &FsmFixMessage) -> u32 {
    let mut score = 24;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_25(msg: &FsmFixMessage) -> u32 {
    let mut score = 25;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_26(msg: &FsmFixMessage) -> u32 {
    let mut score = 26;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_27(msg: &FsmFixMessage) -> u32 {
    let mut score = 27;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_28(msg: &FsmFixMessage) -> u32 {
    let mut score = 28;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_29(msg: &FsmFixMessage) -> u32 {
    let mut score = 29;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_30(msg: &FsmFixMessage) -> u32 {
    let mut score = 30;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}

pub fn fsm_validation_rule_31(msg: &FsmFixMessage) -> u32 {
    let mut score = 31;
    if msg.get(35).is_some() { score += 1; }
    if msg.get(55).is_some() { score += 2; }
    if msg.get(15).map(validate_currency).unwrap_or(true) { score += 1; }
    score
}
