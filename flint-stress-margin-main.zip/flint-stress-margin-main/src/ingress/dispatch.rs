use crate::ingress::scenario_lifecycle::{process_single_envelope, run_scenario_lifecycle, SCENARIO_LIFECYCLE_MAGIC};
use crate::wire::magics::{BATCH_MAGIC, ENVELOPE_MAGIC, SESSION_MAGIC};
use crate::wire::stress_wire_rules::{classify_wire_prefix, WireClass};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TapeProcessOutcome {
    pub envelopes_walked: u32,
    pub channels_sealed: u32,
    pub seal_digest: u32,
}

impl TapeProcessOutcome {
    pub fn from_tape(tape: &crate::ingress::stress_tape::StressTape) -> Self {
        Self {
            envelopes_walked: tape.envelopes_walked,
            channels_sealed: tape.channels_sealed,
            seal_digest: tape.last_seal_digest,
        }
    }
}

/// Process nested scenario envelope ingress stream.
pub fn process_ingress_stream(input: &[u8]) -> Result<TapeProcessOutcome, IngressError> {
    if input.is_empty() {
        return Err(IngressError::Empty);
    }
    if input.len() < 4 {
        return Err(IngressError::Truncated);
    }

    if &input[..4] == SCENARIO_LIFECYCLE_MAGIC {
        let digest = run_scenario_lifecycle(input).map_err(|_| IngressError::Lifecycle)?;
        return Ok(TapeProcessOutcome {
            envelopes_walked: 0,
            channels_sealed: 0,
            seal_digest: digest,
        });
    }

    let class = classify_wire_prefix(input);
    if class != WireClass::ScenarioEnvelope {
        return Err(IngressError::WrongWireType);
    }

    process_single_envelope(input).map_err(|_| IngressError::WalkFailed)
}

pub fn dispatch_wire_bytes(input: &[u8]) -> Result<u32, IngressError> {
    if input.len() < 4 {
        return Err(IngressError::Truncated);
    }
    match &input[..4] {
        b if b == BATCH_MAGIC => {
            crate::engine::stress_pipeline::run_stress_batch_pipeline(input)
                .map_err(|_| IngressError::Pipeline)
        }
        b if b == ENVELOPE_MAGIC || b == SCENARIO_LIFECYCLE_MAGIC => {
            process_ingress_stream(input).map(|o| o.seal_digest)
        }
        b if b == SESSION_MAGIC => crate::engine::scenario_merge::merge_portfolio_sessions(input)
            .map_err(|_| IngressError::Pipeline),
        _ => Err(IngressError::UnknownMagic),
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IngressError {
    Empty,
    Truncated,
    WrongWireType,
    WalkFailed,
    Lifecycle,
    Pipeline,
    UnknownMagic,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_rejected() {
        assert_eq!(process_ingress_stream(&[]), Err(IngressError::Empty));
    }
}
