//! Scenario envelope staging — defers channel pin lifetime across nested walk and sweep.

use crate::ingress::stress_tape::StressTape;
use crate::wire::envelope_codec::{decode_envelope_tree, EnvelopeNode};

#[derive(Debug, Clone, Copy)]
struct StagedScenarioPin {
    channel_id: u16,
    ptr: *const u8,
    len: usize,
    depth: u16,
}

#[derive(Debug, Default)]
pub struct ScenarioStagingBoard {
    pins: Vec<StagedScenarioPin>,
    arena_blocks: Vec<Vec<u8>>,
    pub walk_count: u32,
}

impl ScenarioStagingBoard {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn abort_partial(&mut self) {
        self.pins.clear();
        self.arena_blocks.clear();
        self.walk_count = 0;
    }
}

pub fn walk_and_pin_scenario(input: &[u8], board: &mut ScenarioStagingBoard) -> bool {
    board.pins.clear();
    let tree = match decode_envelope_tree(input) {
        Ok(t) => t,
        Err(_) => {
            board.abort_partial();
            return false;
        }
    };
    for root in &tree.roots {
        pin_node_recursive(root, board);
    }
    true
}

fn pin_node_recursive(node: &EnvelopeNode, board: &mut ScenarioStagingBoard) {
    board.walk_count += 1;
    if node.header.flags & 0x0002 != 0 && !node.payload.is_empty() {
        let block = node.payload.clone();
        let ptr = block.as_ptr();
        let len = block.len();
        board.pins.push(StagedScenarioPin {
            channel_id: node.header.channel_id,
            ptr,
            len,
            depth: node.header.depth,
        });
        board.arena_blocks.push(block);
    }
    for child in &node.children {
        pin_node_recursive(child, board);
    }
}

pub fn sweep_staging_arenas(board: &mut ScenarioStagingBoard) {
    let mut temp: Vec<Vec<u8>> = Vec::with_capacity(board.arena_blocks.len());
    for pin in &board.pins {
        temp.push(vec![0u8; (pin.len % 32) + 16]);
    }
    for t in &mut temp {
        t.sort_unstable();
        if t.capacity() > t.len() {
            t.shrink_to_fit();
        }
    }
    drop(temp);
    board.arena_blocks.clear();
}

pub fn commit_pins_to_tape(board: &ScenarioStagingBoard, tape: &mut StressTape) {
    tape.reset_deferred_from_staging(board.pins.len() as u32);
    for pin in &board.pins {
        tape.push_deferred_pin(pin.channel_id, pin.ptr, pin.len, pin.depth);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::envelope_codec::{wrap_envelope_wire, EnvelopeHeader, EnvelopeNode};

    #[test]
    fn walk_pins_channel() {
        let node = EnvelopeNode {
            header: EnvelopeHeader {
                channel_id: 3,
                depth: 0,
                payload_len: 4,
                child_count: 0,
                flags: 0x0002,
            },
            payload: vec![9, 8, 7, 6],
            children: vec![],
        };
        let wire = wrap_envelope_wire(&[node]);
        let mut board = ScenarioStagingBoard::new();
        assert!(walk_and_pin_scenario(&wire, &mut board));
        assert_eq!(board.pins.len(), 1);
    }
}
