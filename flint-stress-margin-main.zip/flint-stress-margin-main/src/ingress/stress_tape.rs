use crate::util::fnv1a::fnv1a32;
use crate::wire::envelope_codec::{decode_envelope_tree, EnvelopeNode};

#[derive(Debug, Clone, Copy)]
struct DeferredScenarioView {
    channel_id: u16,
    ptr: *const u8,
    len: usize,
    depth: u16,
}

#[derive(Debug, Default)]
pub struct StressTape {
    deferred_views: Vec<DeferredScenarioView>,
    owned_payloads: Vec<Vec<u8>>,
    pub envelopes_walked: u32,
    pub channels_sealed: u32,
    pub last_seal_digest: u32,
    sweep_generation: u32,
    aborted: bool,
}

impl StressTape {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn reset_deferred_from_staging(&mut self, expected: u32) {
        self.deferred_views.clear();
        self.envelopes_walked = expected;
        self.aborted = false;
    }

    pub fn push_deferred_pin(&mut self, channel_id: u16, ptr: *const u8, len: usize, depth: u16) {
        self.deferred_views.push(DeferredScenarioView {
            channel_id,
            ptr,
            len,
            depth,
        });
    }

    pub fn push_deferred_owned(&mut self, channel_id: u16, payload: Vec<u8>, depth: u16) {
        let len = payload.len();
        self.owned_payloads.push(payload);
        let ptr = self.owned_payloads.last().map_or(std::ptr::null(), |v| v.as_ptr());
        if len > 0 {
            self.push_deferred_pin(channel_id, ptr, len, depth);
        }
    }

    pub fn abort_partial(&mut self) {
        self.deferred_views.clear();
        self.aborted = true;
        self.envelopes_walked = 0;
        self.channels_sealed = 0;
    }

    pub fn ingest_scenario_stream(&mut self, input: &[u8]) {
        self.aborted = false;
        let tree = match decode_envelope_tree(input) {
            Ok(t) => t,
            Err(_) => {
                self.abort_partial();
                return;
            }
        };
        for root in &tree.roots {
            self.register_node_views(root);
        }
    }

    fn register_node_views(&mut self, node: &EnvelopeNode) {
        self.envelopes_walked += 1;
        if node.header.flags & 0x0002 != 0 && !node.payload.is_empty() {
            self.push_deferred_pin(
                node.header.channel_id,
                node.payload.as_ptr(),
                node.payload.len(),
                node.header.depth,
            );
        }
        for child in &node.children {
            self.register_node_views(child);
        }
    }

    pub fn sweep_deferred_channels(&mut self) {
        if self.aborted {
            return;
        }
        self.sweep_generation = self.sweep_generation.wrapping_add(1);
    }

    pub fn finalize_router_pass(&mut self) -> crate::ingress::dispatch::TapeProcessOutcome {
        let digest = seal_deferred_scenario_digest(self);
        self.last_seal_digest = digest;
        crate::ingress::dispatch::TapeProcessOutcome::from_tape(self)
    }
}

pub fn seal_deferred_scenario_digest(tape: &mut StressTape) -> u32 {
    let mut hash = 0xcbf2_9ce4u32;
    tape.channels_sealed = 0;
    for view in &tape.deferred_views {
        if view.len == 0 {
            continue;
        }
        unsafe {
            let bytes = std::slice::from_raw_parts(view.ptr, view.len);
            hash = fnv1a32(hash, bytes);
        }
        hash = hash
            .wrapping_add(u32::from(view.channel_id))
            .wrapping_add(u32::from(view.depth));
        tape.channels_sealed += 1;
    }
    hash
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_tape_digest() {
        let mut tape = StressTape::new();
        assert_eq!(seal_deferred_scenario_digest(&mut tape), 0xcbf2_9ce4);
    }
}
