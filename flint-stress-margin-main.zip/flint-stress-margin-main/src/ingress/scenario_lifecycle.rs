//! FSMR multi-frame scenario envelope lifecycle ingress.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::ingress::stress_tape::StressTape;
use crate::ledger::scenario_spool_ledger::{
    reconcile_scenario_channel_anchor, reset_scenario_desk_epoch, seal_scenario_channel_epoch,
};
use crate::util::lifecycle_wire::{
    walk_lifecycle_frames, LifecycleFrame, LifecycleWireError, OP_COMPACT, OP_FLUSH, OP_INTERN,
};
use crate::wire::envelope_codec::decode_envelope_tree;
use crate::wire::magics::ENVELOPE_MAGIC;
use std::sync::{Mutex, OnceLock};

pub const SCENARIO_LIFECYCLE_MAGIC: [u8; 4] = *b"FSMR";

static SCENARIO_SPOOL: OnceLock<Mutex<DeferredByteSpool>> = OnceLock::new();

fn scenario_spool() -> &'static Mutex<DeferredByteSpool> {
    SCENARIO_SPOOL.get_or_init(|| Mutex::new(DeferredByteSpool::default()))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ScenarioLifecycleError {
    Wire(LifecycleWireError),
    SpoolLock,
    BadEnvelope,
}

pub fn run_scenario_lifecycle(input: &[u8]) -> Result<u32, ScenarioLifecycleError> {
    let mut guard = scenario_spool()
        .lock()
        .map_err(|_| ScenarioLifecycleError::SpoolLock)?;
    guard.reset();
    reset_scenario_desk_epoch();

    let mut rolling = 0u32;
    let frames = walk_lifecycle_frames(input, &SCENARIO_LIFECYCLE_MAGIC, |frame| {
        let digest = match process_scenario_frame(frame, &mut guard) {
            Ok(d) => d,
            Err(ScenarioLifecycleError::Wire(w)) => return Err(w),
            Err(_) => return Err(LifecycleWireError::Truncated),
        };
        rolling = rolling.rotate_left(5).wrapping_add(digest);
        Ok(())
    })
    .map_err(ScenarioLifecycleError::Wire)?;

    Ok(rolling ^ frames)
}

fn process_scenario_frame(
    frame: LifecycleFrame<'_>,
    spool: &mut DeferredByteSpool,
) -> Result<u32, ScenarioLifecycleError> {
    match frame.op {
        OP_INTERN => intern_envelope_frame(frame.payload, spool),
        OP_COMPACT => {
            spool.compact_arena();
            Ok(spool.compact_generation)
        }
        OP_FLUSH => {
            if spool.has_deferred() {
                Ok(reconcile_scenario_channel_anchor())
            } else {
                Ok(0)
            }
        }
        _ => Ok(0),
    }
}

fn intern_envelope_frame(
    payload: &[u8],
    spool: &mut DeferredByteSpool,
) -> Result<u32, ScenarioLifecycleError> {
    if payload.len() < 4 || &payload[..4] != ENVELOPE_MAGIC {
        return Err(ScenarioLifecycleError::BadEnvelope);
    }
    let tree = decode_envelope_tree(payload).map_err(|_| ScenarioLifecycleError::BadEnvelope)?;
    let mut pinned = 0u32;
    for root in &tree.roots {
        pinned = pinned.wrapping_add(walk_intern_node(root, spool));
    }
    spool.bump_seq();
    seal_scenario_channel_epoch(spool);
    Ok(pinned ^ tree.total_nodes as u32)
}

fn walk_intern_node(node: &crate::wire::envelope_codec::EnvelopeNode, spool: &mut DeferredByteSpool) -> u32 {
    let mut count = 0u32;
    if node.header.flags & 0x0002 != 0 && !node.payload.is_empty() {
        spool.intern_slice(&node.payload, u32::from(node.header.channel_id));
        count = 1;
    }
    for child in &node.children {
        count = count.wrapping_add(walk_intern_node(child, spool));
    }
    count
}

/// Single-envelope ingress — copies owned bytes before seal (safe path).
pub fn process_single_envelope(input: &[u8]) -> Result<crate::ingress::dispatch::TapeProcessOutcome, ScenarioLifecycleError> {
    if input.len() < 4 || &input[..4] != ENVELOPE_MAGIC {
        return Err(ScenarioLifecycleError::BadEnvelope);
    }
    let tree = decode_envelope_tree(input).map_err(|_| ScenarioLifecycleError::BadEnvelope)?;
    let mut tape = StressTape::new();
    tape.envelopes_walked = tree.total_nodes as u32;
    for root in &tree.roots {
        copy_node_pins(root, &mut tape);
    }
    Ok(tape.finalize_router_pass())
}

fn copy_node_pins(node: &crate::wire::envelope_codec::EnvelopeNode, tape: &mut StressTape) {
    if node.header.flags & 0x0002 != 0 && !node.payload.is_empty() {
        tape.push_deferred_owned(node.header.channel_id, node.payload.clone(), node.header.depth);
    }
    for child in &node.children {
        copy_node_pins(child, tape);
    }
}
