use crate::desk::portfolio_stress_ledger::apply_batch_margin_sweeps;
use crate::desk::stress_checkpoint::record_stress_checkpoint;
use crate::engine::intern_arena::{
    compact_intern_spool, intern_pinned_records, intern_spool, spool_has_deferred,
    BATCH_FLAG_COMPACT_SPOOL, BATCH_FLAG_FLUSH_DEFERRED, BATCH_FLAG_INTERN,
};
use crate::engine::margin_staging::{
    coalesce_payload_arena, stage_batch_digest_pins, BatchSlotTable,
};
use crate::engine::orchestrator::{normalize_stress_batch, StressOrchestrator};
use crate::ledger::margin_digest_chain::flush_batch_digest_from_table;
use crate::ledger::spool_epoch_ledger::{
    reconcile_batch_spool_anchor, reset_batch_desk_epoch, seal_batch_spool_epoch,
};
use crate::util::bounded::{read_u16_le, read_u32_le, slice_at, MAX_WIRE_FRAME};
use crate::wire::batch_codec::{decode_batch_wire, verify_batch_header_chain};
use crate::wire::magics::BATCH_MAGIC;

/// FSML lifecycle stream magic — length-prefixed FSMB frame sequence.
pub const LIFECYCLE_MAGIC: [u8; 4] = *b"FSML";
const LIFECYCLE_VERSION: u16 = 1;
const MAX_LIFECYCLE_FRAMES: usize = 16;

/// Run full stress batch margin pipeline.
pub fn run_stress_batch_pipeline(input: &[u8]) -> Result<u32, StressPipelineError> {
    if input.len() >= 4 && &input[..4] == LIFECYCLE_MAGIC {
        return run_batch_lifecycle(input);
    }
    run_single_stress_batch(input)
}

fn run_single_stress_batch(input: &[u8]) -> Result<u32, StressPipelineError> {
    let mut state = decode_batch_wire(input).map_err(StressPipelineError::Decode)?;
    if !verify_batch_header_chain(&state) {
        return Err(StressPipelineError::HeaderChain);
    }

    let mut orch = StressOrchestrator::new(state.desk_lane);
    orch.load_batch(&mut state);

    let mut slot_table = BatchSlotTable::new();
    normalize_stress_batch(&mut orch, &mut state);
    coalesce_payload_arena(&mut state);
    stage_batch_digest_pins(&state, &mut slot_table);

    let sweep_total = match apply_batch_margin_sweeps(&state) {
        Ok(total) => total,
        Err(crate::desk::portfolio_stress_ledger::SweepError::EmptyBatch)
            if state.flags & (BATCH_FLAG_COMPACT_SPOOL | BATCH_FLAG_FLUSH_DEFERRED) != 0 =>
        {
            0
        }
        Err(e) => return Err(StressPipelineError::Sweep(e)),
    };
    record_stress_checkpoint(&state, sweep_total);

    let digest = flush_batch_digest_from_table(&slot_table);
    Ok(digest ^ sweep_total as u32)
}

fn run_batch_lifecycle(input: &[u8]) -> Result<u32, StressPipelineError> {
    if input.len() < 10 {
        return Err(StressPipelineError::LifecycleTruncated);
    }
    let version = read_u16_le(input, 4).ok_or(StressPipelineError::LifecycleTruncated)?;
    if version != LIFECYCLE_VERSION {
        return Err(StressPipelineError::LifecycleVersion);
    }
    let frame_count = read_u32_le(input, 6).ok_or(StressPipelineError::LifecycleTruncated)?;
    if frame_count as usize > MAX_LIFECYCLE_FRAMES {
        return Err(StressPipelineError::LifecycleTooManyFrames);
    }

    let mut guard = intern_spool()
        .lock()
        .map_err(|_| StressPipelineError::SpoolLock)?;
    guard.reset();
    reset_batch_desk_epoch();

    let mut offset = 10usize;
    let mut rolling_digest = 0u32;
    let mut frames_processed = 0u32;

    for _ in 0..frame_count {
        let frame_len = read_u32_le(input, offset).ok_or(StressPipelineError::LifecycleTruncated)?;
        offset = offset.saturating_add(4);
        let frame_len = frame_len as usize;
        if frame_len == 0 || frame_len > MAX_WIRE_FRAME {
            return Err(StressPipelineError::LifecycleFrameSize);
        }
        let frame = slice_at(input, offset, frame_len).ok_or(StressPipelineError::LifecycleTruncated)?;
        offset = offset.saturating_add(frame_len);

        if frame.len() < 4 || &frame[..4] != BATCH_MAGIC {
            return Err(StressPipelineError::LifecycleBadFrame);
        }

        let frame_digest = process_lifecycle_frame(frame, &mut guard)?;
        rolling_digest = rolling_digest
            .rotate_left(7)
            .wrapping_add(frame_digest);
        frames_processed = frames_processed.wrapping_add(1);
    }

    if offset != input.len() {
        return Err(StressPipelineError::LifecycleTrailing);
    }

    Ok(rolling_digest ^ frames_processed)
}

fn process_lifecycle_frame(
    frame: &[u8],
    spool: &mut crate::engine::intern_arena::InternPayloadSpool,
) -> Result<u32, StressPipelineError> {
    let mut state = decode_batch_wire(frame).map_err(StressPipelineError::Decode)?;
    if !verify_batch_header_chain(&state) {
        return Err(StressPipelineError::HeaderChain);
    }

    let mut orch = StressOrchestrator::new(state.desk_lane);
    orch.load_batch(&mut state);
    normalize_stress_batch(&mut orch, &mut state);

    intern_pinned_records(&state, spool);
    if state.flags & BATCH_FLAG_INTERN != 0 {
        seal_batch_spool_epoch(spool);
    }
    coalesce_payload_arena(&mut state);

    if state.flags & BATCH_FLAG_COMPACT_SPOOL != 0 {
        compact_intern_spool(spool);
    }

    let sweep_total = match apply_batch_margin_sweeps(&state) {
        Ok(total) => total,
        Err(crate::desk::portfolio_stress_ledger::SweepError::EmptyBatch)
            if state.flags & (BATCH_FLAG_COMPACT_SPOOL | BATCH_FLAG_FLUSH_DEFERRED) != 0 =>
        {
            0
        }
        Err(e) => return Err(StressPipelineError::Sweep(e)),
    };
    record_stress_checkpoint(&state, sweep_total);

    let mut digest = sweep_total as u32;
    if state.flags & BATCH_FLAG_FLUSH_DEFERRED != 0 && spool_has_deferred(spool) {
        digest = reconcile_batch_spool_anchor();
    } else if state.flags & (BATCH_FLAG_INTERN | BATCH_FLAG_COMPACT_SPOOL | BATCH_FLAG_FLUSH_DEFERRED) == 0
    {
        let mut slot_table = BatchSlotTable::new();
        stage_batch_digest_pins(&state, &mut slot_table);
        digest = flush_batch_digest_from_table(&slot_table);
    }

    Ok(digest ^ state.flags)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StressPipelineError {
    Decode(crate::wire::batch_codec::BatchDecodeError),
    HeaderChain,
    Sweep(crate::desk::portfolio_stress_ledger::SweepError),
    LifecycleTruncated,
    LifecycleVersion,
    LifecycleTooManyFrames,
    LifecycleFrameSize,
    LifecycleBadFrame,
    LifecycleTrailing,
    SpoolLock,
}

pub use crate::engine::scenario_merge::{
    merge_portfolio_sessions, run_portfolio_session_pipeline, SessionDecodeError,
    SessionPipelineError,
};
