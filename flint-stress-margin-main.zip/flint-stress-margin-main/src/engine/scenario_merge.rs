use crate::engine::session_lifecycle::{run_session_lifecycle, run_single_session_merge, SESSION_LIFECYCLE_MAGIC};
use crate::util::bounded::{read_u16_le, read_u32_le, slice_at, MAX_WIRE_FRAME};
use crate::wire::magics::{SESSION_MAGIC, SESSION_VERSION};

#[derive(Debug, Clone)]
pub struct SessionPosition {
    pub leg_id: u32,
    pub portfolio_tag: u32,
    pub notional_minor: i64,
    pub payload: Vec<u8>,
}

#[derive(Debug, Default, Clone)]
pub struct PortfolioSessionWire {
    pub version: u16,
    pub session_id: u32,
    pub leg_count: u32,
    pub legs: Vec<SessionPosition>,
    pub graft_flags: u32,
}

pub fn decode_portfolio_session(input: &[u8]) -> Result<PortfolioSessionWire, SessionDecodeError> {
    if input.len() < 16 {
        return Err(SessionDecodeError::Truncated);
    }
    if &input[..4] != SESSION_MAGIC {
        return Err(SessionDecodeError::BadMagic);
    }
    if input.len() > MAX_WIRE_FRAME {
        return Err(SessionDecodeError::TooLarge);
    }
    let version = read_u16_le(input, 4).ok_or(SessionDecodeError::Truncated)?;
    if version != SESSION_VERSION {
        return Err(SessionDecodeError::BadVersion);
    }
    let session_id = read_u32_le(input, 6).ok_or(SessionDecodeError::Truncated)?;
    let leg_count = read_u32_le(input, 10).ok_or(SessionDecodeError::Truncated)?;
    let graft_flags = read_u32_le(input, 14).ok_or(SessionDecodeError::Truncated)?;

    let mut offset = 18usize;
    let mut legs = Vec::new();
    for _ in 0..leg_count {
        if offset + 16 > input.len() {
            return Err(SessionDecodeError::Truncated);
        }
        let leg_id = read_u32_le(input, offset).ok_or(SessionDecodeError::Truncated)?;
        offset += 4;
        let portfolio_tag = read_u32_le(input, offset).ok_or(SessionDecodeError::Truncated)?;
        offset += 4;
        let notional_minor = read_i64_le(input, offset).ok_or(SessionDecodeError::Truncated)?;
        offset += 8;
        let plen = read_u32_le(input, offset).ok_or(SessionDecodeError::Truncated)?;
        offset += 4;
        let payload = slice_at(input, offset, plen as usize)
            .ok_or(SessionDecodeError::Truncated)?
            .to_vec();
        offset += plen as usize;
        legs.push(SessionPosition {
            leg_id,
            portfolio_tag,
            notional_minor,
            payload,
        });
    }

    Ok(PortfolioSessionWire {
        version,
        session_id,
        leg_count,
        legs,
        graft_flags,
    })
}

fn read_i64_le(buf: &[u8], offset: usize) -> Option<i64> {
    let s = slice_at(buf, offset, 8)?;
    let mut arr = [0u8; 8];
    arr.copy_from_slice(s);
    Some(i64::from_le_bytes(arr))
}

pub fn graft_position_tree(session: &mut PortfolioSessionWire) {
    if session.graft_flags & 0x1 == 0 {
        return;
    }
    session.legs.sort_by_key(|l| l.leg_id);
    for leg in session.legs.iter_mut() {
        if leg.payload.len() > 4 && session.graft_flags & 0x2 != 0 {
            leg.payload.drain(0..2);
            leg.payload.shrink_to_fit();
        }
        if session.graft_flags & 0x4 != 0 {
            leg.payload.reserve(leg.payload.len() * 2);
            leg.payload.truncate(leg.payload.len().saturating_sub(1));
            leg.payload.shrink_to_fit();
        }
    }
}

pub fn merge_portfolio_sessions(input: &[u8]) -> Result<u32, SessionPipelineError> {
    run_portfolio_session_pipeline(input)
}

pub fn run_portfolio_session_pipeline(input: &[u8]) -> Result<u32, SessionPipelineError> {
    if input.len() >= 4 && &input[..4] == SESSION_LIFECYCLE_MAGIC {
        return run_session_lifecycle(input).map_err(|_| SessionPipelineError::Lifecycle);
    }
    run_single_session_merge(input)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SessionDecodeError {
    Truncated,
    BadMagic,
    TooLarge,
    BadVersion,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SessionPipelineError {
    Decode(SessionDecodeError),
    Lifecycle,
}
