//! FSMX multi-frame FIX margin tag-value lifecycle.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::ledger::fix_spool_ledger::{
    reconcile_fix_tag_anchor, reset_fix_desk_epoch, seal_fix_tag_epoch,
};
use crate::util::lifecycle_wire::{
    walk_lifecycle_frames, LifecycleFrame, LifecycleWireError, OP_COMPACT, OP_FLUSH, OP_INTERN,
};
use crate::wire::fix_parser::parse_fix_message;
use std::sync::{Mutex, OnceLock};

pub const FIX_LIFECYCLE_MAGIC: [u8; 4] = *b"FSMX";

/// Custom desk tag marking a margin value block for cross-frame interning.
pub const FSM_PIN_TAG: u32 = 9876;

static FIX_SPOOL: OnceLock<Mutex<DeferredByteSpool>> = OnceLock::new();

fn fix_spool() -> &'static Mutex<DeferredByteSpool> {
    FIX_SPOOL.get_or_init(|| Mutex::new(DeferredByteSpool::default()))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FixLifecycleError {
    Wire(LifecycleWireError),
    SpoolLock,
    Utf8,
    Parse,
}

pub fn run_fix_lifecycle(input: &[u8]) -> Result<u32, FixLifecycleError> {
    let mut guard = fix_spool()
        .lock()
        .map_err(|_| FixLifecycleError::SpoolLock)?;
    guard.reset();
    reset_fix_desk_epoch();

    let mut rolling = 0u32;
    let frames = walk_lifecycle_frames(input, &FIX_LIFECYCLE_MAGIC, |frame| {
        let digest = match process_fix_frame(frame, &mut guard) {
            Ok(d) => d,
            Err(FixLifecycleError::Wire(w)) => return Err(w),
            Err(_) => return Err(LifecycleWireError::Truncated),
        };
        rolling = rolling.rotate_left(11).wrapping_add(digest);
        Ok(())
    })
    .map_err(FixLifecycleError::Wire)?;

    Ok(rolling ^ frames)
}

fn process_fix_frame(
    frame: LifecycleFrame<'_>,
    spool: &mut DeferredByteSpool,
) -> Result<u32, FixLifecycleError> {
    match frame.op {
        OP_INTERN => intern_fix_frame(frame.payload, spool),
        OP_COMPACT => {
            spool.compact_arena();
            Ok(spool.compact_generation)
        }
        OP_FLUSH => {
            if spool.has_deferred() {
                Ok(reconcile_fix_tag_anchor())
            } else {
                Ok(0)
            }
        }
        _ => Ok(0),
    }
}

fn intern_fix_frame(payload: &[u8], spool: &mut DeferredByteSpool) -> Result<u32, FixLifecycleError> {
    let text = std::str::from_utf8(payload).map_err(|_| FixLifecycleError::Utf8)?;
    let msg = parse_fix_message(text).map_err(|_| FixLifecycleError::Parse)?;
    let mut pinned = 0u32;
    for field in &msg.fields {
        if field.tag == FSM_PIN_TAG && !field.value.is_empty() {
            spool.intern_slice(field.value.as_bytes(), field.tag);
            pinned = pinned.wrapping_add(1);
        }
    }
    spool.bump_seq();
    seal_fix_tag_epoch(spool);
    Ok(pinned ^ msg.checksum)
}