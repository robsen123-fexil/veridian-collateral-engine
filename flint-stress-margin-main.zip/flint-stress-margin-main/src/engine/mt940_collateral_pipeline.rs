//! SWIFT MT940 collateral statement pipeline.

use crate::engine::mt940_line_lifecycle::{run_mt940_lifecycle, MT940_LIFECYCLE_MAGIC};
use crate::wire::swift_mt940::fsm_parse_mt940;

pub fn run_mt940_collateral_pipeline(input: &[u8]) -> Result<u32, Mt940PipelineError> {
    if input.len() >= 4 && &input[..4] == MT940_LIFECYCLE_MAGIC {
        return run_mt940_lifecycle(input).map_err(|_| Mt940PipelineError::Lifecycle);
    }
    run_mt940_collateral_pipeline_inner(input)
}

pub fn run_mt940_collateral_pipeline_inner(input: &[u8]) -> Result<u32, Mt940PipelineError> {
    let text = std::str::from_utf8(input).map_err(|_| Mt940PipelineError::Utf8)?;
    let stmt = fsm_parse_mt940(text);
    let movement = stmt.closing_minor.saturating_sub(stmt.opening_minor);
    let mut digest = 0xcbf2_9ce4u32;
    for line in &stmt.lines {
        digest = digest
            .wrapping_mul(0x0100_0193)
            .wrapping_add(line.len() as u32);
    }
    Ok(digest ^ (movement as u32))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Mt940PipelineError {
    Utf8,
    Lifecycle,
}
