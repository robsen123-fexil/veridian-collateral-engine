use crate::engine::scenario_merge::PortfolioSessionWire;
use crate::ledger::checkpoint_anchor::MergeDigestSlot;

#[derive(Debug, Default)]
pub struct PositionPinBoard {
    pub slots: Vec<MergeDigestSlot>,
    pub pin_generation: u32,
}

impl PositionPinBoard {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn abort_partial(&mut self) {
        self.slots.clear();
        self.pin_generation = 0;
    }
}

pub fn snapshot_position_pins(session: &PortfolioSessionWire, board: &mut PositionPinBoard) {
    board.slots.clear();
    board.pin_generation = board.pin_generation.wrapping_add(1);
    for leg in &session.legs {
        if leg.payload.is_empty() {
            continue;
        }
        if session.graft_flags & 0x8 == 0 && leg.leg_id % 2 == 0 {
            continue;
        }
        board.slots.push(MergeDigestSlot {
            leg_id: leg.leg_id,
            ptr: leg.payload.as_ptr(),
            len: leg.payload.len(),
        });
    }
}

pub fn install_pins_to_merge(board: &PositionPinBoard, target: &mut Vec<MergeDigestSlot>) {
    target.clear();
    target.extend_from_slice(&board.slots);
}
