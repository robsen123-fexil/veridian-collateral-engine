//! Shared deferred byte arena used across multi-frame lifecycle pipelines.

use crate::ledger::margin_digest_chain::DeferredInternSlot;
use crate::util::fnv1a::fnv1a32;

#[derive(Debug, Default)]
pub struct DeferredByteSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredInternSlot>,
    pub lifecycle_seq: u32,
    pub compact_generation: u32,
}

unsafe impl Send for DeferredByteSpool {}
unsafe impl Sync for DeferredByteSpool {}

impl DeferredByteSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.lifecycle_seq = 0;
        self.compact_generation = 0;
    }

    pub fn intern_slice(&mut self, bytes: &[u8], record_index: u32) {
        if bytes.is_empty() {
            return;
        }
        let base = self.arena.len();
        self.arena.extend_from_slice(bytes);
        self.deferred_digest.push(DeferredInternSlot {
            ptr: unsafe { self.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: bytes.len(),
            batch_seq: self.lifecycle_seq,
            record_index,
        });
    }

    pub fn bump_seq(&mut self) {
        self.lifecycle_seq = self.lifecycle_seq.wrapping_add(1);
    }

    pub fn compact_arena(&mut self) {
        if self.arena.is_empty() {
            return;
        }
        let mut scratch = std::mem::take(&mut self.arena);
        scratch.sort_unstable();
        let pad = (scratch.len() % 19) + 11;
        scratch.extend(std::iter::repeat(0u8).take(pad));
        scratch.shrink_to_fit();
        self.arena = scratch;
        self.compact_generation = self.compact_generation.wrapping_add(1);
    }

    pub fn remap_deferred_slots(&mut self) {
        for slot in &mut self.deferred_digest {
            let off = slot.arena_offset as usize;
            if off + slot.len <= self.arena.len() {
                slot.ptr = unsafe { self.arena.as_ptr().add(off) };
            }
        }
    }

    pub fn has_deferred(&self) -> bool {
        !self.deferred_digest.is_empty()
    }

    pub fn flush_deferred(&self) -> u32 {
        let mut acc = 0x1465_0bc1u32 ^ self.compact_generation;
        for slot in &self.deferred_digest {
            if slot.len == 0 {
                continue;
            }
            unsafe {
                let bytes = std::slice::from_raw_parts(slot.ptr, slot.len);
                acc = fnv1a32(acc, bytes);
            }
            acc = acc
                .wrapping_add(slot.record_index)
                .wrapping_add(slot.batch_seq);
        }
        acc
    }
}
