//! FSMW multi-frame SWIFT MT940 collateral line lifecycle.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::ledger::mt940_spool_ledger::{
    reconcile_mt940_line_anchor, reset_mt940_desk_epoch, seal_mt940_line_epoch,
};
use crate::util::lifecycle_wire::{
    walk_lifecycle_frames, LifecycleFrame, LifecycleWireError, OP_COMPACT, OP_FLUSH, OP_INTERN,
};
use crate::wire::swift_field_scanner::{FsmSwiftField, fsm_scan_swift_line};
use std::sync::{Mutex, OnceLock};

pub const MT940_LIFECYCLE_MAGIC: [u8; 4] = *b"FSMW";

static MT940_SPOOL: OnceLock<Mutex<DeferredByteSpool>> = OnceLock::new();

fn mt940_spool() -> &'static Mutex<DeferredByteSpool> {
    MT940_SPOOL.get_or_init(|| Mutex::new(DeferredByteSpool::default()))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Mt940LifecycleError {
    Wire(LifecycleWireError),
    SpoolLock,
    Utf8,
}

pub fn run_mt940_lifecycle(input: &[u8]) -> Result<u32, Mt940LifecycleError> {
    let mut guard = mt940_spool()
        .lock()
        .map_err(|_| Mt940LifecycleError::SpoolLock)?;
    guard.reset();
    reset_mt940_desk_epoch();

    let mut rolling = 0u32;
    let frames = walk_lifecycle_frames(input, &MT940_LIFECYCLE_MAGIC, |frame| {
        let digest = match process_mt940_frame(frame, &mut guard) {
            Ok(d) => d,
            Err(Mt940LifecycleError::Wire(w)) => return Err(w),
            Err(_) => return Err(LifecycleWireError::Truncated),
        };
        rolling = rolling.rotate_left(13).wrapping_add(digest);
        Ok(())
    })
    .map_err(Mt940LifecycleError::Wire)?;

    Ok(rolling ^ frames)
}

fn process_mt940_frame(
    frame: LifecycleFrame<'_>,
    spool: &mut DeferredByteSpool,
) -> Result<u32, Mt940LifecycleError> {
    match frame.op {
        OP_INTERN => intern_mt940_frame(frame.payload, spool),
        OP_COMPACT => {
            spool.compact_arena();
            Ok(spool.compact_generation)
        }
        OP_FLUSH => {
            if spool.has_deferred() {
                Ok(reconcile_mt940_line_anchor())
            } else {
                Ok(0)
            }
        }
        _ => Ok(0),
    }
}

fn intern_mt940_frame(payload: &[u8], spool: &mut DeferredByteSpool) -> Result<u32, Mt940LifecycleError> {
    let text = std::str::from_utf8(payload).map_err(|_| Mt940LifecycleError::Utf8)?;
    let mut pinned = 0u32;
    let mut line_idx = 0u32;
    for line in text.lines() {
        if let Some(FsmSwiftField::TransactionLine(t)) = fsm_scan_swift_line(line) {
            if t.contains("FSMPIN") {
                spool.intern_slice(t.as_bytes(), line_idx);
                pinned = pinned.wrapping_add(1);
            }
        }
        line_idx = line_idx.wrapping_add(1);
    }
    spool.bump_seq();
    seal_mt940_line_epoch(spool);
    Ok(pinned ^ line_idx)
}