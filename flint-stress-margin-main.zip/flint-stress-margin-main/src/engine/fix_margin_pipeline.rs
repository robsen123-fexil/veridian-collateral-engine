//! FIX margin confirmation pipeline.

use crate::engine::fix_tag_lifecycle::{run_fix_lifecycle, FIX_LIFECYCLE_MAGIC};
use crate::wire::fix_parser::parse_fix_message;
use crate::wire::fix_validation_engine::fsm_validate_fix_margin_frame;

pub fn run_fix_margin_pipeline(input: &[u8]) -> Result<u32, FixMarginPipelineError> {
    if input.len() >= 4 && &input[..4] == FIX_LIFECYCLE_MAGIC {
        return run_fix_lifecycle(input).map_err(|_| FixMarginPipelineError::Lifecycle);
    }
    run_fix_margin_pipeline_inner(input)
}

pub fn run_fix_margin_pipeline_inner(input: &[u8]) -> Result<u32, FixMarginPipelineError> {
    let text = std::str::from_utf8(input).map_err(|_| FixMarginPipelineError::Utf8)?;
    let msg = parse_fix_message(text).map_err(FixMarginPipelineError::Parse)?;
    let report = fsm_validate_fix_margin_frame(text);
    let mut digest = 0x811c_9dc5u32;
    for field in &msg.fields {
        digest = digest
            .wrapping_mul(0x0100_0193)
            .wrapping_add(field.tag ^ field.value.len() as u32);
    }
    Ok(digest ^ report.warnings)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FixMarginPipelineError {
    Utf8,
    Parse(&'static str),
    Lifecycle,
}
