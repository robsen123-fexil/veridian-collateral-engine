//! Cross-batch interned payload arena — accumulates pinned record bytes across lifecycle frames.

use crate::ledger::margin_digest_chain::DeferredInternSlot;
use crate::wire::batch_codec::BatchWireState;
use std::sync::{Mutex, OnceLock};

#[derive(Debug, Default)]
pub struct InternPayloadSpool {
    pub arena: Vec<u8>,
    pub deferred_digest: Vec<DeferredInternSlot>,
    pub lifecycle_seq: u32,
    pub compact_generation: u32,
    pub interned_bytes: u64,
}

unsafe impl Send for InternPayloadSpool {}
unsafe impl Sync for InternPayloadSpool {}

impl InternPayloadSpool {
    pub fn reset(&mut self) {
        self.arena.clear();
        self.deferred_digest.clear();
        self.lifecycle_seq = 0;
        self.compact_generation = 0;
        self.interned_bytes = 0;
    }

    pub fn abort_partial(&mut self) {
        self.deferred_digest.clear();
    }
}

static INTERN_SPOOL: OnceLock<Mutex<InternPayloadSpool>> = OnceLock::new();

pub fn intern_spool() -> &'static Mutex<InternPayloadSpool> {
    INTERN_SPOOL.get_or_init(|| Mutex::new(InternPayloadSpool::default()))
}

pub const BATCH_FLAG_INTERN: u32 = 0x0000_0020;
pub const BATCH_FLAG_COMPACT_SPOOL: u32 = 0x0000_0040;
pub const BATCH_FLAG_FLUSH_DEFERRED: u32 = 0x0000_0080;

pub fn intern_pinned_records(state: &BatchWireState, spool: &mut InternPayloadSpool) {
    if state.flags & BATCH_FLAG_INTERN == 0 {
        return;
    }
    for (idx, hdr) in state.headers.iter().enumerate() {
        if hdr.flags & 0x0001 == 0 {
            continue;
        }
        let Some(payload) = state.record_payload(idx) else {
            continue;
        };
        if payload.is_empty() {
            continue;
        }
        let base = spool.arena.len();
        spool.arena.extend_from_slice(payload);
        spool.interned_bytes = spool.interned_bytes.saturating_add(payload.len() as u64);
        spool.deferred_digest.push(DeferredInternSlot {
            ptr: unsafe { spool.arena.as_ptr().add(base) },
            arena_offset: base as u32,
            len: payload.len(),
            batch_seq: spool.lifecycle_seq,
            record_index: idx as u32,
        });
    }
    spool.lifecycle_seq = spool.lifecycle_seq.wrapping_add(1);
}

pub fn compact_intern_spool(spool: &mut InternPayloadSpool) {
    if spool.arena.is_empty() {
        return;
    }
    let mut scratch = std::mem::take(&mut spool.arena);
    scratch.sort_unstable();
    let pad = (scratch.len() % 17) + 8;
    scratch.extend(std::iter::repeat(0u8).take(pad));
    scratch.shrink_to_fit();
    spool.arena = scratch;
    spool.compact_generation = spool.compact_generation.wrapping_add(1);
}

/// Rebind deferred digest slot cursors after arena reshuffle (desk invariant).
pub fn remap_deferred_intern_slots(spool: &mut InternPayloadSpool) {
    for slot in &mut spool.deferred_digest {
        let off = slot.arena_offset as usize;
        if off + slot.len <= spool.arena.len() {
            slot.ptr = unsafe { spool.arena.as_ptr().add(off) };
        }
    }
}

pub fn spool_has_deferred(spool: &InternPayloadSpool) -> bool {
    !spool.deferred_digest.is_empty()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::batch_codec::{BatchRecordHeader, BatchWireState};
    use crate::wire::magics::BATCH_VERSION;

    #[test]
    fn intern_copies_payload() {
        let mut st = BatchWireState::default();
        st.version = BATCH_VERSION;
        st.flags = BATCH_FLAG_INTERN;
        st.headers.push(BatchRecordHeader {
            record_type: 1,
            flags: 0x0001,
            payload_offset: 0,
            payload_len: 4,
            portfolio_tag: 1,
        });
        st.payload_blob = vec![1, 2, 3, 4];
        let mut spool = InternPayloadSpool::default();
        intern_pinned_records(&st, &mut spool);
        assert_eq!(spool.deferred_digest.len(), 1);
        assert_eq!(spool.arena, vec![1, 2, 3, 4]);
    }
}
