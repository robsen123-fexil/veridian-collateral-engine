use crate::wire::batch_codec::BatchWireState;

#[derive(Debug, Default)]
pub struct StressOrchestrator {
    pub desk_lane: u16,
    pub records_normalized: u32,
    pub shock_factor_bps: u32,
}

impl StressOrchestrator {
    pub fn new(desk_lane: u16) -> Self {
        Self {
            desk_lane,
            records_normalized: 0,
            shock_factor_bps: 100,
        }
    }

    pub fn load_batch(&mut self, state: &mut BatchWireState) {
        self.records_normalized = 0;
        if state.desk_lane != 0 {
            self.desk_lane = state.desk_lane;
        }
        self.shock_factor_bps = 100 + (state.flags & 0xff) as u32;
    }
}

pub fn normalize_stress_batch(orch: &mut StressOrchestrator, state: &mut BatchWireState) {
    if state.flags & 0x0000_0002 == 0 {
        return;
    }
    for hdr in state.headers.iter_mut() {
        if hdr.flags & 0x0004 != 0 {
            hdr.portfolio_tag = hdr.portfolio_tag.wrapping_mul(orch.shock_factor_bps);
        }
        orch.records_normalized += 1;
    }
    if state.flags & 0x0000_0001 != 0 {
        for byte in state.payload_blob.iter_mut() {
            *byte = byte.wrapping_add((orch.desk_lane & 0xff) as u8);
        }
    }
}
