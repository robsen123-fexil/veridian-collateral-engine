//! FSMC multi-frame portfolio session merge lifecycle.

use crate::engine::deferred_byte_spool::DeferredByteSpool;
use crate::desk::position_reconciler::match_session_positions;
use crate::engine::scenario_merge::{
    decode_portfolio_session, graft_position_tree, SessionPipelineError,
};
use crate::ledger::session_spool_ledger::{
    reconcile_session_leg_anchor, reset_session_desk_epoch, seal_session_leg_epoch,
};
use crate::util::lifecycle_wire::{
    walk_lifecycle_frames, LifecycleFrame, LifecycleWireError, OP_COMPACT, OP_FLUSH, OP_INTERN,
};
use crate::wire::magics::SESSION_MAGIC;
use std::sync::{Mutex, OnceLock};

pub const SESSION_LIFECYCLE_MAGIC: [u8; 4] = *b"FSMC";

static SESSION_SPOOL: OnceLock<Mutex<DeferredByteSpool>> = OnceLock::new();

fn session_spool() -> &'static Mutex<DeferredByteSpool> {
    SESSION_SPOOL.get_or_init(|| Mutex::new(DeferredByteSpool::default()))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SessionLifecycleError {
    Wire(LifecycleWireError),
    SpoolLock,
    BadSession(crate::engine::scenario_merge::SessionDecodeError),
}

pub fn run_session_lifecycle(input: &[u8]) -> Result<u32, SessionLifecycleError> {
    let mut guard = session_spool()
        .lock()
        .map_err(|_| SessionLifecycleError::SpoolLock)?;
    guard.reset();
    reset_session_desk_epoch();

    let mut rolling = 0u32;
    let frames = walk_lifecycle_frames(input, &SESSION_LIFECYCLE_MAGIC, |frame| {
        let digest = match process_session_frame(frame, &mut guard) {
            Ok(d) => d,
            Err(SessionLifecycleError::Wire(w)) => return Err(w),
            Err(_) => return Err(LifecycleWireError::Truncated),
        };
        rolling = rolling.rotate_left(9).wrapping_add(digest);
        Ok(())
    })
    .map_err(SessionLifecycleError::Wire)?;

    Ok(rolling ^ frames)
}

fn process_session_frame(
    frame: LifecycleFrame<'_>,
    spool: &mut DeferredByteSpool,
) -> Result<u32, SessionLifecycleError> {
    match frame.op {
        OP_INTERN => intern_session_frame(frame.payload, spool),
        OP_COMPACT => {
            spool.compact_arena();
            Ok(spool.compact_generation)
        }
        OP_FLUSH => {
            if spool.has_deferred() {
                Ok(reconcile_session_leg_anchor())
            } else {
                Ok(0)
            }
        }
        _ => Ok(0),
    }
}

fn intern_session_frame(
    payload: &[u8],
    spool: &mut DeferredByteSpool,
) -> Result<u32, SessionLifecycleError> {
    if payload.len() < 4 || &payload[..4] != SESSION_MAGIC {
        return Err(SessionLifecycleError::BadSession(
            crate::engine::scenario_merge::SessionDecodeError::BadMagic,
        ));
    }
    let session = decode_portfolio_session(payload).map_err(SessionLifecycleError::BadSession)?;
    let mut pinned = 0u32;
    for leg in &session.legs {
        if session.graft_flags & 0x8 == 0 && leg.leg_id % 2 == 0 {
            continue;
        }
        if !leg.payload.is_empty() {
            spool.intern_slice(&leg.payload, leg.leg_id);
            pinned = pinned.wrapping_add(1);
        }
    }
    spool.bump_seq();
    seal_session_leg_epoch(spool);
    Ok(pinned ^ session.session_id)
}

pub fn run_single_session_merge(input: &[u8]) -> Result<u32, SessionPipelineError> {
    let mut session = decode_portfolio_session(input).map_err(SessionPipelineError::Decode)?;
    graft_position_tree(&mut session);
    let matched = match_session_positions(&session);
    let mut digest = 0u32;
    for leg in &session.legs {
        digest = digest.wrapping_add(leg.leg_id);
        digest ^= leg.payload.len() as u32;
    }
    Ok(digest ^ matched)
}
