//! Margin batch staging — pins digest views across normalize/coalesce passes.

use crate::wire::batch_codec::{BatchDigestSlot, BatchWireState};

#[derive(Debug, Default)]
pub struct BatchSlotTable {
    pub slots: Vec<BatchDigestSlot>,
    pub capture_generation: u32,
    pub pinned_record_count: u32,
}

impl BatchSlotTable {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn clear(&mut self) {
        self.slots.clear();
        self.pinned_record_count = 0;
    }

    pub fn abort_partial(&mut self) {
        self.clear();
        self.capture_generation = 0;
    }
}

pub fn stage_batch_digest_pins(state: &BatchWireState, table: &mut BatchSlotTable) {
    table.slots.clear();
    table.capture_generation = table.capture_generation.wrapping_add(1);
    for (idx, hdr) in state.headers.iter().enumerate() {
        if hdr.flags & 0x0001 == 0 {
            continue;
        }
        let off = hdr.payload_offset as usize;
        let len = hdr.payload_len as usize;
        if let Some(base) = state.payload_blob.get(off..off.saturating_add(len)) {
            if base.is_empty() {
                continue;
            }
            table.slots.push(BatchDigestSlot {
                record_index: idx as u32,
                ptr: base.as_ptr(),
                len,
            });
            table.pinned_record_count += 1;
        }
    }
}

pub fn coalesce_payload_arena(state: &mut BatchWireState) {
    if state.flags & 0x00_00_00_04 == 0 {
        return;
    }
    if state.payload_blob.is_empty() {
        return;
    }
    let mut scratch = std::mem::take(&mut state.payload_blob);
    scratch.sort_unstable();
    for hdr in state.headers.iter_mut() {
        let off = hdr.payload_offset as usize;
        let len = hdr.payload_len as usize;
        if off + len <= scratch.len() && len > 0 {
            let slice = &scratch[off..off + len];
            if hdr.flags & 0x0010 != 0 {
                let mut dup = slice.to_vec();
                dup.reverse();
                scratch.extend_from_slice(&dup);
            }
        }
    }
    if state.flags & 0x00_00_00_08 != 0 {
        scratch.shrink_to_fit();
    }
    state.payload_blob = scratch;
    remap_header_offsets(state);
}

fn remap_header_offsets(state: &mut BatchWireState) {
    let mut cursor = 0u32;
    for hdr in state.headers.iter_mut() {
        let len = hdr.payload_len;
        hdr.payload_offset = cursor;
        cursor = cursor.saturating_add(len);
    }
}

pub fn slot_table_span(table: &BatchSlotTable) -> usize {
    table.slots.iter().map(|s| s.len).sum()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::batch_codec::{BatchRecordHeader, BatchWireState};
    use crate::wire::magics::BATCH_VERSION;

    #[test]
    fn stage_pins_records() {
        let mut st = BatchWireState::default();
        st.version = BATCH_VERSION;
        st.headers.push(BatchRecordHeader {
            record_type: 1,
            flags: 0x0001,
            payload_offset: 0,
            payload_len: 4,
            portfolio_tag: 1,
        });
        st.payload_blob = vec![1, 2, 3, 4];
        let mut table = BatchSlotTable::new();
        stage_batch_digest_pins(&st, &mut table);
        assert_eq!(table.pinned_record_count, 1);
    }
}
