# FSM wire formats

Binary magics are four-byte little-endian tags at frame start.

## FSML — stress batch lifecycle stream

| Offset | Size | Field |
|--------|------|-------|
| 0 | 4 | Magic `FSML` |
| 4 | 2 | Version `u16` LE |
| 6 | 4 | Frame count `u32` LE |
| 10 | … | Length-prefixed lifecycle frames |

### Lifecycle frame wrapper

| Offset | Size | Field |
|--------|------|-------|
| 0 | 4 | Frame length `u32` LE |
| 2 | 2 | Frame opcode `u16` LE |
| 4 | N-2 | Frame payload |

Lifecycle stream magics: `FSML` (batch), `FSMR` (scenario), `FSMC` (session), `FSMX` (FIX), `FSMW` (MT940).

## FSMB — stress batch

| Offset | Size | Field |
|--------|------|-------|
| 0 | 4 | Magic `FSMB` |
| 4 | 2 | Version `u16` LE |
| 6 | 4 | Record count `u32` LE |
| 10 | 4 | Payload blob length `u32` LE |
| 14 | 4 | Flags `u32` LE |
| 18 | 2 | Desk lane `u16` LE |
| 20 | 16 × N | Record header table |
| 20+16N | P | Payload blob |

### Record header (16 bytes)

| Offset | Size | Field |
|--------|------|-------|
| 0 | 2 | Record type `u16` LE |
| 2 | 2 | Flags `u16` LE |
| 4 | 4 | Payload offset `u32` LE |
| 8 | 4 | Payload length `u32` LE |
| 12 | 4 | Portfolio tag `u32` LE |

## FSME — scenario envelope

| Offset | Size | Field |
|--------|------|-------|
| 0 | 4 | Magic `FSME` |
| 4 | 2 | Version `u16` LE |
| 6 | 2 | Root count `u16` LE |
| 8 | … | Nested nodes |

### Node header (12 bytes + payload + children)

| Offset | Size | Field |
|--------|------|-------|
| 0 | 2 | Channel id `u16` LE |
| 2 | 2 | Depth `u16` LE |
| 4 | 4 | Payload length `u32` LE |
| 8 | 2 | Child count `u16` LE |
| 10 | 2 | Flags `u16` LE |
| 12 | P | Payload bytes |

## FSMS — portfolio session checkpoint

| Offset | Size | Field |
|--------|------|-------|
| 0 | 4 | Magic `FSMS` |
| 4 | 2 | Version `u16` LE |
| 6 | 4 | Session id `u32` LE |
| 10 | 4 | Leg count `u32` LE |
| 14 | 4 | Graft flags `u32` LE |
| 18 | … | Leg records |

### Leg record

| Field | Type |
|-------|------|
| Leg id | `u32` LE |
| Portfolio tag | `u32` LE |
| Notional minor | `i64` LE |
| Payload length | `u32` LE |
| Payload | bytes |

## FIX 4.4 margin confirmation

Standard FIX 4.4 tag=value fields delimited by SOH (`0x01`). Body length tag 9 and checksum tag 10 required.

## SWIFT MT940 collateral statement

Text lines beginning with `:NN:` field tags. Balance fields `:60F:` opening, `:62F:` closing. Transaction lines `:61:`.
