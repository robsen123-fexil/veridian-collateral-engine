mod wire_helpers;

use flint_stress_margin::desk::integration_bridge::fsm_run_desk_integration_smoke;
use flint_stress_margin::engine::stress_pipeline::run_stress_batch_pipeline;
use flint_stress_margin::ingress::dispatch::process_ingress_stream;
use wire_helpers::{
    sample_fix_margin_frame, sample_mt940_collateral, sample_portfolio_session_wire,
    sample_scenario_envelope_wire, sample_stress_batch_wire,
};

#[test]
fn stress_batch_pipeline_returns_digest() {
    let wire = sample_stress_batch_wire();
    let digest = run_stress_batch_pipeline(&wire).expect("pipeline");
    assert_ne!(digest, 0);
}

#[test]
fn scenario_ingress_seals_channels() {
    let wire = sample_scenario_envelope_wire();
    let outcome = process_ingress_stream(&wire).expect("ingress");
    assert!(outcome.channels_sealed >= 1);
}

#[test]
fn portfolio_session_merge_matches_legs() {
    let wire = sample_portfolio_session_wire();
    let digest = flint_stress_margin::merge_portfolio_sessions(&wire).expect("session");
    assert_ne!(digest, 0);
}

#[test]
fn fix_margin_pipeline_parses_frame() {
    let raw = sample_fix_margin_frame();
    let digest = flint_stress_margin::run_fix_margin_pipeline(raw.as_bytes()).expect("fix");
    assert_ne!(digest, 0);
}

#[test]
fn mt940_collateral_pipeline_net_movement() {
    let raw = sample_mt940_collateral();
    let digest = flint_stress_margin::run_mt940_collateral_pipeline(raw.as_bytes()).expect("mt940");
    assert_ne!(digest, 0);
}

#[test]
fn desk_integration_smoke_touches_modules() {
    let report = fsm_run_desk_integration_smoke(2_000_000, 1_500_000);
    assert!(report.modules_touched >= 10);
    assert_ne!(report.total_stressed_minor, 0);
}
