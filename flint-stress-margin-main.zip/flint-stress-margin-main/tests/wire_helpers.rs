//! Inline wire builders for integration tests — no committed crash binaries.

use flint_stress_margin::wire::batch_codec::{
    encode_batch_wire, BatchRecordHeader, BatchWireState,
};
use flint_stress_margin::wire::envelope_codec::{wrap_envelope_wire, EnvelopeHeader, EnvelopeNode};
use flint_stress_margin::wire::magics::{BATCH_VERSION, SESSION_MAGIC, SESSION_VERSION};

pub fn sample_stress_batch_wire() -> Vec<u8> {
    let mut state = BatchWireState::default();
    state.version = BATCH_VERSION;
    state.desk_lane = 2;
    state.flags = 0x0000_0002;
    state.headers.push(BatchRecordHeader {
        record_type: 5,
        flags: 0x0001,
        payload_offset: 0,
        payload_len: 6,
        portfolio_tag: 2001,
    });
    state.payload_blob = vec![10, 20, 30, 40, 50, 60];
    encode_batch_wire(&state)
}

pub fn sample_scenario_envelope_wire() -> Vec<u8> {
    let node = EnvelopeNode {
        header: EnvelopeHeader {
            channel_id: 11,
            depth: 0,
            payload_len: 5,
            child_count: 0,
            flags: 0x0002,
        },
        payload: vec![1, 2, 3, 4, 5],
        children: vec![],
    };
    wrap_envelope_wire(&[node])
}

pub fn sample_portfolio_session_wire() -> Vec<u8> {
    let leg_id: u32 = 3;
    let portfolio_tag: u32 = 77;
    let notional: i64 = 500_000;
    let payload = vec![7, 8, 9, 10];
    let mut out = Vec::new();
    out.extend_from_slice(&SESSION_MAGIC);
    out.extend_from_slice(&SESSION_VERSION.to_le_bytes());
    out.extend_from_slice(&42u32.to_le_bytes());
    out.extend_from_slice(&1u32.to_le_bytes());
    out.extend_from_slice(&0u32.to_le_bytes());
    out.extend_from_slice(&leg_id.to_le_bytes());
    out.extend_from_slice(&portfolio_tag.to_le_bytes());
    out.extend_from_slice(&notional.to_le_bytes());
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&payload);
    out
}

pub fn sample_fix_margin_frame() -> &'static str {
    "8=FIX.4.4\x019=000\x0135=8\x0149=DESK\x0156=CCP\x0134=1\x0152=20260704-12:00:00\x0155=EURUSD\x0154=1\x0132=100\x0131=1.0850\x0110=000\x01"
}

pub fn sample_mt940_collateral() -> &'static str {
    ":20:REF123\r\n:25:ACC456\r\n:60F:C240704EUR1000,00\r\n:61:2407040704D500,00NMSCNONREF\r\n:62F:C240704EUR1500,00\r\n"
}
